# Start Here — Deployment Learning Pack

This folder teaches you every deployment idea used in your two projects:
**microjob** and **petnest**. It goes from the very basics up to the exact
tricks your charts use.

Everything is written in plain English. Where a topic shows up in your real
code, the file path is given so you can open it and match the idea to the line.

## What the two projects actually are

**microjob** — one big Nuxt app.

- `apps/web` — the Nuxt web app (frontend + backend in one).
- `apps/mobile` — Flutter app.
- `apps/web/deploy/helm/microjob` — the Helm chart that deploys it.
- `infra/helm/observability`, `infra/helm/monitoring` — separate charts for
  logging and monitoring.
- Extra pieces: `img-hash` service, background workers, NATS, Postgres (CNPG).

**petnest** — many small services (microservices).

- `services/*` — 12 Go services plus one Python AI service.
- `apps/web`, `apps/admin` — the two frontends.
- `deploy/helm/petnest` — one Helm chart that deploys all of it.
- Extra pieces: NATS, Redis, OpenSearch, Postgres (CNPG), a migrate job,
  seed jobs.

Both run locally with Docker Compose and run in production on **Azure
Kubernetes Service (AKS)**, with images stored in **Azure Container Registry
(ACR)** at `dailyjobsregistry.azurecr.io`.

## Reading order

Read them in number order. Each file assumes you read the ones before it.
From file 04 onward, each has a matching lab in `20-labs/` — read the file,
then run the lab.

| File | Topic |
|---|---|
| `01-big-picture.md` | How code travels from your laptop to the live site |
| `02-docker.md` | Images, Dockerfiles, multi-stage builds, Compose |
| `03-registry-and-tags.md` | Container registry, image tags, promotion |
| `04-kubernetes-core.md` | Cluster, node, pod, deployment, labels, namespace |
| `05-config-and-secrets.md` | ConfigMap, Secret, env injection |
| `06-services-and-networking.md` | Service, ClusterIP, DNS, LoadBalancer |
| `07-ingress-and-tls.md` | Ingress controller, routing, cert-manager, HTTPS |
| `08-storage.md` | Volumes, PVC, StorageClass, StatefulSet |
| `09-health-and-rollouts.md` | Probes, rolling updates, rollback |
| `10-resources-and-scaling.md` | Requests, limits, HPA, node pools, scheduling |
| `11-jobs-and-migrations.md` | Jobs, init containers, Helm hooks, DB migration |
| `12-helm.md` | Charts, values, templates, releases, revisions |
| `13-network-policies.md` | Default-deny, allowlists, egress rules |
| `14-postgres-cnpg-and-pooler.md` | CloudNativePG, replicas, PgBouncer pooler |
| `15-nats-jetstream.md` | Messaging, queues, durable consumers |
| `16-github-actions.md` | CI/CD pipelines, secrets, environments, promotion |
| `17-observability.md` | Logs, metrics, uptime checks, debugging |
| `18-day2-operations.md` | Runbook: deploy, check, fix, roll back |
| `19-practice-path.md` | Hands-on exercises and a command cheat sheet |
| `20-labs/` | **Runnable labs** — real manifests on a throwaway kind cluster |

## One-minute glossary

Read this once. It makes everything else easier.

- **Image** — a frozen copy of your app plus everything it needs to run.
- **Container** — a running copy of an image.
- **Registry** — the place images are stored (yours: ACR).
- **Cluster** — a group of machines that run containers for you.
- **Node** — one machine (a VM) in the cluster.
- **Pod** — the smallest unit Kubernetes runs. Usually one container.
- **Deployment** — "keep N copies of this pod running, and update them safely".
- **Service** — a stable internal address for a group of pods.
- **Ingress** — the door from the internet into the cluster.
- **ConfigMap** — plain settings.
- **Secret** — private settings (passwords, keys).
- **Namespace** — a folder inside the cluster that keeps things separate.
- **Helm** — a templating tool that turns your values into Kubernetes files.
- **Chart** — a Helm package (templates + default values).
- **Release** — one installed copy of a chart in a namespace.
- **Operator** — an add-on that manages a complex thing for you (CNPG manages
  Postgres).
