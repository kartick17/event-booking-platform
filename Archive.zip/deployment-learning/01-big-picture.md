# 01 — The Big Picture

Before any single tool, understand the whole road. Everything else in this pack
is a zoom-in on one step of this road.

## The road, in words

1. You write code on your laptop.
2. You run it locally with **Docker Compose** so it behaves like production.
3. You push code to **GitHub**.
4. **GitHub Actions** builds a **Docker image** for each app or service.
5. Those images are pushed to a **registry** (Azure Container Registry).
6. GitHub Actions runs **Helm**, which turns your chart into Kubernetes files
   and sends them to the **Kubernetes cluster** (Azure AKS).
7. Kubernetes pulls the images and starts **pods**.
8. A **database migration Job** runs first and updates the schema.
9. **Services** give pods stable internal addresses.
10. **Ingress** takes traffic from the internet, terminates HTTPS, and sends
    each hostname to the right service.
11. **Probes** decide when a pod is healthy enough to receive traffic.
12. Old pods are removed only after new ones are healthy — a rolling update.

## The road, as a diagram

```
laptop
  │  git push
  ▼
GitHub  ──►  GitHub Actions
                 │ docker build
                 ▼
          Azure Container Registry (ACR)
                 │  (image:tag)
                 │
                 │ helm upgrade --install
                 ▼
        ┌──────────────────────────────┐
        │  Kubernetes cluster (AKS)    │
        │                              │
        │  Ingress (nginx) ── TLS      │  ◄── internet
        │      │                       │
        │      ▼                       │
        │  Service ──► Pods            │
        │                │             │
        │                ├─► Postgres (CNPG) via PgBouncer pooler
        │                ├─► NATS (messages/queues)
        │                ├─► Redis / OpenSearch (petnest only)
        │                └─► Azure Blob / DO Spaces (files)
        └──────────────────────────────┘
```

## Two environments

Both projects have **staging** and **production**. They are separate
namespaces in the cluster, with separate databases, separate domains and
separate secrets.

| | microjob | petnest |
|---|---|---|
| staging namespace | `microjob-staging` | `petnest-staging` |
| production namespace | `microjob-production` | `petnest-production` |
| staging domain | `staging.microjob.com` | `staging.petnest.com` |
| production domain | `microjob.com` | `petnest.com` |

The same chart deploys both. Only the **values file** differs — for example
`values-microjob-staging.yaml` versus `values-microjob-production.yaml`.

That is the single most important habit in this whole setup:
**one set of templates, many values files.**

## How the two projects differ in shape

**microjob** is a *monolith*. One app image (`microjob-app`), plus a small
`img-hash` helper and a set of **worker** pods that consume queues. Staging
runs one "combined" worker; production splits workers by job type
(task, notifications, queue, email, authEmail).

See `apps/web/deploy/helm/microjob/values.yaml`, block `workers:`.

**petnest** is *microservices*. 12 Go services + 1 Python AI service + 2
frontends. The chart loops over a list in values and generates a Deployment
and Service for each one.

See `deploy/helm/petnest/values.yaml`, block `services:` and the loop in
`deploy/helm/petnest/templates/services.yaml`.

Learning point: the Kubernetes ideas are identical. Only the number of moving
parts changes. petnest simply has more of the same objects.

## What each tool is responsible for

| Tool | Its one job |
|---|---|
| Docker | Package the app into an image |
| Docker Compose | Run several images together on your laptop |
| ACR | Store images |
| Helm | Turn values + templates into Kubernetes YAML |
| Kubernetes | Keep the described state true |
| cert-manager | Get and renew HTTPS certificates |
| nginx ingress | Route hostnames to services, terminate TLS |
| CloudNativePG | Run and heal a Postgres cluster |
| PgBouncer (Pooler) | Share a small number of DB connections |
| NATS | Move messages between services / to workers |
| GitHub Actions | Run the whole pipeline automatically |

## The mental model that makes Kubernetes click

Kubernetes is **not** a script runner. You do not tell it "do these steps".

You tell it **what the world should look like**: "there should be 2 pods
running image `microjob-app:prod-123`, reachable on port 3000, with these env
vars". Kubernetes then keeps comparing reality to that description and fixes
the difference, forever.

This is called a **desired state** system, and the loop that fixes differences
is called a **controller**.

Consequences you will feel every day:

- If you delete a pod by hand, a new one appears. That is not a bug.
- If you change the image tag, Kubernetes replaces pods gradually.
- If a pod keeps crashing, Kubernetes keeps restarting it (CrashLoopBackOff).
- Nothing happens "once". Everything is continuously reconciled.

Helm sits on top: it writes the description. Kubernetes makes it true.
