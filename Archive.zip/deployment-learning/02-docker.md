# 02 — Docker

Docker is step one. If the image is wrong, nothing downstream can save you.

## Image vs container

- An **image** is a read-only snapshot: your code, the runtime (Node, Go,
  Python), system libraries, and a default command.
- A **container** is a running instance of an image.

One image → many containers. This is exactly why Kubernetes can run 5 copies
of your app: it starts 5 containers from one image.

## Layers and cache

A Dockerfile is a list of steps. Each step makes a **layer**. Docker caches
layers. If a step and everything before it is unchanged, Docker reuses the
cached layer instead of redoing the work.

This is why the order of lines matters so much:

```dockerfile
# BAD — any code change invalidates the install step
COPY . .
RUN yarn install

# GOOD — install only re-runs when the lockfile changes
COPY package.json yarn.lock ./
RUN yarn install
COPY . .
```

Your microjob build in CI also uses a **registry cache**, which stores those
layers in ACR so a fresh GitHub runner can reuse them:

```yaml
cache-from: type=registry,ref=.../microjob-app:microjob-production-buildcache
cache-to:   type=registry,ref=.../microjob-app:microjob-production-buildcache,mode=max
```

(from `.github/workflows/web-production.yml`)

Without it, every CI build starts from zero and takes many minutes longer.

## Multi-stage builds

A build needs compilers and dev dependencies. The final running image should
not carry them. Multi-stage builds solve this: build in one stage, copy only
the result into a small final stage.

```dockerfile
FROM node:20 AS build
WORKDIR /app
COPY package.json yarn.lock ./
RUN yarn install --frozen-lockfile
COPY . .
RUN yarn build

FROM node:20-slim AS production
WORKDIR /app
COPY --from=build /app/.output ./.output
CMD ["node", ".output/server/index.mjs"]
```

Your microjob CI picks the stage explicitly:

```yaml
target: production
```

That `target:` is the stage name. The same Dockerfile can therefore serve local
development (`target: development`, with hot reload) and production.

You can see this in `apps/web/docker-compose.yml`:

```yaml
build:
  context: .
  dockerfile: Dockerfile
  target: ${DOCKER_TARGET:-production}
```

Go services (petnest) benefit even more: the build stage needs the whole Go
toolchain (hundreds of MB), the final stage needs only a single static binary
(a few MB).

## Important Dockerfile instructions

| Instruction | Meaning |
|---|---|
| `FROM` | Base image to start from |
| `WORKDIR` | Set the working folder |
| `COPY` / `ADD` | Copy files in (`COPY` is preferred) |
| `RUN` | Run a command at build time, creating a layer |
| `ENV` | Set an environment variable inside the image |
| `ARG` | A build-time-only variable |
| `EXPOSE` | Documentation of the port. Does not publish anything |
| `CMD` | Default command when the container starts |
| `ENTRYPOINT` | Fixed command; `CMD` becomes its arguments |
| `USER` | Run as a non-root user |

`ARG` vs `ENV` matters in CI. microjob passes a build arg:

```yaml
build-args: |
  NUXT_AUTO_APPROVAL_CRON=${{ vars.NUXT_AUTO_APPROVAL_CRON || '0 0 * * *' }}
```

An `ARG` is only available while building. If the app needs it at runtime, it
must come from an env var in Kubernetes instead — which is what most of your
`NUXT_*` settings do.

## .dockerignore

Both projects have one. It stops `node_modules`, `.git`, build output and
local `.env` files from being copied into the build context. This makes builds
faster and stops secrets leaking into images. Treat a missing `.dockerignore`
as a bug.

## Docker Compose — your local cluster

Compose runs several containers together on one network with one command.

microjob: `apps/web/docker-compose.yml` runs nginx, the Nuxt app, a worker,
`img-hash`, Postgres and NATS.

petnest: `infra/docker/docker-compose.local.yml` plus
`docker-compose.deps.yml` (dependencies only) and `docker-compose.test.yml`.

Key Compose ideas, all of which map to Kubernetes ideas later:

```yaml
services:
  app:
    build: { context: ., dockerfile: Dockerfile, target: production }
    environment:
      - NUXT_DATABASE_HOST=postgres     # service name = hostname
      - NUXT_NATS_URL=nats://nats:4222
    depends_on:
      - postgres
      - nats
    networks: [app-network]
    restart: unless-stopped
volumes:
  storage_data:
```

| Compose idea | Kubernetes equivalent |
|---|---|
| service name as hostname (`postgres`) | Service + cluster DNS |
| `environment:` | ConfigMap / Secret via `envFrom` |
| `volumes:` named volume | PersistentVolumeClaim |
| `depends_on` | init containers / readiness probes |
| `restart: unless-stopped` | Deployment controller |
| `ports: "5050:80"` | Ingress or a NodePort/LoadBalancer Service |

Learning that table is a big shortcut: you already understand Kubernetes
partly, because you already use Compose.

## Where Compose and Kubernetes differ

- `depends_on` waits for the container to *start*, not to be *ready*.
  Kubernetes solves this properly with readiness probes and init containers
  (microjob has a `waitForNatsInitContainer`, petnest has a `wait-for-db`
  init container in the migrate job).
- Compose restarts containers; Kubernetes reschedules pods onto other nodes.
- Compose has no rolling update, no autoscaling, no network policy.

## Commands worth memorising

```bash
docker build -t myapp:dev .
docker build --target development -t myapp:dev .
docker run --rm -p 3000:3000 myapp:dev
docker ps
docker logs -f <container>
docker exec -it <container> sh
docker image ls
docker system prune -af          # careful: deletes unused images

docker compose up -d
docker compose logs -f app
docker compose exec app sh
docker compose down -v           # -v also deletes volumes (data!)
```
