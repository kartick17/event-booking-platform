# 03 — Container Registry and Image Tags

A registry is a warehouse for images. Kubernetes never builds anything; it only
pulls images from a registry. So the registry is the hand-off point between
"build" and "run".

Yours is **Azure Container Registry**: `dailyjobsregistry.azurecr.io`.
Both projects share it.

## Image name anatomy

```
dailyjobsregistry.azurecr.io / petnest-gateway : v1.4.0
└──────── registry host ────┘ └── repository ─┘ └ tag ┘
```

- **Registry host** — where it lives.
- **Repository** — one app. Yours include `microjob-app`, `microjob-migrate`,
  `img-hash`, `petnest-gateway`, `petnest-identity`, `petnest-web`,
  `petnest-admin-app`, `petnest-migrate`, `petnest-postgres`, and one per Go
  service.
- **Tag** — which version.

There is also a **digest** — `@sha256:...` — which is the exact content hash.
A tag can be moved to point at different bytes. A digest cannot. That is the
difference that makes `:latest` dangerous.

## How your projects tag images

**microjob** (see `.github/workflows/web-production.yml`):

```bash
TS=$(date +%Y%m%d%H%M%S)
app_tag=microjob-production-$TS
```

and it also pushes a moving pointer:

```
microjob-app:microjob-production-latest
```

So every build gets a unique, timestamped tag *and* refreshes a `-latest`
pointer. The unique tag is what actually gets deployed, so you can always tell
which build is live and can roll back to an exact one.

**petnest** (see `deploy/bin/promote.sh`): staging builds are tagged with the
**git short SHA**. Production uses a plain version tag `vX.Y.Z`.

## Promotion: the most important idea in this file

Never rebuild an image to go from staging to production.

`deploy/bin/promote.sh` does this:

1. Check that all 17 images exist in ACR at `:<short-sha>`.
2. Re-tag those same bytes as `:vX.Y.Z` in the registry — **no rebuild**.
3. Deploy production with `IMAGE_TAG=vX.Y.Z`.

Why this matters: a rebuild can pick up a newer base image, a newer transitive
dependency, or a different build cache. Then the thing you tested in staging is
not the thing you shipped. Re-tagging guarantees production runs the exact
bytes that passed staging.

The script also has a real-world warning baked in:

> the release branch was SQUASH-merged (the tag no longer points at the commit
> staging built). Merge release branches with `--no-ff`.

That is a genuine trap. A squash merge creates a new commit with a new SHA, so
the images built for the old SHA cannot be found.

## Why `:latest` is banned in production

If your Deployment says `image: myapp:latest`:

- You cannot tell which build is running.
- You cannot roll back, because the old bytes have no name any more.
- Two pods started at different times can run different code.

Your charts avoid this. microjob's chart takes `registry.appTag` from values,
and CI passes the timestamped tag. petnest takes `registry.tag` and CI passes
the SHA or version.

`values.yaml` defaults say `latest`, but that is only a placeholder for local
`helm template` runs — CI always overrides it.

## imagePullPolicy

- `Always` — pull on every pod start.
- `IfNotPresent` — use the node's cached copy if present.
- `Never` — only use a local copy.

microjob's app deployment uses `Always`. That is the safe choice when a moving
tag might be involved. With unique immutable tags, `IfNotPresent` is faster and
just as correct.

## Pulling private images: imagePullSecrets

ACR is private. The cluster must authenticate to pull. This is done with a
Secret of type `kubernetes.io/dockerconfigjson`, referenced by pods:

```yaml
spec:
  imagePullSecrets:
    - name: acr-secret
```

On AKS this is often handled instead by attaching the ACR to the cluster's
managed identity, so no secret is needed in the namespace. If you ever see
`ErrImagePull` or `ImagePullBackOff`, the cause is almost always one of:

1. wrong tag (typo, or the build failed and never pushed),
2. missing pull credentials,
3. wrong architecture (see below).

## Platform / architecture

Your CI builds with:

```yaml
platforms: linux/amd64
```

Your AKS nodes are amd64. If you build an image on an Apple Silicon Mac without
specifying the platform, you get an arm64 image, and the pod fails with `exec
format error`. Always set the platform when building for the cluster.

## Useful commands

```bash
az acr login --name dailyjobsregistry

# list repositories and tags
az acr repository list --name dailyjobsregistry -o table
az acr repository show-tags --name dailyjobsregistry --repository petnest-gateway -o table

# check an image exists without pulling it
docker manifest inspect dailyjobsregistry.azurecr.io/petnest-gateway:v1.4.0

# re-tag without rebuilding (what promote.sh does)
docker pull  dailyjobsregistry.azurecr.io/petnest-gateway:abc1234
docker tag   dailyjobsregistry.azurecr.io/petnest-gateway:abc1234 \
             dailyjobsregistry.azurecr.io/petnest-gateway:v1.4.0
docker push  dailyjobsregistry.azurecr.io/petnest-gateway:v1.4.0
```

## Housekeeping

Registries grow forever. Every build adds a tag. Set a retention policy or
periodically delete old timestamped tags — but **never delete a tag that a live
Deployment or a Helm revision you might roll back to still references**.
