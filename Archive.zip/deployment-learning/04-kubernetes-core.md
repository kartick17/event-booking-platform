# 04 — Kubernetes Core Objects

This is the heart of the pack. Everything later builds on these words.

## Cluster, node, node pool

- A **cluster** is the whole system: a control plane plus worker machines.
- A **node** is one virtual machine that runs your pods.
- A **node pool** is a group of identical nodes managed as one unit (an Azure
  concept). You never resize a node; you change the pool and Azure adds or
  removes nodes.

Important consequence: labels and taints belong to the **pool**, not to an
individual node. If a pool is replaced, everything attached to it goes with it.

The **control plane** is the brain: it holds the desired state in `etcd`, runs
the scheduler that picks nodes for pods, and runs the controllers that fix
differences. On AKS, Azure runs and manages it. You only manage the nodes.

## Pod

The smallest thing Kubernetes runs. A pod is one or more containers that:

- share a single IP address,
- share volumes,
- start and die together,
- are always scheduled onto the same node.

Almost all your pods have one main container. Some have extras:

- **init containers** run to completion *before* the main container starts.
  microjob's app pod uses one to wait for NATS and one to fix file permissions
  (`templates/app-deployment.yaml`). petnest's migrate job uses `wait-for-db`.
- **sidecars** run alongside the main container for its whole life.

Pods are **disposable**. They get a new IP each time. Never point anything at a
pod IP — that is what Services are for.

## ReplicaSet

Keeps N identical pods running. You almost never write one by hand; a
Deployment creates and manages ReplicaSets for you.

## Deployment

The object you actually write. It says:

- which pod template to run,
- how many copies,
- how to replace them when the template changes.

From `deploy/helm/petnest/templates/services.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: gateway
  namespace: petnest-staging
  labels: { app: petnest, component: gateway }
spec:
  replicas: 1
  selector:
    matchLabels: { app: petnest, component: gateway }
  template:
    metadata:
      labels: { app: petnest, component: gateway }
    spec:
      containers:
        - name: gateway
          image: dailyjobsregistry.azurecr.io/petnest-gateway:staging-latest
          ports: [{ containerPort: 8080 }]
```

How an update works:

1. You change the image tag.
2. The Deployment creates a **new** ReplicaSet.
3. It scales the new one up and the old one down, following your strategy.
4. The old ReplicaSet is kept (scaled to 0) so you can roll back.

## Labels and selectors — the glue

Labels are key/value tags on objects. Selectors find objects by label. This is
how Kubernetes wires everything together, and there is no other mechanism.

In your petnest chart, the pair `app: petnest, component: <name>` is used by:

- the Deployment, to find its own pods (`spec.selector`),
- the Service, to find which pods to send traffic to,
- NetworkPolicies, to decide who may talk to whom,
- HPA, indirectly through the Deployment.

Change a label carelessly and three unrelated things break at once.

### The immutable selector trap

`spec.selector.matchLabels` on a Deployment **cannot be changed** after
creation. Your microjob chart documents exactly this:

```yaml
# The app Deployment's spec.selector.matchLabels is immutable. The live
# deployment (migrated from microjob-web) selects on `app: dailyjobs`, so we
# keep that exact value to upgrade in place without recreating the pod set.
selectorLabel: dailyjobs
```

(`apps/web/deploy/helm/microjob/values.yaml`)

If you must change a selector, you have to delete and recreate the Deployment,
which means downtime. So decide labels carefully on day one.

## Namespace

A namespace is a folder inside the cluster. It gives you:

- name scoping — a Service called `gateway` in `petnest-staging` does not clash
  with one in `petnest-production`,
- a boundary for NetworkPolicies, quotas and RBAC,
- easy cleanup — delete the namespace, everything inside goes.

Your namespaces: `microjob-staging`, `microjob-production`, `petnest-staging`,
`petnest-production`, plus separate ones for monitoring and observability.

microjob also supports a `testPrefix` value so you can deploy a full parallel
copy into `test-microjob-production` with host `test.staging.microjob.com`,
without touching the live one. That is a very useful pattern: the same chart,
a prefix, and you get a disposable clone.

## Other workload types

| Kind | Use it for | In your projects |
|---|---|---|
| **Deployment** | Stateless apps that can be replaced freely | app, gateway, all Go services, web, admin |
| **StatefulSet** | Pods that need stable names and their own disk | NATS (`nats-0`), OpenSearch |
| **DaemonSet** | One pod on every node | Netdata agents (monitoring chart) |
| **Job** | Run once until success | migrate, seeds |
| **CronJob** | Run on a schedule | scheduled maintenance tasks |

Why NATS is a StatefulSet: JetStream stores data on disk. A StatefulSet gives
each pod a stable name (`nats-0`) and its own PersistentVolumeClaim that
survives restarts. A Deployment would give random pod names and no per-pod
disk.

## Kubernetes objects all share a shape

```yaml
apiVersion: apps/v1       # which API group/version
kind: Deployment          # what type of object
metadata:                 # name, namespace, labels, annotations
  name: gateway
spec:                     # what you want
  ...
status:                   # what actually is (filled in by Kubernetes)
```

You write `spec`. Kubernetes writes `status`. When you debug, you compare them.

## Everyday commands

```bash
kubectl config get-contexts
kubectl config use-context <name>

kubectl get pods -n petnest-staging
kubectl get pods -n petnest-staging -o wide          # shows node + IP
kubectl get deploy,svc,ing -n petnest-staging

kubectl describe pod <pod> -n petnest-staging        # events at the bottom
kubectl logs <pod> -n petnest-staging
kubectl logs <pod> -n petnest-staging --previous     # logs of the crashed one
kubectl logs -f deploy/gateway -n petnest-staging

kubectl exec -it <pod> -n petnest-staging -- sh
kubectl port-forward svc/gateway 8080:8080 -n petnest-staging

kubectl get events -n petnest-staging --sort-by=.lastTimestamp
```

When something is wrong, the order is almost always:
`get pods` → `describe pod` (read the Events) → `logs` (add `--previous` if it
restarted).
