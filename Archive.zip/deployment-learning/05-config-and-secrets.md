# 05 — Config and Secrets

Your app needs settings: database host, feature flags, API keys. Kubernetes has
two objects for this. The difference is smaller than most people think.

## ConfigMap — non-secret settings

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
  namespace: petnest-staging
data:
  OPENSEARCH_URL: http://opensearch-service:9200
  NATS_URL: nats://nats-service:4222
```

Both projects have one called `app-config`
(`templates/app-configmap.yaml` in each chart).

In petnest, extra non-secret env comes straight from values:

```yaml
config:
  OPENSEARCH_URL: http://opensearch-service:9200
```

with a note in the file explaining why it lives there: the in-cluster address
is identical in staging and production, so putting it in the base
`values.yaml` carries it into both environment files through Helm's map merge.
Without it the service falls back to a `localhost:9200` default and every read
returns 500.

## Secret — private settings

Same shape, different kind:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: app-secret
type: Opaque
stringData:              # plain text in; Kubernetes base64-encodes it
  NUXT_JWT_SECRET: "..."
```

**Important and often misunderstood:** a Secret is only base64-encoded, not
encrypted, by default. `base64 -d` reveals it. The real protection comes from:

- RBAC — who is allowed to read Secrets in that namespace,
- encryption at rest on the cluster (AKS supports this),
- not committing them to git.

Use `stringData` when writing YAML (plain text) and `data` when you already
have base64.

## Three ways to get values into a container

**1. Whole object as env — `envFrom`**

```yaml
envFrom:
  - configMapRef: { name: app-config }
  - secretRef:    { name: app-secret }
  - secretRef:    { name: db-secret }
```

Every key becomes an env var. This is what both your charts do for the bulk of
settings. Simple, but you cannot rename keys, and a key clash between two
sources is resolved by order (later wins).

**2. One key at a time — `valueFrom`**

```yaml
- name: REDIS_URL
  valueFrom:
    secretKeyRef: { name: redis-secret, key: REDIS_URL }
```

petnest uses this deliberately for Redis, with a comment explaining why:

> REDIS_URL carries the redis password, so it is secret material: per-pod from
> redis-secret, NOT in the app-config ConfigMap. Only services flagged
> `redis: true` in values.yaml get it.

That is least privilege at the env-var level — a service that does not need
Redis never receives the password.

Note the `optional: true` on the per-service `DATABASE_URL`:

```yaml
- name: DATABASE_URL
  valueFrom:
    secretKeyRef:
      name: db-secret
      key: SVC_{{ upper .name }}_DATABASE_URL
      optional: true
```

Without `optional: true`, a service with no database (like `search`, which only
uses OpenSearch) would fail to start because the key does not exist.

**3. As files — volume mount**

```yaml
volumes:
  - name: pg-ca
    secret:
      secretName: petnest-pg-ca
      items:
        - key: ca.crt          # ONLY this key
volumeMounts:
  - name: pg-ca
    mountPath: /etc/pg-ca
```

petnest mounts the Postgres CA certificate this way
(`templates/_helpers.tpl`). The `items:` selector is a security control, and
the file says so plainly:

> The `<release>-pg-ca` secret ALSO holds `ca.key` (the CA private key); a
> whole-secret mount would hand every app pod the power to mint certs the
> cluster trusts. Never drop the `items:` selector.

Learn that lesson generally: **mount the keys you need, not the whole Secret.**

## Where your secrets actually come from

There are three distinct sources in your setup, and mixing them up causes most
deploy confusion.

**a) Human-supplied secrets file**

`deploy/.secrets/<target>.secrets` — a plain `KEY=value` file, git-ignored,
read by `deploy.sh` and turned into the `app-secret` object. There is an
`example.secrets` in both repos showing the required keys.

**b) GitHub Actions secrets and variables**

In CI there is no local file, so the workflow writes one:

```yaml
- name: Generate secrets file
  run: |
    mkdir -p deploy/.secrets
    cat > deploy/.secrets/${TARGET}.secrets <<EOF
    NUXT_JWT_SECRET=${{ secrets.NUXT_JWT_SECRET }}
    NUXT_PUBLIC_APP_URL=${{ vars.NUXT_PUBLIC_APP_URL }}
    ...
    EOF
```

(`.github/workflows/web-production.yml`)

Note the two namespaces:
- `${{ secrets.X }}` — hidden, masked in logs.
- `${{ vars.X }}` — visible configuration, not sensitive.

Public values like `NUXT_PUBLIC_APP_URL` are `vars`. Keys are `secrets`. Keep
that discipline; it makes logs readable without leaking anything.

**c) Chart-generated secrets**

This is the clever part of the petnest chart, in
`templates/cnpg-secrets.yaml`. Database passwords and the NATS token are not
supplied by a human at all. The chart generates them once and then reuses them
on every upgrade:

```
{{- $dbSecret := lookup "v1" "Secret" $ns "db-secret" }}
{{- if and $dbSecret $dbSecret.data (hasKey $dbSecret.data "NATS_TOKEN") }}
{{-   $natsToken = index $dbSecret.data "NATS_TOKEN" | b64dec }}
{{- else }}
{{-   $natsToken = randAlphaNum 32 }}
{{- end }}
```

Read that in plain English:

1. Look at the live cluster for an existing `db-secret`.
2. If it already has `NATS_TOKEN`, decode and reuse it.
3. If not (first install), generate a random 32-character one.

Without the `lookup` guard, `randAlphaNum` would mint a **new** password on
every `helm upgrade`, and every pod would suddenly fail to connect. This
pattern — "generate once, then look up" — is the standard way to keep
generated secrets stable in Helm.

Two consequences worth writing on a sticky note:

- `helm template` (offline, no cluster) always takes the *generate* branch, so
  the rendered passwords there are throwaway. Only a real cluster gives stable
  values.
- To **rotate** a generated secret, delete the Secret in the namespace and
  redeploy. The comment in the file says exactly this.

The file also explains why all of these must live in **one template**: on a
first install `lookup` is empty, so a second file running its own
`lookup + randAlphaNum` would mint a *different* app password and break every
pooler DSN. One file, one `$appPass`.

## Making pods restart when config changes

A ConfigMap or Secret change does **not** automatically restart pods. Env vars
are read once at container start.

The standard fix is a checksum annotation on the pod template. petnest's NATS
StatefulSet does exactly this:

```yaml
annotations:
  checksum/nats-token: {{ include (print $.Template.BasePath "/cnpg-secrets.yaml") . | sha256sum }}
```

When the rendered secret changes, the annotation changes, the pod template
changes, and Kubernetes rolls the pod. The comment explains the failure it
prevents:

> The server reads NATS_TOKEN once, at container start ... while every client
> re-reads it on each deploy. Without this the pod would survive a token change
> and the two sides would desync — every service losing NATS at once.

Manual equivalent:

```bash
kubectl rollout restart deployment/gateway -n petnest-staging
```

## Rules of thumb

- Never commit real secrets. `deploy/.secrets/` is git-ignored for a reason.
- Public runtime config → ConfigMap or GitHub `vars`.
- Anything that grants access → Secret or GitHub `secrets`.
- Prefer `secretKeyRef` for high-value items so only the pods that need them
  receive them.
- Rotating a secret means: change it, then make sure every consumer restarts.

## Commands

```bash
kubectl get configmap app-config -n petnest-staging -o yaml
kubectl get secret db-secret -n petnest-staging -o jsonpath='{.data.NATS_TOKEN}' | base64 -d
kubectl describe secret app-secret -n petnest-staging     # shows keys, not values
kubectl create secret generic test --from-literal=A=b --dry-run=client -o yaml
```
