# 06 — Services, DNS and Load Balancing

Pods come and go and get new IPs. A **Service** is the stable name and address
in front of them.

## What a Service does

```yaml
apiVersion: v1
kind: Service
metadata:
  name: gateway
  namespace: petnest-staging
spec:
  selector: { app: petnest, component: gateway }
  ports: [{ port: 8080, targetPort: 8080 }]
```

Three things happen:

1. A DNS name `gateway` is created inside the namespace.
2. A virtual IP (ClusterIP) is assigned.
3. Kubernetes tracks which pods match the selector and load-balances across
   them.

The list of matching pod IPs is kept in an object called **Endpoints** (or
`EndpointSlice`). This is your best debugging tool: if a Service has **no
endpoints**, the selector does not match any ready pod, and requests fail even
though the pods look fine in `get pods`.

```bash
kubectl get endpoints gateway -n petnest-staging
```

`port` vs `targetPort`: `port` is what callers use, `targetPort` is the port
inside the container. They are often the same, but they do not have to be.

## Cluster DNS

Inside the cluster, a Service is reachable at:

```
<service>                              # same namespace
<service>.<namespace>                  # cross-namespace
<service>.<namespace>.svc.cluster.local
```

Which is why petnest's config can simply say:

```yaml
OPENSEARCH_URL: http://opensearch-service:9200
GATEWAY_BASE_URL: http://gateway:8080
AI_SERVICE_URL:  http://ai:8000
```

and microjob's says `nats://nats:4222`.

This is the same idea as Docker Compose using the service name as a hostname.

## Service types

| Type | What it gives you | Where you use it |
|---|---|---|
| **ClusterIP** (default) | Internal-only virtual IP | Every app service in both projects |
| **NodePort** | Opens a high port on every node | Rarely; mostly for bare-metal or debugging |
| **LoadBalancer** | Asks the cloud for a real external IP | The ingress controller only |
| **ExternalName** | DNS alias to an outside host | Not used here |
| **Headless** (`clusterIP: None`) | No virtual IP; DNS returns pod IPs directly | StatefulSets that need per-pod addressing |

### Why almost everything is ClusterIP

A cloud LoadBalancer costs money and gives you one IP per Service. With 14
petnest services that would be absurd. Instead:

- every app Service is **ClusterIP**,
- **one** LoadBalancer exists, in front of the nginx **ingress controller**,
- the ingress routes by hostname and path to the right ClusterIP Service.

One external IP, many apps. That is the standard pattern and it is what both
your projects do.

## LoadBalancer, concretely

When you create a Service of type `LoadBalancer` on AKS, Azure provisions an
Azure Load Balancer and assigns a public IP. Your DNS records
(`microjob.com`, `api.staging.petnest.com`, …) all point at that one IP.

You do not manage this Service — it belongs to the ingress-nginx installation.
To see it:

```bash
kubectl get svc -n ingress-nginx
```

The `EXTERNAL-IP` column is the address your DNS must point to.

## Limiting what a Service exposes

petnest's NATS Service is a good example of deliberate narrowing:

```yaml
ports:
  # Only the client port is reachable via the Service. The 8222 monitoring
  # HTTP port stays a bare containerPort — kubelet probes hit it directly on
  # the pod IP; nothing else should reach NATS monitoring.
  - { port: 4222, targetPort: 4222, protocol: TCP, name: client }
```

The container listens on 8222 too, but because the Service does not publish it,
no other pod can reach it by name. Health probes still work because the kubelet
connects straight to the pod IP.

Lesson: a `containerPort` is documentation. What actually makes a port
reachable is a Service (plus any NetworkPolicy that allows it).

## Session affinity

By default a Service load-balances every connection independently. If you need
a client to keep hitting the same pod:

```yaml
spec:
  sessionAffinity: ClientIP
```

Better answer: make your app stateless so you never need this. Both your
projects keep session state in the database / Redis rather than in pod memory,
which is why they can scale horizontally at all.

## How traffic actually flows, end to end

```
browser
  └─► DNS: api.staging.petnest.com → Azure Load Balancer public IP
        └─► Service (LoadBalancer) in ingress-nginx namespace
              └─► ingress-nginx controller pod
                    │ reads Ingress rules, terminates TLS
                    └─► Service "gateway" (ClusterIP) in petnest-staging
                          └─► one of the gateway pods :8080
                                └─► Service "pets" :8081 (internal call)
                                      └─► Service "petnest-pg-pooler-rw" :5432
```

Every arrow after the load balancer is a plain ClusterIP Service lookup.

## Debugging network problems

```bash
# does the Service exist and have endpoints?
kubectl get svc,endpoints -n petnest-staging

# talk to a Service from inside the cluster
kubectl run tmp --rm -it --image=curlimages/curl -n petnest-staging -- sh
  curl -v http://gateway:8080/health
  nslookup gateway

# bring a Service to your laptop
kubectl port-forward svc/gateway 8080:8080 -n petnest-staging
```

If DNS resolves but the connection times out, suspect a **NetworkPolicy**
(file 13). If DNS does not resolve, suspect a wrong Service name or namespace.
If it resolves but refuses instantly, the pod is not listening on that port.
