# 07 — Ingress, HTTPS and Certificates

Ingress is the front door. It takes requests from the internet and decides
which internal Service should handle them.

## Two separate things with confusingly similar names

1. **The Ingress object** — a rule sheet you write: "host X, path Y → service
   Z". On its own it does nothing.
2. **The ingress controller** — a real program (yours is **ingress-nginx**)
   running in the cluster that reads all Ingress objects and configures itself
   accordingly. It is the thing that actually receives traffic.

The controller sits behind one `LoadBalancer` Service with one public IP.
All your domains point at that IP.

## Your petnest Ingress, explained line by line

From `deploy/helm/petnest/templates/ingress.yaml`:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: petnest
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: 250m
    nginx.ingress.kubernetes.io/proxy-read-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "3600"
spec:
  ingressClassName: nginx
  tls:
    - hosts: [staging.petnest.com]
      secretName: petnest-staging-web-tls
    - hosts: [admin.staging.petnest.com]
      secretName: petnest-staging-admin-tls
    - hosts: [api.staging.petnest.com]
      secretName: petnest-staging-api-tls
  rules:
    - host: staging.petnest.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service: { name: web, port: { number: 4000 } }
    - host: admin.staging.petnest.com
      ...  backend: admin-app:4001
    - host: api.staging.petnest.com
      ...  backend: gateway:8080
```

- **`ingressClassName: nginx`** — which controller should pick this up. A
  cluster can run more than one.
- **`rules`** — three hostnames, three different backend Services. This is
  called name-based virtual hosting.
- **`pathType: Prefix`** with `path: /` — everything under that host.
- **`tls`** — for each host, the name of a Secret holding the certificate. You
  do not create these Secrets; cert-manager does (see below).

### The annotations are not decoration

Annotations are how you configure nginx behaviour per-Ingress.

- `force-ssl-redirect: "true"` — http requests are 308-redirected to https.
- `proxy-body-size: 250m` — nginx defaults to 1 MB. Without raising it, every
  large upload fails with **413 Request Entity Too Large**. Both projects set
  250m because they accept media uploads.
- `proxy-read-timeout` / `proxy-send-timeout: 3600` — nginx defaults to 60
  seconds. The chart comment says why:

  > Long-lived WebSocket connections (messaging). nginx proxies upgrades
  > natively, but its default 60s read timeout would sever an idle socket.

microjob's Ingress adds one more:

```yaml
nginx.ingress.kubernetes.io/websocket-services: "app-service"
```

because its Nuxt app serves a websocket on port 4983 alongside http on 3000.

## cert-manager and automatic HTTPS

`cert-manager` is an operator that gets TLS certificates from Let's Encrypt and
renews them before expiry.

Flow:

1. You annotate the Ingress with
   `cert-manager.io/cluster-issuer: letsencrypt-prod`.
2. cert-manager sees the `tls:` block and, for each host, creates a
   `Certificate` object.
3. It requests a certificate from Let's Encrypt and proves you own the domain,
   usually with an **HTTP-01 challenge**: it creates a temporary Ingress rule
   at `/.well-known/acme-challenge/...` that Let's Encrypt fetches over the
   internet.
4. On success it writes the cert and key into the Secret you named
   (`petnest-staging-web-tls`).
5. nginx picks up the Secret and serves HTTPS.
6. About 30 days before expiry, cert-manager renews automatically.

A **ClusterIssuer** is the cluster-wide account/config with Let's Encrypt.
There are normally two: `letsencrypt-staging` (fake certs, generous rate
limits — use while testing) and `letsencrypt-prod` (real certs, strict rate
limits).

**Rate limits matter.** Let's Encrypt allows roughly 5 duplicate certificates
per exact set of names per week. If you repeatedly delete and recreate a
production Ingress you can lock yourself out for days. Test with the staging
issuer first.

### Debugging a certificate that will not appear

```bash
kubectl get certificate -n petnest-staging
kubectl describe certificate petnest-staging-web-tls -n petnest-staging
kubectl get certificaterequest,order,challenge -n petnest-staging
kubectl describe challenge <name> -n petnest-staging
kubectl logs -n cert-manager deploy/cert-manager
```

The usual causes, in order of likelihood:

1. DNS for the host does not point at the ingress load balancer IP yet.
2. The `force-ssl-redirect` annotation breaks the HTTP-01 challenge on some
   setups (ingress-nginx normally handles this correctly; if not, use
   `ssl-redirect` instead of forcing it).
3. A NetworkPolicy or firewall blocks inbound port 80.
4. You hit a Let's Encrypt rate limit — the `Order` will say so.

## microjob's maintenance mode — a neat Ingress trick

`values.yaml` has:

```yaml
maintenance:
  enabled: false
  appHost: ""        # where the real app moves to during maintenance
  basicAuth: ""      # htpasswd line for that host
```

with the comment:

> `enabled` is the only field the toggle workflow flips (it re-renders ONLY
> templates/ingress.yaml). The nginx maintenance pod, its service, config, and
> the basic-auth secret are always deployed and sit idle while enabled=false.

When you flip it to `true`:

- the public host serves a static maintenance page from a tiny nginx pod,
- the real app moves to `appHost`, protected by HTTP basic auth
  (`nginx.ingress.kubernetes.io/auth-type: basic`),
- so your team can still use and verify the app while users see the page.

Nothing is rebuilt or rescheduled. Only routing changes. That is the cheapest
possible maintenance switch, and it is a pattern worth copying.

Generate the basic-auth line with:

```bash
htpasswd -nbB maint '<your-password>'
```

## Useful annotations you will eventually need

| Annotation | Effect |
|---|---|
| `proxy-body-size` | Max upload size |
| `proxy-read-timeout` / `proxy-send-timeout` | Long requests / websockets |
| `ssl-redirect` / `force-ssl-redirect` | http → https |
| `rewrite-target` | Strip or rewrite the path before proxying |
| `configuration-snippet` | Raw nginx config (use sparingly) |
| `limit-rps`, `limit-connections` | Rate limiting |
| `auth-type`, `auth-secret` | HTTP basic auth |
| `enable-cors`, `cors-allow-origin` | CORS headers at the edge |
| `whitelist-source-range` | Allow only certain client IPs |

## Commands

```bash
kubectl get ingress -A
kubectl describe ingress petnest -n petnest-staging
kubectl get svc -n ingress-nginx                    # the public IP
kubectl logs -n ingress-nginx deploy/ingress-nginx-controller -f

# check TLS from outside
curl -I https://staging.petnest.com
openssl s_client -connect staging.petnest.com:443 -servername staging.petnest.com </dev/null 2>/dev/null | openssl x509 -noout -dates -issuer
```
