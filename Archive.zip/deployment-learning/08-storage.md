# 08 — Storage: Volumes, PVCs and StatefulSets

Containers have a writable layer, but it dies with the container. Anything you
want to survive a restart needs a **volume**.

## Volume types you actually use

### emptyDir — scratch space

Created empty when the pod starts, deleted when the pod dies. Shared between
containers in the same pod.

microjob's app pod uses one:

```yaml
volumes:
  - name: storage
    emptyDir:
      sizeLimit: 5Gi
```

Good for caches, temp files and inter-container hand-offs. **Never** for data
you need after a restart. The `sizeLimit` matters: without it, a runaway
process can fill the node's disk and get every pod on that node evicted.

### PersistentVolumeClaim (PVC) — real disk

Three objects work together:

- **StorageClass** — a *kind* of disk the cloud can create
  (`managed-premium`, `azurefile-csi`, `default`).
- **PersistentVolumeClaim** — your request: "10Gi of `managed-premium`,
  read-write once".
- **PersistentVolume** — the actual disk that gets created and bound to the
  claim.

You write the PVC. The StorageClass provisions the PV automatically. This is
called **dynamic provisioning**.

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: microjob-logs
spec:
  accessModes: [ReadWriteMany]
  storageClassName: azurefile-csi
  resources:
    requests:
      storage: 10Gi
```

### Access modes — the detail that bites people

| Mode | Meaning |
|---|---|
| `ReadWriteOnce` (RWO) | Mountable read-write by **one node** |
| `ReadOnlyMany` (ROX) | Read-only by many nodes |
| `ReadWriteMany` (RWX) | Read-write by **many nodes** at once |

Azure Disk (`managed-premium`, `managed-csi`) is **RWO only**. Azure Files
(`azurefile-csi`) supports **RWX**.

This is why microjob's chart says:

```yaml
logs:
  enabled: false
  storageClass: ""        # Must support ReadWriteMany (e.g. azurefile-csi)
  size: 10Gi
  mountPath: /app/logs
  retentionDays: 30
```

The app pod **and every worker pod** mount the same logs volume, and those pods
land on different nodes. Only RWX can do that. If you pointed it at an Azure
Disk class, the second pod would sit in `ContainerCreating` forever with a
multi-attach error.

The same requirement is repeated for the `usageSampler` volume.

RWX (Azure Files / SMB) is slower and has different file-locking behaviour than
a real disk. Use it when you genuinely need shared access, not by default.

### Why the logs PVC exists at all

Pod logs (`kubectl logs`) disappear when a pod is deleted. microjob writes
server-side log files named `${HOSTNAME}-YYYY-MM-DD.log` to the shared volume
and prunes files older than `retentionDays`. That gives durable logs
independent of pod lifetime, alongside the OpenObserve pipeline (file 17).

## StatefulSet and volumeClaimTemplates

A Deployment gives pods random names and shares nothing. A **StatefulSet**
gives:

- stable, ordered names: `nats-0`, `nats-1`, …
- a **separate PVC per pod**, created automatically from a template,
- ordered start-up and shutdown,
- a stable DNS name per pod when paired with a headless Service.

petnest's NATS (`templates/nats.yaml`):

```yaml
kind: StatefulSet
metadata: { name: nats }
spec:
  serviceName: nats-service
  replicas: 1
  ...
  volumeClaimTemplates:
    - metadata: { name: data }
      spec:
        accessModes: [ReadWriteOnce]
        resources: { requests: { storage: 2Gi } }
```

The container runs with `-js -sd /data`, meaning JetStream stores its file
store at `/data`, which is the mounted PVC.

microjob's chart carries a hard-won comment about exactly this:

```yaml
nats:
  persistence:
    # Without it every nats pod restart wipes all streams, consumers and
    # pending jobs (prod outage 2026-07-12).
    enabled: true
    size: 2Gi
```

That is the whole lesson in one line: **a message broker without persistent
storage loses every queued job on restart.**

### A StatefulSet's PVCs are not deleted with it

Delete a StatefulSet and the PVCs remain, on purpose, so you do not lose data
by accident. To truly remove them you must delete the PVCs yourself:

```bash
kubectl delete pvc data-nats-0 -n petnest-staging
```

Be certain before you do. There is no undo.

## Resizing a volume

Most cloud StorageClasses allow expansion (`allowVolumeExpansion: true`).
Edit the PVC's requested size and the disk grows. You **cannot shrink** it.
Some volume types need the pod to restart before the filesystem is resized.

```bash
kubectl patch pvc data-nats-0 -n petnest-staging \
  -p '{"spec":{"resources":{"requests":{"storage":"5Gi"}}}}'
```

## Postgres storage

CNPG manages its own PVCs. You just declare the size and class:

petnest:
```yaml
cnpg:
  storage: { size: 10Gi, storageClass: managed-premium }
```

microjob:
```yaml
cnpg:
  storage:
    size: 20Gi
    storageClass: ""      # empty = cluster default
```

Each Postgres instance gets its own disk. That is the point of a replicated
cluster: the data exists more than once, on more than one disk, on more than
one node.

## Rules of thumb

- Stateless app → `emptyDir` only, or no volume at all.
- Needs to survive restarts → PVC.
- One writer → RWO (fast, cheap).
- Many writers across nodes → RWX (`azurefile-csi`).
- Per-pod identity + per-pod disk → StatefulSet.
- Always set `sizeLimit` on `emptyDir`.
- Always confirm the StorageClass supports the access mode you asked for.

## Commands

```bash
kubectl get storageclass
kubectl get pvc -n petnest-staging
kubectl get pv
kubectl describe pvc data-nats-0 -n petnest-staging
kubectl exec -it nats-0 -n petnest-staging -- df -h /data
```
