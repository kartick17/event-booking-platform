# 09 — Health Checks and Rollouts

This file explains how a new version reaches users without downtime, and how
Kubernetes decides whether a pod is alive.

## The three probes

Kubernetes asks your container three different questions.

| Probe | Question | On failure |
|---|---|---|
| **startupProbe** | "Have you finished booting?" | Keep waiting; kill only after the limit |
| **readinessProbe** | "Can you serve traffic right now?" | Remove pod from Service endpoints |
| **livenessProbe** | "Are you still alive, or stuck?" | Restart the container |

The most important distinction: **readiness removes traffic, liveness
restarts the pod.** Confusing them causes restart storms.

### microjob's app pod

From `templates/app-deployment.yaml`:

```yaml
startupProbe:
  httpGet: { path: /_health, port: 3000 }
  initialDelaySeconds: 10
  periodSeconds: 10
  failureThreshold: 30          # up to 300s to boot
livenessProbe:
  httpGet: { path: /_health, port: 3000 }
  periodSeconds: 15
  timeoutSeconds: 10
  failureThreshold: 5
readinessProbe:
  httpGet: { path: /_health, port: 3000 }
  periodSeconds: 10
  failureThreshold: 3
```

The startup probe buys a Nuxt app up to 300 seconds to come up. While it is
running, the liveness probe is **suspended** — that is exactly what
startupProbes are for. Without one, you would have to set a huge
`initialDelaySeconds` on liveness and lose fast failure detection forever
after.

### petnest's services

```yaml
readinessProbe:
  httpGet: { path: /health/ready, port: 8081 }
  initialDelaySeconds: 3
  periodSeconds: 5
livenessProbe:
  httpGet: { path: /health, port: 8081 }
  initialDelaySeconds: 10
  periodSeconds: 15
  failureThreshold: 3
```

Note the **two different paths**, and the defaults block in `values.yaml`:

```yaml
defaults:
  probe: { healthPath: /health, readyPath: /health/ready }
```

with per-service overrides where the Go service uses a different route
(`/healthz` for taxonomy, search, communications, ai).

This split is good design:

- `/health` (liveness) should be trivial — "the process is running". It must
  **not** check the database. If it did, a brief database blip would restart
  every pod at once and turn a small problem into an outage.
- `/health/ready` (readiness) *may* check dependencies, because failing it only
  removes the pod from load balancing temporarily.

### Probe types

```yaml
httpGet:   { path: /health, port: 8080 }
tcpSocket: { port: 5432 }
exec:      { command: ["sh","-c","pg_isready"] }
grpc:      { port: 9000 }
```

### Probe timing fields

| Field | Meaning |
|---|---|
| `initialDelaySeconds` | Wait this long before the first check |
| `periodSeconds` | How often to check |
| `timeoutSeconds` | How long one check may take |
| `failureThreshold` | Consecutive failures before acting |
| `successThreshold` | Consecutive successes to be considered healthy again |

Rough rule: worst-case detection time is
`periodSeconds × failureThreshold` plus one `timeoutSeconds`.

## Rolling updates

When the pod template changes, the Deployment replaces pods gradually.

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1          # may run 1 extra pod above the desired count
    maxUnavailable: 0    # never drop below the desired count
```

That is microjob's app deployment. `maxUnavailable: 0` means: start a new pod,
wait for it to pass readiness, only then remove an old one. Zero downtime, at
the cost of briefly needing capacity for one extra pod.

### The surgeless case — a real trap petnest hit

Some petnest services bind a **durable NATS JetStream consumer**. Only one
subscriber may hold a durable name at a time. If a new pod starts before the
old one lets go, it crashes.

The chart handles it by flipping the strategy for those services only:

```yaml
{{- if .natsConsumer }}
# Durable JetStream consumer: old pod must release the subscription before the
# new pod starts, else the new pod crashloops ("consumer is already bound").
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 0
    maxUnavailable: 1
{{- end }}
```

`maxSurge: 0, maxUnavailable: 1` means: **stop the old pod first, then start
the new one.** That accepts a short gap in exchange for correctness. With
`replicas: 1` this means a brief unavailability, which is fine for a background
consumer and fatal for a public API — which is why `values.yaml` warns:

> Never set it on gateway.

This is a perfect example of a general rule: **the right rollout strategy
depends on what the workload holds, not on preference.**

## Graceful shutdown

When a pod is removed:

1. It is taken out of Service endpoints.
2. `SIGTERM` is sent to the container.
3. Kubernetes waits `terminationGracePeriodSeconds` (default 30).
4. If still running, `SIGKILL`.

Your app should catch `SIGTERM`, stop accepting new work, finish in-flight
requests, close database and NATS connections, and exit. If it ignores
`SIGTERM`, every deploy drops requests.

A `preStop` hook that sleeps a few seconds is a common trick to let load
balancers notice the endpoint removal before the process stops.

## PodDisruptionBudget

Rolling updates are voluntary and respect your strategy. **Node drains** —
during Azure node upgrades or autoscaling — are different. A PDB protects you
there:

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata: { name: gateway }
spec:
  minAvailable: 1
  selector:
    matchLabels: { app: petnest, component: gateway }
```

Neither chart defines PDBs today. With `replicas: 1` a PDB cannot help anyway —
this is one more reason to run at least 2 replicas for anything user-facing.

## Watching and controlling a rollout

```bash
kubectl rollout status deployment/gateway -n petnest-staging
kubectl rollout history deployment/gateway -n petnest-staging
kubectl rollout undo deployment/gateway -n petnest-staging
kubectl rollout undo deployment/gateway --to-revision=3 -n petnest-staging
kubectl rollout restart deployment/gateway -n petnest-staging
kubectl rollout pause deployment/gateway -n petnest-staging
kubectl rollout resume deployment/gateway -n petnest-staging
```

Note both your CI workflows pass `--no-wait` to the deploy script and then
check pods separately. That keeps the CI job from hanging for the full Helm
timeout when a rollout is slow — but it also means **a green CI run is not
proof the rollout finished**. Always check the pods afterwards.

## Pod states and what they mean

| State | Meaning | First thing to check |
|---|---|---|
| `Pending` | Not scheduled yet | `describe pod` — usually insufficient CPU/memory, or an unbound PVC |
| `ContainerCreating` | Pulling image / mounting volumes | Image name, pull secret, PVC access mode |
| `Running` but `0/1 READY` | Readiness probe failing | App logs, probe path and port |
| `CrashLoopBackOff` | Starts then exits repeatedly | `logs --previous` |
| `ImagePullBackOff` | Cannot fetch the image | Tag exists? credentials? architecture? |
| `OOMKilled` | Exceeded the memory limit | Raise the limit or fix the leak |
| `Evicted` | Node ran out of resources | Requests too low, or node pressure |
| `Terminating` (stuck) | Finalizer or long grace period | `describe`, check `preStop` and `SIGTERM` handling |
