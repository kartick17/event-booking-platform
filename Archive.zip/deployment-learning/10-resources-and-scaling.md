# 10 — Resources, Scheduling and Autoscaling

This is where most real production pain lives. It is worth reading twice.

## Requests vs limits — the single most important idea

- A **request** is what a pod *reserves*. The scheduler uses only this number
  to decide which node a pod fits on.
- A **limit** is the most the pod may *use*.

The scheduler never looks at real usage. So a node can be almost idle and still
be "full", because its reservations are all handed out.

A real measurement from your own cluster notes:

```
cpu requests      6899m (88%)   ← what the scheduler sees
cpu actual usage   491m  (6%)   ← what is really happening
```

That node is doing almost nothing and still cannot accept a pod that requests
much CPU. Requests that are far above real usage are called **phantom
reservations**, and they waste money on every node.

### CPU and memory behave differently under pressure

| | Over the limit | Node under pressure |
|---|---|---|
| **CPU** | Throttled (slowed down) | Slowed down |
| **Memory** | **OOMKilled** (container killed instantly) | Pods evicted |

CPU is compressible, memory is not. That asymmetry drives every rule below.

### Units

- CPU: `1` = one core. `500m` = 0.5 core. `25m` = 0.025 core.
- Memory: `Mi` = mebibyte, `Gi` = gibibyte. Use `Mi`/`Gi`, not `M`/`G`.

## Quality of Service classes

Kubernetes assigns each pod a QoS class, which decides who gets evicted first
when a node runs short of memory:

| Class | Condition | Eviction order |
|---|---|---|
| **Guaranteed** | requests == limits, for every container | Last |
| **Burstable** | requests set, limits higher (or absent) | Middle |
| **BestEffort** | no requests and no limits | **First** |

This is why petnest's pooler has a very pointed comment:

```yaml
# Pooler resources must be set. With none, pgbouncer runs as BestEffort QoS and
# is the first pod the kubelet evicts under node memory pressure — and every
# query to the database passes through it. Measured: ~1-9m CPU, ~20-47Mi.
resources:
  requests: { cpu: 25m, memory: 64Mi }
  limits:   { cpu: 500m, memory: 256Mi }
```

Rule: **anything on the critical path must never be BestEffort.**

## How to choose numbers: measure, do not guess

microjob ships a tool for this — the `usageSampler`
(`templates/usage-sampler.yaml`), off by default:

```yaml
usageSampler:
  enabled: false
  image: alpine/k8s:1.33.9      # needs kubectl AND a shell
  intervalSeconds: 60
  maxLines: 3456000             # ~60 days x 1440 samples x ~40 pods
```

It records real CPU and memory for every pod in the namespace every minute, so
requests can be set from **measured peaks** instead of one lucky
`kubectl top` reading. Read the report with:

```bash
kubectl -n <ns> exec deploy/<release>-usage-sampler -- /scripts/report.sh
```

petnest's NATS resources show the payoff:

```yaml
# Sized from measured peak, not from a snapshot: 4m CPU / 16Mi in production
# and 4m / 17Mi in staging, over 35350 samples. The old 50m / 128Mi request was
# mostly phantom reservation.
resources:
  requests: { cpu: 20m, memory: 64Mi }
  limits:   { cpu: 500m, memory: 512Mi }
```

A practical starting recipe:

1. Set generous requests and limits at first.
2. Measure for a week under real traffic.
3. Set **request ≈ p95 of real usage**.
4. Set **memory limit ≈ peak × 1.5**, and **do not** set it equal to a request
   you are unsure about.
5. Be generous with CPU limits (throttling is invisible and awful to debug);
   be careful with memory limits (they kill).

## Horizontal Pod Autoscaler (HPA)

The HPA changes the replica count of a Deployment based on a metric.

petnest (`templates/hpa.yaml`):

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: gateway }
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: gateway }
  minReplicas: 1
  maxReplicas: {{ .Values.hpa.maxReplicas }}
  metrics:
    - type: Resource
      resource:
        name: cpu
        target: { type: Utilization, averageUtilization: 70 }
```

microjob has per-workload HPA blocks in values, all disabled by default:

```yaml
app:
  hpa: { enabled: false, minReplicas: 2, maxReplicas: 5, cpuTargetPercent: 70 }
```

Three things you must know:

1. **`averageUtilization` is a percentage of the CPU *request*, not of a
   core.** With `requests.cpu: 250m` and a 70% target, the HPA scales up when
   average use passes 175m. If your request is wrong, your autoscaling is
   wrong.
2. **The HPA needs metrics-server** installed in the cluster. Without it the
   HPA shows `<unknown>` and does nothing.
3. **The HPA fights a fixed `replicas:` value.** Once an HPA manages a
   Deployment, do not let Helm keep setting `replicas` — every deploy would
   reset the count. Note how petnest sets `minReplicas` from the same values
   entry that would otherwise set replicas, keeping the two consistent.

CPU is a poor scaling signal for queue workers — they may be busy but not
CPU-bound. For those, scale on queue depth with KEDA rather than on CPU. Your
microjob workers currently have CPU-based HPA blocks; if they ever behave
oddly, that is the reason.

## Cluster autoscaler

The HPA adds pods. If no node has room, those pods sit `Pending`. The **cluster
autoscaler** then adds a node to the pool. These are two different systems and
both must be enabled for scaling to actually work end to end.

## Where pods land: scheduling controls

The scheduler filters nodes (does it fit? are taints tolerated?) then scores
them (spread, affinity) and picks the best.

**nodeSelector** — simple "only on nodes with this label".

**Taints and tolerations** — a taint on a node repels pods; a matching
toleration on a pod lets it through. Used to reserve a node pool, e.g. a
database pool.

**Affinity / anti-affinity** — attract or repel relative to other pods.

petnest's Postgres cluster uses both anti-affinity and topology spread, and the
comment explains the reasoning better than most docs:

```yaml
affinity:
  enablePodAntiAffinity: true
  podAntiAffinityType: preferred
  topologyKey: kubernetes.io/hostname

topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      matchLabels:
        cnpg.io/cluster: petnest-pg
        cnpg.io/podRole: instance
```

> Both stay soft on purpose. Several Postgres clusters share this AKS cluster,
> so a strict rule would leave pods Pending whenever nodes are tight.

Key vocabulary:

- **preferred / `ScheduleAnyway`** = a hint. The pod still schedules if the
  rule cannot be met.
- **required / `DoNotSchedule`** = hard. The pod stays `Pending` instead.
- **`topologyKey: kubernetes.io/hostname`** = spread across nodes.
  Use `topology.kubernetes.io/zone` to spread across availability zones.
- **`maxSkew: 1`** = at most one pod of difference between nodes.

Also note the precise label selector, and why:

> Pooler pods also carry `cnpg.io/cluster`, so selecting on that key alone
> would count poolers as instances and push the spread the wrong way.

That is a subtle, real bug class: a selector that accidentally matches more
than you meant.

## Namespace-level guardrails

- **ResourceQuota** — caps total CPU/memory/object count in a namespace.
- **LimitRange** — supplies default requests/limits to pods that omit them, so
  nothing lands as BestEffort by accident.

Neither chart uses these yet. A LimitRange is a cheap safety net worth adding.

## Commands

```bash
kubectl top nodes
kubectl top pods -n petnest-staging

# what is actually reserved on a node, and by whom
kubectl describe node <node> | sed -n '/Allocated resources/,$p'

kubectl get hpa -n petnest-staging
kubectl describe hpa gateway -n petnest-staging

# why is this pod Pending?
kubectl describe pod <pod> -n petnest-staging | tail -30
```
