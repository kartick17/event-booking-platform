# 11 — Jobs, Init Containers and Database Migrations

A Deployment runs forever. Some work must run **once**, finish, and stop. That
is a **Job**.

## Job basics

```yaml
apiVersion: batch/v1
kind: Job
metadata: { name: migrate-7 }
spec:
  backoffLimit: 3          # retry up to 3 times before giving up
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: migrate
          image: .../petnest-migrate:v1.4.0
```

- `restartPolicy` must be `Never` or `OnFailure` (not `Always`).
- `backoffLimit` — how many failed pods before the Job is marked Failed.
- `completions` / `parallelism` — for batch work; both default to 1.
- `activeDeadlineSeconds` — hard timeout.
- `ttlSecondsAfterFinished` — auto-delete the Job object after it completes.
  Without this, finished Jobs pile up in the namespace.

A **CronJob** is a Job on a schedule (`schedule: "0 3 * * *"`), with
`concurrencyPolicy` deciding what happens if the previous run is still going.

## Init containers

Containers that run to completion, in order, **before** the main containers
start. If one fails, the pod restarts and tries again.

petnest's migrate Job waits for the database to accept connections:

```yaml
initContainers:
  - name: wait-for-db
    image: .../petnest-postgres:16
    command:
      - sh
      - -c
      - |
        until pg_isready -h petnest-pg-rw -p 5432 -U "$DB_USER"; do
          echo "waiting for petnest-pg-rw:5432 ..."
          sleep 2
        done
```

microjob's app pod has two: one that waits for NATS
(`microjob.waitForNatsInitContainer`) and one that fixes file ownership:

```yaml
- name: fix-permissions
  image: busybox:latest
  command:
    - sh
    - -c
    - chown -R 1001:1001 /app/storage && chmod -R 755 /app/storage
```

That second one is a very common pattern: the app runs as a non-root user
(UID 1001), but a freshly created volume is owned by root. An init container
running as root fixes ownership before the app starts.

(The modern alternative is `securityContext.fsGroup`, which asks the kubelet to
chown the volume for you. Both work; the init container is more explicit and
works on volume types that ignore `fsGroup`.)

## Helm hooks — running Jobs at the right moment

A plain Job in a chart is installed alongside everything else. **Hooks** let
you say *when* it runs relative to the rest of the release.

petnest's migrate Job:

```yaml
annotations:
  "helm.sh/hook": post-install,post-upgrade
  "helm.sh/hook-weight": "-5"
  "helm.sh/hook-delete-policy": before-hook-creation
```

Read it as:

- **`post-install,post-upgrade`** — run after Helm applies the release, on both
  first install and every upgrade.
- **`hook-weight: "-5"`** — ordering. Lower runs first. So migrate (-5) runs
  before the admin seed (0) and the wiki content seed (1).
- **`hook-delete-policy: before-hook-creation`** — delete the previous hook Job
  object just before creating the new one. Without this, the second deploy
  fails because a Job with that name already exists.

The Job name also includes `{{ .Release.Revision }}`:

```yaml
name: migrate-{{ .Release.Revision }}
```

so each deploy creates `migrate-1`, `migrate-2`, … — Job specs are largely
immutable, so a fresh name per revision avoids "field is immutable" errors.

### The hook ordering in petnest, in full

| Weight | Hook | What it does |
|---|---|---|
| -5 | `migrate` | Creates remaining per-service databases, runs schema migrations, creates the least-privilege `petnest_admin_app` role |
| 0 | `admin-seed` | Seeds admin accounts + RBAC from `apps/admin/config/seed-users.json` baked into the image |
| 1 | `content-seed` | Seeds wiki taxonomy/species/breeds and pages, with `--create-only` |
| — | `search-index-bootstrap` | `post-upgrade` hook that PUTs OpenSearch index mappings |

Each is idempotent, which is the property that makes this safe:

> Idempotent: a second run finds each account, prints "Admin already exists"
> and exits 0.

and for the content seed:

> It runs with `--create-only`: taxonomy, species, breeds and attribute
> definitions still converge on every deploy, but a wiki page that already
> exists is skipped, so an admin's edit is never reverted.

**Write every migration and seed to be safe to run twice.** Hooks run on every
deploy.

Note also that `search-index-bootstrap` is a separate Job on purpose:

> OpenSearch index mappings are created by a separate post-upgrade hook Job,
> never on service startup.

Doing setup work on service startup means N replicas racing each other. Doing
it in a single Job means it happens exactly once per deploy.

## microjob's migration path

microjob builds a dedicated `microjob-migrate` image in CI and runs it as a Job
(`templates/migrate-job.yaml`). The production workflow has a cleanup step
before deploying:

```yaml
- name: Cleanup stale migration jobs
  run: |
    kubectl delete jobs -n "${TARGET}" -l app=migrate --ignore-not-found=true
    sleep 5
```

That prevents a failed previous migration Job from blocking the new one.

## Migration safety — the rules that prevent outages

During a rolling update, **old and new code run at the same time**. So a
migration must be compatible with both.

Use the **expand / contract** pattern:

1. **Expand** — add the new column as nullable, or add the new table. Deploy.
   Old code ignores it; new code can use it.
2. **Migrate data** — backfill in batches, ideally in a background job, not
   inside the deploy migration.
3. **Contract** — only after all old pods are gone, in a *later* release, add
   the NOT NULL constraint or drop the old column.

Never in one step: rename a column, drop a column still read by running pods,
or add a NOT NULL column without a default.

Other practical rules:

- Avoid long `ALTER TABLE` on big tables during deploy — it takes locks and
  blocks queries. Use `CREATE INDEX CONCURRENTLY` where your tool supports it.
- Set a `lock_timeout` and `statement_timeout` in the migration session so a
  blocked migration fails fast instead of freezing the site.
- Migrations should be forward-only. Rolling back code is easy; rolling back a
  schema is usually not. Design so the previous code version still works
  against the new schema.

## A detail worth understanding: sslmode in the migrate Job

```yaml
- { name: DB_SSLMODE, value: prefer }
```

with the comment:

> Stays `prefer` on purpose. This job builds its own DSNs and runs them through
> psql + atlas — real libpq/pgx clients, where `prefer` means "encrypt if you
> can, do not verify". So it needs no CA mount. The node-postgres
> `prefer == verify-full` quirk that forced verify-ca / verify-full into
> db-secret does not apply to anything here.

Two lessons:

1. `sslmode` values mean different things in different client libraries.
   `node-postgres` treats `prefer` far more strictly than libpq does.
2. Because this Job verifies nothing, it needs no CA file mounted — while the
   Go services do (`sslmode=verify-ca&sslrootcert=/etc/pg-ca/ca.crt`).

Also note the Job connects to `petnest-pg-rw` **directly**, not through the
PgBouncer pooler. Migrations use session-level features (advisory locks,
`CREATE INDEX CONCURRENTLY`, temp tables) that a transaction-pooled PgBouncer
breaks. The NetworkPolicy reflects this — migrate is allowed to reach the
cluster but is deliberately left out of the pooler allowlist.

## Commands

```bash
kubectl get jobs -n petnest-staging
kubectl logs job/migrate-7 -n petnest-staging
kubectl describe job migrate-7 -n petnest-staging

# rerun a hook Job by hand
kubectl delete job migrate-7 -n petnest-staging

# one-off shell against the database
kubectl run psql --rm -it --image=postgres:16 -n petnest-staging -- \
  psql "postgres://user:pass@petnest-pg-rw:5432/petnest_identity"
```
