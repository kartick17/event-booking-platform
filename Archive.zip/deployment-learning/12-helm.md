# 12 — Helm

Helm turns one set of templates plus a values file into finished Kubernetes
YAML, and remembers what it installed so it can upgrade and roll back.

Without Helm you would keep four near-identical copies of every manifest — one
per project per environment — and they would drift apart within a month.

## Chart anatomy

```
deploy/helm/petnest/
├── Chart.yaml                       # name, version, description
├── values.yaml                      # defaults
├── values-petnest-staging.yaml      # staging overrides
├── values-petnest-production.yaml   # production overrides
├── .helmignore
└── templates/
    ├── _helpers.tpl                 # reusable snippets (not rendered directly)
    ├── services.yaml
    ├── ingress.yaml
    ├── cnpg-cluster.yaml
    ├── cnpg-pooler.yaml
    ├── cnpg-secrets.yaml
    ├── nats.yaml
    ├── network-policies.yaml
    ├── egress-policies.yaml
    ├── migrate-job.yaml
    └── ...
```

microjob's chart at `apps/web/deploy/helm/microjob/` has the same shape.

`Chart.yaml`:

```yaml
apiVersion: v2
name: petnest
description: PetNest platform Helm chart (gateway + 9 Go services, web/admin, data layer)
type: application
version: 1.0.0        # version of the CHART
appVersion: "1.0.0"   # version of the APP it installs
```

Files starting with `_` are partials — helpers only, never rendered as objects.

## Values and layering

Helm merges values in this order, later winning:

1. `values.yaml` in the chart
2. `-f my-values.yaml` files, in the order given
3. `--set key=value` on the command line

Merging is **deep for maps** and **replacing for lists**. That trips everyone
up once: if `values.yaml` lists 14 services and your production file lists 2,
production gets 2, not 16.

This is why petnest's base file puts shared config in the `config:` **map**:

> The in-cluster address is identical in staging and production, and Helm's map
> merge carries it into both environment values files.

## Template language basics

Helm uses Go templates plus the Sprig function library.

```
{{ .Values.namespace }}          # from values
{{ .Release.Name }}              # the release name
{{ .Release.Namespace }}
{{ .Release.Revision }}          # 1, 2, 3 ... increments each upgrade
{{ .Chart.Name }} {{ .Chart.Version }}
{{ .Capabilities.KubeVersion }}
```

Whitespace control: `{{-` trims preceding whitespace, `-}}` trims following.
Getting this wrong produces invalid YAML, so always render before deploying.

### Conditionals

```
{{- if .Values.cnpg.enabled }}
...
{{- end }}

{{- with .Values.cnpg.resources }}
resources:
  {{- toYaml . | nindent 4 }}
{{- end }}
```

`with` sets the scope to that value; inside it, `.` means the value. Handy, but
remember you then need `$` to reach the root context.

### Loops — the core of petnest's chart

```
{{- range .Values.services }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .name }}
  namespace: {{ $.Values.namespace }}
...
{{- end }}
```

Inside `range`, `.` is the current list item, so the root context must be
reached with `$`. That is why you see `$.Values` and `$.Release` everywhere in
that file. Forgetting the `$` is the single most common Helm bug.

This one loop generates 28 objects (14 Deployments + 14 Services) from a
14-line list in values. That is the whole payoff of Helm.

### Useful functions

```
{{ .Values.tag | quote }}                 # wrap in quotes
{{ .Values.x | default "fallback" }}
{{ upper .name }} / {{ lower .name }}
{{ toYaml .Values.resources | nindent 12 }}
{{ printf "%s-pg" .Release.Name }}
{{ randAlphaNum 32 }}
{{ include "petnest.labels" . | nindent 4 }}
{{ lookup "v1" "Secret" $ns "db-secret" }}
{{ include (print $.Template.BasePath "/cnpg-secrets.yaml") . | sha256sum }}
```

`toYaml | nindent N` is the standard way to paste a whole values block into a
template at the right indentation. `nindent` adds a newline first; `indent`
does not.

### Helpers (`_helpers.tpl`)

```
{{- define "petnest.labels" -}}
app: petnest
environment: {{ .Values.environment }}
managed-by: helm
{{- end }}
```

used as `{{- include "petnest.labels" . | nindent 4 }}`.

Prefer `include` over `template`: only `include` returns a string you can pipe
into `nindent` or `sha256sum`.

petnest's helpers also encode a real invariant:

> The DSNs in templates/cnpg-secrets.yaml point `sslrootcert` at
> `petnest.pgCaFile`, so the path here and the path there must stay identical —
> that is the only reason these are helpers.

That is the right reason to make a helper: **two places that must never drift
apart.**

### Merging defaults per item

```
{{- $probe := mergeOverwrite (deepCopy $.Values.defaults.probe) (.probe | default dict) }}
{{- $res := .resources | default $.Values.defaults.resources }}
```

Plain English: start from the shared defaults, copy them so the original is not
mutated, then overlay whatever this service specified. `deepCopy` is essential —
without it, `mergeOverwrite` would modify the shared defaults for every later
item in the loop.

## Releases and revisions

A **release** is one installed instance of a chart in a namespace. Helm stores
its state in a Secret in that namespace, one per revision.

```bash
helm list -n petnest-staging
helm history petnest -n petnest-staging
helm get values petnest -n petnest-staging          # values actually used
helm get manifest petnest -n petnest-staging        # YAML actually applied
helm rollback petnest 4 -n petnest-staging
```

`helm get manifest` is your source of truth when reality does not match what
you think you deployed.

## The commands that matter

```bash
# render locally, apply nothing — do this before every real deploy
helm template petnest ./deploy/helm/petnest \
  -f ./deploy/helm/petnest/values-petnest-staging.yaml

# check syntax and schema
helm lint ./deploy/helm/petnest

# ask the cluster to validate without persisting
helm upgrade --install petnest ./deploy/helm/petnest \
  -f values-petnest-staging.yaml --dry-run --debug

# the real thing
helm upgrade --install petnest ./deploy/helm/petnest \
  -n petnest-staging --create-namespace \
  -f values-petnest-staging.yaml \
  --set registry.tag=abc1234 \
  --wait --timeout 10m

# undo
helm rollback petnest -n petnest-staging
```

`--install` makes `upgrade` create the release if it does not exist yet, so one
command works for both first deploy and every later one. Both your deploy
scripts use this form.

### `--atomic` and `--wait`

- `--wait` waits for pods to become ready before reporting success.
- `--atomic` implies `--wait` and **rolls back automatically on failure**.

Your CI passes `--no-wait` for speed and checks pods separately. That is a
deliberate trade-off: faster pipelines, but you must verify manually.

## `helm template` vs a real cluster — the lookup caveat

`lookup` returns an empty map when there is no API server. So:

- `helm template` always takes the "generate a new random password" branch,
- generated values are stable **only** against a real cluster.

The comment in `cnpg-secrets.yaml` states this explicitly. Never diff a
`helm template` output's secrets against production and conclude something
changed.

## Your deploy scripts

Both projects wrap Helm in a script:

- microjob: `apps/web/deploy/bin/deploy.sh`
- petnest: `deploy/bin/deploy.sh`, plus `promote.sh`, `smoke-test.sh`,
  `sample-peak-usage.sh`

petnest's script interface:

```
./deploy.sh <COMMAND> <TARGET> [OPTIONS]

COMMANDS: --deploy --apply --history --rollback --logs --pods --status
TARGETS:  --stag (petnest-staging)  --prod (petnest-production)
OPTIONS:  --yes --skip-build --skip-push --no-wait --revision <N> --follow --tail <N>
ENV:      IMAGE_TAG   (tag applied to all petnest images)
```

The script's real value is that it does the same steps in the same order every
time: build → push → render → `helm upgrade --install` → check. CI calls the
same script with `--skip-build --skip-push`, so **CI and a human deploy follow
identical logic**. That is a genuinely good design decision — copy it into any
future project.

## Chart dependencies

`Chart.yaml` can declare dependencies (subcharts) pulled with
`helm dependency update`. Neither of your app charts uses this — CNPG,
ingress-nginx and cert-manager are installed separately as cluster-wide
components, and your charts only create the custom resources they consume.
That separation is correct: cluster infrastructure has a different lifecycle
from your application.
