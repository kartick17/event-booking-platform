# 14 — PostgreSQL with CloudNativePG and the PgBouncer Pooler

Running a database in Kubernetes is the hardest part of this whole stack. Both
your projects use **CloudNativePG (CNPG)**, an operator that does the hard
parts for you.

## What an operator is

An operator is a controller plus **Custom Resource Definitions (CRDs)**. It
teaches Kubernetes a new noun. After installing CNPG, the cluster understands:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
```

and the CNPG controller then creates the pods, PVCs, Services, Secrets and
certificates needed to make that description true — and keeps them true, doing
failover, backups and rolling upgrades on its own.

Important: the operator is installed **once per cluster**, separately from your
charts. Your charts only create the `Cluster` and `Pooler` resources.

## The Cluster resource

From `deploy/helm/petnest/templates/cnpg-cluster.yaml`:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata: { name: petnest-pg }
spec:
  instances: 2
  imageName: dailyjobsregistry.azurecr.io/petnest-postgres:16
  primaryUpdateStrategy: unsupervised
  enableSuperuserAccess: true
  postgresql:
    parameters:
      max_connections: "200"
      shared_buffers: "256MB"
      effective_cache_size: "768MB"
      work_mem: "4MB"
      max_wal_size: "2GB"
      random_page_cost: "1.1"
      effective_io_concurrency: "200"
      ...
  storage: { size: 10Gi, storageClass: managed-premium }
  superuserSecret: { name: petnest-pg-superuser }
  bootstrap:
    initdb:
      database: petnest_identity
      owner: petnest
      secret: { name: petnest-pg-app }
  managed:
    roles:
      - name: petnest
        ensure: present
        login: true
        createdb: true
        createrole: true
        passwordSecret: { name: petnest-pg-app }
```

Key ideas:

- **`instances: 2`** — one **primary** (read-write) and one **replica**
  (read-only hot standby) kept in sync by streaming replication. If the primary
  dies, CNPG promotes the replica automatically.
- **`primaryUpdateStrategy: unsupervised`** — during an update CNPG may
  switch over the primary without asking. `supervised` would wait for you.
- **`bootstrap.initdb`** — only creates the *first* database. As the comment
  says, the migrate Job creates the rest.
- **`managed.roles`** — the operator ensures the `petnest` role exists with
  `CREATEDB` and `CREATEROLE`, which is precisely what the migrate Job needs to
  create the remaining per-service databases and the least-privilege
  `petnest_admin_app` login role.

microjob pins the image and explains why:

```yaml
# Pin the Postgres operand image so operator upgrades don't silently roll the
# cluster. Bumping this is a deliberate, reviewable chart change.
imageName: ghcr.io/cloudnative-pg/postgresql:18.0-system-trixie
```

Without a pin, upgrading the operator can change the Postgres image and restart
your database at a moment you did not choose.

## The Services CNPG creates for you

For a cluster named `petnest-pg` you get:

| Service | Points to | Use it for |
|---|---|---|
| `petnest-pg-rw` | the current primary | writes, migrations |
| `petnest-pg-ro` | replicas only | read-only queries |
| `petnest-pg-r` | any instance | any read |

These names follow the primary automatically. **Never hardcode a pod name.**
On failover, `-rw` starts pointing at the new primary within seconds and your
app reconnects.

## TLS and the CA

CNPG runs its own certificate authority and gives Postgres a server
certificate. Clients that verify TLS need the CA file on disk. That is the
`petnest-pg-ca` Secret, mounted by every pod that opens a connection via the
`petnest.pgCaVolume` helper, with DSNs like:

```
...?sslmode=verify-ca&sslrootcert=/etc/pg-ca/ca.crt
```

Two details from the chart worth repeating:

- Only `ca.crt` is mounted, never `ca.key` — otherwise every app pod could mint
  certificates the cluster trusts.
- The mount is **not** marked optional, on purpose:

  > a pod that starts without the CA would fail every query for its whole life,
  > while a pod waiting on the mount is retried by the kubelet and starts on
  > its own once CNPG writes the secret.

That is a nice general pattern: prefer "wait for the dependency" over "start
broken".

## The connection problem, and the pooler

Postgres uses **one operating-system process per connection**. Each costs
memory. `max_connections: 200` is not a suggestion — go past it and new
connections are refused outright.

Now count. petnest has 14 services. If each pod opened 10 connections and you
scaled to 3 replicas each, that is 420 connections. The database falls over,
and it falls over exactly when traffic is highest.

**PgBouncer** solves this. It sits in front of Postgres and multiplexes: many
client connections in, a small pool of real database connections out.

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Pooler
metadata: { name: petnest-pg-pooler-rw }
spec:
  cluster: { name: petnest-pg }
  instances: 1
  type: rw
  pgbouncer:
    poolMode: transaction
    parameters:
      max_client_conn: "200"
      default_pool_size: "10"
```

Read those numbers: up to **200 client connections** are accepted, but only
**10 real Postgres connections** per database/user pair are used behind them.

### Pool modes — you must understand these

| Mode | A server connection is held for | Safe to use |
|---|---|---|
| `session` | the whole client connection | always, but least efficient |
| `transaction` | one transaction | most apps — **what you use** |
| `statement` | one statement | rarely; no multi-statement transactions |

In `transaction` mode, these break because they rely on session state:

- prepared statements that persist across transactions,
- `LISTEN` / `NOTIFY`,
- session-level advisory locks,
- `SET` outside a transaction,
- temporary tables,
- `CREATE INDEX CONCURRENTLY` and most migrations.

That is exactly why the migrate Job connects to `petnest-pg-rw` directly and
skips the pooler — and why the `pooler-ingress` policy does not list it.

If you use `node-postgres`, `pgx` or an ORM, turn **off** prepared-statement
caching when going through a transaction-mode pooler, or you will see
intermittent "prepared statement does not exist" errors under load.

### Read/write split

microjob goes one step further:

```yaml
pooler:
  enabled: true
  instances: 2
  readReplica:
    enabled: false
    instances: 2
```

> When enabled, the app gets a second connection (`dbRead`) pointing at this
> pool, which load-balances across the cluster's hot-standby replicas.

and matching per-pod pool sizes:

```yaml
app:
  dbPool: { write: 10, read: 15 }
workers:
  dbPool: { write: 5, read: 5 }
```

> Workers are mostly serial queue consumers, so smaller pools than the web tier
> suffice.

The caution with read replicas is **replication lag**: a row written to the
primary may not be on the replica for a few milliseconds. "Write, then
immediately read your own change" must go to the primary. Everything else
(listings, search, dashboards) can safely use the replica pool.

### Sizing the numbers

A workable formula:

```
pod replicas × per-pod pool size   ≤ pooler max_client_conn
pooler default_pool_size × databases × users ≤ Postgres max_connections − headroom
```

Keep headroom (10–20 connections) for the superuser, CNPG's own instance
manager, and your emergency `psql` session. Being unable to connect to
diagnose an outage because the pool is exhausted is a special kind of bad day.

### Never let the pooler be BestEffort

Already covered in file 10, but it belongs here too:

> With none, pgbouncer runs as BestEffort QoS and is the first pod the kubelet
> evicts under node memory pressure — and every database query goes through it.
> Measured: ~1-9m CPU, ~20-47Mi.

Two more thoughts on availability: with `instances: 1`, the pooler is a single
point of failure for all database traffic, and a pooler restart drops every
in-flight connection. microjob runs 2. For production petnest, 2 is worth
considering.

## Backups

CNPG supports continuous backup to object storage with point-in-time recovery:

```yaml
backup:
  barmanObjectStore:
    destinationPath: "s3://bucket/path"
    s3Credentials: { ... }
  retentionPolicy: "30d"
```

Neither chart currently defines a `backup:` block, so backups are handled
outside the chart (or at the disk-snapshot level). This is worth confirming
explicitly — **a replica is not a backup**. A replica faithfully copies your
`DELETE FROM users` within milliseconds. Only a backup with point-in-time
recovery protects against mistakes and corruption.

Whatever the mechanism, the only real test is a restore drill: restore into a
scratch namespace and check the data.

## Operating CNPG

```bash
kubectl get clusters.postgresql.cnpg.io -n petnest-staging
kubectl describe cluster petnest-pg -n petnest-staging
kubectl get pods -n petnest-staging -l cnpg.io/cluster=petnest-pg

# with the cnpg kubectl plugin
kubectl cnpg status petnest-pg -n petnest-staging
kubectl cnpg promote petnest-pg petnest-pg-2 -n petnest-staging

# a psql session (superuser password from the secret)
kubectl exec -it petnest-pg-1 -n petnest-staging -- psql -U postgres

# who is connected, and to what
SELECT datname, usename, state, count(*)
FROM pg_stat_activity GROUP BY 1,2,3 ORDER BY 4 DESC;

# replication health, on the primary
SELECT client_addr, state, sent_lsn, replay_lsn FROM pg_stat_replication;

# pgbouncer's own stats
kubectl exec -it <pooler-pod> -n petnest-staging -- psql -p 5432 pgbouncer -c 'SHOW POOLS;'
```
