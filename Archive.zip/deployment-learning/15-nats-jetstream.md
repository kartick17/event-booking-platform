# 15 — NATS and JetStream

NATS is a message broker. Both projects use it to decouple work: a web request
publishes a message and returns immediately; a worker or another service picks
it up later.

## Why a broker at all

Without one, a slow job runs inside the HTTP request. Send an email, resize an
image, charge a card — the user waits, and a failure means a 500.

With a broker:

1. The API validates the request and publishes a message.
2. It responds to the user right away.
3. A worker consumes the message and does the slow work.
4. If the worker crashes, the message is redelivered.

The trade-off is that the work becomes **eventually consistent** — it will
happen, but not inside the request. Your UI has to reflect that ("email
queued", not "email sent").

## Core NATS vs JetStream

**Core NATS** is fire-and-forget. If nobody is listening, the message is gone.
Fast, zero storage, no guarantees.

**JetStream** adds persistence: messages are stored in **streams**, and
**consumers** track their position. A subscriber that was down still gets its
messages when it returns.

Both projects run JetStream, and both learned why the hard way.

## How it runs in your clusters

petnest, `templates/nats.yaml`:

```yaml
kind: StatefulSet
metadata: { name: nats }
spec:
  serviceName: nats-service
  replicas: 1
  template:
    spec:
      containers:
        - name: nats
          image: nats:2.10-alpine
          args: ["-js", "-sd", "/data", "-m", "8222", "--auth", "$(NATS_TOKEN)"]
          ports:
            - { containerPort: 4222, name: client }
            - { containerPort: 8222, name: monitoring }
          volumeMounts:
            - { name: data, mountPath: /data }
```

Flags in plain English:

- `-js` — enable JetStream.
- `-sd /data` — store JetStream data at `/data`, which is the PVC.
- `-m 8222` — HTTP monitoring port.
- `--auth $(NATS_TOKEN)` — require a token to connect on 4222.

## Persistence is not optional

microjob's `values.yaml` carries the incident in a comment:

```yaml
nats:
  persistence:
    # Without it every nats pod restart wipes all streams, consumers and
    # pending jobs (prod outage 2026-07-12).
    enabled: true
    size: 2Gi
```

> Streams are capped at 100MB each in app code, so 2Gi covers all queues.

Two lessons:

1. JetStream without a PVC keeps everything in memory. One restart — a node
   upgrade, an eviction, an OOM — and every queued job is gone.
2. Size the volume from the stream limits your code sets, not from guesswork.

Streams need explicit limits (`MaxBytes`, `MaxAge`, `MaxMsgs`) with a
`discard` policy. Without them a stream grows until the disk is full, and a
full JetStream disk stops accepting *all* publishes, not just the noisy stream.

## Token authentication

`--auth <token>` means only clients presenting that token may connect on 4222.
The token lives in `db-secret` as `NATS_TOKEN` and is chart-generated
(file 05).

The subtle part is the restart problem, solved with a checksum annotation:

```yaml
annotations:
  checksum/nats-token: {{ include (print $.Template.BasePath "/cnpg-secrets.yaml") . | sha256sum }}
```

> The server reads NATS_TOKEN once, at container start ... and never revisits
> it, while every client re-reads it on each deploy. Without this the pod would
> survive a token change and the two sides would desync — every service losing
> NATS at once.

And because the token is `lookup`-guarded, an ordinary upgrade leaves the value
untouched and does **not** roll the NATS pod. Only an actual token change does.

The monitoring port 8222 is deliberately not gated by `--auth` (so kubelet
probes work) and deliberately not published by the Service or allowed by the
NetworkPolicy (so nothing else can reach it). Defence in the right layer.

## Durable consumers and the rollout trap

A **durable consumer** is a named subscription whose position NATS remembers.
Only one subscriber may hold a durable name at a time.

That collides with rolling updates. petnest's fix, in `values.yaml`:

```yaml
# natsConsumer: true -> the service binds a durable NATS JetStream consumer, so
# it deploys surgeless (maxSurge 0 / maxUnavailable 1): the old pod must release
# the durable subscription before the new pod starts, or the new pod crashloops
# with "consumer is already bound to a subscription". Never set it on gateway.
```

Which services carry the flag: `pets`, `social`, `commerce`, `discovery`,
`wiki`, `communications`, `media`, `taxonomy`, `search`, `messaging`.
Not `gateway` (public API, must never go down) and not `ai`.

If you ever want a consumer that can scale to several pods, use a **queue
group** / work-queue consumer instead of a single durable subscription. Then
NATS distributes messages across the group and rolling updates are safe.

## Subjects and queue design

Messages are published to **subjects** — dot-separated names, with `*` matching
one token and `>` matching the rest:

```
pets.created
pets.updated
pets.*            → pets.created, pets.updated
pets.>            → everything under pets.
```

microjob names its queues in values, which doubles as documentation of what the
system actually does:

```yaml
workers:
  combined:
    tasks:  "boostDailyCharge,settlement,schedulerHealthCheck,scheduledTaskDispatcher,staleBlockedJobsRelease,submissionAutoApproval"
    queues: "notifications,imgFingerprinting,autoVerification,scheduledTasks,submissionAutoApproval"
```

Staging runs one combined worker; production splits them into `task`,
`notifications`, `queue`, `email` and `authEmail` deployments. That split is
worth understanding as a pattern:

- **Isolation** — a flood of image fingerprinting cannot starve OTP emails.
- **Independent scaling** — each worker gets its own replicas and HPA.
- **Independent failure** — one crashlooping worker does not stop the others.

Separating `authEmail` (OTP / identity mail) from generic `email` is a
deliberate priority decision: a user waiting to log in must not queue behind a
marketing batch.

## Delivery semantics you must design for

JetStream gives **at-least-once** delivery. A message can arrive twice — after
a redelivery, a timeout, or a worker that crashed after doing the work but
before acknowledging.

So **every consumer must be idempotent**. Practical approaches:

- Give each message a stable id and record processed ids.
- Make the operation naturally idempotent (`UPDATE ... SET status='paid'`
  rather than `balance = balance - 10`).
- Use a unique constraint in the database as the final guard.

Other consumer settings that matter:

- **ack wait** — how long NATS waits for an acknowledgement before redelivering.
  Set it longer than your slowest job, or slow jobs get processed repeatedly.
- **max deliver** — how many attempts before giving up.
- **dead letter** — where poison messages go. Without one, a message that
  always fails is retried forever and blocks progress.

## Debugging

```bash
kubectl logs nats-0 -n petnest-staging
kubectl port-forward nats-0 8222:8222 -n petnest-staging
# then: http://localhost:8222/varz  /connz  /jsz

# with the nats CLI, pointed through a port-forward on 4222
nats --server nats://localhost:4222 --creds/--token ... stream ls
nats stream info <stream>
nats consumer report <stream>
nats stream view <stream>
```

Symptom guide:

| Symptom | Likely cause |
|---|---|
| `consumer is already bound to a subscription` | Two pods with the same durable name — check `natsConsumer` / rollout strategy |
| All services lose NATS at once after a deploy | Token changed but the server pod did not roll — checksum annotation missing |
| Queue depth grows forever | Consumer crashed, or ack wait too short causing redelivery loops |
| Everything queued disappeared after a restart | JetStream persistence disabled |
| Publishes suddenly rejected | Stream hit `MaxBytes`, or the PVC is full |
