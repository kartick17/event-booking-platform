# 16 — GitHub Actions: CI/CD

This is the glue that runs everything in files 02–14 automatically.

## Vocabulary

- **Workflow** — one YAML file in `.github/workflows/`.
- **Event / trigger** — what starts it (`push`, `release`, `workflow_dispatch`).
- **Job** — a group of steps on one runner machine. Jobs run in parallel unless
  linked with `needs:`.
- **Step** — one command or one action.
- **Action** — a reusable step (`actions/checkout@v4`).
- **Runner** — the VM the job runs on (`ubuntu-latest`).
- **Environment** — a named target (`production`) that can require approval and
  holds its own secrets.

## Your workflows

**microjob** (`.github/workflows/`):

| File | Purpose |
|---|---|
| `web-staging.yml` | Build + deploy web to staging |
| `web-production.yml` | Build + deploy web to production on release |
| `mobile-staging.yml`, `mobile-production.yml` | Flutter app builds |
| `auto-tag.yml`, `draft-release.yml` | Version tagging and release notes |
| `deploy-observability.yml`, `deploy-monitoring.yml` | The infra charts |
| `hotfix-sync.yml` | Keep branches in step after a hotfix |
| `maintenance.yml` | Toggle maintenance mode |
| `pr-labeler.yml`, `sync-labels.yml` | Repo housekeeping |

**petnest**:

| File | Purpose |
|---|---|
| `ci.yml` | Tests and checks on every PR |
| `release-to-staging.yml` | Build all images at `:<short-sha>`, deploy staging |
| `promote-to-production.yml` | Re-tag those images to `:vX.Y.Z`, deploy production |
| `rollback.yml` | Roll back a release |
| `mobile-release.yml` | Mobile build |

## Reading microjob's production workflow

`.github/workflows/web-production.yml` — it is a good, complete example.

### Trigger and shared config

```yaml
on:
  release:
    types: [published]

env:
  ACR_LOGIN_SERVER: dailyjobsregistry.azurecr.io
  TARGET: microjob-production
  TARGET_FLAG: --mj-prod
  TEST_PREFIX: ""
```

Deploys are triggered by **publishing a GitHub release**, not by a push. That
makes production deploys a deliberate act with a version number attached.

### Job 1 — the gate

```yaml
jobs:
  gate:
    outputs:
      run: ${{ steps.check.outputs.run }}
    steps:
      - id: check
        run: |
          tag='${{ github.event.release.tag_name }}'
          if [[ "$tag" =~ ^(v|web-v)[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            echo "run=true" >> "$GITHUB_OUTPUT"
          else
            echo "Tag $tag does not match v* or web-v*; web production skipped."
            echo "run=false" >> "$GITHUB_OUTPUT"
          fi
```

One repo, several release types (web, mobile). The gate makes sure a mobile
release tag does not trigger a web deploy. Later jobs check
`if: needs.gate.outputs.run == 'true'`.

`$GITHUB_OUTPUT` is how a step passes a value to later jobs. Note that the job
still *runs* and shows green when skipped — read the log, not just the tick.

### Job 2 — build

```yaml
  build:
    needs: gate
    if: needs.gate.outputs.run == 'true'
    environment: production
    outputs:
      app_tag: ${{ steps.tags.outputs.app_tag }}
    steps:
      - uses: actions/checkout@v4
        with:
          ref: ${{ github.event.release.tag_name }}   # check out the tag, not main
      - uses: docker/setup-buildx-action@v3
      - id: tags
        run: |
          TS=$(date +%Y%m%d%H%M%S)
          echo "app_tag=${TARGET}-${TS}" >> "$GITHUB_OUTPUT"
      - uses: docker/login-action@v3
        with:
          registry: ${{ env.ACR_LOGIN_SERVER }}
          username: ${{ secrets.ACR_USERNAME }}
          password: ${{ secrets.ACR_PASSWORD }}
      - uses: docker/build-push-action@v5
        with:
          context: apps/web
          target: production
          push: true
          platforms: linux/amd64
          tags: |
            ${{ env.ACR_LOGIN_SERVER }}/microjob-app:${{ steps.tags.outputs.app_tag }}
            ${{ env.ACR_LOGIN_SERVER }}/microjob-app:${{ env.TARGET }}-latest
          cache-from: type=registry,ref=.../microjob-app:${{ env.TARGET }}-buildcache
          cache-to:   type=registry,ref=.../microjob-app:${{ env.TARGET }}-buildcache,mode=max
```

Three images are built this way: `microjob-app`, `img-hash`,
`microjob-migrate`. `ref: ${{ ... tag_name }}` is important — without it you
would build whatever `main` happens to be, not the released commit.

### Job 3 — deploy

```yaml
  deploy:
    needs: [gate, build]
    environment: production
    defaults:
      run:
        working-directory: apps/web
    steps:
      - uses: azure/setup-helm@v4
        with: { version: 'v3.13.0' }
      - uses: azure/setup-kubectl@v3

      - name: Configure kubeconfig
        run: |
          mkdir -p $HOME/.kube
          echo "${{ secrets.KUBECONFIG }}" | base64 -d > $HOME/.kube/config
          chmod 600 $HOME/.kube/config

      - name: Generate secrets file
        run: |
          mkdir -p deploy/.secrets
          cat > deploy/.secrets/${TARGET}.secrets <<EOF
          NUXT_JWT_SECRET=${{ secrets.NUXT_JWT_SECRET }}
          NUXT_PUBLIC_APP_URL=${{ vars.NUXT_PUBLIC_APP_URL }}
          ...
          EOF

      - name: Cleanup stale migration jobs
        run: |
          kubectl delete jobs -n "${TARGET}" -l app=migrate --ignore-not-found=true
          sleep 5

      - name: Deploy with deploy.sh
        run: |
          chmod +x deploy/bin/deploy.sh
          ./deploy/bin/deploy.sh --deploy ${TARGET_FLAG} --yes --skip-build --skip-push --no-wait
        env:
          APP_TAG: ${{ needs.build.outputs.app_tag }}
          IMG_HASH_TAG: ${{ needs.build.outputs.img_hash_tag }}
          MIGRATE_TAG: ${{ needs.build.outputs.migrate_tag }}

      - name: Verify deployment
        run: |
          kubectl get pods -n "${TARGET}" -o wide
          kubectl get deployments -n "${TARGET}"
```

The best decision here: **CI calls the same `deploy.sh` a human would call**,
just with `--skip-build --skip-push` because CI already built and pushed. There
is no second, divergent deploy path to keep in sync.

`--no-wait` means the pipeline does not block on the rollout — so the "Verify
deployment" step prints a snapshot, but a green pipeline is **not** proof the
rollout succeeded. Check afterwards, or add a `kubectl rollout status` step.

## Secrets, variables and environments

- `${{ secrets.X }}` — encrypted, masked in logs.
- `${{ vars.X }}` — plain configuration, visible.
- Both can be scoped to an **environment**, so `production` and `staging` hold
  different values for the same name.

Declaring `environment: production` on a job also lets you require **manual
approval** and restrict which branches may deploy. If production does not
already require approval, that is a cheap and worthwhile addition.

Secrets used by your deploys: `KUBECONFIG` (base64), `ACR_USERNAME`,
`ACR_PASSWORD`, and every app secret (`NUXT_JWT_SECRET`, payment gateway keys,
mail keys, and so on).

Both repos also have `scripts/gh-env-sync.sh` with `gh-env.staging` /
`gh-env.production` files, so the long list of GitHub variables can be kept in
the repo and pushed to GitHub instead of being clicked in by hand. That is a
good habit — the settings are reviewable and reproducible.

### About the kubeconfig secret

A `KUBECONFIG` in GitHub Actions is a long-lived credential to your cluster.
Reduce the blast radius:

- give it a ServiceAccount limited to the one namespace, not cluster-admin,
- scope the secret to the `production` environment so only approved runs see it,
- prefer OIDC federation (`azure/login` with a federated credential) so no
  standing secret exists at all.

## petnest's staging → production flow

1. `release-to-staging.yml` builds **all 17 images** tagged with the git short
   SHA and deploys to `petnest-staging`.
2. You test staging. `deploy/bin/smoke-test.sh` exists for this.
3. `promote-to-production.yml` (or `deploy/bin/promote.sh` locally) verifies
   every image exists at `:<sha>`, re-tags the **same bytes** to `:vX.Y.Z`, and
   deploys production.

The promote script's error message is a lesson in itself:

> Causes: the release-to-staging build for that sha failed, or the release
> branch was SQUASH-merged (the tag no longer points at the commit staging
> built). Merge release branches with `--no-ff`.

## Patterns worth copying into any project

- **Gate job** — one cheap job decides whether the expensive ones run.
- **Build once, deploy many** — never rebuild between environments.
- **Same script for CI and humans** — no divergence.
- **Registry build cache** — keeps CI builds from starting cold every time.
- **Checkout the tag, not the branch** — deploy what was released.
- **`concurrency`** — add this to stop two deploys racing:

  ```yaml
  concurrency:
    group: deploy-production
    cancel-in-progress: false
  ```

- **Pin action versions** (`@v4`) and, for third-party actions, pin to a commit
  SHA — an action you do not control can change under you.
- **Minimum permissions**:

  ```yaml
  permissions:
    contents: read
  ```

## Commands

```bash
gh workflow list
gh workflow run web-staging.yml
gh run list --workflow=web-production.yml
gh run watch
gh run view <id> --log-failed
gh secret list
gh variable list
```
