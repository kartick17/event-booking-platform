# 17 — Observability: Logs, Metrics and Uptime

Once the app is live, the question changes from "does it deploy?" to "what is
it doing, and is it healthy?".

Three separate things, often confused:

| | Question it answers | Your tool |
|---|---|---|
| **Logs** | What happened, in detail | OpenObserve (+ `kubectl logs`, log PVC) |
| **Metrics** | How much, how fast, over time | Netdata (+ metrics-server for HPA) |
| **Uptime** | Is it reachable from outside? | Uptime Kuma |

microjob ships all three as two separate Helm charts under `infra/helm/`,
deployed by their own workflows (`deploy-observability.yml`,
`deploy-monitoring.yml`). They all live in one `monitoring` namespace.

Note the ownership split, stated in the observability values file:

> Runs in the SAME `monitoring` namespace as Netdata + Uptime Kuma, so this
> chart does NOT create the namespace (the monitoring chart owns it).

Two charts sharing a namespace must agree on exactly one owner for it, or they
fight over creation and deletion. Good detail to copy.

## Logs

### The default: `kubectl logs`

Kubernetes captures a container's stdout/stderr. It is enough for debugging one
pod right now, and useless for anything else:

- logs die with the pod,
- you cannot search across pods,
- there is no retention.

Practical usage:

```bash
kubectl logs deploy/gateway -n petnest-staging
kubectl logs deploy/gateway -n petnest-staging -f --tail=100
kubectl logs <pod> -n petnest-staging --previous     # the container that crashed
kubectl logs -l app=petnest -n petnest-staging --all-containers --tail=50
```

`--previous` is the one people forget. When a pod is in `CrashLoopBackOff`, the
current container has barely started; the useful output is in the previous one.

### OpenObserve

`infra/helm/observability` runs **OpenObserve**, which stores logs, errors and
frontend RUM (real user monitoring) data.

```yaml
image:
  repository: public.ecr.aws/zinclabs/openobserve
  tag: v0.90.3          # pinned deliberately
replicas: 1
storage: { size: 20Gi, storageClass: managed-premium, dataDir: /data }
service:
  httpPort: 5080        # UI + ingest (browser RUM/logs + backend HTTP)
  grpcPort: 5081        # OTLP/gRPC ingest
ingress:
  enabled: true
  host: errors.microjob.com
  certIssuer: letsencrypt-prod
  proxyBodySize: "32m"
```

Two comments in that file are worth internalising.

On version pinning:

> Pin a real stable tag. Latest stable as of writing: v0.90.3. Check the
> releases page before bumping.

On authentication:

> NO nginx basic auth here on purpose: OpenObserve has its own login and uses
> ingest tokens. Basic auth would block the browser RUM SDK and the backend
> from sending data.

That is a real trap. Putting basic auth in front of a service that receives
machine traffic silently breaks ingestion while the UI still works for you.

The app sends data using `NUXT_OPENOBSERVE_AUTH`, injected as a secret from the
CI workflow. `5081` is the OTLP gRPC port — OTLP is the OpenTelemetry wire
format, so you can point standard tooling at it later without changing the
backend.

It is deployed as single-node with local disk. The values file is honest about
that: *"Move to HA + object storage later."* Fine for now; just know that the
log store is currently a single point of failure with a 20Gi cap.

### Durable file logs

Separately, microjob can mount a shared RWX volume and write
`${HOSTNAME}-YYYY-MM-DD.log` files, pruned after `retentionDays: 30` (file 08).
That gives a second, independent copy of the logs that survives pod deletion.

### What good application logs look like

- **Structured JSON**, one object per line — searchable, machine-parseable.
- Always include a **request id / correlation id** and propagate it between
  services. With 14 petnest services, this is the difference between tracing a
  bug in minutes and not tracing it at all.
- Log **levels** used consistently: `error` = a human should look, `warn` =
  unusual but handled, `info` = business events, `debug` = off in production.
- **Never log secrets, tokens, passwords, card numbers or full request bodies.**
  Logs are copied to a searchable store that more people can read than can read
  the database.
- Log to **stdout**, not to a file, as the primary path. Let the platform route
  it.

## Metrics

### metrics-server

The small component that powers `kubectl top` and CPU-based HPAs. If
`kubectl top pods` errors, metrics-server is missing or unhealthy — and your
HPAs are doing nothing.

### Netdata

`infra/helm/monitoring` runs Netdata in a **parent/agent** layout:

```yaml
netdata:
  streamApiKey: ""          # auto-generated on first install, reused via lookup
  parent:
    replicas: 1
    storageSize: 10Gi
    image: "netdata/netdata:v1.46.0"
  agent:
    image: "netdata/netdata:v1.46.0"
    resources:
      requests: { cpu: "50m", memory: "128Mi" }
      limits:   { cpu: "200m", memory: "256Mi" }
```

- **Agents** run as a **DaemonSet** — one pod on every node, collecting CPU,
  memory, disk, network and container metrics.
- The **parent** is a single pod that receives streamed metrics from all agents
  and stores history on a PVC.
- The `streamApiKey` uses the same "generate once, then `lookup`" trick as the
  NATS token (file 05).
- `templates/netdata-rbac.yaml` gives the agents permission to read Kubernetes
  objects, which is how they label metrics by pod and namespace.

Agent resource requests matter more than they look: a DaemonSet request is
multiplied by the number of nodes, so an over-sized request wastes capacity on
every node in the cluster.

### The four numbers to watch first

For any HTTP service: **request rate, error rate, latency (p95/p99), and
saturation** (CPU, memory, connection pool, queue depth).

For your specific stack, add:

- Postgres: connection count vs `max_connections`, replication lag, slow
  queries, disk usage.
- PgBouncer: `SHOW POOLS` — waiting clients is the number that predicts an
  outage.
- NATS: stream size vs limit, consumer pending count, redelivery count.
- Kubernetes: pod restart counts, `Pending` pods, node allocatable vs requested.

## Uptime

**Uptime Kuma** (`louislam/uptime-kuma`) checks your public URLs from inside the
cluster on a schedule and alerts when they fail:

```yaml
kuma:
  image: "louislam/uptime-kuma:1.23.13"
  storageSize: 5Gi
  smtpSecretName: monitoring-smtp
  smtp:
    port: "587"
    to: "admin@microjob.com"
```

Alerts go out over SMTP, with credentials in a Secret
(`templates/smtp-secret.yaml`).

Two honest limitations:

1. It runs **inside the same cluster** it monitors. If the cluster or its
   ingress is down, the thing meant to tell you may also be down. An external
   checker (any third-party uptime service) covers that gap cheaply.
2. Checking `/` only tells you nginx answered. Check an endpoint that actually
   touches the database and the broker, so a "healthy" result means something.

The monitoring ingress is protected with nginx basic auth
(`basicAuthSecretName: monitoring-basic-auth`) — correct here, because Netdata
and Kuma are dashboards for humans, unlike the OpenObserve ingest endpoint.

## Alerting: keep it small on purpose

Alert on **symptoms users feel**, not on every metric:

- the site returns 5xx above a small rate,
- p95 latency crosses a threshold for several minutes,
- a pod is crashlooping,
- database connections or disk are near their limit,
- a queue is growing and not draining,
- a certificate expires in under 14 days.

Every alert must be **actionable**. An alert nobody acts on trains everyone to
ignore the channel, and then the real one is ignored too.

## A debugging order that works

1. Is it reachable from outside? (Kuma, `curl -I`)
2. Are the pods running and ready? (`kubectl get pods`)
3. If not ready — why? (`kubectl describe pod`, read the Events)
4. What does the app say? (`kubectl logs`, add `--previous`)
5. Is it resource-starved? (`kubectl top`, look for OOMKilled/Evicted)
6. Can it reach its dependencies? (exec + `nc -zv`, check NetworkPolicies)
7. Is the database healthy? (`kubectl cnpg status`, `pg_stat_activity`)
8. What actually got deployed? (`helm get manifest`, `kubectl get deploy -o yaml`)
9. Did it work before? (`helm history` — then roll back and investigate calmly)

Step 9 is the professional move: **restore service first, diagnose second.**
