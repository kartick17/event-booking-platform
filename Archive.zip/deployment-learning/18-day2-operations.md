# 18 — Day-2 Operations: A Practical Runbook

"Day 1" is getting it deployed. "Day 2" is everything after — and that is where
you will spend your time. This file is meant to be used, not just read.

## Getting access

```bash
# Azure
az login
az aks get-credentials --resource-group <rg> --name <cluster>

# check what you are pointing at BEFORE you type anything else
kubectl config current-context
kubectl get ns
```

microjob keeps kubeconfigs at `.local-deploy/kubeconfig/staging.yaml` and
`production.yaml`. Use them explicitly:

```bash
export KUBECONFIG=/home/weloin/Projects/microjob/.local-deploy/kubeconfig/staging.yaml
```

**The most common serious mistake in this whole pack is running a command
against production while believing you are on staging.** Two habits prevent it:

- always run `kubectl config current-context` first,
- put the context and namespace in your shell prompt (`kube-ps1`, or the
  Starship `kubernetes` module).

## Normal deploy

**petnest, staging:**

```bash
cd /home/weloin/Projects/petnest
./deploy/bin/deploy.sh --deploy --stag
```

**petnest, production** (after staging is verified):

```bash
./deploy/bin/promote.sh <short-sha> v1.4.0
```

**microjob, staging:**

```bash
cd /home/weloin/Projects/microjob/apps/web
./deploy/bin/deploy.sh --deploy --mj-stag
```

**microjob, production:** publish a GitHub release tagged `vX.Y.Z` or
`web-vX.Y.Z`. The workflow does the rest.

## After every deploy — always check

```bash
NS=petnest-staging

kubectl get pods -n $NS
kubectl get deploy -n $NS
kubectl rollout status deploy/gateway -n $NS
kubectl get jobs -n $NS                      # did the migration succeed?
kubectl logs job/migrate-<rev> -n $NS
kubectl get events -n $NS --sort-by=.lastTimestamp | tail -20
curl -I https://staging.petnest.com
```

Remember both CI pipelines pass `--no-wait`. A green pipeline means "Helm
accepted it", not "it is running".

## Rolling back

Fastest first.

**Helm rollback (preferred — reverts config *and* image):**

```bash
helm history petnest -n petnest-staging
helm rollback petnest -n petnest-staging            # previous revision
helm rollback petnest 7 -n petnest-staging          # a specific one
```

petnest's script wraps it:

```bash
./deploy/bin/deploy.sh --rollback --prod
./deploy/bin/deploy.sh --rollback --prod --revision 7
```

**kubectl rollback (one Deployment only, does not touch Helm's record):**

```bash
kubectl rollout undo deployment/gateway -n petnest-staging
```

Use this to unstick one service quickly, then reconcile with Helm afterwards —
otherwise the next `helm upgrade` silently puts the bad version back.

**Redeploy a known-good image tag:**

```bash
IMAGE_TAG=v1.3.0 ./deploy/bin/deploy.sh --deploy --prod --skip-build --skip-push
```

### The one thing a rollback does not fix

**Database migrations do not roll back.** If a deploy dropped a column, rolling
back the code gives you old code against a new schema, which may be worse. This
is why file 11 insists on expand/contract migrations: they make rollback safe
by keeping the old code compatible with the new schema.

Before every production deploy, ask: *if I have to roll back the code in ten
minutes, does this migration still work?*

## Symptom → cause → fix

### Pod stuck `Pending`

```bash
kubectl describe pod <pod> -n $NS | tail -30
```

- "Insufficient cpu/memory" → requests too high, or the node pool is full.
  Lower requests, or scale the pool.
- "pod has unbound immediate PersistentVolumeClaims" → check the PVC and its
  StorageClass; often an RWX request against an RWO class.
- "node(s) had untolerated taint" → needs a toleration or a nodeSelector.

### `CrashLoopBackOff`

```bash
kubectl logs <pod> -n $NS --previous
```

Usual causes: missing env var or secret key, cannot reach the database or NATS,
a migration that has not run yet, a bad image, a port already in use, or
`consumer is already bound` (file 15).

### `ImagePullBackOff`

Tag typo, image never pushed (check the build job), missing pull credentials,
or wrong CPU architecture (must be `linux/amd64`).

### Running but `0/1 READY`

The readiness probe is failing. Check the probe path and port against what the
app actually serves, then check whether a dependency it probes is down.

### `OOMKilled`

```bash
kubectl describe pod <pod> -n $NS | grep -i -A3 'last state'
```

Raise the memory limit, or fix the leak. If it happens under load only, the
limit is too close to peak — measure and add headroom (file 10).

### 502 / 503 from the ingress

```bash
kubectl get endpoints <service> -n $NS      # empty = no ready pods
kubectl logs -n ingress-nginx deploy/ingress-nginx-controller --tail=100
```

Empty endpoints is by far the most common cause: the Service selector does not
match, or no pod is passing readiness.

### 413 on upload

`proxy-body-size` on the Ingress is too small.

### Websocket disconnects after ~60s

`proxy-read-timeout` / `proxy-send-timeout` are at the nginx default.

### Certificate not issued

```bash
kubectl describe certificate <name> -n $NS
kubectl get challenge -n $NS
```

DNS not pointing at the ingress IP, port 80 blocked, or a Let's Encrypt rate
limit.

### Database connection errors under load

```bash
kubectl exec -it <pooler-pod> -n $NS -- psql -p 5432 pgbouncer -c 'SHOW POOLS;'
```

`cl_waiting > 0` means clients are queuing. Raise `default_pool_size` (within
`max_connections`), add pooler instances, or reduce per-pod pool sizes.

### Everything lost NATS at once after a deploy

Token changed but the NATS pod did not restart. Check the checksum annotation
(file 15), and confirm the token in `db-secret` matches what the pod started
with.

### Queue backing up

Consumer pod crashed, ack wait shorter than the job duration, or a poison
message being redelivered forever. Check consumer pending and redelivery
counts.

## Routine maintenance

**Weekly**

- Look at pod restart counts: `kubectl get pods -A --sort-by=.status.containerStatuses[0].restartCount`
- Check PVC usage: `kubectl exec <pod> -- df -h`
- Skim error logs in OpenObserve for new patterns.
- Check certificate expiry dates.

**Monthly**

- Review resource requests against measured usage (`usageSampler`).
- Prune old image tags in ACR (never one a live release could roll back to).
- Apply base-image and dependency updates; both repos have Renovate configured.
- **Test a database restore into a scratch namespace.** An untested backup is
  not a backup.

**Before every production deploy**

1. Staging deployed from the same images and verified.
2. Migration reviewed for rollback safety.
3. Someone available to watch for 15 minutes afterwards.
4. You know the rollback command without looking it up.

## Emergency: maintenance mode (microjob)

```yaml
maintenance:
  enabled: true
  appHost: app-maint.microjob.com
  basicAuth: "<htpasswd line>"
```

Flipping this re-renders only `templates/ingress.yaml`: users get a static
page, and the real app moves to `appHost` behind basic auth so your team can
still use it. Nothing is rebuilt. Generate the auth line with
`htpasswd -nbB maint '<password>'`.

## Commands worth keeping close

```bash
# what is broken right now, across the namespace
kubectl get pods -n $NS --field-selector=status.phase!=Running
kubectl get events -n $NS --sort-by=.lastTimestamp | tail -30

# what is actually deployed
helm list -n $NS
helm get values petnest -n $NS
helm get manifest petnest -n $NS | grep image:

# quick shell into the cluster network
kubectl run tmp --rm -it --image=nicolaka/netshoot -n $NS -- bash

# scale in an emergency
kubectl scale deploy/gateway --replicas=4 -n $NS

# restart everything in a release
kubectl rollout restart deploy -n $NS

# copy a file out of a pod
kubectl cp $NS/<pod>:/app/logs/x.log ./x.log
```

## Two habits that prevent most incidents

1. **Change one thing at a time, and check.** Batched changes make it
   impossible to know which one broke it.
2. **Write down what you did.** Both charts are full of comments explaining why
   a value is what it is — `(prod outage 2026-07-12)`, `(audit M-3)`,
   `Measured: ~1-9m CPU`. That habit is why those problems only happened once.
   Keep it up.
