# 19 — Practice Path and Cheat Sheet

Reading is not learning. This file turns the pack into exercises, ordered so
each one builds on the last, and ends with the commands you will use daily.

Do every exercise against **staging** or a local cluster. Never learn on
production.

> **The manifests are already written for you.** Everything described here has
> a runnable version in `20-labs/`, with its own README, real YAML, and a
> deliberate failure to trigger. Start there:
>
> ```bash
> cd 20-labs/setup && ./up.sh
> cd ../lab01-deployment-service && cat README.md
> ```
>
> | Week | Labs |
> |---|---|
> | 2 | `lab01-deployment-service` |
> | 3 | `lab02-config-secrets`, `lab03-probes`, `lab04-storage` |
> | 4 | `lab05-helm` |
> | 5 | `lab06-ingress`, `lab07-network-policy`, `lab08-cnpg-pooler` |
> | 6 | `lab09-jobs-hooks`, `lab10-resources-hpa` |

## Set up a throwaway cluster first

You want somewhere you can break things.

```bash
# kind (Kubernetes in Docker) — the simplest option
kind create cluster --name learn

# or k3d
k3d cluster create learn

# tools
kubectl version --client
helm version
```

For the ingress exercises, install an ingress controller in the throwaway
cluster:

```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm install ingress-nginx ingress-nginx/ingress-nginx -n ingress-nginx --create-namespace
```

## Week 1 — Docker and the basics

1. Open `apps/web/Dockerfile` in microjob. Write down what each stage does and
   which one CI selects (`target: production`).
2. Build it locally and run it. Change one line of code and rebuild — watch
   which layers are cached and which are not.
3. Rewrite a small Dockerfile deliberately badly (`COPY . .` before install),
   rebuild after a code change, and compare the times. Now you will never
   forget layer ordering.
4. Bring up `apps/web/docker-compose.yml`. Exec into the app container and
   `ping postgres`. That is service-name DNS — the same idea as a Kubernetes
   Service.
5. Bring up petnest's `infra/docker/docker-compose.local.yml`. List the
   containers and match each one to a Deployment in the Helm chart.

**Check yourself:** explain, out loud, the difference between an image, a
container and a registry — and why `:latest` is banned in production.

## Week 2 — Kubernetes core

6. In your throwaway cluster, write a Deployment for `nginx` by hand. Apply it.
   `kubectl get pods`. Delete a pod and watch it come back.
7. Add a Service. Reach it with `kubectl port-forward`.
8. Break it on purpose: change the Service selector to a label nothing has.
   Run `kubectl get endpoints`. Empty endpoints is the single most useful
   symptom in Kubernetes — learn to recognise it now.
9. Scale to 3 replicas. Watch `kubectl get pods -o wide` and see which nodes
   they land on.
10. Now open `deploy/helm/petnest/templates/services.yaml` and map every field
    back to what you just wrote by hand.

**Check yourself:** why can you not change `spec.selector.matchLabels` on an
existing Deployment? (Answer in file 04.)

## Week 3 — Config, storage, health

11. Create a ConfigMap and a Secret. Mount one as env (`envFrom`) and one as a
    file. Exec in and read both.
12. Change the ConfigMap. Notice the running pod does **not** pick it up. Then
    do `kubectl rollout restart` and watch it change.
13. Add a readiness probe pointing at a path that returns 500. Watch the pod go
    `0/1 READY` and disappear from endpoints — without restarting.
14. Now make the **liveness** probe fail instead. Watch it restart in a loop.
    Feel the difference. This is the distinction people get wrong most often.
15. Create a PVC, mount it, write a file, delete the pod, and confirm the file
    survived. Then do the same with an `emptyDir` and watch it vanish.

**Check yourself:** which of your workloads would break if its volume were RWO
instead of RWX? (Hint: microjob's shared logs volume — file 08.)

## Week 4 — Helm

16. Render your project's chart without deploying:

    ```bash
    helm template petnest ./deploy/helm/petnest \
      -f ./deploy/helm/petnest/values-petnest-staging.yaml > /tmp/rendered.yaml
    ```

    Read `/tmp/rendered.yaml` end to end. This single exercise teaches more than
    any tutorial: you see exactly what the templates produce.
17. Count the objects. Find the 14 Deployments the `range` loop generated from
    the `services:` list.
18. Change one value (`replicas`, a resource request) and re-render. Diff the
    two outputs.
19. Convert your hand-written nginx Deployment from week 2 into a tiny chart
    with `values.yaml`, one template, and one helper in `_helpers.tpl`.
20. Install it, upgrade it, `helm history`, then `helm rollback`. Watch the
    revision numbers.
21. Read `templates/cnpg-secrets.yaml` and explain the `lookup` guard in your
    own words. Then run `helm template` and confirm the passwords differ every
    time — and understand why that is expected.

**Check yourself:** inside a `range`, why is it `$.Values` and not `.Values`?

## Week 5 — Networking and data

22. Read `templates/ingress.yaml` in both projects. For each annotation, write
    one sentence saying what breaks without it.
23. In your throwaway cluster, create an Ingress with two hosts pointing at two
    Services. Test with `curl -H "Host: a.example.com" http://localhost`.
24. Apply a default-deny egress NetworkPolicy **without** a DNS rule. Watch
    everything hang. Add the DNS rule and watch it recover. You will never
    forget this one.
25. Read `templates/network-policies.yaml`. For each policy, name the attack or
    mistake it prevents.
26. Install the CNPG operator in your test cluster. Create a 2-instance
    `Cluster`. Delete the primary pod and watch failover.
27. Add a `Pooler`. Connect through it. Run `SHOW POOLS;` in the `pgbouncer`
    database.
28. With the pooler in `transaction` mode, try a session-level advisory lock
    across two transactions and watch it misbehave. Now you understand why the
    migrate Job bypasses the pooler.

## Week 6 — Pipelines and operations

29. Read `.github/workflows/web-production.yml` line by line. Draw the job
    graph (`gate → build → deploy`) on paper.
30. Trace one secret from GitHub → workflow → `.secrets` file → `deploy.sh` →
    Helm → the `app-secret` object → an env var inside the pod.
31. Read `deploy/bin/promote.sh` and explain why re-tagging beats rebuilding.
32. Deliberately break a staging deploy (wrong image tag). Practise diagnosing
    it with `describe` → `logs` → `helm history`, then roll back. Time
    yourself.
33. Write your own one-page runbook for the two projects, based on file 18, in
    your own words.

## The 20 commands you will actually use

```bash
# where am I?
kubectl config current-context
kubectl config use-context <ctx>

# what is running
kubectl get pods -n $NS
kubectl get pods -n $NS -o wide
kubectl get deploy,svc,ing,pvc -n $NS

# why is it broken
kubectl describe pod <pod> -n $NS
kubectl logs <pod> -n $NS
kubectl logs <pod> -n $NS --previous
kubectl get events -n $NS --sort-by=.lastTimestamp

# get inside
kubectl exec -it <pod> -n $NS -- sh
kubectl port-forward svc/<svc> 8080:8080 -n $NS

# change things
kubectl rollout restart deploy/<name> -n $NS
kubectl rollout status  deploy/<name> -n $NS
kubectl rollout undo    deploy/<name> -n $NS
kubectl scale deploy/<name> --replicas=3 -n $NS

# resources
kubectl top nodes
kubectl top pods -n $NS

# helm
helm list -n $NS
helm history <release> -n $NS
helm get manifest <release> -n $NS
helm rollback <release> -n $NS
```

## A one-page summary of the whole stack

```
Docker            packages the app into an image
ACR               stores images; promote by RE-TAGGING, never rebuilding
Helm              values + templates -> Kubernetes YAML, with revisions
Kubernetes        keeps the described state true, forever
  Namespace       a folder per project per environment
  Deployment      N replicas + a safe update strategy
  Service         stable internal name and load balancing (ClusterIP)
  Ingress         hostname routing + TLS, one public IP for everything
  cert-manager    free certificates, renewed automatically
  ConfigMap       plain settings          Secret     private settings
  PVC             disk that outlives the pod
  Job + hooks     run-once work: migrations and seeds, in weighted order
  Probes          readiness removes traffic; liveness restarts the pod
  Requests        what the scheduler reserves (this is what fills a node)
  Limits          the ceiling; memory over the limit = OOMKilled
  HPA             more pods when CPU passes a % of the REQUEST
  NetworkPolicy   deny by default, allow explicitly, always allow DNS
CNPG              runs Postgres: primary + replica, failover, its own CA
PgBouncer Pooler  many client connections -> few database connections
NATS JetStream    durable queues; needs a PVC, needs idempotent consumers
GitHub Actions    build once, deploy many, same script CI and humans use
Observability     logs (OpenObserve), metrics (Netdata), uptime (Kuma)
```

## The ten rules worth memorising

1. Never deploy `:latest`. Deploy an immutable tag you can roll back to.
2. Promote images by re-tagging. Never rebuild between environments.
3. Requests fill nodes, not usage. Measure before you set them.
4. Never let a critical pod be BestEffort.
5. Readiness removes traffic. Liveness restarts. Do not swap them.
6. Liveness must not check the database.
7. Migrations must be idempotent, and safe for old and new code at once.
8. A default-deny egress policy must allow DNS first.
9. A replica is not a backup. Test restores.
10. Every queue consumer must be idempotent — delivery is at-least-once.
