# 20 — Labs: Runnable Exercises

Hands-on companion to files 01–19. Everything here runs on a throwaway
**kind** cluster on your laptop. Nothing touches microjob or petnest.

Each lab is a folder with its own `README.md` and real manifests. Work through
them in order — later labs assume earlier ones.

| Lab | Folder | Teaches | Pack file |
|---|---|---|---|
| 1 | `lab01-deployment-service` | Deployment, Service, endpoints, the broken-selector symptom | 04, 06 |
| 2 | `lab02-config-secrets` | ConfigMap, Secret, envFrom vs secretKeyRef vs volume, restart-on-change | 05 |
| 3 | `lab03-probes` | readiness vs liveness vs startup, felt directly | 09 |
| 4 | `lab04-storage` | emptyDir vs PVC, StatefulSet volumeClaimTemplates | 08 |
| 5 | `lab05-helm` | Build a tiny chart: values, template, helper, range, upgrade, rollback | 12 |
| 6 | `lab06-ingress` | Two hosts, one IP, path routing, body size | 07 |
| 7 | `lab07-network-policy` | Default-deny, the DNS trap, allowlists | 13 |
| 8 | `lab08-cnpg-pooler` | CNPG cluster, failover, PgBouncer pool modes | 14 |
| 9 | `lab09-jobs-hooks` | Job, init container, Helm hook weights, idempotency | 11 |
| 10 | `lab10-resources-hpa` | Requests vs limits, OOMKilled, QoS, HPA on CPU | 10 |

## Prerequisites

You already have `kubectl`, `helm` and `docker`. You still need **kind**:

```bash
# Linux amd64
curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.27.0/kind-linux-amd64
chmod +x ./kind
sudo mv ./kind /usr/local/bin/kind
kind version
```

## Start the cluster

```bash
cd 20-labs/setup
./up.sh
```

That creates a 3-node cluster named `learn` (1 control-plane + 2 workers), with
ports 80 and 443 mapped to your laptop, and installs ingress-nginx.

Two workers matter: labs 4, 8 and 10 are about scheduling and per-node
behaviour, which a single-node cluster cannot show you.

**Lab 7 needs a second cluster.** kind's default network plugin (kindnet) does
**not** enforce NetworkPolicy — your rules would apply silently and do nothing.
`up-netpol.sh` creates a separate cluster with Calico installed. That is itself
the lesson from file 13: *policies need a CNI that enforces them.*

## Clean up

```bash
./down.sh          # deletes both clusters
```

kind clusters cost nothing when deleted and take about a minute to recreate.
Delete freely.

## How to use a lab

Each `README.md` follows the same shape:

1. **Do this** — commands to run, in order.
2. **Watch for** — the exact output that proves the point.
3. **Break it** — a deliberate failure, because the failure is the lesson.
4. **Answer these** — questions you should be able to answer before moving on.
5. **Back to the real projects** — the file and line in microjob or petnest
   that uses this idea for real.

Do not skip step 3. Every lab is built so the broken state teaches more than
the working state.

## A note on namespaces

Every lab uses its own namespace (`lab01`, `lab02`, …) so labs never collide
and cleanup is one command:

```bash
kubectl delete ns lab01
```
