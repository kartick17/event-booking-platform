# Lab 01 — Deployment, Service, Endpoints

**Pack files:** 04 (Kubernetes core), 06 (Services and networking)
**Time:** ~20 minutes

The goal is not "deploy nginx". The goal is to feel, in your hands, that
**labels are the only glue in Kubernetes** — and to recognise the empty-endpoint
symptom instantly for the rest of your career.

## Do this

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-deployment.yaml
kubectl get pods -n lab01 -o wide
```

**Watch for:** three pods, spread across your two worker nodes. Note the random
name suffixes — `whoami-7d9f8c6b4d-xk2p9`. The middle part is the **ReplicaSet**
hash. The Deployment made a ReplicaSet; the ReplicaSet made the pods.

```bash
kubectl get rs -n lab01
```

Now add the Service:

```bash
kubectl apply -f 02-service.yaml
kubectl get svc,endpoints -n lab01
```

**Watch for:** the `ENDPOINTS` column lists **three pod IPs**. That list is the
Service doing its job. Kubernetes built it by matching labels.

Prove the load balancing is real:

```bash
kubectl run tmp --rm -it --image=curlimages/curl:8.10.1 -n lab01 --restart=Never -- \
  sh -c 'for i in $(seq 1 9); do curl -s http://whoami:8080 | grep Hostname; done'
```

**Watch for:** the hostname changes between requests. You never named a pod.
You said `whoami:8080` and cluster DNS plus the Service did the rest.

## The self-healing loop

```bash
kubectl get pods -n lab01
kubectl delete pod <one-pod-name> -n lab01
kubectl get pods -n lab01
```

**Watch for:** a replacement appears within seconds, with a new name. You did
not ask for it. The ReplicaSet controller compared "3 desired" against "2 real"
and fixed the difference. This is the desired-state model from file 01.

## Break it

Now the important part.

```bash
kubectl apply -f 03-broken-service.yaml
kubectl get endpoints whoami -n lab01
```

**Watch for:**

```
NAME     ENDPOINTS   AGE
whoami   <none>      5m
```

`<none>`. That is the whole symptom.

Confirm what a user would see:

```bash
kubectl run tmp --rm -it --image=curlimages/curl:8.10.1 -n lab01 --restart=Never -- \
  curl -sS --max-time 5 http://whoami:8080 ; echo "exit=$?"
```

The connection fails — even though `kubectl get pods` shows three perfectly
healthy pods. **Healthy pods and a broken Service look identical in
`get pods`.** Only `get endpoints` tells you.

Fix it:

```bash
kubectl apply -f 02-service.yaml
kubectl get endpoints whoami -n lab01
```

## The immutable selector

Try to change what the Deployment selects on:

```bash
kubectl patch deployment whoami -n lab01 --type=merge \
  -p '{"spec":{"selector":{"matchLabels":{"app":"whoami","component":"api"}}}}'
```

**Watch for:** the API server refuses:

```
field is immutable
```

This is exactly why microjob's chart carries this comment:

> The app Deployment's `spec.selector.matchLabels` is immutable. The live
> deployment (migrated from microjob-web) selects on `app: dailyjobs`, so we
> keep that exact value to upgrade in place without recreating the pod set.

Changing it in production would mean deleting and recreating the Deployment,
which means downtime. Labels are a day-one decision.

## Answer these

1. A Service and its pods are in the same namespace with the right names, but
   `curl` times out. What is the first command you run?
2. What are the three things a Service creates when you apply it?
3. Why does `port` differ from `targetPort` here, and which one does a caller
   use?
4. You scale to 10 replicas. Do you have to change the Service? Why not?
5. Why can't you rename a Deployment's selector labels in place?

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/services.yaml` — one `range` loop
  generates this exact Deployment + Service pair 14 times, once per service.
  Read it now; it will look familiar.
- `microjob/apps/web/deploy/helm/microjob/templates/app-deployment.yaml` and
  `app-service.yaml` — the same pair, written out longhand.
- The `app: petnest, component: <name>` label pair in petnest is used by the
  Deployment, the Service, **and** the NetworkPolicies (lab 07). One careless
  label edit breaks three things at once.

## Clean up

```bash
kubectl delete ns lab01
```
