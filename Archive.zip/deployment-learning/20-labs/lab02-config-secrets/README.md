# Lab 02 — ConfigMaps and Secrets

**Pack file:** 05
**Time:** ~25 minutes

Three ways to get settings into a container, why the choice matters, and the
one behaviour that surprises everyone: **changing a ConfigMap does not restart
anything.**

## Do this

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-configmap.yaml
kubectl apply -f 02-secrets.yaml
kubectl apply -f 03-deployment.yaml
kubectl rollout status deploy/reader -n lab02
```

Look at what landed inside the pod:

```bash
kubectl exec -it deploy/reader -n lab02 -- env | sort | grep -E 'APP_ENV|FEATURE|UPSTREAM|JWT|MAIL|REDIS|DATABASE'
```

**Watch for:**

- `APP_ENV`, `FEATURE_NEW_SEARCH`, `UPSTREAM_URL` — from the ConfigMap via
  `envFrom`.
- `JWT_SECRET`, `MAIL_API_KEY` — from the Secret via `envFrom`. Note they look
  **exactly the same** as ConfigMap values once inside the container. The
  container cannot tell the difference and does not care.
- `REDIS_URL` — injected by name with `secretKeyRef`.
- `DATABASE_URL` — **absent**, and the pod started anyway. That is
  `optional: true` doing its job.

Now remove the `optional: true` line from `03-deployment.yaml`, re-apply, and
watch the new pod sit in `CreateContainerConfigError`. Put it back. That single
flag is why petnest's `search` service — which has no database — can share one
template with the twelve services that do.

## Secrets are encoded, not encrypted

```bash
kubectl get secret app-secret -n lab02 -o jsonpath='{.data.JWT_SECRET}' ; echo
kubectl get secret app-secret -n lab02 -o jsonpath='{.data.JWT_SECRET}' | base64 -d ; echo
```

**Watch for:** base64 in, plain text out. Anyone with read access to Secrets in
the namespace has the value. The real protection is RBAC and encryption at
rest — not the encoding.

Useful contrast:

```bash
kubectl describe secret app-secret -n lab02
```

`describe` shows key **names** and byte counts, never values. Safe to paste
into a ticket.

## The `items:` selector is a security control

```bash
kubectl exec -it deploy/reader -n lab02 -- ls -l /etc/pg-ca
kubectl exec -it deploy/reader -n lab02 -- cat /etc/pg-ca/ca.crt
kubectl exec -it deploy/reader -n lab02 -- cat /etc/pg-ca/ca.key
```

**Watch for:** only `ca.crt` exists. `ca.key` — the CA private key sitting in
the same Secret — is not there, because the volume selected one key.

Now break it deliberately. Delete the `items:` block from `03-deployment.yaml`
(leave `secretName: pki`), re-apply, and look again:

```bash
kubectl exec -it deploy/reader -n lab02 -- ls -l /etc/pg-ca
```

Both files are mounted. Every pod using this Secret can now sign certificates
the cluster trusts. That is why petnest's `_helpers.tpl` says, in capitals:
**never drop the `items:` selector.** Put it back.

## Break it: config changes do not reach running pods

```bash
kubectl exec -it deploy/reader -n lab02 -- env | grep APP_ENV
# APP_ENV=staging

kubectl patch configmap app-config -n lab02 --type=merge \
  -p '{"data":{"APP_ENV":"production"}}'

kubectl get configmap app-config -n lab02 -o jsonpath='{.data.APP_ENV}' ; echo
# production   <- the ConfigMap changed

kubectl exec -it deploy/reader -n lab02 -- env | grep APP_ENV
# APP_ENV=staging   <- the POD did not
```

**This is the surprise.** Env vars are read once, at container start. The
ConfigMap is now out of step with every running pod, and nothing tells you.

Two fixes.

Manual:

```bash
kubectl rollout restart deploy/reader -n lab02
kubectl exec -it deploy/reader -n lab02 -- env | grep APP_ENV
# APP_ENV=production
```

Automatic — the checksum annotation:

```bash
kubectl apply -f 04-deployment-with-checksum.yaml
kubectl get pods -n lab02
# edit the annotation value in the file, then:
kubectl apply -f 04-deployment-with-checksum.yaml
kubectl get pods -n lab02
```

**Watch for:** the pod rolls, because the pod *template* changed. In Helm the
value is `sha256sum` of the rendered ConfigMap, so it changes exactly when the
config does — and never on an unrelated deploy.

petnest uses this on NATS for a specific reason worth re-reading:

> The server reads NATS_TOKEN once, at container start, and never revisits it,
> while every client re-reads it on each deploy. Without this the pod would
> survive a token change and the two sides would desync — every service losing
> NATS at once.

**Files behave differently from env.** A ConfigMap or Secret mounted as a
volume *is* updated in place (after a delay of up to a minute). But your app
must re-read the file for that to matter. Env vars never update.

## Answer these

1. You rotate an API key in a Secret and redeploy. The app still uses the old
   key. Why, and what are the two fixes?
2. When would you choose `secretKeyRef` over `envFrom` for a value?
3. What does `optional: true` protect against, and which petnest service needs
   it?
4. Someone asks you to paste a Secret's contents into a bug report. What do you
   run instead?
5. Why must every generated secret in petnest's chart live in **one** template
   file? (Pack file 05, the `$appPass` note.)

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/cnpg-secrets.yaml` — the
  generate-once-then-`lookup` pattern for database passwords and the NATS
  token.
- `petnest/deploy/helm/petnest/templates/services.yaml` — `envFrom` for bulk,
  `secretKeyRef` for `REDIS_URL`, `optional: true` for `DATABASE_URL`.
- `petnest/deploy/helm/petnest/templates/_helpers.tpl` — the `items:` selector
  on the CA mount.
- `microjob/.github/workflows/web-production.yml` — the `Generate secrets file`
  step, showing `secrets.*` versus `vars.*`.

## Clean up

```bash
kubectl delete ns lab02
```
