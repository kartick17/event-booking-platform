# Lab 03 — Probes: Readiness vs Liveness vs Startup

**Pack file:** 09
**Time:** ~30 minutes

The most commonly confused topic in Kubernetes, settled by watching the same
broken app behave two completely different ways.

**Readiness removes traffic. Liveness restarts the pod.**

## Do this

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-nginx-config.yaml
kubectl apply -f 02-app.yaml
kubectl rollout status deploy/web -n lab03
kubectl get pods,endpoints -n lab03
```

**Watch for:** `2/2` ready pods and two endpoint IPs.

Keep a watch running in a second terminal for the rest of this lab — the
transitions are the lesson, and they are easy to miss:

```bash
kubectl get pods -n lab03 -w
```

## Break it, part 1: readiness fails

`/ready` starts returning 503. The process is perfectly alive.

```bash
kubectl apply -f 03-broken-readiness.yaml
kubectl rollout restart deploy/web -n lab03      # pick up the new ConfigMap
sleep 25
kubectl get pods -n lab03
kubectl get endpoints web -n lab03
```

**Watch for:**

- `READY` column shows `0/1` for both pods.
- `STATUS` is still **Running**.
- `RESTARTS` is still **0**.
- Endpoints: `<none>`.

The pods were quietly pulled out of load balancing and left alone. No restart
storm, no lost in-flight work. If this were a real dependency outage, the pods
would rejoin the moment it recovered.

```bash
kubectl describe pod -l app=web -n lab03 | grep -A3 'Readiness probe failed'
```

## Break it, part 2: liveness fails

Same idea, different probe.

```bash
kubectl apply -f 04-broken-liveness.yaml
kubectl rollout restart deploy/web -n lab03
sleep 60
kubectl get pods -n lab03
```

**Watch for:** `RESTARTS` climbing — 1, 2, 3 — and eventually
`CrashLoopBackOff`. Kubernetes is killing a container that was answering
requests fine on `/`.

```bash
kubectl describe pod -l app=web -n lab03 | grep -A5 'Liveness probe failed'
```

**Now hold the two results side by side.** Identical HTTP failure. One removed
traffic gently; the other destroyed the pods in a loop. The only difference was
which probe you aimed at the failing endpoint.

This is why petnest points liveness at `/health` (trivial) and readiness at
`/health/ready` (may check dependencies). If liveness checked the database, a
five-second database blip would restart **every pod in the cluster at once** and
turn a hiccup into an outage.

Restore:

```bash
kubectl apply -f 01-nginx-config.yaml
kubectl rollout restart deploy/web -n lab03
kubectl rollout status deploy/web -n lab03
```

## Break it, part 3: no startupProbe

An app that needs 90 seconds to boot, with an aggressive liveness probe.

```bash
kubectl apply -f 05-slow-start-no-startupprobe.yaml
kubectl get pods -n lab03 -l app=slowboot -w
```

**Watch for:** it never becomes ready. Killed around 25 seconds in, every time,
forever. `CrashLoopBackOff` with **nothing wrong with the application**. This is
a configuration bug that looks exactly like an application bug — and people
burn hours on it.

Now the fix:

```bash
kubectl apply -f 06-slow-start-fixed.yaml
kubectl get pods -n lab03 -l app=slowboot -w
```

**Watch for:** the pod stays in `Running 0/1` for about 90 seconds, then goes
`1/1`. Liveness was suspended the whole time.

The wrong fix would have been to raise liveness `initialDelaySeconds` to 120 —
that buys the boot time but permanently blinds you to hangs for the pod's
entire life. A startupProbe gives a generous boot budget **and** fast detection
afterwards. microjob's app allows up to 300 seconds
(`periodSeconds: 10 x failureThreshold: 30`) for exactly this reason.

## Zero-downtime rollout, proved

```bash
# terminal 1 - hammer the Service and count failures
kubectl run load --rm -it --image=curlimages/curl:8.10.1 -n lab03 --restart=Never -- \
  sh -c 'fail=0; for i in $(seq 1 200); do curl -sf --max-time 2 http://web/ >/dev/null || fail=$((fail+1)); sleep 0.25; done; echo "failures=$fail"'

# terminal 2 - roll it mid-flight
kubectl set image deploy/web nginx=nginx:1.26-alpine -n lab03
```

**Watch for:** `failures=0`. With `maxSurge: 1, maxUnavailable: 0`, a new pod
must pass readiness **before** an old one is removed.

Now try the opposite and feel the difference:

```bash
kubectl patch deploy/web -n lab03 --type=merge -p \
  '{"spec":{"strategy":{"rollingUpdate":{"maxSurge":0,"maxUnavailable":2}}}}'
# re-run both commands above
```

Failures appear, because both pods are stopped before replacements are ready.
That surgeless setting is **wrong** for a public API — and **required** for
petnest's NATS consumers, which crash if two pods hold the same durable
subscription. Same setting, opposite correctness, decided entirely by what the
workload holds.

Reset:

```bash
kubectl apply -f 02-app.yaml
```

## Answer these

1. Your database is briefly unreachable. Which probe should notice, and which
   must not?
2. A pod is `Running` but gets no traffic. Which probe is failing?
3. A pod restarts every 30 seconds with no useful logs. Which probe is failing,
   and what is the first thing you check?
4. Why is raising `initialDelaySeconds` a worse fix for slow boot than adding a
   startupProbe?
5. Worst-case, how long does it take the config in `02-app.yaml` to notice a
   hang? (`periodSeconds x failureThreshold`, plus a timeout.)

## Back to the real projects

- `microjob/apps/web/deploy/helm/microjob/templates/app-deployment.yaml` —
  startup (300s budget), liveness and readiness all on `/_health`.
- `petnest/deploy/helm/petnest/templates/services.yaml` — the
  `$probe.healthPath` / `$probe.readyPath` split, with per-service overrides
  merged from `defaults.probe` in `values.yaml`.
- `petnest/deploy/helm/petnest/values.yaml` — the `natsConsumer` flag and its
  surgeless strategy.

## Clean up

```bash
kubectl delete ns lab03
```
