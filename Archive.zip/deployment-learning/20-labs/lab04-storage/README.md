# Lab 04 — Storage: emptyDir, PVC, StatefulSet

**Pack file:** 08
**Time:** ~30 minutes

Where data lives, what survives a restart, and the access-mode mistake that
leaves a pod stuck in `ContainerCreating` forever.

## Do this: emptyDir does not survive the pod

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-emptydir.yaml
kubectl rollout status deploy/scratch -n lab04

kubectl exec -it deploy/scratch -n lab04 -- sh -c 'echo "written at $(date)" > /data/note.txt; cat /data/note.txt'
kubectl exec -it deploy/scratch -n lab04 -- cat /data/note.txt
```

Now kill the pod:

```bash
kubectl delete pod -l app=scratch -n lab04
kubectl rollout status deploy/scratch -n lab04
kubectl exec -it deploy/scratch -n lab04 -- cat /data/note.txt
```

**Watch for:** `No such file or directory`. The volume was recreated empty with
the new pod.

`emptyDir` is correct for caches, temp files and hand-offs between containers
in the same pod. It is what microjob's app uses for `/app/storage`:

```yaml
volumes:
  - name: storage
    emptyDir:
      sizeLimit: 5Gi
```

The `sizeLimit` matters more than it looks — an `emptyDir` lives on the node's
disk. Without a limit, one pod filling it can get **every pod on that node**
evicted.

## Do this: a PVC does survive

```bash
kubectl apply -f 02-pvc.yaml
kubectl get pvc -n lab04
kubectl rollout status deploy/durable -n lab04

kubectl exec -it deploy/durable -n lab04 -- sh -c 'echo "written at $(date)" > /data/note.txt'
kubectl delete pod -l app=durable -n lab04
kubectl rollout status deploy/durable -n lab04
kubectl exec -it deploy/durable -n lab04 -- cat /data/note.txt
```

**Watch for:** the file is still there. Different pod, same disk.

Look at what was created for you:

```bash
kubectl get pvc,pv -n lab04
kubectl get storageclass
```

**Watch for:** you wrote a PVC (a request). The StorageClass created a PV (a
real disk) and bound them. That is dynamic provisioning — the same mechanism
that gives CNPG its `managed-premium` disks on AKS.

Note the `strategy: Recreate` on that Deployment. With `RollingUpdate`, the new
pod would wait for a RWO volume the old pod still holds, and the rollout would
hang. Read the comment in `02-pvc.yaml`.

## Break it: RWO across two nodes

This is the lesson.

```bash
kubectl apply -f 03-rwo-multiattach.yaml
sleep 20
kubectl get pods -n lab04 -l app=shared-rwo -o wide
```

**Watch for:** one pod `Running`, one stuck in `ContainerCreating` or
`Pending`.

```bash
kubectl describe pod -l app=shared-rwo -n lab04 | tail -25
```

**Watch for:** a message about volume node affinity or multi-attach. The second
pod is on a different node, and a `ReadWriteOnce` volume can only be attached
to one node at a time. It will wait forever.

This is precisely the failure microjob's chart warns about:

```yaml
logs:
  enabled: false
  storageClass: ""        # Must support ReadWriteMany (e.g. azurefile-csi)
  size: 10Gi
  mountPath: /app/logs
```

The app pod **and every worker pod** mount that logs volume, and they land on
different nodes. Point it at an Azure **Disk** class and the second pod never
starts. Only Azure **Files** (`azurefile-csi`) supports RWX.

Access mode summary:

| Mode | Meaning | Azure |
|---|---|---|
| `ReadWriteOnce` | one **node** read-write | Azure Disk (`managed-premium`) |
| `ReadOnlyMany` | many nodes, read-only | Azure Files |
| `ReadWriteMany` | many nodes read-write | Azure Files (`azurefile-csi`) |

RWX is slower and has different file-locking behaviour. Use it when you need
shared access, not by default.

Clean up the stuck one:

```bash
kubectl delete -f 03-rwo-multiattach.yaml
```

## Do this: StatefulSet gives one disk per pod

```bash
kubectl apply -f 04-statefulset.yaml
kubectl get pods -n lab04 -l app=queue -w      # ctrl-c when both are Running
kubectl get pvc -n lab04
```

**Watch for:**

- Pod names are `queue-0` and `queue-1` — stable and ordered, not random
  hashes.
- Two PVCs exist: `data-queue-0` and `data-queue-1`. You wrote one template;
  Kubernetes made one claim per pod.

Prove the disks are separate and the identity is stable:

```bash
kubectl exec -it queue-0 -n lab04 -- sh -c 'echo "I am zero" > /data/id.txt'
kubectl exec -it queue-1 -n lab04 -- sh -c 'echo "I am one"  > /data/id.txt'

kubectl delete pod queue-0 -n lab04
sleep 15
kubectl exec -it queue-0 -n lab04 -- cat /data/id.txt
```

**Watch for:** `I am zero`. The replacement pod took the same name **and**
reattached to the same disk. A Deployment cannot do either.

That is why petnest runs NATS as a StatefulSet: JetStream's file store must
survive restarts, and microjob's chart records what happens when it does not:

> Without it every nats pod restart wipes all streams, consumers and pending
> jobs (prod outage 2026-07-12).

## Break it: PVCs outlive their StatefulSet

```bash
kubectl delete statefulset queue -n lab04
kubectl get pvc -n lab04
```

**Watch for:** both PVCs are **still there**. This is deliberate — deleting a
StatefulSet must not destroy your database. It also means storage leaks quietly
if you never clean up.

```bash
kubectl delete pvc data-queue-0 data-queue-1 -n lab04
```

There is no undo for that command. On a real cluster, take a backup first.

## Answer these

1. Where should a Nuxt build cache live — `emptyDir` or PVC? Why?
2. Your logs PVC is `ReadWriteOnce` and the second worker pod is stuck in
   `ContainerCreating`. What is the fix, and what does it cost you?
3. Why is NATS a StatefulSet and the gateway a Deployment?
4. You delete a StatefulSet. Is your data gone?
5. Why does the PVC-backed Deployment in this lab use `Recreate` rather than
   `RollingUpdate`?

## Back to the real projects

- `microjob/apps/web/deploy/helm/microjob/values.yaml` — `logs:` (RWX
  required), `usageSampler.storage` (RWX required),
  `app.storage.sizeLimit` (emptyDir).
- `microjob/.../templates/logs-pvc.yaml` — the shared RWX claim.
- `petnest/deploy/helm/petnest/templates/nats.yaml` — StatefulSet with
  `volumeClaimTemplates`.
- `petnest/deploy/helm/petnest/values.yaml` — `cnpg.storage.storageClass:
  managed-premium`, one disk per Postgres instance.

## Clean up

```bash
kubectl delete ns lab04
```
