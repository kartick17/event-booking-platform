# Lab 05 — Helm: Build a Chart From Scratch

**Pack file:** 12
**Time:** ~45 minutes

The most valuable lab in the set. You build a small chart that uses the same
techniques as petnest's real one — a `range` loop, helpers, per-item overrides,
a checksum annotation — then upgrade and roll it back.

The chart is in `minisite/`. Read it before running anything.

```
minisite/
├── Chart.yaml
├── values.yaml            # defaults
├── values-prod.yaml       # environment overrides
└── templates/
    ├── _helpers.tpl       # partial - never rendered as an object
    ├── configmap.yaml
    ├── services.yaml      # ONE loop -> 3 Deployments + 3 Services
    └── ingress.yaml       # conditional
```

## Step 1: render before you deploy

Never deploy a chart you have not rendered. This is the habit that prevents
most Helm accidents.

```bash
cd lab05-helm
helm lint minisite
helm template demo ./minisite > /tmp/rendered.yaml
less /tmp/rendered.yaml
```

**Watch for:** 7 objects — 1 ConfigMap, 3 Deployments, 3 Services.

```bash
helm template demo ./minisite | grep '^kind:' | sort | uniq -c
```

You wrote **one** Deployment block. The `range` loop over `services:` produced
three. petnest does the identical thing with 14 entries and gets 28 objects.
That is the entire reason Helm is worth learning.

## Step 2: see the values layering

```bash
helm template demo ./minisite -f minisite/values-prod.yaml \
  | grep -E '^kind:|replicas:|APP_ENV|BANNER|host:'
```

**Watch for** three separate lessons in one output:

```
APP_ENV: "production"                    <- overridden by values-prod.yaml
BANNER: "hello from the minisite chart"  <- SURVIVED: maps MERGE deeply
replicas: 3                              <- web:   defaults.replicas 1 -> 3
replicas: 2                              <- api:   its own override WINS
replicas: 3                              <- admin: defaults.replicas 1 -> 3
kind: Ingress                            <- appeared: ingress.enabled true
host: minisite.example.com
```

- **Maps merge deeply.** `config:` in the prod file only set `APP_ENV`, and
  `BANNER` came through from the base file. This is exactly why petnest puts
  `OPENSEARCH_URL` in the base `config:` map — it reaches both environments
  automatically.
- **Lists replace, they do not merge.** If `values-prod.yaml` defined
  `services:`, you would get *only* those, not the union. Try it: add a
  one-item `services:` list to the prod file, re-render, and count. Then
  remove it.
- **Per-item overrides beat defaults.** `api` kept `replicas: 2`, which is
  `.replicas | default $.Values.defaults.replicas` in action.

## Step 3: install it

```bash
kubectl apply -f 00-namespace.yaml
helm upgrade --install demo ./minisite -n lab05 --wait

helm list -n lab05
kubectl get deploy,svc,cm -n lab05
```

`--install` means "create it if it does not exist". One command works for the
first deploy and every later one, which is why both your real deploy scripts
use this form.

## Step 4: upgrade and roll back

```bash
helm upgrade demo ./minisite -n lab05 --set defaults.replicas=2 --wait
kubectl get deploy -n lab05

helm history demo -n lab05
```

**Watch for:** revision 2. Now break it on purpose:

```bash
helm upgrade demo ./minisite -n lab05 --set image.tag=this-tag-does-not-exist --wait --timeout 60s
```

It fails and hangs until the timeout, because the pods cannot pull the image.

```bash
kubectl get pods -n lab05
```

**Watch for:** `ImagePullBackOff` on the new pods — and the **old pods still
running**. `maxUnavailable` protected you. A broken deploy did not take the
site down.

Roll back:

```bash
helm history demo -n lab05
helm rollback demo -n lab05
kubectl get pods -n lab05
helm history demo -n lab05
```

**Watch for:** the rollback appears as a **new revision** in the history, not
as a deletion. Helm never rewrites history.

Now try `--atomic`, which rolls back automatically on failure:

```bash
helm upgrade demo ./minisite -n lab05 --set image.tag=still-broken --atomic --timeout 60s
kubectl get pods -n lab05
```

**Watch for:** Helm undoes it for you. Your CI passes `--no-wait` instead — a
deliberate speed trade-off that means a green pipeline is not proof of a
successful rollout.

## Step 5: what is actually deployed?

The three commands you will use when reality does not match your expectations:

```bash
helm get values demo -n lab05        # the values that were actually used
helm get manifest demo -n lab05      # the YAML that was actually applied
helm get manifest demo -n lab05 | grep image:
```

`helm get manifest` is the source of truth. Not your local files — those may
have changed since the deploy.

## Step 6: the checksum annotation

```bash
kubectl get deploy demo-web -n lab05 -o jsonpath='{.spec.template.metadata.annotations}' ; echo

# change the config, redeploy
helm upgrade demo ./minisite -n lab05 --set config.BANNER="changed" --wait
kubectl get deploy demo-web -n lab05 -o jsonpath='{.spec.template.metadata.annotations}' ; echo
kubectl get pods -n lab05
```

**Watch for:** the checksum changed, so the pod template changed, so the pods
rolled — and the new env value is live. Without that annotation the ConfigMap
would have changed while every pod kept the old value (lab 02).

Confirm it does **not** roll on an unrelated change:

```bash
helm upgrade demo ./minisite -n lab05 --set defaults.replicas=1 --wait
```

The checksum is unchanged, so existing pods are not restarted. That precision
is why petnest hashes the rendered secret template for NATS rather than using a
timestamp.

## Break it: forget the `$`

Open `minisite/templates/services.yaml` and change one `$.Values.namespace` to
`.Values.namespace`, then render:

```bash
helm template demo ./minisite
```

**Watch for:**

```
Error: ... nil pointer evaluating interface {}.Values
```

Inside `range`, `.` is the current list item — which has no `.Values`. The root
context is only reachable through `$`. Put it back.

## Step 7: write your own template

Add a `NOTES.txt` to `minisite/templates/` — Helm prints it after install:

```
Thanks for installing {{ .Chart.Name }} ({{ .Chart.Version }}).

Release:   {{ .Release.Name }}
Namespace: {{ .Values.namespace }}
Services:
{{- range .Values.services }}
  - {{ $.Release.Name }}-{{ .name }} ({{ .replicas | default $.Values.defaults.replicas }} replicas)
{{- end }}
```

```bash
helm upgrade --install demo ./minisite -n lab05
```

You now know every Helm technique used in petnest's chart except hooks, which
are lab 09.

## Answer these

1. Why does `BANNER` survive `values-prod.yaml` but a redefined `services:`
   list would not?
2. Inside a `range`, how do you reach `.Release.Name`?
3. What does `helm get manifest` tell you that your local files cannot?
4. Why does a rollback create a new revision instead of deleting one?
5. `helm template` shows different generated passwords every run. Is that a
   bug? (Pack file 12, the `lookup` caveat.)

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/services.yaml` — the same loop, with
  `mergeOverwrite (deepCopy ...)` for probes. `deepCopy` is essential: without
  it the merge would mutate the shared defaults for every later item.
- `petnest/deploy/helm/petnest/templates/_helpers.tpl` — helpers that exist
  because two files must agree on the CA path.
- `microjob/apps/web/deploy/helm/microjob/values.yaml` — the same layering,
  with `values-microjob-staging.yaml` and `values-microjob-production.yaml`.

## Clean up

```bash
helm uninstall demo -n lab05
kubectl delete ns lab05
```
