{{/*
Common labels put on every object this chart creates.
A helper exists when two or more places must never drift apart.
*/}}
{{- define "minisite.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
environment: {{ .Values.environment }}
{{- end }}

{{/*
Selector labels: the SUBSET that must stay stable forever, because a
Deployment's spec.selector.matchLabels is immutable after creation.
Never put a version or a changing value in here.

Call with a dict: (dict "root" $ "name" .name)
*/}}
{{- define "minisite.selectorLabels" -}}
app.kubernetes.io/name: {{ .root.Chart.Name }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
component: {{ .name }}
{{- end }}

{{/*
Full image reference, defined once so it can never disagree with itself.
*/}}
{{- define "minisite.image" -}}
{{ .Values.image.repository }}:{{ .Values.image.tag }}
{{- end }}
