# Lab 06 — Ingress: Many Hosts, One IP

**Pack file:** 07
**Time:** ~30 minutes

How three domains reach three different services through a single public IP,
what the annotations actually do, and how microjob's maintenance switch works.

Your `up.sh` cluster maps ports 80 and 443 to your laptop, so plain `curl`
works. There is no DNS for `*.lab06.test`, so send the `Host` header
explicitly — that is exactly what a browser does after a DNS lookup.

## Do this

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-backends.yaml
kubectl rollout status deploy/web   -n lab06
kubectl rollout status deploy/admin -n lab06
kubectl rollout status deploy/api   -n lab06

kubectl apply -f 02-ingress.yaml
kubectl get ingress -n lab06
```

Now route by hostname:

```bash
curl -s -H 'Host: web.lab06.test'   http://localhost/
curl -s -H 'Host: admin.lab06.test' http://localhost/
curl -s -H 'Host: api.lab06.test'   http://localhost/
```

**Watch for:** `WEB backend`, `ADMIN backend`, `API backend`. Same IP, same
port, three different pods. The only thing that changed was the `Host` header.

That is name-based virtual hosting, and it is why petnest needs **one**
LoadBalancer rather than fourteen.

An unknown host proves the routing is real:

```bash
curl -s -o /dev/null -w '%{http_code}\n' -H 'Host: nope.lab06.test' http://localhost/
```

**Watch for:** `404`. No rule matched, so the controller served its default
backend.

## See the generated nginx config

The Ingress object is a rule sheet. The controller turns it into real nginx
config:

```bash
kubectl exec -n ingress-nginx deploy/ingress-nginx-controller -- \
  cat /etc/nginx/nginx.conf | grep -A3 'server_name web.lab06.test'
```

**Watch for:** a normal nginx `server` block. Nothing magic — the controller
watches Ingress objects and rewrites this file.

## Break it: 413 Request Entity Too Large

The Ingress currently allows a 1 MB body.

```bash
head -c 3000000 /dev/urandom > /tmp/blob.bin

curl -s -o /dev/null -w '%{http_code}\n' \
  -H 'Host: api.lab06.test' \
  --data-binary @/tmp/blob.bin \
  http://localhost/upload
```

**Watch for:** `413`.

The backend was happy to accept 500m — the rejection happened at the **edge**,
before the request ever reached your pod. Fix it with one annotation:

```bash
kubectl apply -f 03-ingress-bigger-body.yaml
sleep 3
curl -s -o /dev/null -w '%{http_code}\n' \
  -H 'Host: api.lab06.test' \
  --data-binary @/tmp/blob.bin \
  http://localhost/upload
```

**Watch for:** `200`.

No pod restarted, nothing was rebuilt. This is the single most common
"uploads are broken in production but work locally" cause, and both your
projects set `proxy-body-size: 250m` because of it.

## Break it: empty endpoints behind an Ingress

```bash
kubectl scale deploy/api --replicas=0 -n lab06
sleep 5
curl -s -o /dev/null -w '%{http_code}\n' -H 'Host: api.lab06.test' http://localhost/
kubectl get endpoints api -n lab06
```

**Watch for:** `503`, and `ENDPOINTS: <none>`.

Remember this pairing: **502/503 from the ingress → check endpoints first.**
It is either no ready pods (this case) or a Service selector that matches
nothing (lab 01). Both look identical from outside.

```bash
kubectl scale deploy/api --replicas=1 -n lab06
```

## Do this: maintenance mode

microjob's trick, in a form you can run.

```bash
kubectl apply -f 04-maintenance-mode.yaml
sleep 5

# users see the maintenance page
curl -s -w '\n%{http_code}\n' -H 'Host: web.lab06.test' http://localhost/

# the team can still reach the real app - but not without credentials
curl -s -o /dev/null -w '%{http_code}\n' -H 'Host: app-maint.lab06.test' http://localhost/
curl -s -u maint:letmein -H 'Host: app-maint.lab06.test' http://localhost/
```

**Watch for:** `503` + the maintenance text on the public host; `401` on the
app host without credentials; `WEB backend` with them.

The `web` Deployment never restarted. Only Ingress rules changed. That is why
microjob's chart says the toggle workflow re-renders **only**
`templates/ingress.yaml`, and why the maintenance pod is always deployed and
sits idle while `enabled: false`.

Generate your own auth line with:

```bash
htpasswd -nbB maint 'yourpassword'
```

Turn it off again:

```bash
kubectl delete ingress lab06-apphost -n lab06
kubectl apply -f 03-ingress-bigger-body.yaml
curl -s -H 'Host: web.lab06.test' http://localhost/
```

## TLS: what you would add on a real domain

kind has no public domain, so cert-manager cannot pass an HTTP-01 challenge
here. On a real cluster you add two things:

```yaml
metadata:
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  tls:
    - hosts: [web.lab06.test]
      secretName: lab06-web-tls
```

cert-manager then creates a `Certificate`, proves domain ownership at
`/.well-known/acme-challenge/...`, writes the cert into that Secret, and renews
it about 30 days before expiry.

When a certificate does not appear, work down this list:

```bash
kubectl get certificate,certificaterequest,order,challenge -n <ns>
kubectl describe challenge <name> -n <ns>
```

1. DNS does not point at the ingress IP yet.
2. Inbound port 80 is blocked.
3. You hit a Let's Encrypt rate limit — roughly 5 duplicate certificates per
   week. Test with `letsencrypt-staging` first.

## Answer these

1. A user reports uploads over 2 MB fail with 413, but the same upload works
   against the pod via `port-forward`. Where is the problem?
2. You get 503 from the ingress. What are the two possible causes, and which
   command distinguishes them?
3. Why does petnest need only one LoadBalancer for 14 services?
4. Websockets drop after about 60 seconds. Which annotation is missing?
5. Why does flipping maintenance mode not require a rebuild or a rollout?

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/ingress.yaml` — three hosts, three
  TLS secrets, the websocket timeout comment.
- `microjob/apps/web/deploy/helm/microjob/values.yaml` — the `ingress:` and
  `maintenance:` blocks, including `websocket-services: "app-service"`.

## Clean up

```bash
kubectl delete ns lab06
rm -f /tmp/blob.bin
```
