# Lab 07 — Network Policies

**Pack file:** 13
**Time:** ~40 minutes
**Cluster:** the **separate** Calico cluster, not `learn`

## Why a different cluster

kind's default network plugin (kindnet) accepts NetworkPolicy objects and then
**ignores them**. Your rules would apply cleanly, `kubectl get networkpolicy`
would look perfect, and nothing would be enforced.

That is the most dangerous failure mode in this whole pack: security that
appears configured and is not. Pack file 13 states it as a rule — *policies
need a CNI that enforces them.* This lab makes you live it.

```bash
cd ../setup
./up-netpol.sh          # creates cluster 'learn-netpol' with Calico
kubectl config current-context
# must print: kind-learn-netpol
```

**Check your context before every command in this lab.**

## Do this: everything is open by default

```bash
cd ../lab07-network-policy
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-workloads.yaml
kubectl wait --for=condition=available deploy --all -n lab07 --timeout=120s
kubectl get pods -n lab07
```

A helper for the rest of the lab:

```bash
try() {   # try <from-component> <host> <port>
  kubectl exec -n lab07 deploy/$1 -- \
    timeout 5 nc -zv $2 $3 2>&1 | tail -1
}
```

Baseline — with no policies at all:

```bash
try web db 5432
try web pooler 5432
try api db 5432
```

**Watch for:** all three succeed. `web` can talk straight to the database.
Nobody granted that. **Kubernetes is open by default**, and that is the reason
NetworkPolicies exist.

## Break it: default-deny egress without DNS

The classic mistake, on purpose.

```bash
kubectl apply -f 02-egress-default-BROKEN.yaml

try api db 5432
kubectl exec -n lab07 deploy/api -- timeout 5 nslookup db 2>&1 | tail -3
```

**Watch for:** the name lookup **times out**. Everything is broken, in a way
that gives you no useful error — just hangs.

Note the shape of the failure. The pods are `Running`. Nothing restarted. No
event fired. Applications simply stop finding each other. This is why file 13
says: **always allow DNS first.**

Prove the policy is otherwise fine by using an IP directly:

```bash
DBIP=$(kubectl get pod -n lab07 -l component=db -o jsonpath='{.items[0].status.podIP}')
kubectl exec -n lab07 deploy/api -- timeout 5 nc -zv $DBIP 5432 2>&1 | tail -1
```

**Watch for:** that **succeeds**. In-namespace traffic was always allowed. Only
name resolution was blocked. That is a genuinely confusing symptom, and now you
have seen it once.

Fix it:

```bash
kubectl apply -f 03-egress-default-FIXED.yaml
try api db 5432
```

Working again — one extra rule, allowing UDP and TCP port 53 to `kube-system`.

## Do this: lock the database

```bash
kubectl apply -f 04-db-ingress.yaml
sleep 3

try api db 5432      # allowed
try web db 5432      # DENIED
```

**Watch for:** `api` connects, `web` times out.

Note the **timeout**, not "connection refused". That distinction is your
everyday diagnostic:

| Symptom | Cause |
|---|---|
| times out | a NetworkPolicy is dropping it |
| refused instantly | nothing is listening on that port |
| name not found | wrong Service name, or DNS egress blocked |

## Break it: the proxy nobody locked

The database is protected. Is it?

```bash
try web pooler 5432
```

**Watch for:** it **succeeds**. `web` cannot reach the database directly, but it
can reach the pooler — and the pooler is on the database's allowlist. So
`web → pooler → db` works, and the exclusion you just wrote protects nothing.

This is not hypothetical. It is why petnest ships a second policy with this
comment:

> the app connects to Postgres through `-pg-pooler-rw`, so the pooler needs its
> own guard — otherwise web → pooler:5432 → pg is open and the web exclusion on
> postgres-ingress is defeated.

Close it:

```bash
kubectl apply -f 05-pooler-ingress.yaml
sleep 3
try web pooler 5432     # now DENIED
try api pooler 5432     # still allowed
```

**The general rule: a proxy inherits the trust of whoever can reach it.**
Whenever you put something in front of a protected resource, protect the front
too.

## Do this: selective internet access

Right now nothing can reach the internet — the default policy only allowed DNS
and in-namespace traffic.

```bash
kubectl exec -n lab07 deploy/api -- timeout 6 curl -sS -o /dev/null -w '%{http_code}\n' https://example.com ; echo "exit=$?"
kubectl exec -n lab07 deploy/web -- timeout 6 curl -sS -o /dev/null -w '%{http_code}\n' https://example.com ; echo "exit=$?"
```

**Watch for:** both fail. Grant it to `api` only:

```bash
kubectl apply -f 06-egress-internet-api.yaml
sleep 3
kubectl exec -n lab07 deploy/api -- timeout 6 curl -sS -o /dev/null -w '%{http_code}\n' https://example.com
kubectl exec -n lab07 deploy/web -- timeout 6 curl -sS -o /dev/null -w '%{http_code}\n' https://example.com ; echo "exit=$?"
```

**Watch for:** `api` gets `200`, `web` still fails.

Two policies now select `api` for Egress, and the result is their **union** —
DNS, in-namespace, and the internet on 443. Policies only ever add. There is no
deny rule in NetworkPolicy.

This is exactly why every petnest egress file repeats:

> DNS + in-namespace egress comes from petnest-egress-default (additive union)
> — this policy ONLY adds the extra allow; do not delete the default policy in
> isolation.

Prove additivity by removing the default:

```bash
kubectl delete networkpolicy demo-egress-default -n lab07
kubectl exec -n lab07 deploy/api -- timeout 5 nslookup db 2>&1 | tail -3
```

**Watch for:** DNS breaks for `api`, because its remaining policy never
mentioned port 53. Restore it:

```bash
kubectl apply -f 03-egress-default-FIXED.yaml
```

## The metadata endpoint

```bash
kubectl exec -n lab07 deploy/api -- timeout 5 curl -sS -m 3 http://169.254.169.254/ ; echo "exit=$?"
```

**Watch for:** blocked. `169.254.0.0/16` is in the `except` list. On a real
cloud that address serves node identity and credentials — a compromised pod
reaching it is a standard privilege-escalation step. The `except` list is
security, not tidiness.

## Prove the enforcement point

Go back to the **other** cluster and apply the same policies:

```bash
kubectl config use-context kind-learn
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-workloads.yaml
kubectl wait --for=condition=available deploy --all -n lab07 --timeout=120s
kubectl apply -f 04-db-ingress.yaml
kubectl get networkpolicy -n lab07

kubectl exec -n lab07 deploy/web -- timeout 5 nc -zv db 5432 2>&1 | tail -1
```

**Watch for:** it **succeeds**, even though the policy exists and looks correct.
kindnet does not enforce NetworkPolicy.

Before you rely on policies on any cluster, confirm the CNI enforces them —
with a test exactly like this one, not by reading documentation.

```bash
kubectl delete ns lab07
kubectl config use-context kind-learn-netpol
```

## Answer these

1. You apply a default-deny egress policy and the app hangs with no errors.
   What did you forget?
2. Times out vs refused vs name-not-found — what does each tell you?
3. You block `web` from the database but leave the pooler open. What have you
   achieved?
4. Two policies select the same pod. Is the result the intersection or the
   union?
5. `kubectl get networkpolicy` shows your rules but nothing is blocked. What is
   the first thing you check?

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/network-policies.yaml` — postgres,
  pooler, opensearch, nats. Note the **third** rule on postgres-ingress
  allowing replication between cluster members; without it the standby never
  syncs.
- `petnest/deploy/helm/petnest/templates/egress-policies.yaml` — default-deny
  plus three narrow internet grants, one per service that genuinely needs it.
- `microjob/apps/web/deploy/helm/microjob/templates/network-policies.yaml` —
  the same idea with a smaller graph.

## Clean up

```bash
kubectl delete ns lab07
# and when you are finished with the whole lab set:
cd ../setup && ./down.sh
```
