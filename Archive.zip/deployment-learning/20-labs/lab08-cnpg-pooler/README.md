# Lab 08 — PostgreSQL with CNPG and a PgBouncer Pooler

**Pack file:** 14
**Time:** ~45 minutes
**Cluster:** `kind-learn` (the main one)

An operator, a replicated database, automatic failover, and the connection
pooler that stands between your app and a very hard limit.

```bash
kubectl config use-context kind-learn
```

## Step 1: install the operator

An operator teaches Kubernetes a new noun. Before this, `kind: Cluster` in the
`postgresql.cnpg.io` group means nothing to your cluster. After it, the API
server understands it and a controller acts on it.

```bash
kubectl apply --server-side -f \
  https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.24/releases/cnpg-1.24.1.yaml

kubectl wait --for=condition=available deployment/cnpg-controller-manager \
  -n cnpg-system --timeout=180s

kubectl get crd | grep cnpg
```

**Watch for:** `clusters.postgresql.cnpg.io`, `poolers.postgresql.cnpg.io`, and
others. Those CRDs are the new nouns.

The operator is installed **once per cluster**, separately from your app
charts. Your charts only create the `Cluster` and `Pooler` resources — the same
split petnest and microjob use.

## Step 2: create the database

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-cluster.yaml

kubectl get cluster -n lab08 -w        # ctrl-c when it says "Cluster in healthy state"
```

First start pulls a Postgres image and initialises the data directory — give it
a few minutes.

Look at everything you did **not** write:

```bash
kubectl get pods,svc,pvc,secrets -n lab08
```

**Watch for:**

- Pods `pg-1` and `pg-2`.
- Services `pg-rw`, `pg-ro`, `pg-r`.
- Two PVCs, one per instance — the data exists twice, on two disks.
- Secrets `pg-app`, `pg-superuser`, `pg-ca`, `pg-server`, `pg-replication`.

You wrote 30 lines. The operator produced all of that and now maintains it.

The three Services matter:

| Service | Points at | Use for |
|---|---|---|
| `pg-rw` | the current **primary** | writes, migrations |
| `pg-ro` | **replicas** only | read-only queries |
| `pg-r` | any instance | any read |

These follow the primary automatically. **Never hardcode a pod name.**

```bash
kubectl get pods -n lab08 -L cnpg.io/instanceRole
```

**Watch for:** one pod labelled `primary`, one `replica`.

## Step 3: connect

```bash
kubectl apply -f 02-pooler.yaml
kubectl apply -f 03-client.yaml
kubectl rollout status deploy/client -n lab08
kubectl get pods -n lab08 -l cnpg.io/poolerName=pg-pooler-rw
```

```bash
kubectl exec -it deploy/client -n lab08 -- psql -c 'SELECT version();'
kubectl exec -it deploy/client -n lab08 -- psql -c \
  'CREATE TABLE pets(id serial primary key, name text);'
kubectl exec -it deploy/client -n lab08 -- psql -c \
  "INSERT INTO pets(name) VALUES ('rex'),('mia');"
kubectl exec -it deploy/client -n lab08 -- psql -c 'SELECT * FROM pets;'
```

That traffic went **through PgBouncer** (`PGHOST=pg-pooler-rw`).

Confirm the replica has the data:

```bash
kubectl exec -it deploy/client -n lab08 -- psql -h pg-ro -c 'SELECT * FROM pets;'
kubectl exec -it deploy/client -n lab08 -- psql -h pg-ro -c \
  "INSERT INTO pets(name) VALUES ('nope');"
```

**Watch for:** the read works; the write fails with *"cannot execute INSERT in
a read-only transaction"*. That is the replica behaving correctly.

Check replication health from the primary:

```bash
kubectl exec -it deploy/client -n lab08 -- psql -h pg-rw -c \
  'SELECT client_addr, state, sent_lsn, replay_lsn FROM pg_stat_replication;'
```

**Watch for:** `state = streaming`. If a NetworkPolicy blocked replication
between cluster members, this table would be empty — which is why petnest's
`postgres-ingress` policy has a rule specifically for it.

## Step 4: kill the primary

```bash
kubectl get pods -n lab08 -L cnpg.io/instanceRole
PRIMARY=$(kubectl get pods -n lab08 -l cnpg.io/instanceRole=primary -o name)
echo "killing $PRIMARY"
kubectl delete $PRIMARY -n lab08

kubectl get pods -n lab08 -L cnpg.io/instanceRole -w   # ctrl-c after the roles swap
```

**Watch for:** the surviving replica is promoted to `primary` within seconds.
No human involved.

```bash
kubectl exec -it deploy/client -n lab08 -- psql -c 'SELECT * FROM pets;'
```

**Watch for:** the data is intact and the client works again — it connects to
`pg-pooler-rw`, which follows `pg-rw`, which now points at the new primary. The
connection string never changed.

This is the payoff of `instances: 2` and of never hardcoding a pod name.

## Step 5: exhaust the connections (this is the lesson)

The cluster is configured with `max_connections: "25"`.

Bypass the pooler and open connections directly:

```bash
kubectl exec -it deploy/client -n lab08 -- sh -c '
for i in $(seq 1 30); do
  psql -h pg-rw -c "SELECT pg_sleep(30)" >/dev/null 2>&1 &
done
sleep 5
psql -h pg-rw -c "SELECT 1" 2>&1 | tail -2
'
```

**Watch for:**

```
FATAL: sorry, too many clients already
```

**That is a total outage.** Not slow — refused. Nothing can connect, including
you, trying to diagnose it.

Now do the same through the pooler:

```bash
kubectl exec -it deploy/client -n lab08 -- sh -c '
for i in $(seq 1 30); do
  psql -h pg-pooler-rw -c "SELECT pg_sleep(5)" >/dev/null 2>&1 &
done
sleep 3
psql -h pg-pooler-rw -c "SELECT 1"
'
```

**Watch for:** it works. 30 clients were multiplexed onto `default_pool_size: 5`
real connections. Some waited briefly; none were refused.

Look at the pooler's own view:

```bash
POOLER=$(kubectl get pods -n lab08 -l cnpg.io/poolerName=pg-pooler-rw -o name | head -1)
kubectl exec -it $POOLER -n lab08 -c pgbouncer -- psql -p 5432 -U postgres pgbouncer -c 'SHOW POOLS;'
```

**Watch for** these columns:

- `cl_active` — clients doing something now.
- `cl_waiting` — **clients queued for a server connection. If this is above 0
  under normal load, your pool is too small.** It is the number that predicts
  an outage.
- `sv_active` / `sv_idle` — real Postgres connections in use and spare.

Sizing rule from file 14:

```
pod replicas x per-pod pool size          <= pooler max_client_conn
pooler default_pool_size x databases x users <= postgres max_connections - headroom
```

Always keep headroom so you can still open a `psql` session during an incident.

## Step 6: what transaction mode breaks

Session-level state does not survive transaction pooling. Prove it:

```bash
kubectl exec -it deploy/client -n lab08 -- psql -h pg-pooler-rw -c \
  "SELECT pg_advisory_lock(42);" -c "SELECT objid FROM pg_locks WHERE locktype='advisory';"
```

**Watch for:** the lock does not appear in the second statement — each ran on a
possibly different server connection, so the session-scoped lock was lost.

Now the same directly against the primary:

```bash
kubectl exec -it deploy/client -n lab08 -- psql -h pg-rw -c \
  "SELECT pg_advisory_lock(42);" -c "SELECT objid FROM pg_locks WHERE locktype='advisory';"
```

**Watch for:** the lock is there.

This is precisely why petnest's migrate Job connects to `petnest-pg-rw`
**directly**, and why the `pooler-ingress` policy does not list it. Migrations
use advisory locks, `CREATE INDEX CONCURRENTLY` and temp tables — all of which
transaction pooling breaks.

Same warning for your app: with `node-postgres`, `pgx` or an ORM behind a
transaction pooler, **disable prepared-statement caching**, or you will get
intermittent "prepared statement does not exist" errors under load.

## Step 7: the CA

```bash
kubectl get secret pg-ca -n lab08 -o jsonpath='{.data}' | tr ',' '\n' | cut -d'"' -f2
```

**Watch for:** the Secret holds **both** `ca.crt` and `ca.key`. Mounting the
whole Secret would hand every app pod the CA private key — the power to mint
certificates the cluster trusts. petnest mounts one key with `items:` and its
helper says: *never drop the `items:` selector.* You did this hands-on in
lab 02.

## Answer these

1. Your app's connection string points at `pg-1`. The primary fails over. What
   happens, and what should the string have been?
2. `SHOW POOLS` reports `cl_waiting: 14`. What does that mean and what are your
   three options?
3. Why does a migration job bypass the pooler?
4. Is a replica a backup? Explain in one sentence.
5. Why must the pooler have resource requests set?

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/cnpg-cluster.yaml` — tuned
  `postgresql.parameters`, `managed.roles` with CREATEDB/CREATEROLE for the
  migrate job, soft anti-affinity plus topology spread, and the note about the
  selector needing **both** labels so poolers are not counted as instances.
- `petnest/deploy/helm/petnest/templates/cnpg-pooler.yaml` — the resources
  comment, word for word.
- `microjob/.../values.yaml` — `cnpg.pooler.readReplica` and the per-tier
  `dbPool: { write, read }` sizes.

## Clean up

```bash
kubectl delete ns lab08
kubectl delete -f https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.24/releases/cnpg-1.24.1.yaml
```
