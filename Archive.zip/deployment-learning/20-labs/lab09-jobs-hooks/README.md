# Lab 09 — Jobs, Init Containers and Helm Hooks

**Pack file:** 11
**Time:** ~35 minutes
**Cluster:** `kind-learn`

Run-once work: migrations and seeds. How to order them, how to make them safe
to run on every deploy, and what happens when they are not.

## Step 1: a plain Job

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-plain-job.yaml

kubectl get jobs,pods -n lab09
kubectl wait --for=condition=complete job/hello-once -n lab09 --timeout=60s
kubectl logs job/hello-once -n lab09
```

**Watch for:** the pod goes to `Completed`, not `Running`. A Deployment would
have restarted it; a Job is finished.

`ttlSecondsAfterFinished: 300` means the Job object deletes itself five minutes
later. Without it, finished Jobs pile up in the namespace forever — one of the
most common sources of clutter in a long-lived cluster.

## Step 2: a Job that fails

```bash
kubectl apply -f 02-failing-job.yaml
kubectl get pods -n lab09 -l job-name=always-fails -w   # ctrl-c after ~90s
```

**Watch for:** three pods total, created with growing gaps between them —
roughly 10s, then 20s. That is exponential backoff. After `backoffLimit: 2` is
exceeded, the Job is marked Failed and stops trying.

```bash
kubectl describe job always-fails -n lab09 | tail -12
kubectl delete job always-fails -n lab09
```

The important detail for real deploys: a **failed migration Job blocks the
release**. That is why microjob's production workflow deletes stale migration
Jobs before deploying:

```yaml
kubectl delete jobs -n "${TARGET}" -l app=migrate --ignore-not-found=true
```

## Step 3: hooks in weighted order

Install the chart. Read `pipeline/templates/` first — the annotations are the
whole lesson.

```bash
helm upgrade --install demo ./pipeline -n lab09
```

While it runs, watch in a second terminal:

```bash
kubectl get pods -n lab09 -w
```

**Watch for**, in this exact order:

1. `store` starts, and takes 20 seconds to become ready.
2. `migrate-1` appears. Its **init container** sits in `Init:0/1`, printing
   `waiting for store:5432 ...` until the store answers.
3. Only then does the migrate container run.
4. `admin-seed-1` runs — after migrate finishes.
5. `content-seed-1` runs last.

```bash
kubectl logs job/migrate-1      -n lab09 -c wait-for-store
kubectl logs job/migrate-1      -n lab09
kubectl logs job/admin-seed-1   -n lab09
kubectl logs job/content-seed-1 -n lab09
```

Two mechanisms produced that order, and they are different things:

- **`hook-weight`** (-5, 0, 1) ordered the three Jobs relative to each other.
  Lower runs first. Helm waits for each weight to complete before starting the
  next.
- **The init container** made migrate wait for a dependency that was not ready
  yet. Weights order *your* hooks; init containers wait on the *world*.

petnest uses exactly this pair: `migrate` at -5 with a `wait-for-db` init
container, `admin-seed` at 0, `content-seed` at 1.

## Step 4: upgrade — hooks run again

```bash
helm upgrade demo ./pipeline -n lab09
kubectl get jobs -n lab09
```

**Watch for:** `migrate-2`, `admin-seed-2`, `content-seed-2`. The revision
number is in the name.

Two things made that work:

- **`{{ .Release.Revision }}` in the name.** Job specs are largely immutable —
  reusing a name gives you `field is immutable` on the second deploy.
- **`hook-delete-policy: before-hook-creation`.** Helm removes the previous
  hook Job just before creating the new one.

Remove either one and the second deploy fails. Try it if you want the error
burned in: delete the `hook-delete-policy` line, change the name to a fixed
`migrate`, and upgrade twice.

```bash
kubectl logs job/admin-seed-2 -n lab09
```

**Watch for:** `Admin already exists - nothing to do`. It ran again and changed
nothing. **That is the property that makes hooks safe.**

## Step 5: what non-idempotent looks like

```bash
kubectl apply -f 03-non-idempotent-job.yaml
kubectl wait --for=condition=complete job/bad-seed -n lab09 --timeout=60s
kubectl logs job/bad-seed -n lab09

kubectl delete job bad-seed -n lab09
kubectl apply -f 03-non-idempotent-job.yaml
kubectl wait --for=condition=complete job/bad-seed -n lab09 --timeout=60s
```

Every run inserts again. As a Helm hook this would run on **every deploy**,
duplicating rows quietly. Nobody notices until a report is wrong months later.

Make seeders idempotent by construction:

- `INSERT ... ON CONFLICT DO NOTHING`
- check-then-insert, like the admin seeder
- `--create-only`, like the wiki content seeder: reference data converges every
  deploy, but a page an admin edited is never reverted

That last distinction is worth re-reading in petnest's `values.yaml`:

> taxonomy, species, breeds and attribute definitions still converge on every
> deploy, but a wiki page that already exists is skipped, so an admin's edit is
> never reverted.

## Step 6: turn a hook off

```bash
helm upgrade demo ./pipeline -n lab09 --set contentSeed.enabled=false
kubectl get jobs -n lab09
```

**Watch for:** no `content-seed-3`. The `{{- if .Values.contentSeed.enabled }}`
guard means the object is never rendered — the same switch petnest exposes as
`contentSeed.enabled` and `adminSeed.enabled`.

## Step 7: why setup belongs in a Job, not in startup code

Imagine index creation on service startup instead of in a Job. Scale to 3
replicas and three pods race to create the same index at boot. Two fail, one
wins, and which one is random.

petnest is explicit about this for OpenSearch:

> index mappings are created by a separate post-upgrade hook Job, never on
> service startup.

**One Job = exactly once per deploy. Startup code = once per replica, racing.**

## Migration safety, which no lab can enforce for you

During a rolling update, old and new code run **at the same time**. Use
expand/contract:

1. **Expand** — add the nullable column or the new table. Deploy. Old code
   ignores it, new code can use it.
2. **Backfill** — in batches, in a background job, not inside the deploy.
3. **Contract** — in a *later* release, once no old pods remain, add the
   constraint or drop the old column.

Never in one step: rename a column, drop a column still read by running pods,
or add a NOT NULL column without a default.

Also set `lock_timeout` and `statement_timeout` in the migration session, so a
blocked `ALTER TABLE` fails fast instead of freezing the site behind a lock.

Before every production deploy, ask: *if I roll the code back in ten minutes,
does this migration still work?* Code rolls back in seconds. Schemas do not.

## Answer these

1. What are the two different mechanisms that ordered the three Jobs in step 3?
2. Why does the Job name include `.Release.Revision`?
3. What does `hook-delete-policy: before-hook-creation` prevent?
4. Why must a seeder be idempotent, given that hooks run on every deploy?
5. You need to drop a column. What is the safe two-release sequence?

## Back to the real projects

- `petnest/deploy/helm/petnest/templates/migrate-job.yaml` — weight -5,
  `wait-for-db` init container, and the `DB_SSLMODE: prefer` comment explaining
  why this Job needs no CA mount.
- `petnest/deploy/helm/petnest/templates/admin-seed-job.yaml` (weight 0),
  `content-seed-job.yaml` (weight 1), `search-index-bootstrap.yaml`.
- `microjob/.github/workflows/web-production.yml` — the
  `Cleanup stale migration jobs` step.

## Clean up

```bash
helm uninstall demo -n lab09
kubectl delete ns lab09
```
