# Lab 10 — Resources, QoS and Autoscaling

**Pack file:** 10
**Time:** ~40 minutes
**Cluster:** `kind-learn`

Where most real production pain lives. You will get a pod OOMKilled, watch
another get silently throttled, make one unschedulable on an idle cluster, and
drive an HPA.

## Step 1: QoS classes

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-qos-classes.yaml
sleep 10
kubectl get pods -n lab10 -o custom-columns=NAME:.metadata.name,QOS:.status.qosClass
```

**Watch for:**

```
NAME             QOS
qos-besteffort   BestEffort
qos-burstable    Burstable
qos-guaranteed   Guaranteed
```

You never set a QoS field. Kubernetes derived it from your requests and limits:

| Class | Condition | Evicted |
|---|---|---|
| Guaranteed | requests == limits, every container | last |
| Burstable | requests set, limits higher | middle |
| BestEffort | nothing set | **first** |

This is exactly why petnest's pooler carries this comment:

> With none, pgbouncer runs as BestEffort QoS and is the first pod the kubelet
> evicts under node memory pressure — and every database query goes through it.

**Rule: nothing on the critical path may be BestEffort.**

## Step 2: memory over the limit = killed

```bash
kubectl apply -f 02-oomkill.yaml
sleep 25
kubectl get pod memory-hog -n lab10
kubectl describe pod memory-hog -n lab10 | grep -iA4 'last state'
```

**Watch for:**

```
Last State: Terminated
  Reason:   OOMKilled
  Exit Code: 137
```

and `RESTARTS` climbing toward `CrashLoopBackOff`.

No warning, no slowdown. The process asked for 200MB against a 64Mi limit and
the kernel killed it. Exit code 137 = killed by SIGKILL (128 + 9) — memorise
that number, it appears constantly.

```bash
kubectl delete pod memory-hog -n lab10
```

## Step 3: CPU over the limit = slowed, not killed

```bash
kubectl apply -f 03-cpu-throttle.yaml
sleep 30
kubectl top pod cpu-hog -n lab10
kubectl get pod cpu-hog -n lab10
```

**Watch for:** CPU pinned at roughly `200m` — the limit — while the process is
trying to use 2000m. `STATUS` is `Running`, `RESTARTS` is `0`.

**Nothing is reported as wrong.** The app is simply ten times slower than it
should be. There is no event, no log line, no restart. This is why CPU
throttling is so hard to diagnose, and why file 10 says: **be generous with CPU
limits, careful with memory limits.**

```bash
kubectl delete pod cpu-hog -n lab10
```

## Step 4: requests fill nodes, usage does not

```bash
kubectl top nodes
```

**Watch for:** your nodes are almost idle.

```bash
kubectl apply -f 04-unschedulable.yaml
sleep 10
kubectl get pod too-big -n lab10
kubectl describe pod too-big -n lab10 | tail -8
```

**Watch for:** `Pending`, with `0/3 nodes are available: Insufficient cpu`.

An idle cluster that cannot schedule a pod. The scheduler never looks at real
usage — only at what is **reserved**. Look at the reservations:

```bash
kubectl describe node kind-worker | sed -n '/Allocated resources/,/^Events/p'
```

**Watch for** the `Requests` percentages, which have nothing to do with the
usage you saw in `kubectl top`. That gap is a phantom reservation, and it is
what your `usageSampler` exists to eliminate:

```
cpu requests      6899m (88%)   <- what the scheduler sees
cpu actual usage   491m  (6%)   <- what is really happening
```

```bash
kubectl delete pod too-big -n lab10
```

## Step 5: install metrics-server

An HPA on CPU needs metrics-server. kind does not ship it, and its kubelet
certificates are self-signed, so the standard patch is required:

```bash
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

kubectl patch deployment metrics-server -n kube-system --type=json -p \
  '[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'

kubectl wait --for=condition=available deployment/metrics-server -n kube-system --timeout=180s
kubectl top nodes
```

`--kubelet-insecure-tls` is for this throwaway cluster only. Never on a real
one.

If `kubectl top` errors on any cluster, **your HPAs are doing nothing** — they
show `<unknown>` and never scale. Worth checking on your real clusters.

## Step 6: drive the HPA

```bash
kubectl apply -f 05-hpa-target.yaml
kubectl rollout status deploy/worker -n lab10
kubectl get hpa -n lab10
```

**Watch for:** `TARGETS` showing something like `0%/50%` once metrics arrive
(give it a minute; `<unknown>` at first is normal).

Watch in one terminal:

```bash
kubectl get hpa,pods -n lab10 -w
```

Generate load in another:

```bash
kubectl run load --rm -it --image=busybox:1.36 -n lab10 --restart=Never -- \
  sh -c 'while true; do wget -q -O- http://worker/ >/dev/null; done'
```

**Watch for:** `TARGETS` climbing well past 50%, then `REPLICAS` rising — 1, 2,
4, up toward 6. Scaling decisions are made about every 15 seconds.

```bash
kubectl describe hpa worker -n lab10 | tail -15
```

**Watch for** the events explaining each decision.

Now stop the load (`ctrl-c` the load generator) and keep watching.

**Watch for:** CPU drops immediately, but replicas stay high for a while before
coming down. That is `scaleDown.stabilizationWindowSeconds: 120`. The default
is 300s. Scaling down slowly is deliberate — it prevents flapping, where a
brief dip throws away capacity you need again seconds later.

## The detail everyone gets wrong

`averageUtilization: 50` means **50% of the CPU request**, not 50% of a core.

The request here is `100m`, so the HPA targets `50m` per pod. If someone
"tidies up" the request to `500m` without touching the HPA, the trigger point
silently becomes `250m` — five times higher — and the app stops scaling when it
should.

**Requests and HPA targets are coupled. Never change one without the other.**

Two more consequences:

- The HPA fights a fixed `replicas:` in your chart. Once an HPA owns a
  Deployment, Helm must not keep setting `replicas` on every deploy. petnest
  avoids this by feeding the same values entry into `minReplicas`.
- CPU is a poor signal for queue workers — they can be busy without being
  CPU-bound. Scale those on queue depth (KEDA) instead.

## Step 7: the safety net

```bash
kubectl apply -f 06-limitrange.yaml

kubectl run nolimits --image=busybox:1.36 -n lab10 --restart=Never -- sleep 3600
sleep 5
kubectl get pod nolimits -n lab10 -o jsonpath='{.status.qosClass}{"\n"}'
kubectl get pod nolimits -n lab10 -o jsonpath='{.spec.containers[0].resources}{"\n"}'
```

**Watch for:** `Burstable`, with requests and limits filled in — even though
you specified none. Without the LimitRange it would have been `BestEffort`.

A LimitRange in every namespace is cheap insurance against the pooler problem.

## How to pick numbers for real

1. Start generous.
2. Measure for a week under real traffic — that is what microjob's
   `usageSampler` is for, sampling every pod every 60 seconds.
3. Set **request ≈ p95 of real usage**.
4. Set **memory limit ≈ peak × 1.5**.
5. Be generous with CPU limits, careful with memory limits.

petnest's NATS shows the result of doing this properly:

> Sized from measured peak, not from a snapshot: 4m CPU / 16Mi in production
> and 4m / 17Mi in staging, over 35350 samples. The old 50m / 128Mi request was
> mostly phantom reservation.

## Answer these

1. A pod exits with code 137 and restarts. What happened and what do you change?
2. A service is slow but healthy, no restarts, no errors. What do you check
   first?
3. Your cluster is 6% CPU-utilised but a new pod is Pending. Why?
4. Someone raises a Deployment's CPU request from 100m to 500m and leaves the
   HPA at 50%. What breaks?
5. Why must the PgBouncer pooler never be BestEffort?

## Back to the real projects

- `microjob/.../templates/usage-sampler.yaml` and the `usageSampler:` values
  block — measured peaks instead of a lucky `kubectl top`.
- `petnest/deploy/helm/petnest/templates/cnpg-pooler.yaml` — the BestEffort
  comment.
- `petnest/deploy/helm/petnest/templates/nats.yaml` — resources sized from
  35350 samples.
- `petnest/deploy/helm/petnest/templates/hpa.yaml` and microjob's per-workload
  `hpa:` blocks.

## Clean up

```bash
kubectl delete ns lab10
# and when you are done with everything:
cd ../setup && ./down.sh
```
