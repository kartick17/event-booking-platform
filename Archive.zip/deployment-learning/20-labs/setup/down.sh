#!/usr/bin/env bash
# Delete both lab clusters.
set -uo pipefail
for c in learn learn-netpol; do
  if kind get clusters 2>/dev/null | grep -qx "$c"; then
    echo "==> Deleting cluster '$c'"
    kind delete cluster --name "$c"
  fi
done
echo "Done."
