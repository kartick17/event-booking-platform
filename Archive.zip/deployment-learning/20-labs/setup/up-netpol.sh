#!/usr/bin/env bash
# Create the lab-07 cluster with Calico, which actually enforces NetworkPolicy.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if kind get clusters 2>/dev/null | grep -qx learn-netpol; then
  echo "Cluster 'learn-netpol' already exists."
else
  echo "==> Creating kind cluster 'learn-netpol' (no default CNI)"
  kind create cluster --config "${SCRIPT_DIR}/kind-netpol-cluster.yaml"
fi

kubectl config use-context kind-learn-netpol

echo "==> Installing Calico"
kubectl apply -f https://raw.githubusercontent.com/projectcalico/calico/v3.28.2/manifests/calico.yaml

echo "==> Waiting for nodes to become Ready (Calico must start first, up to 5 min)"
kubectl wait --for=condition=Ready nodes --all --timeout=300s

echo
kubectl get nodes
echo
echo "Ready. NetworkPolicy is now ENFORCED on this cluster."
echo "Next: cd ../lab07-network-policy && cat README.md"
