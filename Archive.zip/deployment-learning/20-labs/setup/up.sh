#!/usr/bin/env bash
# Create the main lab cluster and install ingress-nginx.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if kind get clusters 2>/dev/null | grep -qx learn; then
  echo "Cluster 'learn' already exists. Delete it with ./down.sh first."
else
  echo "==> Creating kind cluster 'learn' (3 nodes)"
  kind create cluster --config "${SCRIPT_DIR}/kind-cluster.yaml"
fi

kubectl config use-context kind-learn

echo "==> Installing ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.11.3/deploy/static/provider/kind/deploy.yaml

echo "==> Waiting for the ingress controller to be ready (up to 3 min)"
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=180s

echo
echo "Ready. Nodes:"
kubectl get nodes
echo
echo "Ingress reachable at http://localhost  (send a Host header)"
echo "Next: cd ../lab01-deployment-service && cat README.md"
