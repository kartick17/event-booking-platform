# Java Concurrency — 17 Interview Questions (Rapid-Fire Notes)

**Priority: Interview-critical** — rapid-fire revision format.

---

## Core Concurrency Concepts & OS Internals

### Q1. Independent Process vs Thread-based Multithreading
A **process** is an isolated program with its own memory, heap, and file handles — OS gives it a separate address space. **Threads** live *inside* one process and share heap + code but have their own stack and program counter. So inter-thread talk is cheap (shared memory), but inter-process talk needs IPC (sockets, pipes).

### Q2. Multitasking vs Multithreading
**Multitasking** = OS runs many *processes* together (Chrome + IntelliJ + Spotify). **Multithreading** = one process runs many *threads* together (one Spring Boot app handling 200 HTTP requests at once). Multitasking is process-level, multithreading is thread-level.

### Q3. Context Switching & Scheduler
The **OS scheduler** picks which thread runs on a CPU core for a tiny time slice (~10ms). When time is up or thread blocks, the OS does a **context switch** — saves the thread's registers/PC/stack pointer and loads the next thread's. This is why we *feel* everything runs in parallel even on a 1-core CPU.

---

## Thread Creation & Execution Mechanics

### Q4. Primary types of thread creation
**(1) extends Thread** — bad, burns your only inheritance slot. **(2) implements Runnable** — clean, preferred. **(3) Callable + Future** — when you need a return value or exception. **(4) ExecutorService** — production standard, reuses threads. Use ExecutorService in real projects; never `new Thread()` per request.

```java
// Real: process payment webhook events without blocking the HTTP thread
ExecutorService pool = Executors.newFixedThreadPool(10);
pool.submit(() -> paymentService.process(webhookPayload));
```

### Q5. Why `start()` and not `run()`?
`start()` asks the **JVM to create a new OS thread** and *then* calls `run()` on that new thread. If you call `run()` directly, it just runs in the *current* thread — no new thread is born, no parallelism. `start()` can also only be called once per thread.

### Q6. Thread Scheduler in Java
It's the **JVM's component** (which delegates to the OS scheduler) that decides which Runnable thread gets CPU next. It uses **priority + algorithm (preemptive or time-slicing)**, but exact behavior is **JVM/OS-dependent** — so never write code that depends on scheduling order.

### Q7. Thread class vs Runnable interface
**Thread** is a class — extending it locks your class from extending anything else (Java has no multiple inheritance). **Runnable** is a functional interface — you only define the *task*, then hand it to a Thread or Executor. Runnable separates *what to run* from *how it runs*, which is why all modern APIs (ExecutorService, CompletableFuture) take Runnable, not Thread.

---

## Thread Lifecycle Control

### Q8. yield() vs join() vs sleep()
- **yield()** — hint to scheduler "I'm okay pausing, give someone else a turn" (not guaranteed). Stays Runnable.
- **sleep(ms)** — blocks current thread for fixed time, releases CPU but **keeps locks**.
- **join()** — current thread waits until target thread *finishes*. Used to wait for a worker to complete.

### Q9. Where do we call join() and its overloads?
Call it on the **thread you want to wait for**, from the thread that needs to wait. Three forms: `join()` (wait forever), `join(ms)` (wait up to ms), `join(ms, nanos)` (fine-grained). All throw `InterruptedException`.

```java
// Real: parallel report — wait for both DB fetches before merging
Thread orders = new Thread(() -> data.put("orders", orderRepo.fetch()));
Thread users  = new Thread(() -> data.put("users", userRepo.fetch()));
orders.start(); users.start();
orders.join(); users.join();   // main thread waits for both
return reportBuilder.merge(data);
```

### Q10. yield() with maximum priority
`yield()` only hints to give CPU to **threads of equal or higher priority**. If your thread is already at `MAX_PRIORITY` (10) and no other thread has the same priority, the scheduler will likely **re-pick the same thread** — so `yield()` becomes a no-op. Don't rely on it for fairness.

---

## Synchronization & Thread Safety

### Q11. What is Synchronization and why needed?
Synchronization makes sure **only one thread at a time** enters a critical section, by acquiring a lock on an object's **monitor**. Needed to prevent **race conditions** when multiple threads read/write shared state (e.g. two threads incrementing the same counter and losing updates).

```java
// Real: prevent double-booking of a seat
public synchronized boolean bookSeat(Long seatId, Long userId) {
    if (seatRepo.isAvailable(seatId)) {
        seatRepo.assign(seatId, userId);
        return true;
    }
    return false;
}
```

### Q12. Synchronized Block vs Synchronized Method
**Method** — locks the whole method on `this` (or `Class` if static). Simple but coarse — blocks even threads that don't touch shared state. **Block** — locks only a specific code region on a specific object you choose. Block is **finer-grained, faster, and lets you lock on a private `Object lock = new Object();`** which is safer than locking `this`.

---

## Advanced Concurrency & Modern Alternatives

### Q13. Interfaces & Lambdas simplifying multithreading
Because `Runnable` and `Callable` are **functional interfaces** (one abstract method), you can pass a lambda instead of writing an anonymous class. This removes 4–5 lines of boilerplate and reads like "run this code in a thread".

```java
// Old: 6 lines anonymous class. New: 1 line lambda.
executor.submit(() -> emailService.sendInvoice(orderId));
```

### Q14. Thread Group and why legacy?
A **ThreadGroup** groups threads so you can call `interrupt()` or `setMaxPriority()` on all of them. It's **legacy** because its API is broken (no lifecycle control, weak isolation, methods like `suspend/stop` are deprecated). Today we use **ExecutorService** — it gives clean shutdown, pooling, and futures.

### Q15. ExecutorService and what it solves
ExecutorService is a **thread pool manager** — you submit tasks, it reuses a fixed set of threads. It solves: (1) cost of creating threads per request, (2) no upper bound on threads (OOM risk), (3) no return values, (4) no clean shutdown. Always use it instead of `new Thread()` in production.

```java
// Real: bulk-send 10k notifications, capped at 20 concurrent sends
ExecutorService pool = Executors.newFixedThreadPool(20);
users.forEach(u -> pool.submit(() -> notifier.send(u)));
pool.shutdown();
pool.awaitTermination(5, TimeUnit.MINUTES);
```

### Q16. Main problem with Runnable
`Runnable.run()` returns **void** and **cannot throw checked exceptions**. So you can't get a result back from the worker thread, and you must wrap any checked exception in a RuntimeException — losing type safety and clean error handling.

### Q17. How Callable solves Runnable's problems
`Callable<V>` has `V call() throws Exception` — it **returns a value** and **can throw checked exceptions**. You submit it to an ExecutorService and get a `Future<V>`; calling `future.get()` blocks until the result is ready (or rethrows the worker's exception).

```java
// Real: fetch user profile + recent orders in parallel, then combine
Future<User>        userF   = pool.submit(() -> userRepo.findById(id));
Future<List<Order>> orderF  = pool.submit(() -> orderRepo.findRecent(id));
return new Dashboard(userF.get(), orderF.get());   // .get() re-throws as ExecutionException
```

---

**Memorize this:** In modern Java, never `new Thread()` — submit `Runnable`/`Callable` to an `ExecutorService`, use `join()`/`Future.get()` to wait, and lock the smallest possible block on a private lock object.

**Next likely topics:** `synchronized` vs `ReentrantLock` (with `tryLock`/fairness), or `volatile` + Java Memory Model (happens-before, visibility) — both are top MNC interview hits.
