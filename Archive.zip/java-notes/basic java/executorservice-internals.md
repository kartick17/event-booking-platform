# `ExecutorService` & `ThreadPoolExecutor` Internals

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

**`ExecutorService`** is an interface for **submitting tasks to a managed pool of threads**. You hand it a `Runnable` or `Callable`; it picks an existing worker thread (or creates one) to run the task. You never `new Thread()` directly.

The concrete workhorse behind almost every executor you'll use is **`ThreadPoolExecutor`** — even the `Executors.newFixedThreadPool(n)` factory just returns a pre-configured `ThreadPoolExecutor`.

A `ThreadPoolExecutor` has **7 knobs** (all in the full constructor):
- `corePoolSize` — minimum threads kept alive even when idle.
- `maximumPoolSize` — hard ceiling on threads.
- `keepAliveTime` — how long extra (above core) threads sit idle before dying.
- `workQueue` — `BlockingQueue<Runnable>` where pending tasks wait.
- `threadFactory` — how new worker threads are created (name, daemon, priority).
- `handler` — `RejectedExecutionHandler`: what to do when the pool can't accept more.

Why it exists: creating a `Thread` per task is expensive (OS call, ~1MB stack, GC pressure) and unbounded — you can OOM by launching too many. A pool **reuses** threads and **bounds** concurrency, so 10,000 tasks can be handled by 50 reusable workers.

> **Interview definition (say this out loud):** "`ExecutorService` is the standard interface for submitting tasks to a managed thread pool. The real engine is `ThreadPoolExecutor` — it has core and max pool sizes, a `BlockingQueue` for pending work, a keep-alive time for elastic threads, a thread factory, and a rejection policy. The dispatch rule is the trap most people get wrong: if pool has < core threads it spawns a new one, else it queues; only if the queue is *full* does it spawn up to max; if that's full too, the rejection policy fires. That order is why an unbounded `LinkedBlockingQueue` makes the max-pool setting completely useless."

---

## 2. Under the Hood

### 2.1 The seven constructor parameters

```java
new ThreadPoolExecutor(
    int corePoolSize,
    int maximumPoolSize,
    long keepAliveTime,
    TimeUnit unit,
    BlockingQueue<Runnable> workQueue,
    ThreadFactory threadFactory,
    RejectedExecutionHandler handler
);
```

| Parameter | Meaning | Production tip |
|---|---|---|
| `corePoolSize` | Threads kept warm even when idle | Set to expected steady-state concurrency |
| `maximumPoolSize` | Absolute ceiling | Set based on downstream capacity, not "more is better" |
| `keepAliveTime` | Idle time before above-core threads die | Set `allowCoreThreadTimeOut(true)` to make core elastic too |
| `workQueue` | Where queued tasks wait | The single biggest tuning decision — see 2.4 |
| `threadFactory` | Worker creation hook | Always set names (`"order-worker-%d"`) for jstack debuggability |
| `handler` | What to do when full | Default is `AbortPolicy` — throws `RejectedExecutionException` |

### 2.2 The dispatch rule (memorize this exact order)

When you call `executor.execute(task)`:

```
1. currentThreads < corePoolSize?
   → Create a new thread and run the task on it. Even if other workers are idle.
2. Else, can we offer the task to the workQueue?
   → Add to queue. A worker will pick it up.
3. Else (queue is full), currentThreads < maximumPoolSize?
   → Create a new thread and run the task on it.
4. Else → call RejectedExecutionHandler.
```

This order has a huge consequence: **the pool only grows past `corePoolSize` when the queue is full**. With an unbounded queue (`new LinkedBlockingQueue<>()` — the default!), the queue is *never* full, so the pool never exceeds `corePoolSize`. `maximumPoolSize` becomes a lie. This is the #1 production bug with `Executors.newFixedThreadPool`.

### 2.3 The packed control state (HotSpot trick)

`ThreadPoolExecutor` stores **both the run state and the worker count in a single `AtomicInteger`** called `ctl`:

```
high 3 bits: run state    (RUNNING, SHUTDOWN, STOP, TIDYING, TERMINATED)
low 29 bits: worker count (up to ~500M)
```

Why? So state transitions (e.g., "go from RUNNING to SHUTDOWN and decrement workers") happen in a **single CAS** without locks. This is a textbook lock-free pattern — and one reason `ThreadPoolExecutor` scales well under heavy submission.

Run states (in order):
- **RUNNING** — accepts new tasks, runs queued tasks.
- **SHUTDOWN** — rejects new tasks, drains the queue, then terminates.
- **STOP** — rejects new tasks, drops the queue, interrupts running workers.
- **TIDYING** — all tasks done, all workers gone; runs `terminated()` hook.
- **TERMINATED** — `terminated()` returned; `awaitTermination()` callers wake.

### 2.4 Choice of `BlockingQueue` — the most consequential decision

| Queue | Behavior | Use when |
|---|---|---|
| `LinkedBlockingQueue` (unbounded) | Infinite — never rejects, pool stays at core | **Dangerous default** — OOM risk if producers outrun consumers |
| `LinkedBlockingQueue(capacity)` | Bounded FIFO | Bursty workload; backpressure when full |
| `ArrayBlockingQueue(capacity)` | Bounded, array-backed, slightly less overhead | Same as above; fixed capacity from day one |
| `SynchronousQueue` | Zero capacity — **direct handoff** | Cached pools — every submission spawns a thread if needed |
| `PriorityBlockingQueue` | Ordered by priority | Some tasks must run before others; loses FIFO |
| `DelayQueue` | Each task has a delay | Scheduled executors (`ScheduledThreadPoolExecutor`) |

**Critical pairing rule:**
- Unbounded queue + small core → memory bomb under load.
- Bounded queue + small max → fast rejection (good for backpressure).
- `SynchronousQueue` + large max → cached pool, can spawn unboundedly.
- Bounded queue + bounded max + sensible rejection = production-safe.

### 2.5 Rejection policies — what happens when the pool is full

| Policy | What it does |
|---|---|
| `AbortPolicy` (default) | Throws `RejectedExecutionException` — caller knows immediately |
| `CallerRunsPolicy` | Runs the task on the **submitting thread** — natural backpressure, slows producers |
| `DiscardPolicy` | Silently drops the task. Production trap — invisible loss |
| `DiscardOldestPolicy` | Drops the head of the queue, retries the new task |

`CallerRunsPolicy` is the senior pick for HTTP servers: when the pool is saturated, the Tomcat thread runs the task itself, which means it can't accept the next request until done — a self-limiting backpressure loop. Slow but no drops, no OOM.

### 2.6 The `Executors.newXxx` factories — and why most are traps

| Factory | Equivalent ThreadPoolExecutor | Trap |
|---|---|---|
| `newFixedThreadPool(n)` | core=n, max=n, **unbounded LinkedBlockingQueue** | OOM under load — queue grows forever |
| `newCachedThreadPool()` | core=0, **max=Integer.MAX_VALUE**, SynchronousQueue, 60s keep-alive | Unbounded thread count — can spawn thousands |
| `newSingleThreadExecutor()` | core=1, max=1, unbounded queue | Same OOM risk as fixed |
| `newScheduledThreadPool(n)` | DelayQueue, schedules `Runnable`s | Silently swallows exceptions — top silent-failure source |
| `newWorkStealingPool()` | `ForkJoinPool` — work-stealing, good for CPU-bound | Doesn't behave like a normal `ThreadPoolExecutor` |

Production advice: **construct `ThreadPoolExecutor` directly**. Pick a bounded queue, a sensible max, name the threads, and choose a rejection policy. The factory methods optimize for "quick to write", not "safe to operate".

### 2.7 Sizing the pool (Little's Law, in plain terms)

For **CPU-bound** work: `threads ≈ cores + 1` (one spare to ride out cache misses).

For **I/O-bound** work, use the **Brian Goetz formula**:
```
threads = cores × cpuUtilization × (1 + waitTime / cpuTime)
```

Concrete: 8 cores, 90% CPU target, each task waits 100ms on I/O for every 10ms of CPU →
`threads ≈ 8 × 0.9 × (1 + 100/10) = 79`. That's why "default 200 Tomcat threads" is roughly right for a typical I/O-bound microservice.

With **virtual threads (Java 21+)**, this whole calculation goes away — you size by RAM, not by thread budget.

### 2.8 Shutdown — `shutdown()` vs `shutdownNow()`

```java
pool.shutdown();                            // refuse new tasks, finish queued ones
pool.awaitTermination(30, TimeUnit.SECONDS);
if (!pool.isTerminated()) {
    pool.shutdownNow();                     // interrupt running, drop queued
    pool.awaitTermination(5, TimeUnit.SECONDS);
}
```

- `shutdown()` — sets state to SHUTDOWN. No new submissions accepted; queued tasks finish. Already-running tasks are **not** interrupted.
- `shutdownNow()` — sets state to STOP. Drains the queue (returns the dropped tasks), interrupts all workers. Tasks must respond to interrupt or they keep running.
- Always call **`awaitTermination`** afterward with a deadline. Without it, JVM may exit while tasks are mid-flight (if pool threads are daemon) or hang (if non-daemon).

### 2.9 Common silent-failure source

`ScheduledExecutorService` (and `ThreadPoolExecutor` via `submit`) **swallows exceptions** thrown by scheduled tasks — the next scheduled run is **skipped silently**. The fix is to wrap every scheduled task in a try/catch that logs:

```java
scheduled.scheduleAtFixedRate(() -> {
    try { doWork(); }
    catch (Throwable t) { log.error("scheduled task failed", t); }
}, 0, 10, TimeUnit.SECONDS);
```

Top-3 cause of "the cron stopped running and no one noticed" outages.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| Background task runner | None native — `worker_threads`, BullMQ, or just the event loop | `ExecutorService` |
| "Pool size" | `UV_THREADPOOL_SIZE` (default 4) for libuv I/O ops | `corePoolSize` / `maximumPoolSize` |
| Bounded queue / backpressure | Manual — BullMQ rate limits, or `p-limit` | `BlockingQueue` capacity + rejection policy |
| "Pool is full" handling | Reject the request, return 503 | `RejectedExecutionHandler` (Abort, CallerRuns, etc.) |
| Graceful shutdown | `SIGTERM` → drain queues | `shutdown()` + `awaitTermination()` |

### Where the comparison breaks down

- Node's libuv pool is a fixed 4 threads for blocking I/O (fs, crypto). You don't tune it per task type — it's a global. Java's `ExecutorService` is **per-purpose**: one pool for DB, one for outbound HTTP, one for CPU-heavy work. Mixing them is a classic head-of-line blocking bug.
- BullMQ / Redis queues are durable across process restarts. `ThreadPoolExecutor`'s queue is **in-memory only** — JVM crash = tasks lost. For durability, the queue must live in Redis / Kafka / a DB.
- Backpressure in Node is mostly at the HTTP layer (return 503). In Java, `CallerRunsPolicy` makes the producing thread run the work itself — the same effect (slow down producers), achieved at the executor layer, not the HTTP layer.

---

## 4. Production-Grade Code

A realistic snippet: a production-safe `ThreadPoolExecutor` factory used in a Spring Boot service for outbound HTTP fan-out — bounded queue, named threads, structured rejection, scheduled exception logging.

```java
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.*;

public final class ExecutorFactory {
    private static final Logger log = LoggerFactory.getLogger(ExecutorFactory.class);

    private ExecutorFactory() {}

    /**
     * Production-safe pool for I/O-bound work (outbound HTTP).
     * - Bounded queue → backpressure, no OOM.
     * - CallerRunsPolicy → producer slows down naturally when saturated.
     * - Named, non-daemon threads → visible in jstack, won't get killed mid-task.
     */
    public static ThreadPoolExecutor ioPool(String name, int core, int max, int queueCapacity) {
        ThreadFactory factory = namedFactory(name);

        ThreadPoolExecutor pool = new ThreadPoolExecutor(
            core,
            max,
            60L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(queueCapacity),
            factory,
            new ThreadPoolExecutor.CallerRunsPolicy()   // backpressure, not silent drop
        );
        pool.allowCoreThreadTimeOut(true);   // even core threads die if idle — elastic shrink
        return pool;
    }

    /**
     * Scheduled pool that won't silently swallow exceptions.
     * Wrap each task in a try/catch — required because ScheduledExecutorService
     * stops re-scheduling after one uncaught exception.
     */
    public static ScheduledExecutorService safeScheduled(String name, int size) {
        ScheduledThreadPoolExecutor sched = new ScheduledThreadPoolExecutor(size, namedFactory(name));
        sched.setRemoveOnCancelPolicy(true);   // cancelled tasks evicted, not retained
        return sched;
    }

    public static Runnable safe(Runnable inner, String taskName) {
        return () -> {
            try { inner.run(); }
            catch (Throwable t) { log.error("task '{}' failed", taskName, t); }
        };
    }

    private static ThreadFactory namedFactory(String prefix) {
        AtomicInteger seq = new AtomicInteger();
        return r -> {
            Thread t = new Thread(r, prefix + "-" + seq.incrementAndGet());
            t.setDaemon(false);   // finish in-flight work on JVM shutdown
            t.setUncaughtExceptionHandler(
                (thr, e) -> log.error("uncaught in {}", thr.getName(), e));
            return t;
        };
    }
}
```

Usage:

```java
ThreadPoolExecutor http = ExecutorFactory.ioPool("payment-out", 20, 100, 500);
ScheduledExecutorService cron = ExecutorFactory.safeScheduled("retry-cron", 2);

cron.scheduleAtFixedRate(
    ExecutorFactory.safe(retryService::sweepFailedPayments, "retry-sweep"),
    0, 30, TimeUnit.SECONDS
);

// Graceful shutdown on Spring's @PreDestroy:
http.shutdown();
if (!http.awaitTermination(30, TimeUnit.SECONDS)) {
    http.shutdownNow();
    http.awaitTermination(5, TimeUnit.SECONDS);
}
```

Why each piece matters:
- **`LinkedBlockingQueue(500)`** — bounded; saves you from OOM when downstream stalls.
- **`CallerRunsPolicy`** — when the pool is saturated, the Tomcat thread runs the task; the next HTTP request can't be accepted until done. Backpressure, no drops.
- **`allowCoreThreadTimeOut(true)`** — even core threads die after `keepAlive`. The pool shrinks during off-hours, saving RAM.
- **Named threads** — `jstack` shows `payment-out-12` instead of `pool-3-thread-12`. Massive debugging quality-of-life.
- **`safe()` wrapper** — every scheduled task is exception-isolated. One bad run doesn't kill the schedule.
- **Graceful shutdown sequence** — `shutdown` → `awaitTermination` → `shutdownNow` → `awaitTermination`. Anything less and you lose in-flight work or hang.

---

## 5. Top 3 MNC Interview Questions

**Q1: I set `corePoolSize=10, maximumPoolSize=100` and the pool never goes above 10 threads even under load. Why?**
*What they're testing:* the dispatch rule + the unbounded-queue trap. Top filter question.
*Ideal answer:* Because the work queue is unbounded. `ThreadPoolExecutor`'s dispatch order is: spawn up to core, *then queue*, *then* spawn up to max only when the queue is full. With a `LinkedBlockingQueue()` (the default for `newFixedThreadPool` and the most common mistake), the queue is never full, so the pool never grows past core. `maximumPoolSize` becomes unreachable. The fix is to use a bounded queue — `new LinkedBlockingQueue<>(500)` or `ArrayBlockingQueue(500)` — so once it fills up the pool can elastically grow up to max, and beyond that the rejection policy fires. This is also why memory blows up under load with `newFixedThreadPool` — the queue silently grows forever.

**Q2: How would you handle a saturated thread pool in a high-traffic HTTP service — without dropping requests?**
*What they're testing:* whether you've operated a production system and understand backpressure.
*Ideal answer:* `CallerRunsPolicy`. When the pool's queue is full and threads are at max, the executor runs the task on the **submitting thread** — typically the Tomcat HTTP worker. That thread is now busy doing the actual work, so it can't accept the next HTTP request, which makes the load balancer route elsewhere or the upstream slow down. It's a natural backpressure loop with no drops and no OOM. The trade-off is latency goes up for that request — but that's better than `AbortPolicy` (503s) or `DiscardPolicy` (silent loss). I'd pair it with a bounded queue so the cliff is predictable, and a metric on `queueSize / queueCapacity` so I can alert before the cliff.

**Q3: What's wrong with `Executors.newFixedThreadPool(20)` for a production microservice?**
*What they're testing:* the factory-methods trap; whether you've read the Goetz book or learned the hard way.
*Ideal answer:* Two things. First, it uses an **unbounded** `LinkedBlockingQueue`, so if producers outrun consumers, the queue grows forever and you OOM — no backpressure. Second, the thread factory creates threads named `pool-N-thread-M`, which is useless in a thread dump when you're debugging a hang at 3 a.m. In production I always build a `ThreadPoolExecutor` directly with a bounded queue, a named `ThreadFactory`, an explicit rejection policy (usually `CallerRuns`), and `allowCoreThreadTimeOut(true)` for elasticity. The `Executors` factory methods are convenience for demos, not for services that need to stay up.

---

### Memorize this
> **Memorize this:** Dispatch order is `core → queue → max → reject`, so an unbounded queue makes `maxPoolSize` a lie; in production, always build `ThreadPoolExecutor` directly with a bounded queue, named threads, `CallerRunsPolicy` for backpressure, and `shutdown → awaitTermination → shutdownNow` for graceful exit.

---

**Next likely topics:** `CompletableFuture` (the non-blocking, composable evolution of `Future` running on these same executors), or **virtual threads** (Java 21 — when you might throw out most of this pool-tuning math because each task gets its own cheap virtual thread). Both are direct senior-interview follow-ups.
