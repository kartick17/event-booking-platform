# `Future` and `List<Future>` — Working with Async Results

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

A **`Future<V>`** is a handle to a value that **doesn't exist yet**. When you submit a `Callable` to an `ExecutorService`, you get back a `Future<V>` immediately — the task runs on a worker thread, and you call `future.get()` later to retrieve the result (blocking until ready).

It supports four operations:
- **`get()`** — block until done, return the result (or rethrow worker exception).
- **`get(timeout, unit)`** — block with a deadline; throw `TimeoutException` if not done.
- **`cancel(mayInterrupt)`** — try to stop the task; if `true`, interrupt the worker thread.
- **`isDone()` / `isCancelled()`** — non-blocking state checks.

A **`List<Future<V>>`** is the standard pattern for **parallel fan-out**: submit N tasks, collect N futures, then walk the list calling `get()` on each. This is how you run independent operations concurrently and combine results — like fetching from 3 microservices in parallel.

Two helper methods on `ExecutorService` automate the fan-out:
- **`invokeAll(tasks)`** — submit all, **block until all complete**, return `List<Future>`.
- **`invokeAny(tasks)`** — submit all, return the result of the **first one that succeeds**, cancel the rest.

Why it exists: before `Future`, the only way to get a result from a worker thread was shared mutable state plus `wait`/`notify` — error-prone and verbose. `Future` packages "I'll have it later" as a typed value.

> **Interview definition (say this out loud):** "A `Future<V>` is a placeholder for a value computed asynchronously — you get one back when you submit a `Callable` to an `ExecutorService`. `get()` blocks until the result is ready and re-throws worker exceptions wrapped in `ExecutionException`. For parallel fan-out I collect a `List<Future<V>>` and walk it, or use `invokeAll` which blocks until all are done. The big limitations are that `Future` is blocking-only — no `.then()` chaining — and `get()` without a timeout will park your thread forever. That's why modern code uses `CompletableFuture`."

---

## 2. Under the Hood (JVM & Library Internals)

### 2.1 The `Future` interface

```java
public interface Future<V> {
    boolean cancel(boolean mayInterruptIfRunning);
    boolean isCancelled();
    boolean isDone();
    V get()              throws InterruptedException, ExecutionException;
    V get(long t, TimeUnit u) throws InterruptedException, ExecutionException, TimeoutException;
}
```

That's all. No `.then()`, no `.onComplete()`, no combinators. Pure pull-model: you ask, it answers.

### 2.2 The state machine inside `FutureTask`

The concrete class behind almost every `Future` you get from an `ExecutorService` is `FutureTask`. It holds an `int state`:

| State | Meaning |
|---|---|
| `NEW` (0) | Just created, not started |
| `COMPLETING` (1) | Worker finished, storing result — brief transient state |
| `NORMAL` (2) | Done, result stored |
| `EXCEPTIONAL` (3) | Done, exception stored |
| `CANCELLED` (4) | Cancelled before completion |
| `INTERRUPTING` (5) → `INTERRUPTED` (6) | Cancel with `mayInterrupt=true` |

Transitions happen via **CAS** (compare-and-swap) on the state field — `FutureTask` is lock-free for the happy path. Storing the result and updating state to `NORMAL` is a single CAS; that's why `get()` either sees the full result or sees `NEW` — never a torn read.

### 2.3 What `get()` actually does

```
1. Read state.
2. If state > COMPLETING (done) → return the stored result or rethrow stored exception.
3. Else, create a WaitNode, add it to a Treiber stack of waiters.
4. LockSupport.park(this) — thread state becomes WAITING (or TIMED_WAITING for timed get).
5. On wake: re-check state and loop back to step 2.
6. When the worker finishes, it walks the waiter stack and LockSupport.unpark()s each waiter.
```

Two consequences:
- A thread parked in `get()` shows as **WAITING** in `jstack` — never BLOCKED. (Same as `ReentrantLock` waiters.)
- `Future.get()` does **not** use `wait`/`notify` — it uses `LockSupport.park`/`unpark` directly. So a stuck future is *not* on any monitor's wait set; you must trace via the parking blocker.

### 2.4 How exceptions travel from worker to caller

Inside the worker:
```java
try {
    result = callable.call();
    set(result);              // state: NEW → COMPLETING → NORMAL
} catch (Throwable t) {
    setException(t);          // state: NEW → COMPLETING → EXCEPTIONAL
}
```

Inside `get()`:
```java
if (state == NORMAL)      return result;
if (state == EXCEPTIONAL) throw new ExecutionException(savedException);
if (state >= CANCELLED)   throw new CancellationException();
```

Why `ExecutionException`? Because the worker can throw **any** `Throwable`, including checked `Exception`s that the caller's method may not declare. Wrapping into `ExecutionException` (unchecked? no — it's checked, derived from `Exception`) makes the API consistent and forces the caller to unwrap intentionally:

```java
try {
    User u = future.get();
} catch (ExecutionException ee) {
    Throwable cause = ee.getCause();      // the original exception
    if (cause instanceof IOException io) { /* handle */ }
    else throw new RuntimeException(cause);
}
```

### 2.5 `cancel()` — what it really does (and doesn't)

```java
future.cancel(true);   // mayInterruptIfRunning = true
```

- If state is `NEW` and the task hasn't started — CAS to `CANCELLED`, the worker will skip it.
- If the task is *already running* and `mayInterrupt=true` — call `Thread.interrupt()` on the worker. **The worker must be cooperative** — it has to check `Thread.interrupted()` or be blocked in an interruptible call (`sleep`, `wait`, `Lock.lockInterruptibly`, `BlockingQueue.take`). If the worker is in a tight CPU loop with no interrupt check, `cancel()` does **nothing visible** — the work continues.
- If the task is already done or already cancelled — returns `false`, no-op.

So `cancel(true)` is a **request**, not a guarantee. Production code that needs hard cancellation needs cooperative tasks. This is a top interview trap.

### 2.6 `List<Future>` — the two patterns

**Manual fan-out:**
```java
List<Future<User>> futures = new ArrayList<>();
for (long id : userIds) {
    futures.add(pool.submit(() -> userRepo.findById(id)));
}
List<User> users = new ArrayList<>();
for (Future<User> f : futures) {
    users.add(f.get());   // blocks for each — total time = max, not sum
}
```

Total wall time ≈ max(individual task time), because all tasks run in parallel and you only wait for the slowest.

**`invokeAll` — the library helper:**
```java
List<Future<User>> futures = pool.invokeAll(callables);   // blocks until ALL done
```
All futures returned from `invokeAll` are **already done** when the call returns (success, exception, or cancelled by `invokeAll` timeout). You can still `get()` each one to retrieve the value or exception.

Timed variant: `invokeAll(tasks, 5, SECONDS)` — cancels any task still running after 5 seconds and returns the list (you check `isCancelled()` on each).

### 2.7 The five traps everyone hits

| Trap | What goes wrong |
|---|---|
| `future.get()` with no timeout in a request handler | Stuck downstream → thread parked forever → connection pool exhausted → outage |
| Walking the list in submit order, calling `get()` blockingly | You wait for *that* future even if others finished long ago. Use `ExecutorCompletionService` to get results in completion order. |
| Submitting and never calling `get()` | Exception lives inside the Future forever — silent failure. Either `get()` it or `execute()` instead. |
| Calling `get()` twice expecting fresh work | `Future` is one-shot — second call returns the same cached result instantly. |
| Cancelling and assuming the task stopped | Cancel only interrupts; an uncooperative worker keeps running and burning resources. |

### 2.8 `ExecutorCompletionService` — get results in completion order

When you want to process futures **as they finish** (not in submit order), use `ExecutorCompletionService<V>`:

```java
CompletionService<User> cs = new ExecutorCompletionService<>(pool);
for (long id : ids) cs.submit(() -> userRepo.findById(id));
for (int i = 0; i < ids.size(); i++) {
    User u = cs.take().get();   // returns the next COMPLETED future
    process(u);
}
```

`take()` blocks until any task completes and returns its Future. Lets you start processing the first result without waiting for the slowest one.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| Async value placeholder | `Promise<V>` | `Future<V>` |
| Wait for one result | `await promise` | `future.get()` (blocking) |
| Wait for all | `Promise.all([...])` | `executor.invokeAll(...)` or list+loop |
| First one wins | `Promise.race([...])` | `executor.invokeAny(...)` |
| First settled (any result) | `Promise.any([...])` | No direct equivalent; build with `ExecutorCompletionService` |
| Chain transformation | `.then(v => v + 1)` | **Not on `Future`** — must upgrade to `CompletableFuture.thenApply` |
| Cancellation | `AbortController.abort()` | `future.cancel(true)` + cooperative interrupt check |
| Silent unhandled failure | `unhandledRejection` event (loud since Node 15) | **Buried in the Future** until someone calls `get()` |

### Where the comparison breaks down

- `Promise.then` is **non-blocking** — the callback runs when the value lands, the calling code returns immediately. `Future.get()` is **blocking** — the OS thread parks. This is the single biggest reason teams move from `Future` to `CompletableFuture`.
- `Promise` resolution is durable and observable by many `.then`s. A `Future`'s result is also durable (cached after completion), but there's no observer pattern — you can only pull, not subscribe. `CompletableFuture` adds the observer pattern.
- `Promise.all` rejects fast on the first rejection by default. `invokeAll` does **not** — it always waits for all tasks; you check each Future for success/failure individually. So "fail fast on first error" is harder with raw `Future` — you build it yourself or use `CompletableFuture.allOf` with `anyOf` racing an error.

---

## 4. Production-Grade Code

A realistic snippet: a **product page aggregator** that fans out to 3 backends in parallel — product details, inventory, related products. Shows manual `List<Future>`, `invokeAll`, and `ExecutorCompletionService` with proper timeout, error unwrapping, and cancellation.

```java
import java.util.*;
import java.util.concurrent.*;

public class ProductPageAggregator {

    private final ExecutorService pool;
    private final ProductService   productSvc;
    private final InventoryService inventorySvc;
    private final RelatedService   relatedSvc;

    public ProductPageAggregator(ExecutorService pool, ProductService p,
                                 InventoryService i, RelatedService r) {
        this.pool = pool;
        this.productSvc = p;
        this.inventorySvc = i;
        this.relatedSvc = r;
    }

    /** Manual fan-out — total wall time ≈ slowest call, not sum. */
    public ProductPage build(long productId) throws InterruptedException {
        Future<Product>       pf = pool.submit(() -> productSvc.find(productId));
        Future<Inventory>     inf = pool.submit(() -> inventorySvc.check(productId));
        Future<List<Product>> rf = pool.submit(() -> relatedSvc.recommend(productId));

        try {
            Product       p = pf.get(500, TimeUnit.MILLISECONDS);   // required
            Inventory     i = inf.get(300, TimeUnit.MILLISECONDS);  // required
            List<Product> r = safeGet(rf, 200);                     // optional — degrade gracefully
            return new ProductPage(p, i, r);
        } catch (ExecutionException ee) {
            // Required dependency failed — surface the cause
            throw new ProductPageException("required service failed", ee.getCause());
        } catch (TimeoutException te) {
            // Critical SLO breach — cancel everything still in flight
            pf.cancel(true);  inf.cancel(true);  rf.cancel(true);
            throw new ProductPageException("timed out building page", te);
        }
    }

    /** Optional data — degrade to empty list on timeout or failure. */
    private List<Product> safeGet(Future<List<Product>> f, long ms) {
        try {
            return f.get(ms, TimeUnit.MILLISECONDS);
        } catch (TimeoutException | ExecutionException e) {
            f.cancel(true);                   // stop the wasted work
            return List.of();                 // degrade
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            return List.of();
        }
    }

    /** Bulk variant — load N product pages in parallel using invokeAll. */
    public List<ProductPage> buildBulk(List<Long> productIds) throws InterruptedException {
        List<Callable<ProductPage>> tasks = new ArrayList<>(productIds.size());
        for (Long id : productIds) tasks.add(() -> build(id));

        List<Future<ProductPage>> done = pool.invokeAll(tasks, 2, TimeUnit.SECONDS);
        List<ProductPage> out = new ArrayList<>(done.size());
        for (Future<ProductPage> f : done) {
            try {
                if (!f.isCancelled()) out.add(f.get());
            } catch (ExecutionException ignored) {
                // log per-id failure to metrics; skip this product
            }
        }
        return out;
    }

    /** Process results in completion order — start rendering as soon as each one lands. */
    public void streamBulk(List<Long> productIds, java.util.function.Consumer<ProductPage> sink)
            throws InterruptedException {
        CompletionService<ProductPage> cs = new ExecutorCompletionService<>(pool);
        for (Long id : productIds) cs.submit(() -> build(id));

        for (int i = 0; i < productIds.size(); i++) {
            Future<ProductPage> f = cs.take();   // blocks for the NEXT completed one
            try { sink.accept(f.get()); }
            catch (ExecutionException ignored) { /* per-id metric */ }
        }
    }

    // Minimal domain types so the snippet stands alone:
    public record Product(long id, String name) {}
    public record Inventory(long productId, int stock) {}
    public record ProductPage(Product product, Inventory inventory, List<Product> related) {}
    public interface ProductService   { Product find(long id); }
    public interface InventoryService { Inventory check(long id); }
    public interface RelatedService   { List<Product> recommend(long id); }
    public static class ProductPageException extends RuntimeException {
        public ProductPageException(String m, Throwable c) { super(m, c); }
    }
}
```

Why each piece matters:
- **`get(timeoutMs)` everywhere** — every blocking call has a deadline. No untimed `get()` in a request path.
- **Two error paths** — `ExecutionException` (worker threw) vs `TimeoutException` (took too long). Unwrap `.getCause()` for the real exception.
- **`cancel(true)` on timeout** — stop the wasted work; don't leak threads. Remember it's cooperative — your downstream HTTP client must respect interrupt.
- **`safeGet` pattern** — required vs optional fields are handled differently. Optional data degrades to empty.
- **`invokeAll(tasks, timeout)`** — bounded bulk fan-out, with per-task `isCancelled()` check.
- **`ExecutorCompletionService`** — when you can start emitting results as each finishes (SSE, streaming response), don't wait for the slowest.

---

## 5. Top 3 MNC Interview Questions

**Q1: What happens if I call `future.get()` twice?**
*What they're testing:* whether you understand `Future` is a one-shot result holder, not a re-runnable task.
*Ideal answer:* The second call returns the same cached result instantly — `Future` stores the outcome once the task completes, and `get()` just reads that stored value. It does not re-run the task. If the first call returned a value, the second returns the same value; if the first threw `ExecutionException`, the second throws the same `ExecutionException`. The wait-and-park machinery only kicks in if the task is still running. If you need to re-run, you have to submit a new `Callable` and get a new `Future`.

**Q2: I'm running 100 tasks in parallel with `List<Future>` and processing results in order. The first task is the slowest — how do I process results as they finish instead?**
*What they're testing:* whether you know about `ExecutorCompletionService` — most candidates only know `invokeAll`.
*Ideal answer:* Use `ExecutorCompletionService`. You wrap your `ExecutorService`, submit tasks the same way, and call `take()` which blocks until *any* task finishes and returns its Future. So you process results in completion order, not submit order. This matters when you're streaming responses or want to surface the first hit while slower ones are still running. Internally it pushes completed tasks onto a `BlockingQueue` — so `take()` is just a queue poll. The alternative is `CompletableFuture.anyOf` or manual `whenComplete` callbacks pushing to a queue, but `ExecutorCompletionService` is the cleanest pre-Java 8 answer.

**Q3: I called `future.cancel(true)` but the worker is still running. Why?**
*What they're testing:* the cooperative cancellation contract — top trap.
*Ideal answer:* Because `cancel(true)` only sends `Thread.interrupt()` to the worker — it does not forcibly kill anything. The worker has to either be blocked in an interruptible call like `sleep`, `wait`, `Lock.lockInterruptibly`, or `BlockingQueue.take`, or it has to periodically check `Thread.interrupted()`. If the worker is in a tight CPU loop or stuck in a non-interruptible call like a blocking I/O socket read on an old `InputStream`, the interrupt is set but ignored — the work continues. The fix is to make the task cooperative: check the interrupt flag in any long loop, and prefer interruptible APIs like `nio` channels over old blocking streams. `cancel` returning `true` only means "the cancellation was accepted into the Future's state", not "the work has actually stopped".

---

### Memorize this
> **Memorize this:** A `Future<V>` is a one-shot pull-model handle to an async result — `get()` blocks (always with a timeout in production), worker exceptions arrive wrapped in `ExecutionException`, and `cancel(true)` is a cooperative interrupt request not a kill. For fan-out, use `List<Future>` + loop, `invokeAll` for "wait for all", or `ExecutorCompletionService` for "process as they finish".

---

**Next likely topics:** `CompletableFuture` (non-blocking `Future` with `.thenApply`/`.thenCombine`/`.exceptionally` — the API you actually use in modern Spring Boot), or `ExecutorService` / `ThreadPoolExecutor` internals (core/max pool size, queue choice, rejection policy — the daily tuning knobs). Both are direct follow-ups.
