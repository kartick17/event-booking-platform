# `Runnable`, Its Problems, and `Callable`

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

**`Runnable`** is Java's oldest task abstraction — a functional interface with one method `void run()`. You give a `Runnable` to a `Thread` or `ExecutorService` and it runs the code on a worker thread. Lives in `java.lang`.

**`Callable<V>`** is the modern replacement — `V call() throws Exception`. Two key differences from `Runnable`:
1. It **returns a value** of type `V`.
2. It **can throw checked exceptions**.

Lives in `java.util.concurrent`, added in Java 5 alongside `ExecutorService` and `Future`.

You don't run a `Callable` directly on a `Thread` (the `Thread` constructor doesn't accept one). You submit it to an `ExecutorService`, which gives you back a `Future<V>` — call `future.get()` to wait for the result.

Why both exist: `Runnable` came in Java 1.0 — fire-and-forget tasks. `Callable` came in Java 5 — Java needed tasks that can produce results and propagate failures cleanly. They coexist today; modern APIs still accept `Runnable` for void tasks, `Callable` for value-returning ones.

> **Interview definition (say this out loud):** "`Runnable` is the classic task interface — `void run()`, no return, no checked exceptions. `Callable<V>` is the Java 5 replacement — `V call() throws Exception`. So `Runnable` is for fire-and-forget side effects, `Callable` is for tasks that produce a value or might fail. You submit `Callable` to an `ExecutorService` and get a `Future<V>` back; `future.get()` blocks until the result is ready, and re-throws any worker exception wrapped in `ExecutionException`. In modern code, `CompletableFuture` further wraps this with chaining and non-blocking composition."

---

## 2. Under the Hood (JVM & Library Internals)

### 2.1 The two interfaces, side by side

```java
@FunctionalInterface
public interface Runnable {
    void run();                 // no return, no throws
}

@FunctionalInterface
public interface Callable<V> {
    V call() throws Exception;  // returns V, throws checked exception
}
```

Both are `@FunctionalInterface` — single abstract method, lambda-compatible.

### 2.2 The two problems with `Runnable`

| Problem | What breaks | Why it matters |
|---|---|---|
| `run()` returns `void` | Worker can't communicate a result back to the caller without shared mutable state (a field, a `volatile`, or a `BlockingQueue`) | Forces ugly side-channel code, brittle synchronization |
| `run()` can't throw checked exceptions | Worker must wrap every `IOException`/`SQLException` in a `RuntimeException`, or swallow it | Type safety is lost; stack traces get mangled; many "silent task failures" in prod come from this |

There's a **third, subtler problem**: if a `Runnable` running on a `Thread` throws an unchecked exception, the exception kills the thread and is **silently swallowed** unless you registered an `UncaughtExceptionHandler`. Many Spring Boot logs of "task vanished" are this exact bug.

### 2.3 What `Callable` fixes

```java
Callable<Invoice> task = () -> {
    return invoiceService.generate(orderId);   // returns a value
    // can throw checked SQLException, IOException, etc. — no wrapping needed
};

ExecutorService pool = Executors.newFixedThreadPool(4);
Future<Invoice> future = pool.submit(task);

Invoice inv = future.get();   // blocks; rethrows worker exception as ExecutionException
```

What you get:
- **Return value** — `Future.get()` returns the `V` produced by `call()`.
- **Checked exception propagation** — wrapped in `ExecutionException`, with the original as `cause`. You `unwrap()` once and handle naturally.
- **Cancellation** — `future.cancel(true)` interrupts the worker if it's still running.
- **Timeout** — `future.get(500, MILLISECONDS)` throws `TimeoutException` if not done.
- **Completion check** — `future.isDone()`, `future.isCancelled()`.

### 2.4 How `submit` wires them together

When you call `executor.submit(callable)`, internally:
1. The executor wraps the `Callable` in a **`FutureTask`** (which implements both `Runnable` and `Future<V>`).
2. The executor's worker thread calls `futureTask.run()`.
3. Inside `run()`, it calls `callable.call()`, catches any thrown `Throwable`, stores either the result or the exception in an internal slot.
4. It signals waiters parked in `get()` (built on `LockSupport.park`).
5. `get()` returns the result, or re-throws the stored exception as `ExecutionException`.

This is why `Callable` doesn't run "directly" — the bridge is `FutureTask`. The same bridge lets you submit a `Runnable` and still get a `Future<?>` back (with `null` as the result).

### 2.5 `submit(Runnable)` vs `submit(Callable)` vs `execute(Runnable)`

| Method | Argument | Returns | Use when |
|---|---|---|---|
| `execute(Runnable)` | `Runnable` | `void` | Fire-and-forget; no need to track completion |
| `submit(Runnable)` | `Runnable` | `Future<?>` (result is `null`) | Need to wait for completion, but no result |
| `submit(Runnable, T result)` | `Runnable` + sentinel | `Future<T>` (returns sentinel on success) | Rare — when you want a typed Future from a Runnable |
| `submit(Callable<V>)` | `Callable<V>` | `Future<V>` | Need a result or want exception propagation |

**Trap:** `execute(Runnable)` silently swallows unchecked exceptions (just logs to `UncaughtExceptionHandler`). `submit(Runnable)` *captures* the exception inside the Future — you only see it if you call `future.get()`. **If you `submit` and never `get`, exceptions vanish.** This is a top-3 production silent-failure source.

### 2.6 The modern follow-up — `CompletableFuture`

`Future<V>` is **blocking only** — `get()` is the only way to retrieve the result, and it parks the calling thread. That's still better than `Runnable`, but it doesn't compose.

`CompletableFuture<V>` (Java 8) builds on the same ideas but adds:
- Non-blocking chaining: `.thenApply()`, `.thenCompose()`, `.thenCombine()`.
- Combinators: `allOf(...)`, `anyOf(...)`.
- Error handling: `.exceptionally()`, `.handle()`.
- Choice of executor for each stage.

This is the API you'll actually use in production Spring Boot services. `Callable` is the underlying contract; `CompletableFuture` is the ergonomic surface.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| Fire-and-forget side effect | `setImmediate(() => doWork())` | `executor.execute(runnable)` |
| Task that returns a value | `async function fetch(): Promise<T>` | `Callable<T>` returning `Future<T>` |
| Awaiting the result | `await promise` | `future.get()` (blocking) or `CompletableFuture.thenApply` (non-blocking) |
| Error from a worker | `try { await p } catch (e) { ... }` | `try { future.get() } catch (ExecutionException ee) { ee.getCause() }` |
| Cancellation | `AbortController.abort()` | `future.cancel(true)` |
| Silent error if you don't await | `UnhandledPromiseRejection` (loud since Node 15) | **No warning** — submitted-but-never-`get()` swallows exceptions |

### Where the comparison breaks down

- Node treats an unawaited rejected promise as a process-level error in modern versions. Java's `Future` does **not** — if you submit a `Callable` and never call `get()`, a failure is buried inside the Future object forever. This is exactly the silent-failure bug that bites teams new to Java.
- `await` is non-blocking — it suspends the async function but frees the event loop. `future.get()` is **blocking** — the OS thread parks doing nothing. That's why we moved to `CompletableFuture.thenApply` (callback chain) or virtual threads.
- `Promise` resolution is durable and observable by many `.then`s. A `Future` is one-shot and consumed by one `get()`. `CompletableFuture` is the closer parallel to `Promise`.

---

## 4. Production-Grade Code

A realistic snippet: a **checkout service** that runs three independent enrichments in parallel — fetching the user, the cart total, and a fraud score. Shows the `Runnable` pain point (logging task), `Callable` with `Future`, and the modern `CompletableFuture` version side by side.

```java
import java.util.List;
import java.util.concurrent.*;

public class CheckoutEnrichmentService {

    private final ExecutorService pool = Executors.newFixedThreadPool(8);
    private final UserRepository    userRepo;
    private final CartService       cartService;
    private final FraudClient       fraudClient;
    private final AuditLogger       auditLogger;

    public CheckoutEnrichmentService(UserRepository userRepo, CartService cartService,
                                     FraudClient fraudClient, AuditLogger auditLogger) {
        this.userRepo    = userRepo;
        this.cartService = cartService;
        this.fraudClient = fraudClient;
        this.auditLogger = auditLogger;
    }

    /** Fire-and-forget audit — Runnable is the right tool, no result needed. */
    public void logCheckoutAttempt(long userId) {
        pool.execute(() -> auditLogger.write("checkout-attempt user=" + userId));
        // NOTE: execute() — not submit() — because we don't need a Future.
        // If we used submit() and never called get(), exceptions would silently vanish.
    }

    /** Classic Callable + Future — works on Java 5+. */
    public EnrichedCheckout enrichClassic(long userId, long cartId)
            throws InterruptedException, ExecutionException, TimeoutException {

        Callable<User>       fetchUser  = () -> userRepo.findById(userId);
        Callable<Money>      fetchTotal = () -> cartService.totalFor(cartId);
        Callable<FraudScore> fetchScore = () -> fraudClient.score(userId);   // throws IOException

        Future<User>       uf = pool.submit(fetchUser);
        Future<Money>      tf = pool.submit(fetchTotal);
        Future<FraudScore> sf = pool.submit(fetchScore);

        // Each get() with a deadline — never block forever in a request path
        return new EnrichedCheckout(
            uf.get(800, TimeUnit.MILLISECONDS),
            tf.get(800, TimeUnit.MILLISECONDS),
            sf.get(800, TimeUnit.MILLISECONDS)
        );
        // Worker exceptions arrive here wrapped as ExecutionException — unwrap with .getCause()
    }

    /** Modern CompletableFuture — non-blocking chaining, same Callable contract underneath. */
    public CompletableFuture<EnrichedCheckout> enrichAsync(long userId, long cartId) {
        var userF  = CompletableFuture.supplyAsync(() -> userRepo.findById(userId), pool);
        var totalF = CompletableFuture.supplyAsync(() -> cartService.totalFor(cartId), pool);
        var scoreF = CompletableFuture.supplyAsync(() -> {
            try { return fraudClient.score(userId); }
            catch (Exception e) { throw new CompletionException(e); }   // checked → unchecked bridge
        }, pool);

        return CompletableFuture.allOf(userF, totalF, scoreF)
            .thenApply(v -> new EnrichedCheckout(userF.join(), totalF.join(), scoreF.join()));
    }

    public void shutdown() {
        pool.shutdown();
    }

    // Minimal domain types so the snippet stands alone:
    public record User(long id, String email) {}
    public record Money(long cents) {}
    public record FraudScore(int value) {}
    public record EnrichedCheckout(User user, Money total, FraudScore score) {}
    public interface UserRepository { User findById(long id); }
    public interface CartService    { Money totalFor(long cartId); }
    public interface FraudClient    { FraudScore score(long userId) throws java.io.IOException; }
    public interface AuditLogger    { void write(String msg); }
}
```

Why each piece matters:
- **`execute()` for audit** — fire-and-forget; no need for a Future. `submit()` would silently swallow exceptions if no one calls `get()`.
- **`Callable` for `fraudClient.score()`** — it throws checked `IOException`. `Runnable` would force you to wrap.
- **`get(800, MILLISECONDS)`** — never `get()` without a timeout in a request handler. Caller dies, your thread parks forever.
- **`CompletableFuture` version** shows the modern composition — `allOf` + `thenApply`, no blocking until the very end.
- **`CompletionException` wrap** in the async version — `supplyAsync` lambdas can't throw checked exceptions either (the lambda must match `Supplier`), so you wrap.

---

## 5. Top 3 MNC Interview Questions

**Q1: What's the difference between `Runnable` and `Callable`, and why does `Callable` exist?**
*What they're testing:* whether you understand both the return-value gap and the checked-exception gap.
*Ideal answer:* `Runnable.run()` returns `void` and can't throw checked exceptions, so a worker can't directly hand back a result or propagate a typed failure. `Callable.call()` returns a value and throws `Exception`. You submit a `Callable` to an `ExecutorService`, which wraps it in a `FutureTask` and returns a `Future`. `Future.get()` blocks until done and re-throws any worker exception wrapped in `ExecutionException`. `Callable` exists because real services need to retrieve results and route errors — `Runnable` was for fire-and-forget background work.

**Q2: I called `executor.submit(myRunnable)` and the task threw a `NullPointerException`, but my logs show nothing. Why?**
*What they're testing:* the silent-failure trap — top-3 real production bug.
*Ideal answer:* `submit()` captures the exception inside the returned `Future`. It only surfaces when someone calls `future.get()`. If you ignore the Future, the exception is buried forever — no log, no crash, no signal. The fix is one of: call `get()` and handle, use `execute()` instead so the `UncaughtExceptionHandler` fires, or wrap your task in a try/catch that logs explicitly. With `CompletableFuture` you'd add `.exceptionally(e -> { log.error(e); return null; })` or use `whenComplete`. It's such a common bug that AWS SDK and Spring's `@Async` both add their own logging wrappers to avoid it.

**Q3: How does `Future.get()` actually work? What state is the thread in while waiting?**
*What they're testing:* whether you've looked under the hood at `FutureTask`.
*Ideal answer:* `FutureTask` wraps the `Callable` and has an internal state field — `NEW`, `COMPLETING`, `NORMAL`, `EXCEPTIONAL`, `CANCELLED`. When the worker thread finishes `call()`, it CAS-updates the state and stores the result or exception in fields. `get()` checks the state; if not done, it puts the calling thread on an internal waiter list and calls `LockSupport.park()` — the thread goes to **WAITING** (or TIMED_WAITING for `get(timeout)`). When the worker completes, it walks the waiter list and `unpark()`s each. So `get()` is built on the same primitive as `ReentrantLock` — AQS-style park/unpark, not `wait`/`notify`. That's why a stuck `Future.get()` shows as WAITING in `jstack`, never BLOCKED.

---

### Memorize this
> **Memorize this:** `Runnable` is `void run()`, no result, no checked throws — use `execute()` for fire-and-forget; `Callable<V>` is `V call() throws Exception` — submit it to an `ExecutorService` to get a `Future<V>` that blocks on `get()` and re-throws worker errors as `ExecutionException`; never `submit()` and ignore the Future, or exceptions vanish.

---

**Next likely topics:** `Future` vs `CompletableFuture` (why we moved to non-blocking composition), or `ExecutorService` internals (`ThreadPoolExecutor` parameters — core/max pool size, queue choice, rejection policy — the daily knobs of production tuning). Both are direct senior-interview follow-ups.
