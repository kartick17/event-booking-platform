# Synchronization in Java

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

**Synchronization** is Java's built-in way to make sure that **only one thread at a time** can execute a critical section of code on a given object. It's the foundation of thread-safety in Java.

Two things synchronization gives you:
1. **Mutual exclusion** — one thread runs, others wait (BLOCKED state).
2. **Memory visibility** — changes made by one thread become visible to the next thread that acquires the same lock. This is the Java Memory Model (JMM) guarantee.

Three forms:
- **Synchronized instance method** — locks on `this`.
- **Synchronized static method** — locks on `ClassName.class`.
- **Synchronized block** — locks on any object you choose: `synchronized (lockObj) { ... }`.

Why it exists: without synchronization, two threads writing to the same field can **lose updates** (race condition) and reads from another thread may see **stale data** (visibility problem). Java needed a built-in primitive because most enterprise apps are multi-threaded servers.

> **Interview definition (say this out loud):** "Synchronization in Java is built on every object's intrinsic monitor lock. Marking code `synchronized` means a thread must acquire that object's monitor before entering, and release it on exit — that gives mutual exclusion. But it also creates a happens-before edge in the Java Memory Model, so writes before `unlock` are visible to the next thread after `lock`. Without that visibility guarantee, even non-conflicting threads could see stale data due to CPU caches and instruction reordering."

---

## 2. Under the Hood (JVM Internals)

### 2.1 Every object has a monitor

Every Java object has a hidden header (in HotSpot: `mark word`) that the JVM uses for locking. When you write `synchronized (obj)`, the JVM uses `obj`'s monitor — not a separate lock object.

The mark word goes through **lock states** (HotSpot optimization):

| Lock state | When | Cost |
|---|---|---|
| **Biased lock** (removed in JDK 15+) | First thread to lock — JVM "biases" the lock to it; no atomic op on re-entry | Almost zero |
| **Thin / lightweight lock** | Low contention — uses CAS (compare-and-swap) on the mark word | Few nanoseconds |
| **Inflated / heavyweight lock** | High contention — promoted to a full OS-level `ObjectMonitor` with wait queues | Microseconds, may park threads |

This is why `synchronized` is **cheap when uncontended**. The "synchronized is slow" myth comes from the old days before lock coarsening, biased locking, and escape analysis.

### 2.2 The bytecode — `monitorenter` / `monitorexit`

A `synchronized` block compiles to two bytecodes:

```
monitorenter   // acquire lock on top-of-stack object
... critical section ...
monitorexit    // release
// plus a second monitorexit in an exception handler — to guarantee release
```

A `synchronized` method doesn't use these bytecodes — it has the `ACC_SYNCHRONIZED` flag in its method header; the JVM acquires the lock on entry and releases on return (or exception). Functionally identical, slightly different wiring.

### 2.3 The happens-before contract (JMM)

This is the part most candidates miss. Synchronization is not only about mutual exclusion — it's about **memory visibility**.

The Java Memory Model (JMM) says:
- An **unlock** (monitor exit) on object M *happens-before* every subsequent **lock** (monitor enter) on the same object M.

Concrete consequence: every write made by thread A before `unlock(M)` is **visible** to thread B after `lock(M)`. Without `synchronized` (or `volatile`, or `Lock`), thread B might see a stale cached value forever — CPU caches and JIT reordering would make it legal.

This is why "I only read, I don't need to synchronize" is **wrong**. If thread A wrote without synchronization, your read may never see the write.

### 2.4 Reentrancy

Java's intrinsic locks are **reentrant** — the same thread can re-acquire a lock it already holds without blocking itself. The JVM maintains a hold count; `unlock` happens only when the count reaches zero.

```java
synchronized void outer() {
    inner();   // re-enters the same lock — does NOT deadlock
}
synchronized void inner() { ... }
```

This matters for recursive code and for `synchronized` methods calling each other.

### 2.5 What `synchronized` does NOT do

- **Doesn't make individual fields atomic.** `synchronized` protects code blocks, not data. Two threads can each acquire **different** locks and still race on the same field.
- **Doesn't release locks on `Thread.sleep()`** — that's the famous trap. Only `wait()` releases the monitor.
- **Doesn't time out.** A thread can wait forever. If you need timeout, use `ReentrantLock.tryLock(timeout)`.
- **Doesn't fail fast.** No interruption (unlike `ReentrantLock.lockInterruptibly()`).
- **Doesn't scale across processes.** It's JVM-local. For distributed locks, use Redis/Zookeeper.

### 2.6 Common pitfalls

| Pitfall | Why it fails |
|---|---|
| `synchronized` on `String` literal | Interned strings are shared JVM-wide — your "private" lock is shared with every library that locks on the same literal. |
| `synchronized` on `Integer.valueOf(1)` | Boxed integers `-128..127` are cached and shared. Same problem. |
| `synchronized` on `this` for a public class | Library users can lock on your instance externally — you can't reason about your own locking. |
| `synchronized` on a `volatile` field reassigned at runtime | You'd lock on different objects each time — no mutual exclusion. |
| Holding lock during I/O | Network call inside `synchronized` = the whole pool blocks during a 30-second timeout. |

**Best practice:** lock on a **private final Object**: `private final Object lock = new Object();`. Nobody else can grab it.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| Shared mutable state across requests | Rare — single-threaded event loop | Normal — every request handler is a different OS thread sharing the heap |
| Critical section primitive | Doesn't exist — `await` interleaves but never preempts mid-statement | `synchronized` block / method |
| Memory visibility | Single thread, single memory view — no issue | JMM happens-before required, otherwise stale reads |
| "Atomic increment" | `counter++` is safe — no preemption | `counter++` is **broken** without `synchronized`/`AtomicInteger` |

### Where the comparison breaks down

- Node's event loop gives you a free "lock" — only one piece of JS runs at a time per process. **Java has no such guarantee.** Every public method on a service bean can be entered by 200 threads simultaneously. Coming from Node, this is the single biggest mental shift: in Java, *every* shared mutable field is suspect.
- Node devs often don't think about memory visibility because there's only one memory view. In Java, even `boolean stop = true;` set by one thread may be invisible to another forever without `volatile` or synchronization. Interviewers love this.
- The "fix" in Node for cross-request state is usually Redis or a DB row lock. In Java, the first answer is `synchronized` or `AtomicXxx`, then `ReentrantLock`, then a distributed lock if you have multiple JVMs.

---

## 4. Production-Grade Code

Realistic snippet: a **seat-booking service** that prevents double-booking. Shows the right lock granularity, the wrong vs. right lock object, and where to put I/O.

```java
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class SeatBookingService {

    // One lock per seat — fine-grained, threads booking different seats don't block each other.
    // Keyed by seatId so the lock object is stable across calls for the same seat.
    private final Map<Long, Object> seatLocks = new HashMap<>();
    private final Object registryLock = new Object();   // private final — no one can grab it externally

    private final SeatRepository seatRepo;
    private final BookingRepository bookingRepo;

    public SeatBookingService(SeatRepository seatRepo, BookingRepository bookingRepo) {
        this.seatRepo = seatRepo;
        this.bookingRepo = bookingRepo;
    }

    public BookingResult book(long seatId, long userId) {
        // 1. Pre-lock work (DB read) — outside critical section to keep it short
        Optional<Seat> seat = seatRepo.findById(seatId);
        if (seat.isEmpty()) return BookingResult.notFound();

        Object lock = lockFor(seatId);

        // 2. Critical section — minimal, no network I/O
        synchronized (lock) {
            if (bookingRepo.existsForSeat(seatId)) {
                return BookingResult.alreadyBooked();
            }
            bookingRepo.insert(new Booking(seatId, userId));
        }

        // 3. Side effects after the lock is released — notifications, metrics, etc.
        return BookingResult.success(seatId, userId);
    }

    private Object lockFor(long seatId) {
        synchronized (registryLock) {
            return seatLocks.computeIfAbsent(seatId, k -> new Object());
        }
    }

    // Minimal domain types so the snippet stands alone:
    public record Seat(long id) {}
    public record Booking(long seatId, long userId) {}
    public interface SeatRepository    { Optional<Seat> findById(long id); }
    public interface BookingRepository {
        boolean existsForSeat(long seatId);
        void insert(Booking b);
    }
    public sealed interface BookingResult {
        record Success(long seatId, long userId) implements BookingResult {}
        record AlreadyBooked() implements BookingResult {}
        record NotFound() implements BookingResult {}
        static BookingResult success(long s, long u) { return new Success(s, u); }
        static BookingResult alreadyBooked()         { return new AlreadyBooked(); }
        static BookingResult notFound()              { return new NotFound(); }
    }
}
```

Why each piece matters:
- **One lock per seat** — coarse-grained `synchronized` on the whole service would serialize unrelated bookings. This pattern (stripe-locking) is what `ConcurrentHashMap` does internally.
- **`registryLock` is `private final Object`** — no external code can `synchronized (service.registryLock)` and break you.
- **DB read happens outside the lock**, write happens inside — minimizes lock hold time. Even better in real code: use a DB row lock (`SELECT ... FOR UPDATE`) instead — JVM locks don't help across multiple instances.
- **No I/O inside `synchronized`** — would block every booker if the DB stalls.
- **Sealed `BookingResult`** — Java 17 modeling of a closed result set; pairs well with pattern matching at call sites.

---

## 5. Top 3 MNC Interview Questions

**Q1: What does `synchronized` actually guarantee beyond mutual exclusion?**
*What they're testing:* whether you know about the Java Memory Model — the line between juniors and seniors.
*Ideal answer:* It guarantees a happens-before edge in the JMM. Specifically, every write that happens before the `unlock` of monitor M is visible to every read after a later `lock` of the same monitor M by another thread. Without this, the JIT and the CPU are free to reorder operations and cache values per-core — so even a simple `boolean done = true;` set by one thread may never be observed by another. So `synchronized` gives you both *atomicity* of the critical section and *visibility* of the writes inside it. That's why people sometimes use `synchronized` blocks just to publish a value safely, with no real contention.

**Q2: Why is it a bad idea to do `synchronized (this)` in a public class?**
*What they're testing:* lock encapsulation and the difference between safe and unsafe lock objects.
*Ideal answer:* Because `this` is publicly visible. Any code holding a reference to your instance can write `synchronized (yourInstance)` and acquire the same lock you're using internally. That can cause deadlocks or unexpected blocking that you can't reason about from your own class. The right pattern is `private final Object lock = new Object();` — nobody outside can reach it. Same reason you should never `synchronized` on `String` literals or boxed primitives in the cache range, since those are shared JVM-wide.

**Q3: A thread calls `Thread.sleep(5000)` while inside a `synchronized` block. What happens to the lock?**
*What they're testing:* the classic `sleep` vs `wait` distinction — a junior-vs-mid filter.
*Ideal answer:* The thread goes to TIMED_WAITING for 5 seconds, but it **keeps the monitor**. Any thread trying to enter a `synchronized` block on the same object will go to BLOCKED for the full duration. This is the single biggest difference between `sleep()` and `wait()` — `wait()` releases the monitor it's called on, `sleep()` releases nothing. In production this is a classic cause of thread-pool starvation: a single slow operation inside a `synchronized` block stalls every other thread that needs the same lock.

---

### Memorize this
> **Memorize this:** `synchronized` is one feature with two jobs — mutual exclusion (one thread at a time) and JMM happens-before (visibility of writes). Always lock on a `private final Object`, never on `this`, `String`, or boxed primitives, and never do I/O or `sleep` while holding the lock.

---

**Next likely topics:** `synchronized` vs `ReentrantLock` (tryLock, fairness, interruptible, conditions), or `volatile` and the Java Memory Model (when synchronization is overkill and visibility is all you need). Both come up immediately after `synchronized` in any senior interview.
