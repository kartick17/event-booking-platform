# `synchronized` vs `ReentrantLock`

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

Both `synchronized` and `ReentrantLock` give you **mutual exclusion** — one thread runs the critical section, others wait. They also give the same JMM happens-before guarantee (lock release → next lock acquire).

The difference is **control**:
- **`synchronized`** is a language keyword. The JVM manages the lock. You get safety, but no knobs.
- **`ReentrantLock`** is a class in `java.util.concurrent.locks`. You manage the lock — `lock()`, `unlock()`, plus extra powers: timeouts, interruptibility, fairness, multiple condition variables, lock-state inspection.

Both are **reentrant** (same thread can lock again without deadlock). Both are JVM-local (not distributed).

The rule of thumb: **use `synchronized` by default**. Reach for `ReentrantLock` only when you need a feature `synchronized` cannot give you.

> **Interview definition (say this out loud):** "`ReentrantLock` is the explicit, programmatic version of `synchronized`. Both give mutual exclusion and the same happens-before edge in the JMM. `ReentrantLock` adds four things `synchronized` doesn't have: `tryLock` with a timeout, interruptible acquire, optional fairness, and multiple `Condition` variables. The trade-off is you have to `unlock()` in a `finally` block by hand — forget it, and the lock leaks. So I default to `synchronized` and switch to `ReentrantLock` only when one of those four features is needed."

---

## 2. Under the Hood (JVM Internals)

### 2.1 Feature comparison — the cheat sheet

| Feature | `synchronized` | `ReentrantLock` |
|---|---|---|
| Built into language | Yes (keyword) | No (class) |
| Auto-release on exception/return | **Yes** | **No** — must `unlock()` in `finally` |
| Reentrant | Yes | Yes |
| Try to acquire without blocking | No | `tryLock()` |
| Try to acquire with timeout | No | `tryLock(time, unit)` |
| Interruptible acquire | No | `lockInterruptibly()` |
| Fairness option | No (always unfair) | `new ReentrantLock(true)` for FIFO |
| Multiple wait sets | One per monitor | `newCondition()` — many per lock |
| Inspect lock holder / queue | No | `getOwner()`, `getQueueLength()`, etc. |
| Lock state | JVM mark word (biased → thin → inflated) | Java-level `AbstractQueuedSynchronizer` state |
| Performance (uncontended) | ~equal (after JIT optimizations) | ~equal |
| Performance (highly contended) | Inflated monitor: similar to `ReentrantLock` | Often slightly faster, more predictable |
| Works with `wait()`/`notify()` | Yes (intrinsic monitor) | No — use `Condition.await()` / `signal()` |

### 2.2 How `ReentrantLock` actually works — AQS

`ReentrantLock` is built on **`AbstractQueuedSynchronizer` (AQS)** — the framework behind `Semaphore`, `CountDownLatch`, `ReentrantReadWriteLock`, and more.

AQS keeps three things:
1. An `int state` — for `ReentrantLock`, this is the **hold count** (0 = free, n = held n times by owner).
2. A reference to the **owning thread** (`exclusiveOwnerThread`).
3. A FIFO **CLH-style queue** of parked threads waiting for the lock.

When you call `lock()`:
- CAS `state` from 0 → 1. Win? You own it. Done.
- Lose? Check: am I already the owner? If yes, `state++` (reentrancy). Done.
- Otherwise: enqueue self, `LockSupport.park()` → state becomes **WAITING** (not BLOCKED — important!).
- When the owner calls `unlock()` and `state` drops to 0, AQS picks the next node and `unpark()`s it.

This is why threads waiting on a `ReentrantLock` show **WAITING** in `jstack`, not **BLOCKED**. A trap for mid-level devs.

### 2.3 The four features `synchronized` cannot do

**(1) `tryLock()` — non-blocking acquire**
```java
if (lock.tryLock()) {
    try { /* critical section */ } finally { lock.unlock(); }
} else {
    // didn't get the lock — do something else, don't block
}
```
Use case: you want to skip work rather than wait. Real-world: a cache warmer that says "if someone else is already warming, skip this round".

**(2) `tryLock(timeout)` — bounded wait**
```java
if (lock.tryLock(500, TimeUnit.MILLISECONDS)) {
    try { /* ... */ } finally { lock.unlock(); }
} else {
    throw new TimeoutException("could not acquire lock in 500ms");
}
```
Use case: avoid hanging forever. SLO-bound services use this constantly. `synchronized` has no equivalent — it waits forever.

**(3) `lockInterruptibly()` — cancellable acquire**
A thread waiting on `synchronized` **cannot be interrupted**. It will sit in BLOCKED forever, ignoring `Thread.interrupt()`. With `ReentrantLock.lockInterruptibly()`, a wait can be cancelled — the thread wakes with `InterruptedException`. Critical for graceful shutdown of long-running workers.

**(4) Fairness — FIFO order**
```java
ReentrantLock fair = new ReentrantLock(true);
```
- **Unfair (default, same as `synchronized`):** a thread releasing the lock can hand it to a newly-arrived thread that "barged" in front of the queue — **higher throughput**, but possible **starvation**.
- **Fair:** lock goes to the longest-waiting thread — **no starvation**, but ~10× lower throughput because of more context switches.
Use fair only when starvation is observable. Most production code uses unfair.

### 2.4 `Condition` — better than `wait()`/`notify()`

With `synchronized`, every monitor has **one** wait set. `notifyAll()` wakes everyone waiting on that monitor — even those waiting for a different condition. Costly.

`ReentrantLock` lets you create **many `Condition`s** per lock, each with its own queue:

```java
ReentrantLock lock = new ReentrantLock();
Condition notFull  = lock.newCondition();
Condition notEmpty = lock.newCondition();
```

Now producers wait on `notFull`, consumers wait on `notEmpty`. When a producer adds an item, it signals **only** `notEmpty` — no wasted wake-ups. This is exactly how `ArrayBlockingQueue` is implemented internally.

Mapping:
- `obj.wait()` ↔ `condition.await()`
- `obj.notify()` ↔ `condition.signal()`
- `obj.notifyAll()` ↔ `condition.signalAll()`

Same rule: must hold the lock to call them.

### 2.5 The biggest risk of `ReentrantLock` — leaked locks

`synchronized` releases the lock automatically on exception or return. `ReentrantLock` does not. **Always** use this pattern:

```java
lock.lock();
try {
    // critical section
} finally {
    lock.unlock();   // even if an exception was thrown
}
```

Forget the `finally`, throw an exception, and the lock is held forever. Every other thread waits forever. Production hang. This is the **#1 reason** to default to `synchronized` — it's harder to misuse.

Don't put `lock.lock()` *inside* the `try` — if the lock call itself throws (e.g., `tryLock` throwing on a closed scope), you'd `unlock()` a lock you never acquired and get `IllegalMonitorStateException`.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| Mutual exclusion | Not needed (event loop) | `synchronized` or `ReentrantLock` |
| "Try without blocking" | `if (!busy) { busy = true; ... }` | `tryLock()` |
| "Wait with timeout" | `Promise.race([work, timeout])` | `tryLock(timeout)` |
| "Cancellable wait" | `AbortController.abort()` | `lockInterruptibly()` + `Thread.interrupt()` |
| Multiple wait queues per resource | Multiple event emitters / channels | Multiple `Condition`s on one lock |
| Auto-cleanup on error | `try/finally` (rarely needed for locks) | **`try/finally` is mandatory for `ReentrantLock`** |

### Where the comparison breaks down

- In Node, "tryLock" is usually just a boolean flag because nothing preempts you mid-statement. In Java, you need an actual CAS-based primitive or you get torn reads — a boolean flag check is racy.
- `AbortController` in Node is opt-in cooperative cancellation by the awaiting code. Java `Thread.interrupt()` is similar — but `synchronized` ignores it entirely. That blind spot is exactly why `lockInterruptibly()` exists.
- Multiple wait queues feel exotic to a Node dev because Node never blocks on a lock. The Java pattern is closer to multiple event listeners on an EventEmitter — except they're tied to one lock, not free-floating.

---

## 4. Production-Grade Code

A realistic snippet: a **bounded job queue** for an export service. Producers add jobs, consumers process them. Uses two `Condition`s on one `ReentrantLock`, `tryLock` with timeout for the metric, and `lockInterruptibly` for shutdown.

```java
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedJobQueue<T> {

    private final Deque<T> buffer = new ArrayDeque<>();
    private final int capacity;

    // One lock guards the buffer; two conditions distinguish "not full" vs "not empty".
    private final ReentrantLock lock = new ReentrantLock();   // unfair by default — higher throughput
    private final Condition notFull  = lock.newCondition();
    private final Condition notEmpty = lock.newCondition();

    private volatile boolean shuttingDown = false;

    public BoundedJobQueue(int capacity) {
        this.capacity = capacity;
    }

    /** Producer side — interruptible so shutdown can unstick it. */
    public void put(T job) throws InterruptedException {
        lock.lockInterruptibly();
        try {
            while (buffer.size() == capacity && !shuttingDown) {
                notFull.await();   // releases lock, parks thread, re-acquires on wake
            }
            if (shuttingDown) throw new InterruptedException("queue is shutting down");
            buffer.addLast(job);
            notEmpty.signal();      // wake exactly one consumer — not signalAll
        } finally {
            lock.unlock();
        }
    }

    /** Consumer side — bounded wait, returns empty if nothing arrives in time. */
    public Optional<T> poll(long timeoutMs) throws InterruptedException {
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs);
        lock.lockInterruptibly();
        try {
            while (buffer.isEmpty()) {
                long remaining = deadline - System.nanoTime();
                if (remaining <= 0) return Optional.empty();
                notEmpty.awaitNanos(remaining);   // handles spurious wakeups via the loop
            }
            T job = buffer.removeFirst();
            notFull.signal();
            return Optional.of(job);
        } finally {
            lock.unlock();
        }
    }

    /** Metric: best-effort size read. Skips the read if a writer holds the lock. */
    public int sizeOrMinusOne() {
        if (!lock.tryLock()) return -1;   // don't block a metrics scrape on a busy queue
        try {
            return buffer.size();
        } finally {
            lock.unlock();
        }
    }

    /** Graceful shutdown — wakes everyone parked on a condition. */
    public void shutdown() {
        lock.lock();
        try {
            shuttingDown = true;
            notFull.signalAll();   // unblock producers so they can see the flag
            notEmpty.signalAll();
        } finally {
            lock.unlock();
        }
    }
}
```

Why each piece matters:
- **Two `Condition`s** — producers and consumers wait on different queues, so `signal()` wakes the right thread. With `synchronized` you'd need `notifyAll()` and a wasted-wakeup storm.
- **`lockInterruptibly()`** — a stuck producer can be interrupted during shutdown. With `synchronized`, it would hang forever.
- **`await()` is inside a `while` loop** — never `if`, because of spurious wakeups (the JVM is allowed to wake `await()` for no reason).
- **`tryLock()` for metrics** — read-only observers shouldn't queue behind writers.
- **`finally { lock.unlock(); }` everywhere** — every code path that locks must release. No exceptions.

---

## 5. Top 3 MNC Interview Questions

**Q1: When would you actually pick `ReentrantLock` over `synchronized` in production?**
*What they're testing:* whether you've used both, or just know the trivia.
*Ideal answer:* I default to `synchronized` because it's harder to misuse — auto-release on exception, no `finally` needed. I switch to `ReentrantLock` only when I need a feature the keyword can't give me: timed `tryLock` to avoid hanging past an SLO, `lockInterruptibly` so graceful shutdown can unstick a thread, multiple `Condition`s so producers and consumers don't wake each other unnecessarily, or true fairness to prevent starvation. Performance is not a reason — modern JVMs make them roughly equal in the uncontended case.

**Q2: A thread is waiting on a `ReentrantLock`. What state does `jstack` show — BLOCKED or WAITING?**
*What they're testing:* the AQS internals trap — most candidates say BLOCKED.
*Ideal answer:* WAITING. `ReentrantLock` is built on AQS, which parks contending threads using `LockSupport.park()` — and `park` puts a thread in WAITING, not BLOCKED. BLOCKED is reserved for threads waiting to enter a `synchronized` block. So in a thread dump, "I'm waiting on a lock" can appear as either state depending on which primitive you used. It also means using only "BLOCKED count" as a contention metric will silently miss all `ReentrantLock` contention.

**Q3: Why is `await()` always called inside a `while` loop, never an `if`?**
*What they're testing:* the spurious-wakeup contract.
*Ideal answer:* Because the JVM is explicitly allowed to wake a thread from `await()` (or `Object.wait()`) for no reason — that's called a spurious wakeup. If you used `if`, the woken thread would proceed even when the condition isn't actually true and you'd hit the bug exactly once a month in production. With `while`, the thread re-checks the condition and goes back to `await()` if it's not satisfied. Same rule applies to `Object.wait()`. It's such a common bug that the Javadoc explicitly tells you to use a loop.

---

### Memorize this
> **Memorize this:** Default to `synchronized`; switch to `ReentrantLock` only for `tryLock(timeout)`, `lockInterruptibly`, fairness, or multiple `Condition`s — and always `lock(); try { ... } finally { unlock(); }`, with `await()` inside a `while` loop.

---

**Next likely topics:** `volatile` and the Java Memory Model (the lightweight visibility primitive that `synchronized` and `Lock` both rely on), or `ReadWriteLock` / `StampedLock` (the read-heavy optimization you reach for when `ReentrantLock` becomes the bottleneck). Both are direct follow-ups.
