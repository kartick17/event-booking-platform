# Thread Lifecycle in Java

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

A Java thread is not always "running" — it moves through a **finite set of states** managed by the JVM and OS. At any moment, every thread is in exactly **one** of 6 states defined in `Thread.State` enum.

The 6 states:
- **NEW** — created with `new Thread()`, but `start()` not yet called.
- **RUNNABLE** — eligible to run; either currently on CPU or waiting for CPU time slice.
- **BLOCKED** — waiting to acquire a **monitor lock** (entering a `synchronized` block held by someone else).
- **WAITING** — waiting *indefinitely* for another thread to signal it (`wait()`, `join()`, `LockSupport.park()`).
- **TIMED_WAITING** — same as WAITING but with a timeout (`sleep(ms)`, `wait(ms)`, `join(ms)`).
- **TERMINATED** — `run()` finished or threw an uncaught exception. **Cannot restart.**

Why it exists: the OS has only a few CPU cores, but a JVM can have thousands of threads. The state machine lets the scheduler **multiplex** them and lets developers reason about *why a thread is stuck* (BLOCKED vs WAITING tells you whether it's a lock contention bug or a missed `notify()`).

> **Interview definition (say this out loud):** "A Java thread moves through 6 states defined in `Thread.State` — NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING, TERMINATED. RUNNABLE actually combines OS-level *ready* and *running* — Java doesn't distinguish them. BLOCKED means waiting on a monitor lock, WAITING means waiting on a signal — that distinction is what we use to debug stuck threads in production."

---

## 2. Under the Hood (JVM Internals)

### 2.1 The state machine — full transition map

| From → To | Trigger |
|---|---|
| NEW → RUNNABLE | `start()` called once |
| RUNNABLE → BLOCKED | Tried to enter `synchronized` but lock held by another thread |
| BLOCKED → RUNNABLE | Acquired the monitor lock |
| RUNNABLE → WAITING | `obj.wait()`, `thread.join()`, `LockSupport.park()` |
| WAITING → RUNNABLE | `obj.notify()`/`notifyAll()`, target thread finishes (for `join`), `unpark()` |
| RUNNABLE → TIMED_WAITING | `Thread.sleep(ms)`, `obj.wait(ms)`, `join(ms)`, `parkNanos()` |
| TIMED_WAITING → RUNNABLE | Time expires or signal received |
| RUNNABLE → TERMINATED | `run()` returns or throws uncaught exception |

**Key trap:** there is **no direct path** NEW → TERMINATED, and **no path** TERMINATED → anywhere. Once dead, always dead. Calling `start()` on a TERMINATED thread throws `IllegalThreadStateException`.

### 2.2 RUNNABLE is a lie (the OS truth)

The JVM merges two OS-level states into one Java state:
- **Ready** — on the OS run queue, waiting for a CPU.
- **Running** — currently executing on a CPU core.

Java's `Thread.getState()` returns `RUNNABLE` for both. Why? Because by the time you call `getState()` and read the result, the answer could have flipped — so the JVM doesn't pretend to know. **If you need to know whether a thread is *actually* on a CPU, you need OS-level tools** (`top -H`, `jstack`, async-profiler).

### 2.3 BLOCKED vs WAITING — the #1 senior interview trap

| | BLOCKED | WAITING |
|---|---|---|
| Cause | Cannot enter `synchronized` | Voluntarily paused waiting for a signal |
| Wakes when | Lock is released | Another thread calls `notify` / `unpark` / target `join` completes |
| Holds the monitor it's waiting on? | No (hasn't acquired yet) | No — `wait()` releases that monitor; but keeps other unrelated locks |
| `ReentrantLock.lock()` waits in | — | **WAITING** (not BLOCKED!) |

**Critical fact:** `synchronized` puts you in **BLOCKED**. `ReentrantLock.lock()` puts you in **WAITING** — because internally it uses `LockSupport.park()`. So a thread "waiting on a lock" can show either state in `jstack` depending on which lock primitive you used. Mid-level devs miss this.

### 2.4 Memory & object identity of the thread

- Every `Thread` is a regular Java object on the **heap** — its fields (`name`, `priority`, `state`, `ThreadLocalMap`) live there.
- Each thread also gets its **own native stack** (default ~512KB–1MB, set via `-Xss`). Stack is *not* on the heap — it's a separate OS-allocated region.
- The mapping between the Java `Thread` object and the OS thread is held in JVM-internal C++ structures (`JavaThread` in HotSpot). When the Java object is GC'd, the OS thread is already gone (you can only collect a TERMINATED thread).
- **Daemon vs user threads:** the JVM exits when all *user* threads die — daemon threads are killed abruptly. Set via `setDaemon(true)` *before* `start()`.

### 2.5 Virtual threads (Java 21+) — what changes

Virtual threads use the **same `Thread.State` enum** — so the lifecycle model still applies. But:
- WAITING/TIMED_WAITING no longer pins an OS thread — the carrier thread is freed to run other virtual threads (this is "unmounting").
- BLOCKED *does* still pin the carrier thread (until Loom team fixes `synchronized` pinning — partially fixed in JDK 24).
- TERMINATED virtual threads are cheap to GC — no OS thread to clean up.

This is why interviewers in 2025+ ask "what happens to a virtual thread in WAITING?" — answer: it unmounts from its carrier, and the carrier picks up another virtual thread.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| Unit of concurrency | Async task on event loop | OS thread (or virtual thread) |
| "Waiting for I/O" | Promise pending in microtask queue | Thread in WAITING / TIMED_WAITING |
| "Blocked on a lock" | Doesn't exist — single-threaded | BLOCKED state |
| "Task finished" | Promise resolved/rejected | TERMINATED |
| Inspect state | `--inspect` chrome devtools, async hooks | `jstack`, `Thread.getState()`, JFR |

### Where the comparison breaks down

- Node has **no BLOCKED state** because it has no shared-memory locks — the event loop never contends for a mutex. Java BLOCKED is a foreign concept to a Node dev, but it's the **#1 cause of production hangs** in Java apps.
- A Node `await` on a slow DB call **frees the event loop** for other requests. A Java thread in WAITING/TIMED_WAITING on a `Future.get()` **occupies an OS thread** doing nothing — this is why old Java needs thread pools and Node doesn't. Virtual threads close this gap.
- Node "stuck" usually means CPU-bound code on the loop. Java "stuck" usually means BLOCKED (lock contention) or WAITING (missed notify, dead `Future`). The debugging tool is different: Node = flame graph, Java = `jstack` + state column.

---

## 4. Production-Grade Code

A realistic snippet: an order-export worker that demonstrates **every state transition** and shows how to inspect them.

```java
import java.lang.Thread.State;
import java.util.concurrent.locks.ReentrantLock;

public class OrderExportWorker {

    private final ReentrantLock exportLock = new ReentrantLock();
    private final Object resultGate = new Object();
    private volatile boolean resultReady = false;

    public Thread launch(long orderId) {
        Thread worker = new Thread(() -> {
            try {
                // RUNNABLE: actively running

                exportLock.lock();   // RUNNABLE → WAITING (ReentrantLock uses LockSupport.park)
                try {
                    Thread.sleep(200);   // RUNNABLE → TIMED_WAITING (simulate S3 upload)

                    synchronized (resultGate) {
                        while (!resultReady) {
                            resultGate.wait(); // RUNNABLE → WAITING (releases resultGate monitor)
                        }
                    }
                } finally {
                    exportLock.unlock();
                }
                // run() returns → TERMINATED
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }
        }, "order-export-" + orderId);

        // NEW until start() is called
        worker.setDaemon(false); // user thread — keeps JVM alive until done
        worker.start();          // NEW → RUNNABLE
        return worker;
    }

    public void signalReady() {
        synchronized (resultGate) {
            resultReady = true;
            resultGate.notifyAll();   // wakes thread from WAITING → BLOCKED → RUNNABLE
        }
    }

    /** Diagnostic — call from a separate monitoring thread. */
    public static void dumpState(Thread t) {
        State s = t.getState();
        System.out.printf("[%s] state=%s alive=%b%n", t.getName(), s, t.isAlive());
        // In prod: send s.name() as a tag to Micrometer / Prometheus
        // BLOCKED count rising = lock contention; WAITING rising = missed notify or slow downstream
    }
}
```

Why each piece matters:
- `setDaemon(false)` before `start()` — after `start()` it throws.
- `ReentrantLock.lock()` is shown so you remember it produces **WAITING**, not BLOCKED.
- `wait()` is inside `while (!flag)` — classic spurious-wakeup guard. Interviewers check for this.
- `getState()` is the supported API to read lifecycle state at runtime; pair it with Micrometer in real services.

---

## 5. Top 3 MNC Interview Questions

**Q1: A thread is stuck in production. How do you tell whether it's BLOCKED or WAITING, and what does each mean for the fix?**
*What they're testing:* whether you can debug a real hang, not just recite states.
*Ideal answer:* I'd take a thread dump with `jstack` and look at the state column. BLOCKED means the thread is trying to enter a `synchronized` block held by someone else — the fix is to find the lock holder, also in the dump, and figure out why it's not releasing. WAITING means the thread voluntarily paused on `wait()`, `join()`, or `LockSupport.park()` — usually a missed `notify()`, a downstream call that never returns, or a `Future` whose producer died. One trap: `ReentrantLock.lock()` shows up as WAITING, not BLOCKED, because it uses `park()` internally — so "waiting on a lock" can appear as either state.

**Q2: Why does Java collapse "ready" and "running" into a single RUNNABLE state?**
*What they're testing:* understanding of the JVM-OS boundary.
*Ideal answer:* Because by the time `getState()` returns its answer, the thread may already have switched between ready and running — the OS scheduler operates on nanosecond timescales. So the JVM exposes a coherent abstraction: "eligible to run". If you genuinely need to know which threads are currently on a CPU core, you need OS tools like `top -H` or a profiler — Java's API can't promise that level of precision.

**Q3: Can a thread go from TERMINATED back to RUNNABLE? Why or why not?**
*What they're testing:* whether you know Thread is a one-shot object — a common junior mistake is calling `start()` twice.
*Ideal answer:* No. Once `run()` returns or throws, the thread enters TERMINATED and stays there forever. Calling `start()` on it throws `IllegalThreadStateException`. The underlying reason is that the OS thread is gone — the Java object lingers only so you can inspect the final state, but there's no native thread to resume. If you need to "restart", you create a new `Thread` instance, or better, use an `ExecutorService` which reuses pooled threads under the hood — the same OS thread runs many `Runnable`s sequentially, but each one runs in a fresh logical task.

---

### Memorize this
> **Memorize this:** 6 states — NEW → RUNNABLE → (BLOCKED on `synchronized`) / (WAITING on `notify`/`join`/`park`) / (TIMED_WAITING on timeout) → TERMINATED; RUNNABLE merges OS *ready* + *running*, BLOCKED is only for `synchronized` (ReentrantLock = WAITING), and TERMINATED is one-way.

---

**Next likely topics:** `wait()` / `notify()` / `notifyAll()` contract (and why they must be inside `synchronized`), or `ReentrantLock` vs `synchronized` (fairness, `tryLock`, interruptible acquire). Both are direct follow-ups your interviewer will push into.
