# Threads & Multithreading in Java

**Priority: Interview-critical**

---

## 1. Core Mechanism

- A **thread** is a single path of execution inside a JVM process. The JVM itself runs as one OS process; threads are the workers inside it.
- **Multithreading** = running many threads at the same time inside one JVM, sharing the same heap (object memory), but each thread keeps its own stack (local variables, method frames).
- Why Java cares so much: Java was built for **multi-core servers handling many requests at once**. Languages like C give you OS threads through a library (`pthread`); Java made threads a **first-class language feature** with `Thread`, `synchronized`, `volatile`, and a formal memory model. That is why concurrency is asked in *every* MNC Java interview.
- Two reasons you spin up threads in real backends:
  1. **Parallelism** — use multiple CPU cores at once (CPU-heavy work).
  2. **Concurrency** — let slow I/O calls wait without blocking the whole app (DB, HTTP, file).

> **Interview definition (say this out loud):** "A thread is the smallest unit of scheduled execution inside the JVM. Multithreading means many threads run inside the same process, sharing the heap but each having its own stack — that lets one Java app use multiple CPU cores and handle many requests in parallel."

---

## 2. Under the Hood (JVM & OS Internals)

### 2.1 JVM thread = OS thread (the 1:1 model)

- A `java.lang.Thread` is **not** a Java-level construct that the JVM schedules itself. The JVM calls into the OS (`pthread_create` on Linux, `CreateThread` on Windows) and gets a **real kernel thread**.
- This is called the **1:1 threading model**. One Java thread = one OS thread = one schedulable entity for the OS scheduler.
- Consequence: the **OS decides** which thread runs when, on which core, and for how long. Java does not have its own scheduler. `Thread.sleep`, `Thread.yield`, priorities — they are all **hints to the OS**, not commands.
- Cost of a platform thread:
  - **~1 MB of stack** by default (configurable via `-Xss`).
  - Kernel resources (kernel stack ~16KB, scheduler entry).
  - **Context switch** ~1–10 microseconds (kernel-mode, flushes CPU caches).
  - Practical ceiling: a few thousand platform threads per JVM. After that, memory and scheduling cost dominate.

### 2.2 Memory layout per thread

Each thread owns:
- **Java stack** — method frames, local primitives, references. Private. Grows downward.
- **Program counter (PC)** — current bytecode instruction. Private.
- **Native method stack** — for JNI calls. Private.

Each thread **shares**:
- **Heap** — every `new` object lives here, visible to all threads. *This is where race conditions are born.*
- **Metaspace** — class metadata.
- **String pool** — interned strings.

This is why interview questions like "where do local primitives live?" → **stack, per thread**. "Where does a `new ArrayList()` live?" → **heap, shared**.

### 2.3 Thread lifecycle (`Thread.State` enum)

| State | What it means | How you enter it |
|---|---|---|
| `NEW` | Object created, `start()` not called yet. | `new Thread(r)` |
| `RUNNABLE` | Eligible to run. May be *running on a core* or *ready and waiting for a core*. Java collapses these two into one state. | `start()` called |
| `BLOCKED` | Waiting to enter a `synchronized` block whose monitor is held by another thread. | Hit a contended `synchronized` |
| `WAITING` | Indefinite wait until another thread signals. | `obj.wait()`, `LockSupport.park()`, `Thread.join()` |
| `TIMED_WAITING` | Same as `WAITING` but with a timeout. | `Thread.sleep(ms)`, `wait(ms)`, `join(ms)` |
| `TERMINATED` | `run()` returned (normally or by exception). Cannot be restarted. | Method exits |

Key trap: `RUNNABLE` does **not** mean "currently executing". It means "the OS can run me whenever it wants." Interviewers love this.

### 2.4 Java Memory Model (JMM) in one breath

Threads share the heap, but **each CPU core has its own cache**. Without rules, a write by thread A might never be visible to thread B (cached locally).

The JMM defines **happens-before**: if action X happens-before action Y, X's writes are visible to Y. You get a happens-before edge from:
- `synchronized` lock release → next lock acquire on the same monitor.
- `volatile` write → next read of the same field.
- `Thread.start()` → first action in the new thread.
- Thread A's last action → Thread B's `join()` returning.

Without one of these edges, the JVM and CPU are **free to reorder reads/writes**. That is why `volatile` and `synchronized` exist even on a single variable.

### 2.5 Virtual threads (Java 21) — the M:N model

Platform threads are heavy. For an app that does 90% blocking I/O (typical backend), 99% of those expensive OS threads are *sleeping*. Java 21 fixed this with **virtual threads** (Project Loom).

- A virtual thread is a `Thread` instance, but it lives in **JVM user space**, not the OS.
- The JVM keeps a small pool of real OS threads called **carriers** (default: one per CPU core).
- A virtual thread **mounts** onto a carrier to run. When it hits a blocking call (`socketRead`, `Thread.sleep`, `BlockingQueue.take`), the JVM **unmounts** it and parks it. The carrier immediately picks up another virtual thread.
- Cost of a virtual thread: **~1 KB** initial stack (grows on demand). You can launch **millions** per JVM.
- Caveat — **pinning**: if a virtual thread blocks inside a `synchronized` block or a JNI call, it **cannot unmount**. The carrier is stuck too. Fix: use `ReentrantLock` instead of `synchronized` for code that may block.

| | Platform thread | Virtual thread |
|---|---|---|
| Mapping | 1:1 to OS thread | M:N onto carrier pool |
| Stack | ~1 MB fixed | ~1 KB, grows |
| Practical max | a few thousand | millions |
| Scheduled by | OS kernel | JVM |
| Good for | CPU-bound work | I/O-bound work |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java / Spring |
|---|---|---|
| Concurrency model | Single-threaded **event loop** + libuv worker pool for fs/crypto | **Thread-per-request** (platform or virtual) |
| Handling 10k requests | Event loop multiplexes them; one slow CPU task stalls everyone | Each request gets its own thread; OS or JVM schedules them |
| Async unit | `Promise` / `async-await` | `CompletableFuture`, virtual threads, `@Async` |
| Shared state across requests | Almost never — same isolate, but each request lives in its own closure/context | **Yes — heap is shared.** Race conditions are real. |
| Blocking a DB call | Disaster — whole server stalls | Fine — only *that* thread parks |
| Cooperative vs preemptive | **Cooperative** — you must `await` to yield | **Preemptive** — OS interrupts whenever it wants |

**Where the comparison breaks down:**
- In Node, you never write a mutex because there's nothing to mutex against — one request's variables are unreachable from another's stack. In Java, two threads can both call `counter++` on a shared object and corrupt it. **This is the biggest mental shift.**
- Node's `async/await` is *syntactic*. Java's threading is *runtime*. A Java thread can be paused mid-instruction; a JS function only yields at an `await` point.
- Java has true **parallelism**. Node, by default, has concurrency but not parallelism (you need `worker_threads` or `cluster` for parallel cores).
- Virtual threads make Java look almost like Node — write blocking code, the JVM handles the multiplexing — but you still get real heap sharing and real locks. Best of both worlds, with the same footguns.

---

## 4. Production-Grade Code

A realistic enrichment service: one inbound order needs data from three downstream services in parallel. Shown two ways — classic `ExecutorService` + `CompletableFuture`, then the Java 21 virtual-thread style.

```java
import java.util.concurrent.*;

public class OrderEnrichmentService {

    private final InventoryClient inventoryClient;
    private final PricingClient   pricingClient;
    private final ShippingClient  shippingClient;

    // Bounded platform-thread pool. Sized for downstream concurrency,
    // NOT request volume — that's the classic mistake.
    private final ExecutorService ioPool = Executors.newFixedThreadPool(50);

    public OrderEnrichmentService(InventoryClient i, PricingClient p, ShippingClient s) {
        this.inventoryClient = i; this.pricingClient = p; this.shippingClient = s;
    }

    // Classic style: three blocking fetches fanned out to a pool, joined back.
    public EnrichedOrder enrich(String orderId) {
        var invF = CompletableFuture.supplyAsync(() -> inventoryClient.fetch(orderId), ioPool);
        var prF  = CompletableFuture.supplyAsync(() -> pricingClient.fetch(orderId),   ioPool);
        var shF  = CompletableFuture.supplyAsync(() -> shippingClient.fetch(orderId),  ioPool);

        // allOf waits for all three; .join() surfaces the first failure as a runtime exception
        return CompletableFuture.allOf(invF, prF, shF)
                .thenApply(v -> new EnrichedOrder(orderId, invF.join(), prF.join(), shF.join()))
                .join();
    }

    // Java 21 virtual-thread style: no pool sizing, one virtual thread per task.
    // try-with-resources shuts the executor down and waits for tasks on close.
    public EnrichedOrder enrichV21(String orderId) throws Exception {
        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<Inventory> invF = exec.submit(() -> inventoryClient.fetch(orderId));
            Future<Pricing>   prF  = exec.submit(() -> pricingClient.fetch(orderId));
            Future<Shipping>  shF  = exec.submit(() -> shippingClient.fetch(orderId));
            return new EnrichedOrder(orderId, invF.get(), prF.get(), shF.get());
        }
    }

    public record EnrichedOrder(String orderId, Inventory inv, Pricing pr, Shipping sh) {}

    public interface InventoryClient { Inventory fetch(String id); }
    public interface PricingClient   { Pricing   fetch(String id); }
    public interface ShippingClient  { Shipping  fetch(String id); }
    public record Inventory(int stock) {}
    public record Pricing(double price) {}
    public record Shipping(String slaDays) {}
}
```

What to notice as an interviewer would:
- The platform-thread pool is **bounded** — never use `newCachedThreadPool` for unbounded I/O work in prod; it will spawn until the JVM OOMs.
- Virtual-thread executor is created **per request** and closed in `try-with-resources` — that is the Loom-recommended pattern (structured concurrency).
- The classic version routes failures through `CompletableFuture`; the virtual-thread version uses plain blocking `.get()` — because blocking is now *cheap* and reads like sequential code.

---

## 5. Top 3 MNC Interview Questions

**Q1: What is the difference between `Thread` and `Runnable`? Which do you prefer and why?**

- *What they're testing:* whether you understand inheritance vs composition, and whether you know not to extend `Thread` in real code.
- *Ideal answer:* `Thread` is a class that *is* an executable. `Runnable` is a functional interface that *describes* a task. I always prefer `Runnable` (or `Callable` when I need a return value), because extending `Thread` couples my business logic to the threading mechanism and burns my single inheritance slot. In production I almost never instantiate `Thread` directly anyway — I submit `Runnable`/`Callable` to an `ExecutorService` so the pool controls lifecycle, naming, and shutdown.

**Q2: Walk me through the states of a Java thread.**

- *What they're testing:* whether you know `RUNNABLE` covers both "running" and "ready to run", and whether you can tell `BLOCKED` from `WAITING`.
- *Ideal answer:* Six states from `Thread.State`. `NEW` before `start()`. `RUNNABLE` once started — and that covers both currently executing and ready-on-the-queue; Java collapses them because scheduling is the OS's job. `BLOCKED` means waiting for a `synchronized` monitor another thread holds. `WAITING` is indefinite — `wait()`, `join()`, `LockSupport.park()`. `TIMED_WAITING` is the same with a timeout, like `sleep` or `wait(ms)`. `TERMINATED` once `run()` returns. The trap is calling `RUNNABLE` "running" — it isn't, the OS may not have scheduled it yet.

**Q3: What are virtual threads, and how are they different from platform threads?**

- *What they're testing:* whether you've actually used Java 21 or just heard the term, and whether you know the pinning gotcha.
- *Ideal answer:* A platform thread is a 1:1 wrapper around an OS thread — about 1 MB stack, scheduled by the kernel, practical limit a few thousand. A virtual thread lives in JVM user space; it mounts onto a small pool of carrier OS threads and unmounts whenever it blocks on I/O. Stack is ~1 KB and grows, so you can run millions. They're scheduled by the JVM, not the OS. The catch is **pinning**: if a virtual thread blocks inside a `synchronized` block or a JNI call, it can't unmount and the carrier is stuck — so for code that blocks under a lock, switch to `ReentrantLock`. Best use case: I/O-heavy backends; for CPU-bound work, platform threads with a pool sized to cores is still right.

---

> **Memorize this:** A Java thread = own stack, shared heap, 1:1 to an OS thread, scheduled by the kernel — virtual threads (Java 21) break that 1:1 by mounting millions of cheap user-mode threads onto a tiny pool of carrier OS threads.

---

**Next likely topics:** `synchronized` vs `ReentrantLock` (locks and the monitor), or **`volatile` and the Java Memory Model** (visibility & happens-before).
