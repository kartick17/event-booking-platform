# `wait()` / `notify()` / `notifyAll()` — The Monitor Contract

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

These three methods live on `java.lang.Object` — **every** object has them. They are the primitive building block for **thread coordination**: one thread waits for a condition, another thread signals when the condition is true.

The three methods:
- **`obj.wait()`** — the current thread **releases `obj`'s monitor** and goes to **WAITING** state. It will not wake until another thread calls `obj.notify()` or `obj.notifyAll()` (or it's interrupted, or a timed `wait(ms)` expires).
- **`obj.notify()`** — wakes **one** thread waiting on `obj`'s monitor. Which one? JVM's choice — no fairness guarantee.
- **`obj.notifyAll()`** — wakes **all** threads waiting on `obj`'s monitor. They then compete for the monitor again.

The **hard rule**: all three must be called **while holding `obj`'s monitor**. Calling them outside a `synchronized` block on `obj` throws `IllegalMonitorStateException` at runtime.

Why these exist: `synchronized` alone gives you mutual exclusion, but no way to **wait for a state change**. Without `wait`/`notify`, the only way to wait would be a busy-loop checking a flag — burning CPU. `wait()` parks the thread cheaply until told to wake.

> **Interview definition (say this out loud):** "`wait`, `notify`, and `notifyAll` are the low-level coordination primitives on every Java object. They must be called while holding that object's monitor — `wait` then atomically releases the monitor and parks the thread, and re-acquires it before returning. `notify` wakes one waiter; `notifyAll` wakes all. They're the building block under `BlockingQueue`, `CountDownLatch`, and every higher-level synchronizer. In modern code I use `Condition` or `BlockingQueue` instead, but I have to know the contract because a missed `notify` is a classic production hang."

---

## 2. Under the Hood (JVM Internals)

### 2.1 Why must you hold the monitor?

Look at the typical pattern:
```java
synchronized (queue) {
    while (queue.isEmpty()) {
        queue.wait();
    }
    Item item = queue.poll();
}
```

The check `queue.isEmpty()` and the call `queue.wait()` **must happen atomically with respect to the producer**. If they didn't:
1. Consumer sees `queue.isEmpty() == true`.
2. **Producer adds an item and calls `notify()`** — no one is waiting yet, signal is **lost**.
3. Consumer calls `wait()` and parks forever.

This is the **lost-wakeup problem**. The JVM forces you to hold the monitor so that producer and consumer cannot interleave between the check and the wait. The producer can't acquire the monitor to add an item until the consumer has released it via `wait()`.

`IllegalMonitorStateException` exists precisely to catch this misuse at runtime — the JVM cannot make `wait/notify` safe if you don't hold the monitor.

### 2.2 What `wait()` actually does (atomically)

```
1. Verify: current thread holds obj's monitor — else throw IllegalMonitorStateException.
2. Record current hold count (for reentrancy).
3. Release the monitor completely (hold count → 0).
4. Add this thread to obj's wait set.
5. Park the thread (state = WAITING, or TIMED_WAITING for wait(ms)).
6. ... time passes ...
7. Woken by notify / notifyAll / interrupt / timeout / spurious wakeup.
8. Re-acquire the monitor (this can BLOCK — wake doesn't mean instant run).
9. Restore the original hold count.
10. Return from wait().
```

Steps 3 and 4 are **atomic** from any other thread's perspective. That atomicity is what `synchronized` provides — and why this can't be done without it.

### 2.3 `notify()` vs `notifyAll()` — when to use which

| | `notify()` | `notifyAll()` |
|---|---|---|
| Wakes | One arbitrary waiter | All waiters |
| Cost | Cheap | Expensive (thundering herd) |
| Safe when | All waiters wait for the *same* condition, and any one of them can proceed | Different waiters may wait for different conditions |
| Risk | **Lost wakeup** if the woken thread can't actually proceed | Wasted wakeups (woken threads re-`wait()`) |

**Default to `notifyAll()`**. Use `notify()` only when you've proven every waiter is interchangeable. Example of the trap:

```java
// Producers wait for "not full", consumers wait for "not empty" — both on same monitor.
// If you call notify() after adding an item, JVM might wake a producer instead of a consumer.
// Producer sees "still full", goes back to wait. Consumer never woke. Deadlock.
```

This is exactly the problem `Condition` solves with multiple wait queues per lock.

### 2.4 The `while` loop is non-negotiable

```java
// WRONG
synchronized (obj) {
    if (!condition) obj.wait();
    doWork();
}

// RIGHT
synchronized (obj) {
    while (!condition) obj.wait();
    doWork();
}
```

Three reasons `while` beats `if`:
1. **Spurious wakeups** — the JVM is explicitly allowed to wake `wait()` for no reason. Documented in the Javadoc.
2. **`notifyAll` storms** — multiple threads wake, but only one can succeed; the others must re-check.
3. **Condition can change between wake and monitor re-acquire** — another thread can sneak in.

Using `if` here is the most common concurrency bug in junior code. Interviewers ask about it specifically.

### 2.5 The wait set vs the entry set

Every monitor has **two queues**:
- **Entry set** — threads in **BLOCKED** state waiting to *enter* the `synchronized` block.
- **Wait set** — threads in **WAITING** state that called `wait()` and are waiting for a notification.

`notify()` moves one thread from the wait set to the entry set. It does **not** put the thread back into the running state — the thread must still re-acquire the monitor, which means BLOCKED until it wins. This is why notifying doesn't make the woken thread run immediately — it just makes it *eligible* to compete.

### 2.6 The four ways `wait()` can return

| Reason | How to detect |
|---|---|
| `notify` / `notifyAll` woke me | Re-check the condition — that's why `while` |
| Timeout expired (`wait(ms)`) | Re-check the condition (no API to tell which) |
| `Thread.interrupt()` was called | `InterruptedException` is thrown |
| Spurious wakeup | Re-check the condition (no signal at all) |

Notice: **you cannot tell *why* you woke up** without re-checking state. The condition variable is the ground truth, not the wake-up itself.

### 2.7 Why these are on `Object`, not `Thread`

A common confusion: "Shouldn't `wait` be on `Thread`?" No. Threads coordinate **through a shared object**. The object is the rendezvous point — the place where one says "I'm ready" and the other says "I'm waiting for ready". Each object has its own wait set; threads pick which object to wait/notify on based on what state they care about.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| "Wait for a condition" | `await new Promise(res => emitter.once('ready', res))` | `obj.wait()` inside `synchronized (obj)` |
| "Signal one waiter" | `emitter.emit('ready')` (first listener) | `obj.notify()` |
| "Signal all waiters" | Multiple listeners on the event | `obj.notifyAll()` |
| Lost-wakeup possible? | Rare — single-threaded loop | **Yes — the default failure mode** if you forget the monitor |
| Atomic check-then-wait | Free (no preemption) | Must hold the monitor |

### Where the comparison breaks down

- Node devs think of `emit` as "if no one's listening, no harm done" — the signal is simply lost. In Java the *same* lost signal causes a thread to park forever, hanging the request. The atomic check-then-wait inside `synchronized` is what prevents it.
- `EventEmitter` listeners are persistent; `wait()` is a **one-shot** — once woken, you must call `wait()` again to wait again. Forgetting the `while` loop makes this single-shot model look broken.
- Node's `await Promise` is the closest match, but a Node promise resolves exactly once and is durable. A `notify` in Java is fire-and-forget — if no one is in the wait set at that moment, the notification is gone forever. This is the #1 mental shift.

---

## 4. Production-Grade Code

A realistic snippet: a **token bucket rate limiter** for outbound API calls. Refiller adds tokens periodically; callers wait when the bucket is empty. Demonstrates the contract exactly.

```java
public class TokenBucketLimiter {

    private final Object monitor = new Object();   // private final — no external locking
    private final int capacity;
    private int tokens;
    private volatile boolean shutdown = false;

    public TokenBucketLimiter(int capacity, int initialTokens) {
        this.capacity = capacity;
        this.tokens = initialTokens;
    }

    /** Caller blocks until a token is available or the bucket is shut down. */
    public void acquire() throws InterruptedException {
        synchronized (monitor) {
            while (tokens == 0 && !shutdown) {
                monitor.wait();   // releases monitor; re-acquires before returning
            }
            if (shutdown) throw new InterruptedException("limiter is shut down");
            tokens--;
        }
    }

    /** Same as acquire(), but with a deadline. Returns false on timeout. */
    public boolean tryAcquire(long timeoutMs) throws InterruptedException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        synchronized (monitor) {
            while (tokens == 0 && !shutdown) {
                long remaining = deadline - System.currentTimeMillis();
                if (remaining <= 0) return false;
                monitor.wait(remaining);   // could return early — loop re-checks
            }
            if (shutdown) return false;
            tokens--;
            return true;
        }
    }

    /** Called by the refill scheduler every second. */
    public void refill(int n) {
        synchronized (monitor) {
            int added = Math.min(n, capacity - tokens);
            if (added == 0) return;
            tokens += added;
            // notifyAll because multiple waiters might each grab a token.
            // notify() would wake only one — the rest would sit on remaining tokens.
            monitor.notifyAll();
        }
    }

    public void shutdown() {
        synchronized (monitor) {
            shutdown = true;
            monitor.notifyAll();   // wake every waiter so they see the flag and exit
        }
    }
}
```

Why each piece matters:
- **`monitor` is `private final Object`** — never lock on `this`. Outside code can't break our coordination.
- **`while` loop around `wait()`** — handles spurious wakeups and shutdown races.
- **Re-check `shutdown` after `wait()` returns** — the wakeup itself doesn't tell you why; the flag does.
- **`notifyAll()` in `refill`** — if we added 5 tokens, 5 waiters can each take one; `notify()` would wake only 1 and the other 4 stay parked.
- **`wait(remaining)` for the timed version** — `wait(0)` means "forever", so always compute a positive value or you'll hang.
- **`shutdown` is `volatile`** — read outside the monitor by other code (e.g., a health check) needs visibility. Inside the monitor, the happens-before edge already covers it.

---

## 5. Top 3 MNC Interview Questions

**Q1: Why must `wait()` and `notify()` be called while holding the object's monitor?**
*What they're testing:* whether you understand the **lost-wakeup** problem — the entire reason the contract exists.
*Ideal answer:* To prevent lost wakeups. If a consumer could check a condition and then call `wait()` without holding the monitor, a producer could slip in between, change the condition, and call `notify()` — and the consumer would then `wait()` forever because the signal already happened. Holding the monitor forces the check and the wait to be atomic from the producer's perspective. `wait()` then atomically releases the monitor and parks, so the producer can finally enter, update state, and notify. `IllegalMonitorStateException` is the JVM's way of catching this misuse at runtime.

**Q2: Why is `wait()` always inside a `while` loop, never an `if`?**
*What they're testing:* the spurious-wakeup contract — junior-vs-mid filter.
*Ideal answer:* Three reasons. First, the JVM is allowed to wake a thread from `wait()` for no reason at all — spurious wakeups are documented behavior. Second, if you used `notifyAll()` and multiple waiters wake, only one can succeed; the rest need to re-check the condition. Third, between the wake and re-acquiring the monitor, another thread can change the state again. `while` re-checks the actual condition on every wake; `if` would let the thread proceed when the condition is false. Same rule applies to `Condition.await()`.

**Q3: When should you use `notify()` instead of `notifyAll()`?**
*What they're testing:* whether you can reason about wakeup correctness, not just spam `notifyAll`.
*Ideal answer:* Only when every waiter is waiting for the *exact same* condition and any one of them can fully consume the state change. If different waiters wait for different conditions on the same monitor — say producers waiting for "not full" and consumers waiting for "not empty" — `notify()` can wake the wrong one, who goes back to waiting, and the right one never wakes. That's a deadlock. `notifyAll()` is the safe default; `notify()` is a performance optimization that needs proof of correctness. In practice, when I need different conditions on the same lock, I switch to `ReentrantLock` with multiple `Condition` objects — that gives me targeted signaling without the lost-wakeup risk.

---

### Memorize this
> **Memorize this:** `wait`/`notify`/`notifyAll` are `Object` methods that must run inside `synchronized` on that object — `wait` atomically releases the monitor and parks, `notify`/`notifyAll` move waiters from the wait set to the entry set; always loop on `while (!condition) wait();` and prefer `notifyAll` unless every waiter is interchangeable.

---

**Next likely topics:** `Condition` API in `ReentrantLock` (the modern, multi-queue replacement that solves the `notifyAll` thundering herd), or `BlockingQueue` (the high-level abstraction built on top of `wait`/`notify` — the one you actually use in production). Both are the natural step up from raw monitor coordination.
