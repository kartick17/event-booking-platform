# `yield()`, `join()`, `sleep()` — The Three Thread Control Methods

**Priority: Interview-critical** — full deep-dive below.

## 1. Core Mechanism

These are the **three static/instance methods** every Java dev uses to control thread execution. They look similar but do very different things:

- **`Thread.sleep(ms)`** — static. **Pause the current thread** for a fixed time. Thread goes to **TIMED_WAITING**. Keeps all locks it holds.
- **`Thread.yield()`** — static. A **hint** to the scheduler: "I'm fine giving up CPU now". Thread stays **RUNNABLE**. May or may not actually pause.
- **`someThread.join()`** — instance. **Pause the current thread** until `someThread` finishes. Current thread goes to **WAITING** (or TIMED_WAITING if timeout).

The big trap: `sleep()` and `yield()` act on the **current thread that calls them** (static). `join()` acts on the **thread you call it on**, but pauses the **caller**.

> **Interview definition (say this out loud):** "`sleep` pauses the current thread for a fixed time and keeps its locks. `yield` is a non-binding hint to the scheduler to let equal-priority threads run — it may be a no-op. `join` is called on a target thread but pauses the *current* thread until the target terminates. None of them release `synchronized` monitors held by the calling thread — only `wait()` does that."

---

## 2. Under the Hood (JVM Internals)

### 2.1 Side-by-side comparison

| | `sleep(ms)` | `yield()` | `join()` |
|---|---|---|---|
| Static or instance? | static | static | instance |
| Acts on | Current thread | Current thread | Caller pauses, target keeps running |
| Thread state | TIMED_WAITING | RUNNABLE | WAITING (or TIMED_WAITING with timeout) |
| Releases monitors? | **No** — keeps all locks | **No** — never enters wait state | **No** — keeps all locks |
| Throws `InterruptedException`? | Yes | No | Yes |
| Guaranteed effect? | Yes — sleeps at least `ms` | **No** — hint only | Yes — waits until target dies (or timeout) |
| Can be interrupted? | Yes — wakes up with `InterruptedException` | N/A | Yes — same |
| Internal mechanism | Native call → OS `nanosleep` | Native call → OS `sched_yield` (no-op on many JVMs) | Uses `wait()` on the target Thread object's monitor |

### 2.2 How `join()` actually works — the surprise

`join()` is **not** magic. Look at the JDK source (simplified):

```java
public final synchronized void join(long millis) throws InterruptedException {
    // ... validation
    if (millis == 0) {
        while (isAlive()) {
            wait(0);   // <-- waits on the Thread object itself!
        }
    } else {
        // timed version with deadline math
    }
}
```

Key facts:
1. `join()` is `synchronized` on the target `Thread` object.
2. It calls `wait()` on that object — so the **caller** goes into WAITING.
3. When the target thread terminates, the JVM internally calls `notifyAll()` on the Thread object — that's what wakes joiners.
4. **Never call `wait()`/`notify()` on a `Thread` instance yourself** — you'll break `join()`. This is a documented gotcha in the Javadoc.

### 2.3 `sleep()` — what really happens

- Calls `Thread.sleep0()` → native code → OS-level timed park.
- On Linux: `pthread_cond_timedwait` or `nanosleep`.
- **Accuracy is OS-dependent.** On Windows, the default timer tick is ~15ms — `sleep(1)` may actually sleep ~15ms. On Linux with `CLOCK_MONOTONIC`, accuracy is microseconds.
- `sleep(0)` is special: it's essentially a `yield()` request to the OS. Don't rely on it.
- **Holds all locks** — this is the most common production bug. A thread that calls `sleep()` inside a `synchronized` block holds the monitor the whole time, blocking everyone else.

### 2.4 `yield()` — why it's almost useless

`yield()` calls native `os::naked_yield()` → `sched_yield()` on Linux. The OS scheduler then decides: "do I have another thread of equal-or-higher priority ready? If yes, switch. If no, keep running this one."

Real-world consequences:
- On a multi-core machine with idle cores, `yield()` is **almost always a no-op** — the scheduler has no one to switch to.
- Different JVMs implement it differently. HotSpot on Linux honors it; some JVMs treat it as a hint and ignore it.
- **Modern verdict:** `yield()` is mostly a code smell. Use `LockSupport.parkNanos()`, proper synchronization, or `CompletableFuture` instead. It survives mainly in spin-loops and JCStress tests.

### 2.5 The interrupt contract

`sleep()` and `join()` both throw `InterruptedException`. When caught, you have two choices:

```java
try {
    Thread.sleep(1000);
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();   // re-set the interrupt flag
    // optionally: return, break out of loop, etc.
}
```

**Why re-set the flag?** When `sleep()`/`join()` throws, the JVM **clears the interrupted flag**. If you swallow the exception, upstream code thinks no interrupt happened — and the thread never shuts down. Re-setting is the polite contract. Interviewers love this question.

`yield()` doesn't throw because it never enters a waiting state — there's nothing to interrupt.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java |
|---|---|---|
| "Pause for N ms" | `await new Promise(r => setTimeout(r, ms))` | `Thread.sleep(ms)` |
| "Let other tasks run" | `await Promise.resolve()` / `setImmediate` | `Thread.yield()` |
| "Wait for another task to finish" | `await otherPromise` | `otherThread.join()` |
| Holds resources during pause? | No — frees event loop | **Yes — keeps all locks** |

### Where the comparison breaks down

- In Node, `await setTimeout` is **free** — the event loop runs other tasks meanwhile. In Java, `sleep()` **blocks an OS thread** doing nothing for the entire duration. On a 200-thread Tomcat pool, sleeping inside a request handler is a denial-of-service against yourself.
- Node has no equivalent of "joining a thread" because there are no threads to join — promises chain via `.then`/`await`. Java's `join()` is the only way to wait for a `Thread` object; for tasks submitted to an `ExecutorService`, the equivalent is `future.get()`.
- `yield()` has **no Node equivalent** that makes sense — the single-threaded event loop cooperates by definition; you don't "yield" to yourself.
- Biggest trap: a Node dev's instinct is "sleep is harmless, I do it in tests all the time". In Java, `Thread.sleep()` inside a `synchronized` block is a **production hang** waiting to happen.

---

## 4. Production-Grade Code

A realistic snippet: a `PaymentRetryPolicy` that uses all three methods correctly — backoff with `sleep`, parallel fan-out with `join`, and shows where `yield` belongs (almost nowhere).

```java
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class PaymentRetryPolicy {

    private static final int MAX_ATTEMPTS = 3;
    private static final long BASE_BACKOFF_MS = 200;

    /** Retry with exponential backoff — classic sleep() use case. */
    public PaymentResult charge(PaymentGateway gateway, Order order) {
        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try {
                return gateway.charge(order);
            } catch (TransientGatewayException tge) {
                if (attempt == MAX_ATTEMPTS) throw tge;
                long backoff = (BASE_BACKOFF_MS << (attempt - 1))
                             + ThreadLocalRandom.current().nextLong(50); // jitter
                try {
                    Thread.sleep(backoff);   // TIMED_WAITING — keeps no locks here, safe
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();   // re-set the flag
                    throw new PaymentInterruptedException("retry interrupted", ie);
                }
            }
        }
        throw new IllegalStateException("unreachable");
    }

    /** Fan-out: charge a batch in parallel, wait for all — classic join() use case. */
    public List<PaymentResult> chargeBatch(PaymentGateway gateway, List<Order> orders) {
        List<Thread> workers = new ArrayList<>(orders.size());
        List<PaymentResult> results = new ArrayList<>(orders.size());
        for (Order o : orders) results.add(null);

        for (int i = 0; i < orders.size(); i++) {
            final int idx = i;
            Thread t = new Thread(
                () -> results.set(idx, charge(gateway, orders.get(idx))),
                "pay-" + orders.get(i).id()
            );
            workers.add(t);
            t.start();
        }

        for (Thread t : workers) {
            try {
                t.join(5_000);   // WAITING up to 5s per worker
                if (t.isAlive()) t.interrupt();   // timed out — cancel
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new PaymentInterruptedException("batch join interrupted", ie);
            }
        }
        return results;
    }

    // Domain types kept minimal so the snippet compiles in your head:
    public record Order(long id, long amountCents) {}
    public record PaymentResult(long orderId, String reference) {}
    public interface PaymentGateway { PaymentResult charge(Order o); }
    public static class TransientGatewayException extends RuntimeException {}
    public static class PaymentInterruptedException extends RuntimeException {
        public PaymentInterruptedException(String m, Throwable c) { super(m, c); }
    }
}
```

Where would `yield()` go? **Nowhere in this code.** In a real service, prefer `ExecutorService` + `CompletableFuture.allOf()` over manual `join()` — but this snippet exists to show the *primitives* working correctly.

Why each piece matters:
- `Thread.sleep` is outside any `synchronized` block — never sleep while holding a monitor.
- `Thread.currentThread().interrupt()` re-sets the flag — interview gold.
- `t.join(5_000)` shows the timed variant — production code should always bound waits.
- Backoff has **jitter** — without it, retries from many clients collide (thundering herd).

---

## 5. Top 3 MNC Interview Questions

**Q1: A thread calls `Thread.sleep(5000)` while holding a `synchronized` lock. What happens?**
*What they're testing:* whether you know `sleep()` does **not** release monitors — a classic production bug.
*Ideal answer:* The thread goes to TIMED_WAITING for 5 seconds, but **keeps the monitor it holds**. Any other thread trying to enter a `synchronized` block on the same object will go to BLOCKED for the full 5 seconds. This is the single biggest difference between `sleep()` and `wait()` — `wait()` releases the monitor it's called on, `sleep()` doesn't release anything. In production, this is why you should never sleep inside a critical section — do the sleep outside, or move to a `ReentrantLock` with `tryLock` and timeout.

**Q2: When would you actually use `yield()` in production code?**
*What they're testing:* whether you recognize it as a code smell — most candidates over-explain.
*Ideal answer:* Honestly, almost never. `yield()` is a non-binding hint to the scheduler, and on multi-core machines with idle cores, it's usually a no-op. The legitimate uses are narrow: spin-wait loops in lock-free data structures (and even there, `Thread.onSpinWait()` since Java 9 is better), or stress-test code trying to trigger race conditions. In real services I'd reach for `LockSupport.parkNanos()`, `ScheduledExecutorService`, or proper synchronization — never `yield()`.

**Q3: Why does `join()` work — what's it doing under the hood?**
*What they're testing:* whether you know `join()` is built on `wait()`/`notify()`.
*Ideal answer:* `join()` is `synchronized` on the target Thread object and calls `wait()` on it in a loop while the target is alive. When the target thread terminates, the JVM internally calls `notifyAll()` on the Thread object — that wakes the joiners. The practical takeaway is that you should never call `wait()` or `notify()` on a Thread instance yourself — you'd interfere with `join()`. It's documented in the Javadoc but I've seen real bugs from this.

---

### Memorize this
> **Memorize this:** `sleep` pauses you for a fixed time and keeps your locks; `join` pauses you until another thread dies and is internally `wait()` on the Thread object; `yield` is a scheduler hint that's usually a no-op — none of them release `synchronized` monitors, only `wait()` does.

---

**Next likely topics:** `wait()` / `notify()` / `notifyAll()` contract (why they must be inside `synchronized`, and how they differ from `sleep`/`join`), or the `Thread.interrupt()` mechanism (interrupt flag, `InterruptedException`, cooperative cancellation). Both are direct follow-ups your interviewer will push into.
