**Priority: Interview-critical** — full deep-dive below.

# Java Collection Framework

---

## 1. Core Mechanism

The **Collection Framework** is Java's unified set of interfaces and classes for storing and working with groups of objects. It was added in **Java 1.2** (1998).

Why it exists:
- Before 1.2, Java had `Vector`, `Hashtable`, `Stack`, `Properties`, raw arrays — each with its own API. You couldn't write one method that worked on "any group of items".
- The framework gave Java **one common interface family** (`Collection`, `List`, `Set`, `Map`) so code is written against contracts, not concrete classes.
- It also standardized **iteration**, **ordering**, and **equality** behavior across all data structures.

The framework has 4 parts:
- **Interfaces** — the contracts: `List`, `Set`, `Queue`, `Deque`, `Map`.
- **Implementations** — the real classes: `ArrayList`, `HashMap`, `LinkedList`, etc.
- **Algorithms** — utility static methods in `Collections` (`sort`, `binarySearch`, `unmodifiableList`).
- **Iterators** — `Iterator`, `ListIterator`, `Spliterator` for traversal.

> **Interview definition (say this out loud):** "The Collection Framework is Java's standard hierarchy of interfaces and implementations for grouping objects — `Collection` is the root for `List`, `Set`, `Queue`; `Map` is a sibling, not a child, because it stores key-value pairs, not single elements. The framework gives us one contract per data shape and many implementations per contract, so we can swap `ArrayList` for `LinkedList` without rewriting the calling code."

---

## 2. Under the Hood (JVM & Framework Internals)

### 2.1 The hierarchy (memorize this shape)

```
Iterable<T>
   └── Collection<T>
         ├── List<T>      → ArrayList, LinkedList, Vector, Stack, CopyOnWriteArrayList
         ├── Set<T>       → HashSet, LinkedHashSet, TreeSet, EnumSet
         └── Queue<T>     → PriorityQueue, ArrayDeque, LinkedList
               └── Deque<T> → ArrayDeque, LinkedList

Map<K,V>   (separate root — NOT a Collection)
   ├── HashMap, LinkedHashMap, TreeMap, EnumMap
   ├── Hashtable (legacy, synchronized)
   └── ConcurrentHashMap
```

- **`Iterable`** is the *real* top — it's what makes the `for-each` loop work (the loop calls `iterator()`).
- **`Map` is not under `Collection`** because its unit of storage is a *pair* (`K,V`), not a single element. `Collection.add(e)` takes one thing; `Map.put(k,v)` takes two. You can't subtype `Collection` cleanly when your basic operation has a different shape.

### 2.2 Interface contracts (what each one promises)

| Interface | Allows duplicates? | Ordered? | Indexed access? | Null allowed? |
|---|---|---|---|---|
| `List` | Yes | Yes (insertion order) | Yes (`get(i)`) | Usually yes |
| `Set` | No | Depends on impl | No | `HashSet` yes, `TreeSet` no |
| `Queue` | Yes | FIFO (or priority) | No | Some impls no |
| `Map` (keys) | No (unique keys) | Depends on impl | By key | `HashMap` yes, `TreeMap` no |

### 2.3 Fail-fast vs fail-safe iterators

This is a top interview trap.

- **Fail-fast** (`ArrayList`, `HashMap`, `HashSet`): the iterator keeps an internal counter `expectedModCount`. The collection has a `modCount` field that bumps on every structural change. If you modify the collection while iterating (except via `iterator.remove()`), the next `next()` call sees `modCount != expectedModCount` and throws **`ConcurrentModificationException`**. It is **not** thread-safety — it's a best-effort bug detector inside a single thread.
- **Fail-safe** (`CopyOnWriteArrayList`, `ConcurrentHashMap`): the iterator works on a **snapshot** (CoW) or a **weakly consistent** view (CHM). It will never throw `CME`, but you might not see writes that happened after iteration started.

### 2.4 The "optional operations" pattern

Some methods in the interfaces are **optional** — implementations can throw `UnsupportedOperationException`. Common example: `List.of(1,2,3)` returns an immutable list, so `add()` throws `UOE`. This is why "I made a list with `Arrays.asList`, but `add` crashes" is a classic bug — `Arrays.asList` returns a **fixed-size** list backed by the array.

### 2.5 Generics + Type Erasure (the JVM truth)

At runtime, `List<String>` and `List<Integer>` are both just `List`. The `<String>` part is erased after compile-time checks. Consequences:
- You **cannot** do `new T[10]` or `instanceof List<String>`.
- You can sneak a `Integer` into a `List<String>` using raw types — the JVM won't notice until you cast and crash with `ClassCastException`.
- Collections rely on `equals()` and `hashCode()` from `Object`, not from `T`, because the JVM only sees `Object` references inside the array.

### 2.6 The `equals` / `hashCode` contract (why your `HashSet` "loses" elements)

Every hash-based collection (`HashMap`, `HashSet`, `LinkedHashMap`, `LinkedHashSet`) depends on this contract:
- If `a.equals(b)` is true, then `a.hashCode() == b.hashCode()` **must** be true.
- The reverse is not required (two different objects *can* share a hash code — that's a collision).

If you override `equals` without `hashCode`, a `HashSet.contains(yourObj)` will return `false` even when an "equal" object is inside, because the lookup goes to the wrong bucket.

### 2.7 Comparable vs Comparator

- **`Comparable<T>`** — the class defines its *natural order* by implementing `compareTo`. Used by `TreeSet`, `TreeMap`, `Collections.sort(list)`.
- **`Comparator<T>`** — an external strategy, passed in. Used when you want a custom order without changing the class: `list.sort(Comparator.comparing(Order::getCreatedAt))`.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java / Spring |
|---|---|---|
| Ordered list, indexed | `Array` | `ArrayList`, `LinkedList` |
| Unique-key store | `Map` (ES6) / plain `{}` | `HashMap`, `LinkedHashMap` |
| Unique-value store | `Set` (ES6) | `HashSet`, `TreeSet` |
| FIFO queue | `Array.shift()` / library | `ArrayDeque`, `LinkedList` |
| Iteration protocol | `Symbol.iterator` | `Iterable` + `Iterator` |
| Sort | `arr.sort(fn)` | `list.sort(Comparator)` |
| Immutable | `Object.freeze`, `[...]` spread | `List.of(...)`, `Collections.unmodifiableList` |

### Where the comparison breaks down

- **JS has one `Array`, Java has many `List`s.** In Node you reach for `arr.push`, `arr.shift`, `arr.indexOf` regardless of use case. In Java you must *choose*: `ArrayList` for indexed reads, `LinkedList` for head/tail mutations, `ArrayDeque` for queue/stack. Interviewers expect you to justify the choice.
- **JS `Map` keys can be anything by reference.** Java `HashMap` keys are matched by `equals` / `hashCode`. If you put a mutable object in as a key and change a field used in `hashCode`, the entry is **lost forever** — you can see it iterating, but `get(key)` returns `null`.
- **No "fail-fast" in JS.** You can mutate a JS array during `forEach` and JS shrugs. Java throws `ConcurrentModificationException` immediately. This is a *feature*, not a bug — it catches concurrency mistakes early.
- **Java collections are not thread-safe by default.** In Node you don't worry because the event loop is single-threaded. In Java, `ArrayList` shared across threads will corrupt — you need `Collections.synchronizedList`, `CopyOnWriteArrayList`, or `ConcurrentHashMap`.
- **Generics are real at compile time, gone at runtime.** TypeScript is the same. But in Java the standard library actually uses them, so you cannot avoid generics — `List` (raw) gives compiler warnings everywhere.

---

## 4. Production-Grade Code

```java
package com.shop.order;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class OrderBook {

    public record Order(String id, String customerId, long amountCents, Instant placedAt)
            implements Comparable<Order> {
        @Override
        public int compareTo(Order other) {
            return this.placedAt.compareTo(other.placedAt);   // natural order = oldest first
        }
    }

    // Thread-safe lookup by order id — many reads, occasional writes.
    private final Map<String, Order> ordersById = new ConcurrentHashMap<>();

    // Per-customer history, oldest first. Wrapped synchronized — writes are rare here.
    private final Map<String, List<Order>> historyByCustomer =
            Collections.synchronizedMap(new HashMap<>());

    // Top-N pending orders by amount — PriorityQueue is a min-heap, so invert for "biggest first".
    private final Queue<Order> highValuePending =
            new PriorityQueue<>(Comparator.comparingLong(Order::amountCents).reversed());

    public void place(Order order) {
        ordersById.put(order.id(), order);

        historyByCustomer
                .computeIfAbsent(order.customerId(), k -> new ArrayList<>())
                .add(order);

        if (order.amountCents() >= 1_000_00) {            // ≥ ₹1000
            highValuePending.offer(order);
        }
    }

    public Optional<Order> findById(String id) {
        return Optional.ofNullable(ordersById.get(id));
    }

    public List<Order> historyOf(String customerId) {
        List<Order> list = historyByCustomer.getOrDefault(customerId, List.of());
        // Defensive copy + immutable view — caller cannot mutate our internal state.
        synchronized (historyByCustomer) {
            return List.copyOf(list);
        }
    }

    public List<Order> topPending(int n) {
        // PriorityQueue's iterator is NOT in priority order — drain a copy instead.
        PriorityQueue<Order> copy = new PriorityQueue<>(highValuePending);
        List<Order> result = new ArrayList<>(n);
        for (int i = 0; i < n && !copy.isEmpty(); i++) {
            result.add(copy.poll());
        }
        return Collections.unmodifiableList(result);
    }
}
```

What this snippet shows that interviewers like:
- **Right tool per job:** `ConcurrentHashMap` for hot key-value reads, `PriorityQueue` for top-N, `ArrayList` for per-customer log.
- **Records** (Java 16+) for immutable value objects with auto `equals`/`hashCode`.
- **`Comparable` + `Comparator.reversed()`** — both styles in one file.
- **Defensive copies** with `List.copyOf` so internal state cannot leak.
- **The `PriorityQueue` iteration gotcha** — its `iterator()` does **not** return items in priority order, you must `poll()`.

---

## 5. Top 3 MNC Interview Questions

**Q1: Why is `Map` not a child of `Collection`?**
- *What they're testing:* whether you understand interface design, not just memorized the hierarchy.
- *Ideal answer:* "`Collection`'s core operation is `add(E e)` — one element at a time. `Map` stores key-value pairs, so its core operation is `put(K k, V v)` — a fundamentally different shape. If `Map` extended `Collection`, methods like `size()` or `iterator()` would be ambiguous: iterator over keys, values, or entries? The framework designers kept them as siblings and gave `Map` three views — `keySet()`, `values()`, `entrySet()` — each of which *is* a `Collection`. So `Map` integrates with the framework through views, without breaking the `Collection` contract."

**Q2: What is fail-fast vs fail-safe, and is fail-fast about thread safety?**
- *What they're testing:* the very common misconception that fail-fast = thread-safe.
- *Ideal answer:* "Fail-fast iterators track a `modCount` counter on the collection. If the collection is structurally modified during iteration through any path except `iterator.remove()`, the next `next()` throws `ConcurrentModificationException`. It is **not** thread safety — even a single thread that calls `list.add()` mid-iteration will trigger it. It's just an early-warning system for bugs. Fail-safe iterators, like in `CopyOnWriteArrayList` or `ConcurrentHashMap`, iterate over a snapshot or a weakly consistent view, so they never throw — but they may miss recent writes. For real thread safety you still need a concurrent collection or external locking."

**Q3: I created a `HashSet<Employee>` and added the same employee twice — but `size()` returns 2. Why?**
- *What they're testing:* the `equals` / `hashCode` contract.
- *Ideal answer:* "`HashSet` is backed by a `HashMap` and uses `hashCode()` to find the bucket and `equals()` to compare within the bucket. If `Employee` doesn't override `equals` and `hashCode`, Java uses `Object`'s versions — which compare by reference identity. So two `Employee` objects with the same employee id are different references and land in different buckets. The fix is to override both, using the id field, and respect the contract: equal objects must have equal hash codes. With records, this is free — `record Employee(long id, String name)` generates the correct `equals`/`hashCode` automatically."

---

## 6. Memorize this

> **Memorize this:** The Collection Framework gives you one **contract per shape** (`List`, `Set`, `Queue`, `Map`) and many **implementations per contract** — `Map` sits outside `Collection` because it stores pairs, and every hash-based collection lives or dies by the `equals`/`hashCode` contract.
