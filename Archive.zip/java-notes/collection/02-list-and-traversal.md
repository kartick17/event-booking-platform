**Priority: Interview-critical** — full deep-dive below.

# `List` Interface & All Traversal Methods

---

## 1. Core Mechanism

`List<E>` is the **ordered, indexed, duplicate-allowing** child of `Collection`. Every element has a position (0-based), so you can do `get(i)`, `set(i, e)`, `add(i, e)`, `remove(i)`, and `subList(from, to)`.

Why it exists:
- `Collection` only promises "a bag of elements". `List` adds **order** and **position**.
- It is the most-used collection in real code — request lists, log lines, query results, batch payloads.

Main implementations:
- **`ArrayList`** — backed by a resizable array. Fast random access, slow head/middle inserts.
- **`LinkedList`** — doubly-linked nodes. Fast head/tail ops, slow `get(i)`.
- **`Vector`** / **`Stack`** — legacy, synchronized, avoid.
- **`CopyOnWriteArrayList`** — thread-safe, snapshot iteration, great for read-heavy/write-rare cases.

> **Interview definition (say this out loud):** "`List` is the ordered, indexed, duplicate-allowing contract under `Collection`. The two implementations that matter are `ArrayList`, a resizable array with O(1) random access, and `LinkedList`, a doubly-linked list with O(1) head/tail ops. Pick the implementation by access pattern, not by habit — and never iterate a `LinkedList` by index, because each `get(i)` walks from the head."

---

## 2. Under the Hood — All Traversal Methods

There are **7 real ways** to walk a `List`. Each has a different bytecode shape, different cost, and different rules about modification.

### 2.1 Classic index `for` loop

```java
for (int i = 0; i < list.size(); i++) {
    Order o = list.get(i);
}
```

- Compiles to a plain integer counter + `list.get(i)` call.
- **`ArrayList.get(i)` is O(1)** — direct array index.
- **`LinkedList.get(i)` is O(n)** — walks from head or tail (whichever is closer). So this loop is **O(n²) on a `LinkedList`**. Classic interview trap.
- You can modify the list during this loop **if you adjust the index yourself** — but it's error-prone (off-by-one on `remove`).

### 2.2 Enhanced `for-each` loop

```java
for (Order o : list) { ... }
```

- The compiler rewrites this to:
  ```java
  Iterator<Order> it = list.iterator();
  while (it.hasNext()) { Order o = it.next(); }
  ```
- Works on anything that implements `Iterable<T>`.
- **O(n) on both `ArrayList` and `LinkedList`** — no quadratic trap.
- **Fail-fast:** any structural modification through the list (not the iterator) throws `ConcurrentModificationException` on the next `next()`.

### 2.3 Explicit `Iterator`

```java
Iterator<Order> it = list.iterator();
while (it.hasNext()) {
    Order o = it.next();
    if (o.cancelled()) it.remove();   // safe — uses the iterator
}
```

- Same as for-each under the hood, but you hold the iterator.
- **`iterator.remove()` is the only safe way to delete during traversal.** It updates `expectedModCount` so no `CME`.
- Forward-only. No `add`, no backward step.

### 2.4 `ListIterator` — the power tool

```java
ListIterator<Order> it = list.listIterator();
while (it.hasNext()) {
    Order o = it.next();
    if (needsReplace(o)) it.set(buildReplacement(o));
    if (needsInsertAfter(o)) it.add(buildExtra(o));
}
```

- Only `List` exposes this (not `Set`, not `Collection`).
- Adds 4 powers over `Iterator`: **bidirectional** (`hasPrevious`/`previous`), **`set(e)`** to replace the last returned element, **`add(e)`** to insert at current cursor, and **`nextIndex()`/`previousIndex()`**.
- Lets you transform a list in place without copying.

### 2.5 `forEach` + `Consumer` (Java 8+)

```java
list.forEach(o -> process(o));
```

- Default method on `Iterable`. Internally just an enhanced-for loop.
- Cleaner syntax, but **you cannot remove from the list inside it** — throws `CME`.
- No `break` — to stop early you must throw an exception (don't) or use a Stream with `takeWhile`/`findFirst`.

### 2.6 Streams (sequential and parallel)

```java
list.stream()
    .filter(Order::isPending)
    .map(this::enrich)
    .toList();
```

- Lazy pipeline. Nothing runs until a **terminal operation** (`toList`, `count`, `forEach`, `reduce`).
- Built on `Spliterator` (see 2.7).
- `parallelStream()` splits the source via the spliterator and runs stages on the **common `ForkJoinPool`**. Worth it only for CPU-heavy work on large lists — *not* for I/O, *not* for small lists. Wrong-pool usage is a top production bug.
- Stream pipelines should be **side-effect-free** — mutating an external list inside `.map()` is undefined behavior under parallel.

### 2.7 `Spliterator` (the iteration primitive)

```java
Spliterator<Order> s = list.spliterator();
s.forEachRemaining(o -> ...);
Spliterator<Order> half = s.trySplit();   // splits work for parallelism
```

- The "split-able iterator" introduced in Java 8. You will rarely call it directly — it powers `Stream` and `parallelStream`.
- `ArrayList`'s spliterator is **late-binding** (snapshots `modCount` only on first traversal) and **`SIZED`, `SUBSIZED`, `ORDERED`** — which is why parallel streams over `ArrayList` split cheaply.
- `LinkedList`'s spliterator has no fast split — parallel streams over `LinkedList` give little benefit.

### 2.8 Summary table (revise from this)

| Method | Safe to remove? | Backward? | Index aware? | Notes |
|---|---|---|---|---|
| Index `for` | Yes (manual) | No | Yes | Quadratic on `LinkedList` |
| For-each | No → `CME` | No | No | Compiles to `Iterator` |
| `Iterator` | Only via `it.remove()` | No | No | Forward-only |
| `ListIterator` | Yes (`set`/`add`/`remove`) | Yes | Yes (`nextIndex`) | Only on `List` |
| `forEach(Consumer)` | No → `CME` | No | No | No `break` |
| `Stream` | Don't mutate source | No | No | Lazy, terminal op needed |
| `parallelStream` | No (must be stateless) | No | No | Uses common ForkJoinPool |

### 2.9 The fail-fast machinery (one sentence per piece)

- `AbstractList` has an `int modCount` field.
- Every structural change (`add`, `remove`, `clear`) bumps it.
- The iterator captures it as `expectedModCount` when created.
- On every `next()`, if they differ → throw `ConcurrentModificationException`.
- It is a **best-effort bug detector**, not a thread-safety guarantee. A second thread modifying mid-iteration *might* trigger it, but is not guaranteed to.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java / Spring |
|---|---|---|
| Indexed loop | `for (let i = 0; i < arr.length; i++)` | `for (int i = 0; i < list.size(); i++)` |
| For-each | `for (const x of arr)` | `for (Order o : list)` |
| Callback iteration | `arr.forEach(x => ...)` | `list.forEach(o -> ...)` |
| Filter / map / reduce | `arr.filter().map()` | `list.stream().filter().map().toList()` |
| Mutating during loop | "JS shrugs, you get weird results" | Java throws `CME` immediately |
| Parallel work | `Promise.all(arr.map(asyncFn))` | `list.parallelStream()...` *(CPU only)* |

### Where the comparison breaks down

- **JS `Array` is one type, Java has many `List`s.** In JS, `arr[5]` is always fast. In Java, `linkedList.get(5)` walks 5 nodes. Choosing the wrong `List` implementation is the #1 perf bug for Node devs new to Java.
- **`Promise.all` ≠ `parallelStream`.** `Promise.all` is **concurrency** for I/O on the event loop. `parallelStream` is **parallelism** for CPU on multiple threads. Using `parallelStream` to call a DB or HTTP API is wrong — it blocks `ForkJoinPool.commonPool` and starves the whole JVM.
- **`forEach` is loud in Java.** In JS, mutating `arr` during `arr.forEach` silently misbehaves. In Java, the same mistake throws `ConcurrentModificationException`. Treat it as a *gift* — it catches bugs at the point of crime.
- **No early `break` in stream/forEach.** In Java you must restructure with `findFirst`, `takeWhile`, or fall back to an old-school loop. In JS you'd use `.some()` or just `break` inside `for-of`.

---

## 4. Production-Grade Code

```java
package com.shop.order;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

public final class OrderTraversalService {

    public record Order(String id, Status status, Instant placedAt, long amountCents) {
        public enum Status { PENDING, PAID, CANCELLED, FAILED }
    }

    /** Replace every FAILED order older than 1 hour with a RETRYING marker — in place. */
    public void retryStale(List<Order> orders, Instant now) {
        ListIterator<Order> it = orders.listIterator();
        while (it.hasNext()) {
            Order o = it.next();
            if (o.status() == Order.Status.FAILED
                    && Duration.between(o.placedAt(), now).toHours() >= 1) {
                it.set(new Order(o.id(), Order.Status.PENDING, now, o.amountCents()));
            }
        }
    }

    /** Cancel + remove all expired pending orders. Safe deletion during iteration. */
    public int purgeExpired(List<Order> orders, Instant now) {
        int removed = 0;
        Iterator<Order> it = orders.iterator();
        while (it.hasNext()) {
            Order o = it.next();
            if (o.status() == Order.Status.PENDING
                    && Duration.between(o.placedAt(), now).toMinutes() > 30) {
                it.remove();              // only safe way to delete mid-traversal
                removed++;
            }
        }
        return removed;
    }

    /** Read-only report: total paid amount. Stream is fine — no mutation. */
    public long totalPaidCents(List<Order> orders) {
        return orders.stream()
                .filter(o -> o.status() == Order.Status.PAID)
                .mapToLong(Order::amountCents)
                .sum();
    }

    /** CPU-heavy scoring on a large immutable batch — parallelStream is justified. */
    public Map<String, Double> riskScores(List<Order> snapshot) {
        // snapshot is an immutable copy from upstream → safe to parallelize
        return snapshot.parallelStream()
                .collect(java.util.stream.Collectors.toUnmodifiableMap(
                        Order::id,
                        this::expensiveRiskScore));
    }

    private double expensiveRiskScore(Order o) {
        // pretend this is heavy math — NOT I/O. I/O here would kill the common pool.
        double s = 0;
        for (int i = 0; i < 1000; i++) s += Math.log1p(o.amountCents() + i);
        return s;
    }

    /** WRONG pattern — kept here as a comment for revision. */
    // for (Order o : orders) {                   // → ConcurrentModificationException
    //     if (o.status() == CANCELLED) orders.remove(o);
    // }
}
```

What this snippet shows:
- **`ListIterator.set`** for in-place transform — no allocation of a new list.
- **`Iterator.remove`** as the *only* safe deletion during traversal.
- **`Stream`** for read-only aggregation — declarative, no mutation.
- **`parallelStream` justified** only because the work is CPU-heavy and the source is an immutable snapshot.
- The commented anti-pattern at the bottom — a revision reminder of the classic `CME` bug.

---

## 5. Top 3 MNC Interview Questions

**Q1: Why is `for (int i = 0; i < list.size(); i++) list.get(i)` fine on `ArrayList` but terrible on `LinkedList`?**
- *What they're testing:* whether you know the underlying data structure, not just the API.
- *Ideal answer:* "`ArrayList.get(i)` is O(1) — it's a direct index into the backing array. `LinkedList.get(i)` is O(n) — it walks from the head or tail, whichever is closer. So an indexed for-loop over a `LinkedList` is O(n²). The fix is to use the enhanced for-each loop, which compiles to an `Iterator` that holds a pointer to the current node and advances in O(1) per step. So for `LinkedList`, always iterate, never index."

**Q2: What's the difference between `Iterator` and `ListIterator`, and when would you choose one?**
- *What they're testing:* whether you know `List`-specific operations and in-place transformation.
- *Ideal answer:* "`Iterator` is forward-only with one mutation: `remove()`. `ListIterator` is bidirectional and adds `set()` to replace the last returned element, `add()` to insert at the cursor, and `nextIndex`/`previousIndex`. `ListIterator` is only available on `List` because those operations need positional semantics. I reach for it when I'm transforming a list in place — say, replacing every failed payment with a retry marker — because `set()` avoids allocating a new list and avoids the `ConcurrentModificationException` you'd get if you mutated the underlying list directly."

**Q3: Show me three ways this code can throw `ConcurrentModificationException`, and one way to do the same thing safely.**
- *What they're testing:* deep grasp of fail-fast and the `modCount` mechanism.
- *Ideal answer:* "First, calling `list.remove(o)` inside a for-each loop — that's the classic case. Second, calling `list.add(...)` inside a `forEach(Consumer)` — same problem, the `Consumer` runs inside an iterator. Third, one thread iterating while another mutates the same list, since fail-fast is best-effort but usually fires. The mechanism is a `modCount` counter the iterator captures as `expectedModCount` and re-checks on every `next()`. The safe fix is `Iterator.remove()` for deletion, `ListIterator.set/add` for transformation, or `CopyOnWriteArrayList` if you need concurrent mutation during read."

---

## 6. Memorize this

> **Memorize this:** Pick traversal by intent — index-`for` only on `ArrayList`, for-each for read, `Iterator.remove` for delete, `ListIterator.set/add` for in-place edits, `Stream` for read-only pipelines, `parallelStream` **only** for CPU-heavy work on immutable sources.
