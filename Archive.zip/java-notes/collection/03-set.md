**Priority: Interview-critical** — full deep-dive below.

# `Set` Interface & Implementations

---

## 1. Core Mechanism

`Set<E>` is the **no-duplicates** child of `Collection`. Adding an element that already exists (by `equals`) is a no-op — `add` returns `false` instead of throwing.

Why it exists:
- Models a mathematical set: every element is unique.
- Lets you ask "does this collection contain X?" in **O(1)** (for hash sets) or **O(log n)** (for tree sets), instead of scanning the whole list.

Main implementations:
- **`HashSet`** — backed by a `HashMap`. O(1) add/contains/remove. No order.
- **`LinkedHashSet`** — backed by a `LinkedHashMap`. O(1) ops + keeps **insertion order**.
- **`TreeSet`** — backed by a `TreeMap` (Red-Black tree). O(log n) ops + keeps **sorted order**.
- **`EnumSet`** — backed by a `long` bit vector. Insanely fast, only for enum types.
- **`ConcurrentHashMap.newKeySet()`** / **`CopyOnWriteArraySet`** — thread-safe variants.

> **Interview definition (say this out loud):** "`Set` is the no-duplicates contract under `Collection`. The three real choices are `HashSet` for O(1) unordered lookup, `LinkedHashSet` when you also need insertion order, and `TreeSet` when you need sorted order at O(log n). All hash-based sets live or die by the `equals`/`hashCode` contract on the element type."

---

## 2. Under the Hood

### 2.1 `HashSet` is just a `HashMap` in disguise

Look at the source — `HashSet` has one field:

```java
private transient HashMap<E, Object> map;
private static final Object PRESENT = new Object();

public boolean add(E e) {
    return map.put(e, PRESENT) == null;
}
```

- Every element is a **key** in the underlying `HashMap`. The value is a shared dummy `PRESENT` object.
- So everything you know about `HashMap` (buckets, treeify at 8, `(n-1) & hash`, load factor 0.75) applies to `HashSet`.
- Memory cost: about the same as a `HashMap` with `n` entries — not "lighter" just because there's no value.

### 2.2 `LinkedHashSet` — insertion order for free

- Extends `HashSet` but passes a `LinkedHashMap` to the parent constructor.
- `LinkedHashMap` adds **two pointers** per entry (`before`, `after`) → a doubly-linked list threaded through the buckets.
- Iteration follows that linked list → insertion order, regardless of bucket layout.
- Tiny memory overhead (16 bytes per entry on 64-bit), but iteration is actually **faster** than `HashSet` because it walks the linked list directly, not the bucket array.

### 2.3 `TreeSet` — Red-Black tree under the hood

- Backed by a `TreeMap`, which is a **Red-Black tree** (a self-balancing binary search tree).
- All ops are O(log n), not O(1) — tree walk, not hash.
- Elements must be `Comparable` or you must pass a `Comparator`.
- **Throws `ClassCastException` if you add an element that can't be compared** — easy bug.
- Gives you bonus methods: `first()`, `last()`, `headSet(x)`, `tailSet(x)`, `subSet(a, b)`, `floor(x)`, `ceiling(x)`. These are why you reach for `TreeSet` — not just sorting.

### 2.4 `EnumSet` — bit-vector magic

- Special. Only works for `enum` types.
- Backed by a `long` (or `long[]` for huge enums). Each enum constant gets one bit.
- `add`, `remove`, `contains` are 1–2 bitwise ops → orders of magnitude faster than `HashSet`.
- **Always prefer `EnumSet` over `HashSet<MyEnum>`** — it's a free win.

### 2.5 Thread-safe variants

| Need | Use | Notes |
|---|---|---|
| Concurrent add/remove/contains | `ConcurrentHashMap.newKeySet()` | Built on `ConcurrentHashMap`. Modern default. |
| Many reads, rare writes | `CopyOnWriteArraySet` | Every write copies the whole backing array — only use if writes are very rare. |
| Old code | `Collections.synchronizedSet(set)` | Coarse lock around every method. Avoid. |

### 2.6 The `equals` / `hashCode` rule (again — this is why sets break)

If you put a **mutable** object into a `HashSet` and then change a field that participates in `hashCode`:
- The object is still in the underlying bucket array.
- But `set.contains(obj)` will look in a **different** bucket → returns `false`.
- You can see the object via iteration, but you cannot find it. It's "lost".

Rule: **set elements should be immutable**, or at least their hash-relevant fields should be.

### 2.7 Summary table

| Impl | Backing | Order | add/contains | Allows null? | Thread-safe? |
|---|---|---|---|---|---|
| `HashSet` | `HashMap` | None | O(1) | Yes (one) | No |
| `LinkedHashSet` | `LinkedHashMap` | Insertion | O(1) | Yes (one) | No |
| `TreeSet` | `TreeMap` (RB tree) | Sorted | O(log n) | No | No |
| `EnumSet` | bit vector | Enum order | O(1), faster | No | No |
| `CHM.newKeySet()` | `ConcurrentHashMap` | None | O(1) | No | Yes |
| `CopyOnWriteArraySet` | `CopyOnWriteArrayList` | Insertion | O(n) | Yes | Yes |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| Unique values | `new Set()` | `HashSet` |
| Set with insertion order | `Set` (ES2015 keeps insertion order) | `LinkedHashSet` |
| Sorted set | None built-in (use sorted array) | `TreeSet` |
| Set of enum | `Set` of strings | `EnumSet` (way faster) |
| Concurrent set | N/A (single-threaded loop) | `ConcurrentHashMap.newKeySet()` |

### Where the comparison breaks down

- **JS `Set` is always insertion-ordered.** Java's `HashSet` gives **no order guarantee** — and the order can change between JVM versions. If you assume order, you'll get burned in tests.
- **JS `Set` uses `SameValueZero` (reference for objects).** Java uses `equals`/`hashCode` on the element type. Two different `Employee` instances with the same id are *the same* to Java if you override `equals`/`hashCode` — but always *different* to JS.
- **No sorted Set in JS.** If you need ordered uniqueness in JS, you build it yourself. Java has `TreeSet` with O(log n) ops and bonus range queries (`headSet`, `tailSet`) — useful in real systems for things like "give me all events before timestamp X".
- **JS doesn't have an `EnumSet` equivalent.** A `Set<'PENDING' | 'PAID'>` in TS is just a `Set` of strings — same cost as any other `Set`. Java's `EnumSet` is bit-level fast.

---

## 4. Production-Grade Code

```java
package com.shop.permission;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class PermissionService {

    public enum Permission { READ, WRITE, DELETE, ADMIN, BILLING, REFUND }

    // Per-role permissions — fixed at startup, read constantly. EnumSet is the obvious win.
    private static final Map<String, Set<Permission>> ROLE_PERMS = Map.of(
            "viewer", EnumSet.of(Permission.READ),
            "editor", EnumSet.of(Permission.READ, Permission.WRITE),
            "admin",  EnumSet.allOf(Permission.class)
    );

    // Audit log of unique user ids seen today — concurrent, set-of-strings.
    private final Set<String> seenUserIdsToday = ConcurrentHashMap.newKeySet();

    // Recently blocked IPs in insertion order (oldest → newest) for a tail-drop policy.
    private final Set<String> recentlyBlockedIps =
            Collections.synchronizedSet(new LinkedHashSet<>());

    // Sorted set of active session expirations — lets us pop the soonest one in O(log n).
    private final TreeSet<Long> sessionExpiriesMs = new TreeSet<>();

    public boolean hasPermission(String role, Permission p) {
        Set<Permission> perms = ROLE_PERMS.getOrDefault(role, EnumSet.noneOf(Permission.class));
        return perms.contains(p);              // 1-bit AND on EnumSet
    }

    public boolean recordUserSeen(String userId) {
        return seenUserIdsToday.add(userId);   // returns false if already present
    }

    public void blockIp(String ip, int cap) {
        synchronized (recentlyBlockedIps) {
            recentlyBlockedIps.add(ip);
            // Tail-drop the oldest if over cap — LinkedHashSet keeps insertion order.
            Iterator<String> it = recentlyBlockedIps.iterator();
            while (recentlyBlockedIps.size() > cap && it.hasNext()) {
                it.next();
                it.remove();
            }
        }
    }

    public synchronized Optional<Long> nextExpiringSession() {
        // TreeSet.first() = smallest, O(log n). pollFirst() removes + returns.
        return sessionExpiriesMs.isEmpty()
                ? Optional.empty()
                : Optional.of(sessionExpiriesMs.pollFirst());
    }
}
```

What this shows:
- **`EnumSet`** for role permissions — the canonical use case.
- **`ConcurrentHashMap.newKeySet()`** for a thread-safe unordered set (the modern way).
- **`LinkedHashSet`** + synchronized wrapper for an ordered "recent items" cache with FIFO eviction.
- **`TreeSet.pollFirst`** for an O(log n) "next-to-expire" queue.

---

## 5. Top 3 MNC Interview Questions

**Q1: How is `HashSet` implemented internally?**
- *What they're testing:* whether you know it's a `HashMap` wrapper, or if you'll wave your hands.
- *Ideal answer:* "`HashSet` is a thin wrapper around a `HashMap<E, Object>`. Every element you add becomes a key in the map, and the value is a shared static dummy called `PRESENT`. So `add` returns `map.put(e, PRESENT) == null`, `contains` is `map.containsKey`. That means every `HashMap` internal applies — bucket array sized to a power of two, load factor 0.75, treeify at 8 collisions, hash spreading via `(h ^ (h >>> 16))`. The set's iteration order is the map's bucket-walk order, which is not insertion order and not stable across JDK versions."

**Q2: I added a `User` object to a `HashSet`, then changed the user's email — now `set.contains(user)` is `false` even though the object is in there. Why?**
- *What they're testing:* the mutability-and-hashCode trap.
- *Ideal answer:* "When you added the user, `hashCode()` placed it in bucket *X*. Then you mutated the email, which is part of `hashCode`. Now `set.contains(user)` recomputes the hash — it points to bucket *Y* — finds nothing, and returns `false`. The object is still physically inside the set's bucket array at *X*, but it's unreachable by lookup. That's why set elements must be effectively immutable, at least for the fields used in `equals`/`hashCode`. The fix is either making `User` a record, or using an immutable id field for hashing."

**Q3: When would you pick `TreeSet` over `HashSet`?**
- *What they're testing:* whether you know `TreeSet`'s real value beyond "sorted".
- *Ideal answer:* "Three reasons. First, when I need iteration in sorted order without paying a sort cost on every read. Second, when I need O(log n) range queries — `headSet`, `tailSet`, `subSet`, `floor`, `ceiling` — for things like 'find the next expiring session' or 'all events before timestamp X'. Third, when the element type doesn't have a usable `hashCode` but does have a natural order. The cost is O(log n) instead of O(1) on every op, plus the elements must implement `Comparable` or I pass a `Comparator` to the constructor."

---

## 6. Memorize this

> **Memorize this:** `HashSet` is a `HashMap` with a dummy value — same internals, same `equals`/`hashCode` rules; `LinkedHashSet` adds insertion order via a linked list, `TreeSet` is a Red-Black tree with O(log n) range queries, and `EnumSet` is a bit-vector that beats everything for enum keys.
