**Priority: Interview-critical** — full deep-dive below.

# `Queue` & `Deque` Interfaces

---

## 1. Core Mechanism

`Queue<E>` is the **FIFO** (first-in-first-out) child of `Collection`. Elements are added at the tail and removed from the head — like a line at the counter.

`Deque<E>` ("deck") extends `Queue` and lets you add/remove from **both ends** — so you can use it as a queue *or* a stack.

Why both exist:
- Real systems are full of "process the next item" patterns: task schedulers, message buffers, retry backlogs, BFS traversals, undo stacks.
- The framework gives you **one common API** so you can swap a single-threaded `ArrayDeque` for a thread-safe `LinkedBlockingQueue` without rewriting producers/consumers.

Main implementations:
- **`ArrayDeque`** — circular array. Fastest single-threaded queue *and* fastest stack.
- **`LinkedList`** — also implements `Deque`, but slower; only use when you already need its `List` features.
- **`PriorityQueue`** — min-heap. Not FIFO — orders by priority.
- **`ArrayBlockingQueue`**, **`LinkedBlockingQueue`** — thread-safe, *blocking* (producer waits if full, consumer waits if empty).
- **`ConcurrentLinkedQueue`** / **`ConcurrentLinkedDeque`** — thread-safe, *non-blocking* (lock-free via CAS).

> **Interview definition (say this out loud):** "`Queue` is the FIFO contract under `Collection`; `Deque` extends it with both-ended access, so it doubles as a stack. In single-threaded code I always use `ArrayDeque` — for queue *and* for stack — because it's a circular array with O(1) head/tail ops and no node allocation. For concurrent producer-consumer work I use a `BlockingQueue` like `LinkedBlockingQueue`, and for ordering-by-priority I use `PriorityQueue`, which is a min-heap, not a FIFO queue."

---

## 2. Under the Hood

### 2.1 The two method families (this is a favorite interview trap)

`Queue` has **two parallel sets** of methods for every op — one *throws* on failure, one *returns a special value*.

| Operation | Throws on failure | Returns sentinel |
|---|---|---|
| Insert tail | `add(e)` → `IllegalStateException` if full | `offer(e)` → returns `false` |
| Remove head | `remove()` → `NoSuchElementException` if empty | `poll()` → returns `null` |
| Peek head | `element()` → `NoSuchElementException` if empty | `peek()` → returns `null` |

- Use the **`offer`/`poll`/`peek`** family in real code — they handle empty/full gracefully.
- `add`/`remove` come from the `Collection` interface; the queue-specific methods exist because bounded queues exist.

`Deque` doubles every method with a `First`/`Last` suffix: `offerFirst`, `offerLast`, `pollFirst`, `pollLast`, `peekFirst`, `peekLast`, plus `push`/`pop`/`peek` aliased for stack use.

### 2.2 `ArrayDeque` — circular array, no nodes

- Backed by a `Object[]` array. Two `int` pointers: `head` and `tail`.
- When you `offerLast`, increment `tail` (wrap with `& (capacity - 1)` since the array is a power of two).
- When you `pollFirst`, increment `head` similarly.
- When full → double the array and re-copy.
- **No `Node` object per element** → much less GC pressure than `LinkedList`. CPU cache loves it.
- **Not thread-safe.** **Does not allow `null`** (it uses `null` to mean empty slot).
- This is the **default deque** — `ArrayDeque` is faster than `LinkedList` as a queue and faster than `Stack` (synchronized, legacy) as a stack.

### 2.3 `PriorityQueue` — binary min-heap

- Backed by a `Object[]` representing a **binary min-heap**.
- `offer` → place at end, "sift up" until heap property holds. O(log n).
- `poll` → take root, move last element to root, "sift down". O(log n).
- `peek` is O(1) (root).
- **The iterator does NOT return elements in priority order** — it walks the array layout. To process in order, you must keep `poll`-ing until empty. Top interview trap.
- Not FIFO — it's "priority-FO". For ties, ordering is undefined.
- Needs `Comparable` elements or a `Comparator`. Throws `ClassCastException` otherwise.

### 2.4 `BlockingQueue` family — the concurrency workhorses

| Class | Backing | Bounded? | Lock model |
|---|---|---|---|
| `ArrayBlockingQueue` | Circular array | Yes (fixed at construction) | Single `ReentrantLock` + 2 conditions |
| `LinkedBlockingQueue` | Linked nodes | Optional (defaults to `Integer.MAX_VALUE`) | **Two separate locks** (head + tail) → higher throughput |
| `PriorityBlockingQueue` | Heap | Unbounded | One lock |
| `DelayQueue` | Heap | Unbounded | Elements available only after their delay expires |
| `SynchronousQueue` | None — direct hand-off | 0 capacity | Each put waits for a take |
| `LinkedTransferQueue` | Linked nodes | Unbounded | Lock-free + transfer semantics |

Each `BlockingQueue` adds two more method pairs:
- **`put(e)` / `take()`** — block forever until space/element available.
- **`offer(e, timeout)` / `poll(timeout)`** — block with timeout.

These are how **`ThreadPoolExecutor`** holds its work queue, how producer-consumer pipelines work, how `@Async` tasks queue up.

### 2.5 `ConcurrentLinkedQueue` — lock-free, CAS-based

- Implements Michael & Scott's lock-free queue algorithm.
- Uses **`compareAndSwap` (CAS)** on the head/tail node pointers — no locks at all.
- Best throughput under heavy contention from many threads.
- **Weakly consistent** iterator — won't throw `CME`, but may miss recent additions.
- `size()` is O(n) and not necessarily accurate at a given instant — never use `size()` in a hot path on a concurrent queue.

### 2.6 Why `LinkedList` as a `Queue` is usually wrong

- `LinkedList` implements `Deque`, so you *can* use it as a queue.
- But every element allocates a `Node` object (about 40 bytes on 64-bit), plus the element reference. So GC pressure is much higher than `ArrayDeque`.
- Iteration walks pointers — cache-unfriendly.
- Rule: prefer **`ArrayDeque`** unless you also need `List` indexing on the same object (which is rare and usually a smell).

### 2.7 Summary table

| Impl | Order | Bounded? | Thread-safe? | Blocking? | Null allowed? |
|---|---|---|---|---|---|
| `ArrayDeque` | FIFO / LIFO | Grows | No | No | No |
| `LinkedList` | FIFO / LIFO | Grows | No | No | Yes |
| `PriorityQueue` | Priority | Grows | No | No | No |
| `ArrayBlockingQueue` | FIFO | Yes | Yes | Yes | No |
| `LinkedBlockingQueue` | FIFO | Optional | Yes | Yes | No |
| `PriorityBlockingQueue` | Priority | Grows | Yes | Yes (take) | No |
| `ConcurrentLinkedQueue` | FIFO | Grows | Yes | No | No |
| `SynchronousQueue` | Hand-off | Cap 0 | Yes | Yes | No |
| `DelayQueue` | Time-based | Grows | Yes | Yes | No |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| FIFO queue | `arr.push() / arr.shift()` | `ArrayDeque.offerLast / pollFirst` |
| Stack | `arr.push() / arr.pop()` | `ArrayDeque.push / pop` |
| Priority queue | None built-in (use lib) | `PriorityQueue` |
| Producer-consumer queue | EventEmitter + buffer, or RxJS Subject | `LinkedBlockingQueue` |
| Background job queue | Bull/BullMQ (Redis-backed) | `ThreadPoolExecutor` + `BlockingQueue` |
| Async scheduling | `setTimeout`, `setImmediate` | `DelayQueue`, `ScheduledExecutorService` |

### Where the comparison breaks down

- **JS `Array.shift()` is O(n).** Every shift re-indexes the whole array. So using a JS array as a queue is fine for ~hundreds, terrible for millions. `ArrayDeque` in Java is real O(1) at both ends.
- **No real threading in Node.** Producer-consumer is solved by the event loop + async callbacks — there's no contention. In Java, you choose your queue based on contention level: `LinkedBlockingQueue` (two locks) for moderate, `ConcurrentLinkedQueue` (lock-free CAS) for very high.
- **Bull/BullMQ ≠ `BlockingQueue`.** Bull is a *distributed* job queue on Redis, surviving process restarts. `BlockingQueue` is **in-process only** — restart the JVM and the queue is gone. For distributed work in Java you'd reach for Kafka, RabbitMQ, or Spring Cloud Stream.
- **`null` is allowed in JS arrays but not in most Java queues.** Most concurrent queues use `null` as the "empty" sentinel, so they reject null elements. Easy NPE-producing bug for Node devs.

---

## 4. Production-Grade Code

```java
package com.shop.task;

import java.time.*;
import java.util.*;
import java.util.concurrent.*;

public final class TaskPipeline {

    public record Task(String id, int priority, Instant scheduledFor) {}

    // Single-threaded BFS-style worklist — ArrayDeque beats LinkedList for this.
    public List<String> walkDependencies(String rootId, Map<String, List<String>> graph) {
        Deque<String> worklist = new ArrayDeque<>();
        Set<String> seen = new HashSet<>();
        List<String> visited = new ArrayList<>();
        worklist.offerLast(rootId);
        while (!worklist.isEmpty()) {
            String id = worklist.pollFirst();
            if (!seen.add(id)) continue;
            visited.add(id);
            for (String child : graph.getOrDefault(id, List.of())) {
                worklist.offerLast(child);
            }
        }
        return visited;
    }

    // Producer-consumer with backpressure. Bounded queue → if full, producer blocks.
    private final BlockingQueue<Task> incoming = new LinkedBlockingQueue<>(1_000);

    public void submit(Task t) throws InterruptedException {
        incoming.put(t);                            // blocks if queue is full
    }

    public Task pickup() throws InterruptedException {
        return incoming.take();                     // blocks if queue is empty
    }

    public Optional<Task> pickupWithin(Duration d) throws InterruptedException {
        return Optional.ofNullable(incoming.poll(d.toMillis(), TimeUnit.MILLISECONDS));
    }

    // Top-N by priority — PriorityQueue is a min-heap, so reverse the comparator.
    public List<Task> topNByPriority(Collection<Task> all, int n) {
        PriorityQueue<Task> heap = new PriorityQueue<>(
                Comparator.comparingInt(Task::priority).reversed());
        heap.addAll(all);
        List<Task> out = new ArrayList<>(n);
        for (int i = 0; i < n && !heap.isEmpty(); i++) {
            out.add(heap.poll());                   // poll, NOT iterate — iterator is unordered
        }
        return out;
    }

    // Lock-free queue for very high contention — no blocking, just CAS.
    private final ConcurrentLinkedQueue<String> auditTrail = new ConcurrentLinkedQueue<>();

    public void audit(String event) {
        auditTrail.offer(event);                    // never blocks, never null
    }

    public Optional<String> drainOne() {
        return Optional.ofNullable(auditTrail.poll());
    }
}
```

What this shows:
- **`ArrayDeque` for BFS** — the canonical single-threaded worklist.
- **`LinkedBlockingQueue(1_000)`** — bounded so producers feel backpressure (`put` blocks) instead of OOM'ing.
- **`PriorityQueue`** for top-N with the iteration-order gotcha called out.
- **`ConcurrentLinkedQueue`** for a lock-free audit trail under heavy concurrent writes.
- All three method styles: `offer`/`poll`/`peek` (non-blocking), `put`/`take` (blocking forever), `poll(timeout)` (blocking with timeout).

---

## 5. Top 3 MNC Interview Questions

**Q1: What's the difference between `add`/`remove` and `offer`/`poll` on a `Queue`?**
- *What they're testing:* whether you know the bounded-queue semantics and pick the right method.
- *Ideal answer:* "Both pairs do the same thing on a happy path. The difference is failure handling. `add(e)` throws `IllegalStateException` if the queue is full, and `remove()`/`element()` throw `NoSuchElementException` if it's empty. `offer(e)` returns `false` on full, and `poll()`/`peek()` return `null` on empty. The `offer`/`poll`/`peek` family exists for bounded queues, where 'full' and 'empty' are normal conditions, not errors. In production code I always use `offer`/`poll`/`peek` — exception-driven control flow is slower and uglier. The throwing versions come from the `Collection` interface and exist mainly for backwards compatibility."

**Q2: Why is `ArrayDeque` preferred over `LinkedList` for a queue or a stack?**
- *What they're testing:* whether you know data-structure cost beyond Big-O.
- *Ideal answer:* "`ArrayDeque` is a circular array — two int pointers `head` and `tail`, bitmasked into a power-of-two array. Every op is O(1) with almost zero allocation. `LinkedList` allocates a `Node` object per element — about 40 bytes plus the element pointer — so it churns GC and is cache-unfriendly because each node is a pointer-chase. Both are O(1) at the ends, but `ArrayDeque` is several times faster in practice. The only reason to use `LinkedList` is if you genuinely need `List` indexing on the same object, which is rare. For a stack, `ArrayDeque` is also the right answer — the old `java.util.Stack` is synchronized and considered legacy."

**Q3: I want a thread-safe queue. When do I pick `LinkedBlockingQueue` vs `ConcurrentLinkedQueue`?**
- *What they're testing:* whether you understand blocking vs non-blocking and back-pressure.
- *Ideal answer:* "Different problems. `LinkedBlockingQueue` is *blocking* — producers can `put` and block when full, consumers can `take` and block when empty. It's the right pick for producer-consumer pipelines where you want **backpressure** and clean wait/notify semantics — that's why `ThreadPoolExecutor` uses one internally. Bound it, or producers will OOM the heap. `ConcurrentLinkedQueue` is *non-blocking*, lock-free via CAS. It never blocks anyone, but consumers must poll and handle `null`. Use it when you have many threads writing concurrently and you don't want anyone to wait — like a hot audit log or a stat aggregator. One more catch: `size()` on `ConcurrentLinkedQueue` is O(n) and approximate, so never call it in a hot path."

---

## 6. Memorize this

> **Memorize this:** `Queue` is FIFO with two method families (`offer`/`poll`/`peek` for graceful, `add`/`remove`/`element` for throwing); `ArrayDeque` is the single-threaded default for both queue and stack, `PriorityQueue` is a min-heap with an unordered iterator, and for concurrency pick `LinkedBlockingQueue` for backpressure or `ConcurrentLinkedQueue` for lock-free throughput.
