**Priority: Interview-critical** — full deep-dive below. (This is THE most-asked Java interview topic. Plan to revise it twice.)

# `Map` Family & Internals

---

## 1. Core Mechanism

`Map<K, V>` stores **key → value pairs**. Keys are unique (no duplicates); values can repeat. It is **not** a child of `Collection` — it's a separate root because its unit of storage is a pair, not a single element.

Why it exists:
- The single most-used data shape in real backend code — caches, lookups, configs, indexes, request-id → response, user-id → session.
- Java gives one common contract (`put`, `get`, `remove`, `containsKey`) with many implementations tuned for different needs: O(1) average lookup, sorted order, thread-safe, weak references, enum-only, etc.

The 6 implementations that matter:

| Impl | When to reach for it |
|---|---|
| `HashMap` | Default. O(1) average. Single-threaded. |
| `LinkedHashMap` | Same as `HashMap` + insertion or access order. LRU cache base. |
| `TreeMap` | Sorted keys, O(log n), range queries (`headMap`, `floorKey`). |
| `ConcurrentHashMap` | Thread-safe, lock-free reads, high-throughput. Modern default for concurrency. |
| `Hashtable` | Legacy, fully synchronized. Don't use — kept for backwards compatibility. |
| `EnumMap` / `WeakHashMap` / `IdentityHashMap` | Specialty maps, see 2.8. |

> **Interview definition (say this out loud):** "`Map` is the key-value contract that sits outside `Collection` because its unit is a pair. `HashMap` is the default — a power-of-two array of buckets, each bucket a linked list that treeifies into a Red-Black tree once it hits 8 nodes, load factor 0.75. `LinkedHashMap` adds a doubly-linked list for insertion or access order. `TreeMap` is a Red-Black tree giving O(log n) sorted access. For concurrency I use `ConcurrentHashMap`, which uses CAS on empty bins and synchronizes only on the first node of a contended bin — never `Hashtable`."

---

## 2. Under the Hood

### 2.1 The `Map` interface contract

- `put(k, v)` — insert or replace; returns the **old value** (or `null`).
- `get(k)` — returns value or `null`. **Cannot distinguish "absent" from "present with null value"** — that's why `containsKey` exists.
- `putIfAbsent`, `computeIfAbsent`, `computeIfPresent`, `compute`, `merge` — Java 8 atomic helpers (atomic on `ConcurrentHashMap`, not on plain `HashMap`).
- Three views: `keySet()`, `values()`, `entrySet()`. **They are live** — modifying the view modifies the map.
- `forEach((k, v) -> ...)` — clean iteration, but mutating the map inside throws `CME` (except on `ConcurrentHashMap`).

---

### 2.2 `HashMap` — the structure (memorize this picture)

```
HashMap
├── Node<K,V>[] table     ← the bucket array. Always size = power of 2.
│   ├── [0] → Node → Node → Node           (linked list when few collisions)
│   ├── [1] → null
│   ├── [2] → TreeNode (red-black tree root)   (after 8+ collisions)
│   └── ...
├── int size              ← total entries
├── int threshold         ← capacity * loadFactor → resize trigger
├── float loadFactor      ← default 0.75
└── int modCount          ← bumps on every structural change (fail-fast)
```

Each `Node<K,V>` has 4 fields: `int hash`, `K key`, `V value`, `Node<K,V> next`. (TreeNode adds parent/left/right/red.)

**Key constants in `HashMap`:**

| Constant | Value | Meaning |
|---|---|---|
| `DEFAULT_INITIAL_CAPACITY` | 16 | Starting bucket count |
| `MAXIMUM_CAPACITY` | 1 << 30 | Max bucket count |
| `DEFAULT_LOAD_FACTOR` | 0.75 | Resize when size > capacity × 0.75 |
| `TREEIFY_THRESHOLD` | 8 | Convert bucket list → tree at 8 nodes |
| `UNTREEIFY_THRESHOLD` | 6 | Convert tree → list when shrinking ≤ 6 |
| `MIN_TREEIFY_CAPACITY` | 64 | Don't treeify if table is small — resize instead |

---

### 2.3 The hash function — why `(h ^ (h >>> 16))`

```java
static final int hash(Object key) {
    int h;
    return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
}
```

- Calls the key's `hashCode()`.
- **Shifts the top 16 bits down and XORs them with the low 16 bits.**
- Why? The bucket index is computed as `(n - 1) & hash` — a bitmask using only the **low bits** of the hash. If many keys have similar low bits but differ only in high bits, they'd all land in the same bucket. Spreading high bits into low bits avoids that.
- `null` keys always hash to 0 → always go to bucket 0.

---

### 2.4 The index formula — `(n - 1) & hash`

```java
int index = (table.length - 1) & hash(key);
```

- Why `&` instead of `%`? Bitwise AND is faster than modulo — single CPU instruction.
- This only works if `table.length` is a **power of 2**, because then `n - 1` is a bitmask like `0000...01111`. That's why `HashMap` rounds any initial capacity up to the next power of 2.

---

### 2.5 `put(k, v)` — full walkthrough

1. Compute `h = hash(key)`. Compute `i = (n - 1) & h`.
2. If `table[i] == null` → create a new `Node`, place it there. Done.
3. Otherwise, walk the chain at `table[i]`:
   - If a node's `hash == h && (k == node.key || k.equals(node.key))` → **replace** value, return old.
   - Else continue down the list.
4. If we reached the end without a match → append a new `Node`. If chain length is now ≥ 8 **and** table size ≥ 64 → **treeify** this bucket into a Red-Black tree. If chain length ≥ 8 but table size < 64 → **resize** instead (cheaper than treeifying).
5. `modCount++`. If `++size > threshold` → **resize**.

Lookup (`get`) is the same flow without the insert step. In the tree case, traversal is O(log n) by hash, key class, and `compareTo` if `Comparable`.

---

### 2.6 Resize — the doubling trick

When `size > threshold`:
- New capacity = old × 2.
- New threshold = new capacity × load factor.
- Walk every entry and re-place it. **Trick:** because capacity doubles, the new index is either:
  - The **same** index `i` (if the new high bit of the hash is 0), or
  - `i + oldCapacity` (if the new high bit is 1).
- So each old bucket splits into exactly **two** new buckets — checked by a single bit AND. No need to fully re-hash every key. This is why doubling-and-power-of-2 is the design choice.

Cost: O(n). The reason `HashMap` is slow under heavy bursty insertion if you don't pre-size it.

---

### 2.7 Treeify — when buckets get bad

- If `equals`/`hashCode` is poorly written and many keys collide into one bucket, lookup degenerates from O(1) to O(n).
- Defense: once a bucket has 8 nodes and the table is at least 64 buckets, the bucket is converted from a linked list into a **Red-Black tree** of `TreeNode`s. Lookup becomes O(log n) for that bucket.
- This was added in Java 8 specifically to make `HashMap` resilient to **hash-flooding DoS attacks** (sending many keys with the same hash).
- When entries leave a tree bucket and it shrinks to ≤ 6 → it untreeifies back to a list.

---

### 2.8 `LinkedHashMap` — order on top of `HashMap`

- Extends `HashMap`. Each entry is an `Entry` that adds two fields: `Entry before`, `Entry after`.
- A **doubly-linked list** is threaded through all entries, in either:
  - **Insertion order** (default) — entries added at the tail.
  - **Access order** (constructor flag `accessOrder = true`) — every `get` moves the entry to the tail.
- Iteration walks the linked list, not the bucket array → predictable order.
- Override `removeEldestEntry(eldest)` to return `true` when you want to drop the head — gives you a **bounded LRU cache** in ~10 lines of code.

---

### 2.9 `TreeMap` — Red-Black tree

- Self-balancing binary search tree. All ops O(log n).
- Keys must be `Comparable` or you pass a `Comparator`. **No `equals`/`hashCode` involvement** — uniqueness is decided by `compareTo` returning 0.
- Bonus methods: `firstKey`, `lastKey`, `floorKey(k)`, `ceilingKey(k)`, `headMap(k)`, `tailMap(k)`, `subMap(a, b)`. These are why you reach for `TreeMap` — sorted iteration and **range queries** are free.
- Iteration is in key order.

---

### 2.10 `ConcurrentHashMap` (JDK 8+) — the big one

Everything below changed dramatically from JDK 7 (which used `Segment[]` lock striping). **Always describe the JDK 8+ design in interviews** unless asked specifically about the old one.

**Structure:** Same `Node[]` table as `HashMap`. Same treeify-at-8 rule. The difference is **how writes are synchronized**.

**Write algorithm in one mental model:**

1. Compute index `i` like `HashMap`.
2. If `table[i] == null` → use **CAS** (atomic compare-and-swap) to install a new node. No lock. If CAS fails, retry the loop.
3. If `table[i]` is non-null → **`synchronized` on that head node**. Only one writer per bin at a time. Other bins remain fully unlocked.
4. If the table is being resized while you arrive, you see a `ForwardingNode` and you **help with the resize** before completing your write.

**Reads** (`get`) are completely **lock-free** — they walk the bin and the bin's nodes use `volatile` fields, so they see consistent values without a barrier.

**Atomic key-level ops:** `computeIfAbsent`, `computeIfPresent`, `compute`, `merge` are **atomic per bin** — the function runs inside the bin-level lock. This is huge in production: it replaces the classic "check-then-act" race.

**`size()` is approximate:** uses a `LongAdder`-style striped counter (an array of `CounterCell`s, like Java's `LongAdder`) to avoid one global counter becoming a contention hotspot. Reading `size()` sums them — accurate at quiet moments, approximate under load.

**Resize is parallel:** multiple threads can transfer buckets from the old table to the new one concurrently. The size threshold for resize is signaled via the `sizeCtl` field.

**Things you cannot do:** put `null` keys or `null` values — both throw `NullPointerException`. Why? Because `get` returning `null` would be ambiguous between "absent" and "present-but-null", and you can't use `containsKey` atomically with `get` in a concurrent map without locking.

---

### 2.11 The other maps (briefly, but you should recognise them)

| Impl | What's special | When to use |
|---|---|---|
| `Hashtable` | Synchronized on every method. Legacy. No null keys/values. | **Never** in new code. |
| `WeakHashMap` | Keys held by **weak references** — entries vanish when the key is GC'd. | Caches keyed by objects you don't own (e.g., `Class` → metadata). |
| `IdentityHashMap` | Uses `==` and `System.identityHashCode`, not `equals`/`hashCode`. | Reference-based graphs (serializers, cycle detection). |
| `EnumMap` | Backed by a flat array indexed by `enum.ordinal()`. No hashing at all. | **Always** prefer over `HashMap<MyEnum, V>` — much faster, denser. |
| `Collections.synchronizedMap(m)` | Wraps any map with a coarse `synchronized` block. | Almost never — `ConcurrentHashMap` is faster. |
| `Map.of(...)` / `Map.copyOf(...)` | Immutable, throws on mutation, throws on null keys/values. | Configs, constants, defensive returns. |

---

### 2.12 One-line comparison table (revise from this)

| Impl | Order | Null keys? | Null values? | Thread-safe? | Big-O |
|---|---|---|---|---|---|
| `HashMap` | None | 1 | Yes | No | O(1) avg, O(log n) worst |
| `LinkedHashMap` | Insertion or access | 1 | Yes | No | O(1) avg |
| `TreeMap` | Sorted | No | Yes | No | O(log n) |
| `ConcurrentHashMap` | None | **No** | **No** | Yes | O(1) avg |
| `Hashtable` | None | No | No | Yes (coarse) | O(1) avg |
| `EnumMap` | Enum order | No | Yes | No | O(1) array index |
| `WeakHashMap` | None | 1 | Yes | No | O(1) avg |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| Generic key-value store | `Map` (ES6), plain `{}` | `HashMap` |
| Preserve insertion order | `Map` does so by spec | `LinkedHashMap` |
| Sorted keys | None built-in | `TreeMap` |
| LRU cache | `lru-cache` npm package | `LinkedHashMap` + `removeEldestEntry` |
| Concurrent map | N/A (single-threaded event loop) | `ConcurrentHashMap` |
| Weak-keyed cache | `WeakMap` | `WeakHashMap` |
| Atomic check-and-set | Don't need — single-threaded | `computeIfAbsent` on `ConcurrentHashMap` |

### Where the comparison breaks down

- **JS `Map` keeps insertion order by spec.** Java's `HashMap` order is **not guaranteed** and changes between JVM versions. If your tests rely on iteration order, switch to `LinkedHashMap` or you'll get flaky failures.
- **JS `Map` uses `SameValueZero` (reference for objects).** Java uses `equals` and `hashCode`. Two different `Order` instances with the same id are equal to Java, but never equal to JS. This is why mutating a Java map key after insertion silently breaks lookup.
- **No real concurrency in Node.** A JS `Map` is fine in any handler because there's only one thread. In Java, sharing a `HashMap` between threads will eventually corrupt the bucket array (an infinite loop during resize was a famous JDK 7 bug). `ConcurrentHashMap` is mandatory for shared state.
- **`computeIfAbsent` is more than syntactic sugar.** In Node you'd do `if (!cache.has(k)) cache.set(k, compute(k))` — that's only safe because of the event loop. In Java on a `ConcurrentHashMap`, `cache.computeIfAbsent(k, this::compute)` is **atomic per key** — exactly one thread runs `compute(k)`, others wait. This is the canonical pattern for thread-safe lazy initialization.
- **`null` rules differ.** JS lets you `map.set(k, null)`. `HashMap` allows null values; `ConcurrentHashMap` doesn't. Easy NPE-producing porting bug.

---

## 4. Production-Grade Code

```java
package com.shop.cache;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;

public final class MapPlayground {

    public record User(String id, String email) {}
    public enum Role { VIEWER, EDITOR, ADMIN }

    /* 1) Bounded LRU cache — LinkedHashMap with access-order + removeEldestEntry. */
    public static <K, V> Map<K, V> lruCache(int capacity) {
        return Collections.synchronizedMap(
                new LinkedHashMap<K, V>(capacity, 0.75f, true) {     // accessOrder = true
                    @Override protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                        return size() > capacity;
                    }
                });
    }

    /* 2) Per-role permissions — EnumMap is denser and faster than HashMap. */
    private static final Map<Role, Set<String>> ROLE_PERMS = new EnumMap<>(Role.class);
    static {
        ROLE_PERMS.put(Role.VIEWER, Set.of("read"));
        ROLE_PERMS.put(Role.EDITOR, Set.of("read", "write"));
        ROLE_PERMS.put(Role.ADMIN,  Set.of("read", "write", "delete"));
    }

    /* 3) Sorted index for "events before timestamp X" — TreeMap with range queries. */
    private final NavigableMap<Instant, String> eventsByTime = new TreeMap<>();
    public Map<Instant, String> eventsBefore(Instant cutoff) {
        return eventsByTime.headMap(cutoff, false);     // exclusive view, NOT a copy
    }

    /* 4) Thread-safe cache with atomic lazy initialization — the canonical CHM pattern. */
    private final ConcurrentMap<String, User> userCache = new ConcurrentHashMap<>();
    public User loadUser(String id, Function<String, User> dbLoader) {
        // computeIfAbsent is atomic per key — exactly one thread runs dbLoader for this id.
        // Other threads with the same id block on the bin, then read the cached result.
        return userCache.computeIfAbsent(id, dbLoader);
    }

    /* 5) Thread-safe counter — merge replaces the read-modify-write race. */
    private final ConcurrentMap<String, Long> hitCounts = new ConcurrentHashMap<>();
    public void recordHit(String endpoint) {
        hitCounts.merge(endpoint, 1L, Long::sum);       // atomic increment, no lock
    }

    /* 6) WeakHashMap for "metadata about a class I don't own" — entries vanish when key is GC'd. */
    private static final Map<Class<?>, String> classLabels =
            Collections.synchronizedMap(new WeakHashMap<>());
    public static String labelFor(Class<?> c) {
        return classLabels.computeIfAbsent(c, Class::getSimpleName);
    }

    /* 7) Pre-sized HashMap to avoid resize churn during a bulk load. */
    public static Map<String, User> loadAll(Collection<User> users) {
        // Capacity rule of thumb: expectedSize / 0.75 + 1, rounded up.
        Map<String, User> out = new HashMap<>((int) (users.size() / 0.75f) + 1);
        for (User u : users) out.put(u.id(), u);
        return out;
    }
}
```

What this snippet shows:
- **`LinkedHashMap(cap, 0.75f, true) + removeEldestEntry`** — the 10-line LRU.
- **`EnumMap`** for the role permissions — flat array indexed by ordinal, zero hashing.
- **`NavigableMap.headMap`** — the `TreeMap` super-power: O(log n) range views, live, not copies.
- **`computeIfAbsent` on `ConcurrentHashMap`** — atomic lazy init. Replace every `if (!cache.containsKey) cache.put(...)` race with this.
- **`merge` for counters** — atomic increment without `synchronized`.
- **`WeakHashMap`** keyed by `Class<?>` so the JVM can unload classes cleanly.
- **Pre-sizing** the `HashMap` — `expectedSize / 0.75 + 1` avoids multiple resize passes during a bulk load.

---

## 5. Top 3 MNC Interview Questions

**Q1: Walk me through what happens inside `HashMap.put(k, v)`.**
- *What they're testing:* whether you actually know the internals or just call the API.
- *Ideal answer:* "First I compute `hash = key.hashCode() ^ (key.hashCode() >>> 16)` — the XOR spreads high bits into the low bits because the index uses only low bits. Then `index = (n - 1) & hash`, which works because the bucket array length is always a power of two. If `table[index]` is null I drop in a new `Node`. If not, I walk the chain — if any node's hash matches and `equals` returns true, I replace its value and return the old one. Otherwise I append. If the chain has now reached 8 nodes and the table has at least 64 buckets, the bucket is converted to a Red-Black tree for O(log n) lookup. Finally, if `++size > capacity × 0.75`, I double the table and re-place every entry — each old bucket splits into either the same index or `index + oldCapacity`, decided by one bit."

**Q2: What's the difference between `Hashtable` and `ConcurrentHashMap`?**
- *What they're testing:* whether you know modern concurrent design, not just "both are thread-safe".
- *Ideal answer:* "`Hashtable` synchronizes every public method on the whole map — one global lock, so only one thread can read or write at a time. Useless under load. `ConcurrentHashMap` in JDK 8 uses a bin-level strategy: reads are completely lock-free using `volatile` reads, writes use CAS to install a node into an empty bin and only fall back to `synchronized` on the first node of the bin if there's a collision. So contention is limited to threads hitting the same bin, not the whole map. It also has atomic key-level operations like `computeIfAbsent`, `merge`, and `compute` that run inside the bin lock — the canonical safe lazy-init and counter patterns. The catch is it rejects null keys and null values."

**Q3: Why does `HashMap`'s bucket array have to be a power of two?**
- *What they're testing:* whether you understand the bitmask trick and the resize optimization.
- *Ideal answer:* "Two reasons. First, the index lookup uses `(n - 1) & hash` instead of `hash % n`. That only gives a valid distribution if `n - 1` is a bitmask like `0000...01111`, which only happens when `n` is a power of two. Bitwise AND is one cycle; modulo is much slower. Second, resize doubles the capacity, and because of the doubling, every entry's new index is either the same as the old one or the old one plus the old capacity — decided by a single new bit in the hash. So resize re-places entries in O(1) per entry without re-hashing. Both optimizations break the moment `n` isn't a power of two, which is why any custom initial capacity gets rounded up internally."

---

## 6. Memorize this

> **Memorize this:** Every Java map is some variant of "array of buckets" — `HashMap` is a power-of-two bucket array with chains that treeify at 8 nodes and resize at 0.75 load factor; `LinkedHashMap` threads a doubly-linked list through it for order; `TreeMap` is a Red-Black tree for sorted range queries; `ConcurrentHashMap` keeps the same `HashMap` layout but uses **CAS on empty bins + `synchronized` on the head node of contended bins** — and rejects nulls because `get` returning null must mean "absent".
