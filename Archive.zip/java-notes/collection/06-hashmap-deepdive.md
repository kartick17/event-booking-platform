**Priority: Interview-critical** — full deep-dive below. (You already have a `Map` overview — this is the dedicated `HashMap` deep-dive. Senior interviewers ask 30 minutes about just this class.)

# `HashMap` — Internals Deep Dive

---

## 1. Core Mechanism

`HashMap<K, V>` is Java's default key-value store. **Average O(1)** for `put`, `get`, and `remove`. **Not** thread-safe. **Allows one null key** and many null values. **No iteration order guarantee.**

Why it exists:
- Backbone of every cache, lookup, and index in real backend code.
- Java needs a fast, general-purpose associative array — `HashMap` is the default since 1.2, with a major redesign in **JDK 8** that added tree-bucket fallback.

> **Interview definition (say this out loud):** "`HashMap` is a hash table — an array of buckets sized to a power of two, indexed by `(n-1) & spread(hash)`. Each bucket starts as a singly-linked list of nodes; once it grows past 8 nodes **and** the table has at least 64 buckets, that bucket is converted to a Red-Black tree, dropping the worst-case lookup from O(n) to O(log n). It resizes by doubling when `size > capacity × 0.75`, and during resize each old bucket splits into two new ones based on a single new bit in the hash."

---

## 2. Under the Hood

### 2.1 The structure (one mental picture)

```
HashMap
├── Node<K,V>[] table           ← bucket array, length = power of 2
│   ├── [0] → null
│   ├── [1] → Node → Node → Node              (chain, low collision count)
│   ├── [2] → TreeNode (Red-Black tree root)  (≥ 8 collisions + table ≥ 64)
│   └── [3] → null
├── int size                    ← total entries
├── int threshold               ← next resize at this size = capacity * loadFactor
├── float loadFactor            ← default 0.75
└── int modCount                ← bumps on every structural change (fail-fast)
```

**Constants** (memorize these — interviewers ask the exact numbers):

| Constant | Value | Meaning |
|---|---|---|
| `DEFAULT_INITIAL_CAPACITY` | 16 | Starting bucket count |
| `MAXIMUM_CAPACITY` | 1 << 30 (≈ 1 billion) | Upper cap |
| `DEFAULT_LOAD_FACTOR` | 0.75 | Resize when `size > capacity × 0.75` |
| `TREEIFY_THRESHOLD` | 8 | List → tree at 8 nodes in a bucket |
| `UNTREEIFY_THRESHOLD` | 6 | Tree → list when shrinking ≤ 6 |
| `MIN_TREEIFY_CAPACITY` | 64 | Don't treeify a small table — resize instead |

---

### 2.2 The `Node` (and `TreeNode`) layout

```java
static class Node<K,V> {
    final int hash;     // cached spread hash — never recomputed
    final K key;        // final — that's why mutating the key breaks lookup
    V value;
    Node<K,V> next;
}
```

- The hash is **cached on the node** — it's never recomputed during walks, even after resize. So `equals` and `hashCode` are only called when `put`/`get` is invoked, not during table resize.
- `key` is `final` — you literally cannot change the reference inside the node — but the *object* the key points to can still be mutated, which is the classic bug.
- `TreeNode` extends `Node` and adds `parent`, `left`, `right`, `prev`, `red` (color bit). About 2× the memory of a `Node`.

---

### 2.3 The hash function — `(h ^ (h >>> 16))`

```java
static final int hash(Object key) {
    int h;
    return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
}
```

Three things to know:

1. **`null` key → hash = 0** → always lands in bucket 0. There's exactly one slot for a null key in the whole map.
2. **`h >>> 16`** is unsigned right shift by 16 — pushes the **top 16 bits down** into the bottom 16 bit positions.
3. **XOR them** → mixes the high bits into the low bits.

Why mix? The bucket index uses only the **low bits** of the hash (next section). If two keys differ only in their **high** bits (very common with bad `hashCode` implementations), without spreading they'd collide into the same bucket. Spreading is a cheap defense.

---

### 2.4 The index — `(n - 1) & hash`

```java
int index = (table.length - 1) & hash(key);
```

- `n` = `table.length`. Since `n` is always a power of 2, `n - 1` is a bitmask like `0000...01111`.
- So `(n - 1) & hash` keeps only the low `log₂(n)` bits of the hash — exactly the range `[0, n-1]`.
- This is the **bitmask trick**. It's many times faster than `hash % n` on hot paths.
- **Why every HashMap is power-of-two**: this trick only gives a uniform distribution when `n` is a power of two. Any custom initial capacity gets rounded up internally by `tableSizeFor`.

---

### 2.5 `put(k, v)` — step-by-step

Let's trace `map.put("orderId-42", order)` on a fresh map (capacity 16):

1. `hash = "orderId-42".hashCode() ^ (h >>> 16)` → say `0x3F2A8B71`.
2. `index = 15 & 0x3F2A8B71 = 0x1 = 1`. We aim at bucket 1.
3. `table[1] == null` → create a new `Node(hash, "orderId-42", order, null)`, place it.
4. `++size`. If `size > 12` (16 × 0.75) → **resize**.

Now suppose another key `"orderId-99"` hashes to the same bucket:

1. Compute `i`, find `table[1]` is non-null.
2. Walk the chain. For each existing node:
   - **First** check `node.hash == newHash` — cheap int comparison.
   - **Then** check `node.key == newKey || node.key.equals(newKey)` — `==` short-circuits when interned strings or same reference.
3. If a match → **replace** value, return the old one.
4. If no match → append a new node at the tail.
5. **After appending**, if the chain length is now ≥ 8:
   - If `table.length >= 64` → **treeify** this bucket.
   - Else → **resize** instead (table is too small; resizing usually splits the bucket).
6. If `++size > threshold` → resize.

`get` is the same walk but without the insert step.

---

### 2.6 Resize — the doubling trick (favorite interview question)

```java
// Pseudocode of resize
newCap = oldCap * 2;
newThreshold = newCap * loadFactor;
for each oldBucket b:
    walk every node in b → re-place it in newTable
```

The clever part: because the new table is exactly twice the size, every old bucket splits into **two** new buckets, decided by **one single new bit** in the hash.

If you had bucket index `i` in a 16-slot table, after doubling to 32 slots, the new index is either:
- **`i`** (if the new high bit `(hash & oldCap) == 0`), or
- **`i + oldCap`** (if `(hash & oldCap) != 0`).

So during resize, JDK 8 walks each old bucket once and splits it into two linked lists (`loHead` and `hiHead`), placing each at the right new slot. No re-hashing, no per-key arithmetic — one bitmask check per entry.

JDK 8 also keeps trees as trees during resize (split into two trees of the same shape), so no rebuild cost.

**Cost of resize:** O(n). This is why pre-sizing the map matters: every resize re-touches every entry.

**Pre-sizing rule:** `new HashMap<>((int)(expectedSize / 0.75f) + 1)` — avoids any resize during bulk insertion.

---

### 2.7 Treeification — the DoS defense

Added in JDK 8. If a bucket reaches 8 nodes:
- If `table.length >= 64` → that bucket is converted from a linked list into a **Red-Black tree** of `TreeNode`s. Lookup inside becomes O(log n) instead of O(n).
- If `table.length < 64` → just resize the whole table; the bucket usually splits into two smaller chains.

When trees shrink to ≤ 6 entries during removal → untreeify back to a list.

**Why exactly 8 and 6?** Statistical: under a **good** hash distribution, the probability of a bucket having 8 collisions is roughly `1 in 10⁷` (Poisson distribution at 0.75 load factor). So treeification almost never happens in normal code — it's purely a **safety net for bad `hashCode` implementations or DoS attacks** (sending many keys with the same hash). The 6/8 gap is hysteresis (a buffer to avoid thrashing list ↔ tree as entries are added and removed).

**Catch:** for tree comparison, JDK first uses the hash, then `class.getName().compareTo`, and only then uses `compareTo` if the key implements `Comparable`. So even with bad hashing, the lookup is well-behaved.

---

### 2.8 JDK 7 vs JDK 8 (asked at every senior interview)

| | JDK 7 | JDK 8 |
|---|---|---|
| Bucket structure | Linked list only | List, then tree at 8 |
| Worst-case lookup | O(n) | O(log n) |
| Resize transfer | Inserts each entry at **head** of new bucket (reverses order) | Splits into two preserving relative order |
| Resize concurrency bug | Yes — **infinite loop** possible if multiple threads resize at once (head-insert can form a cycle) | No infinite loop (tail-insert and split keeps lists acyclic) |
| Hash function | More expensive (4 XORs and shifts) | Simpler: `h ^ (h >>> 16)` |
| `null` key | Yes (bucket 0) | Yes (bucket 0) |

**The infinite-loop bug** is a classic interview question. In JDK 7, two threads resizing simultaneously could **link a node back to itself**, so a later `get` on a key in that bucket would spin forever, pinning a CPU core. The "fix" was always "don't share a `HashMap` across threads — use `ConcurrentHashMap`". JDK 8 changed the transfer algorithm so the bug no longer exists, but **`HashMap` still isn't thread-safe** — concurrent puts can still lose updates.

---

### 2.9 Iteration & fail-fast

- The iterator captures `expectedModCount = modCount` at creation.
- Every `next()` checks `modCount == expectedModCount`. If not → `ConcurrentModificationException`.
- Structural changes (`put` new key, `remove`, `clear`, `resize`) bump `modCount`. Replacing a value of an existing key does **not** bump it.
- Iteration walks the bucket array `table[0..n]` and within each bucket walks the chain or tree. So iteration order is "bucket-walk order" — depends on hashes and capacity, and is **not stable** across JVM versions or even across same-input maps with different insertion orders.

---

### 2.10 The cost numbers (for back-of-envelope answers)

| Op | Best | Average | Worst (good hash) | Worst (bad hash) |
|---|---|---|---|---|
| `get` / `put` / `remove` | O(1) | O(1) | O(log n) (treed bucket) | O(log n) (treed bucket) |
| Iteration | O(n + capacity) | — | — | — |
| Resize | O(n) | — | — | — |

Memory per entry (64-bit JVM, compressed oops): ~48 bytes (`Node`) + key + value. `TreeNode`: ~80 bytes.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| Default map | `new Map()` | `new HashMap<>()` |
| Object as key by id | Need `===` reference equality | `equals`/`hashCode` on key class |
| Iteration order | Insertion order (spec) | Undefined, not stable |
| Null key | `map.set(null, v)` works | `map.put(null, v)` works (one slot) |
| Resize | Engine-internal, not specified | Doubles at 0.75 load factor |
| Concurrent safety | N/A — single-threaded | Not safe; use `ConcurrentHashMap` |

### Where the comparison breaks down

- **Insertion order is not guaranteed in `HashMap`.** JS devs writing Java tests are surprised when iteration order drifts between JVM versions. If you need order, use `LinkedHashMap`.
- **Object-key behavior is opposite.** In JS, two `{ id: 1 }` literals are different keys (reference). In Java, two `new User(1)` objects can be the **same key** if you override `equals`/`hashCode`. This is power *and* a footgun — mutating a key after insertion silently breaks `get`.
- **Resize cost is exposed in Java.** Tuning the initial capacity actually matters for bulk loads. JS engines hide this; in Java, sizing wrong means you walk every entry multiple times.
- **No thread safety.** A JS `Map` is safe in any handler because Node is single-threaded. Sharing a Java `HashMap` between threads can silently lose entries on `put` and (rarely) corrupt the table. There is no "make it thread-safe" mode — switch to `ConcurrentHashMap`.

---

## 4. Production-Grade Code

```java
package com.shop.session;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

public final class SessionIndex {

    // Records give correct equals/hashCode for free — essential for HashMap keys.
    public record SessionKey(String tenantId, String userId) {}

    public record Session(SessionKey key, String token, Instant expiresAt) {}

    private final Map<SessionKey, Session> byKey;

    public SessionIndex(int expectedSessions) {
        // Pre-size to avoid resize churn during bulk load.
        // expectedSize / loadFactor + 1, rounded up.
        int initialCapacity = (int) (expectedSessions / 0.75f) + 1;
        this.byKey = new HashMap<>(initialCapacity);
    }

    public Session put(Session s) {
        return byKey.put(s.key(), s);                 // returns the displaced session, if any
    }

    public Optional<Session> find(SessionKey key) {
        return Optional.ofNullable(byKey.get(key));
    }

    /** Bulk insert without intermediate resizes. */
    public void loadAll(Collection<Session> sessions) {
        // If sessions is much larger than current capacity, resize once up-front.
        // ensureCapacity-style hint: re-create the map with the right size.
        for (Session s : sessions) byKey.put(s.key(), s);
    }

    /** Safe deletion during iteration — use the iterator's remove(). */
    public int purgeExpired(Instant now) {
        int removed = 0;
        Iterator<Map.Entry<SessionKey, Session>> it = byKey.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<SessionKey, Session> e = it.next();
            if (e.getValue().expiresAt().isBefore(now)) {
                it.remove();                          // only safe deletion path
                removed++;
            }
        }
        return removed;
    }

    /** Get-or-compute pattern — replaces the classic "check then put" race only safe single-threaded. */
    public Session getOrCreate(SessionKey key, java.util.function.Function<SessionKey, Session> factory) {
        // computeIfAbsent on plain HashMap is NOT atomic across threads — fine here, single-threaded.
        return byKey.computeIfAbsent(key, factory);
    }

    public int size() {
        return byKey.size();
    }

    /** Wrong pattern, kept as comment for revision — mutating a key after put. */
    // SessionKey k = new SessionKey("t1", "u1");
    // byKey.put(k, session);
    // ((MutableKey) k).setUserId("u2");           // would land in different bucket on lookup
    // byKey.get(k);                                // returns null even though entry exists
}
```

What this snippet shows:
- **`record` as a map key** — gives the correct `equals`/`hashCode` automatically. Never use a mutable class as a key.
- **Pre-sizing** with `(expected / 0.75f) + 1` — avoids every resize during a bulk load.
- **`iterator().remove()`** as the only safe deletion path during iteration (no `CME`).
- **`computeIfAbsent`** for the "get or create" pattern — atomic only on `ConcurrentHashMap`, but still clean syntax here.
- A commented anti-pattern at the bottom — the mutating-key bug, written down so you remember it.

---

## 5. Top 3 MNC Interview Questions

**Q1: Walk me through `HashMap.put(k, v)` end to end.**
- *What they're testing:* whether you actually know the algorithm or just call the API.
- *Ideal answer:* "I compute `hash = key.hashCode() ^ (key.hashCode() >>> 16)` — the XOR mixes the high bits into the low bits because the index only uses the low bits. Then `index = (table.length - 1) & hash`, which works because the table size is always a power of two. If `table[index]` is null, I put a new `Node` there. Otherwise I walk the chain; if a node has the same hash and `equals` returns true, I replace its value and return the old one. Otherwise I append. If the chain now has 8 nodes and the table is at least 64 buckets, that bucket is converted into a Red-Black tree so future lookups are O(log n). Finally, if `size > capacity × 0.75`, I resize — the table doubles, and each old bucket splits into two new ones based on a single new bit in the hash."

**Q2: Why does `HashMap` use a Red-Black tree once a bucket has 8 entries?**
- *What they're testing:* whether you know the *reason* (DoS resistance), not just the trivia.
- *Ideal answer:* "It's a defense against bad hashing. Under a healthy hash distribution at 0.75 load factor, the probability of any bucket reaching 8 entries is roughly one in ten million by Poisson — so treeification almost never fires. But if `hashCode` is poorly written or an attacker is sending crafted keys with colliding hashes — a hash-flooding DoS attack — a bucket could grow huge and degrade `get` to O(n). At 8 nodes, JDK 8 converts that bucket from a linked list into a Red-Black tree, bounding worst-case lookup to O(log n). The thresholds 8 and 6 have a hysteresis gap so the structure doesn't thrash between list and tree as entries are added and removed."

**Q3: What happens if I share a `HashMap` between multiple threads?**
- *What they're testing:* whether you know it's not thread-safe and *why* — and whether you know the JDK 7 infinite-loop history.
- *Ideal answer:* "`HashMap` is not thread-safe. Two threads calling `put` at the same time can race on the bucket chain and silently lose one of the entries. On JDK 7, concurrent resizes could form a cycle in a bucket's linked list because the algorithm inserted entries at the head, and a later `get` on that bucket would loop forever, pinning a CPU. JDK 8 changed the resize algorithm so the infinite loop no longer happens, but `HashMap` still isn't safe — lost updates and incorrect size are still possible. The right fix is `ConcurrentHashMap`, which uses CAS on empty bins and synchronizes only on the head node of a contended bin, and also gives you atomic `computeIfAbsent` and `merge`."

---

## 6. Memorize this

> **Memorize this:** `HashMap` is a power-of-two array of buckets; index is `(n-1) & (hashCode() ^ hashCode() >>> 16)`; each bucket is a linked list that treeifies into a Red-Black tree once it hits 8 entries (with table ≥ 64); resize doubles the table at 0.75 load factor and splits each old bucket into two new ones by one new hash bit.
