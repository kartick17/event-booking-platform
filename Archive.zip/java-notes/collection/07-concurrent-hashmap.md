**Priority: Interview-critical** — full deep-dive below. (Senior interview staple. Plan to revise it twice.)

# `ConcurrentHashMap` — Internals Deep Dive

---

## 1. Core Mechanism

`ConcurrentHashMap<K, V>` is Java's thread-safe `HashMap` replacement. **Lock-free reads. Bin-level locking on writes.** Same `(n-1) & hash` indexing, same treeify-at-8 rule as `HashMap` — but a completely different concurrency strategy.

Why it exists:
- `Hashtable` is fully synchronized — only one thread can read **or** write at a time. Useless under load.
- `Collections.synchronizedMap(new HashMap<>())` is the same coarse-lock trick — also useless.
- Real systems need thousands of threads hitting the same map (caches, session stores, counters). `ConcurrentHashMap` makes that fast.

Two key facts that surprise people:
- **No null keys, no null values.** Both throw `NullPointerException`. (Reason explained in 2.10.)
- **`size()` is approximate** under load. So is `isEmpty()`.

> **Interview definition (say this out loud):** "`ConcurrentHashMap` in JDK 8+ uses the same `Node[]` bucket array as `HashMap`, but reads are completely lock-free using `volatile` semantics, writes use **CAS** to install a node into an empty bin, and only fall back to **`synchronized` on the head node** of a bin when there's a real collision. So contention is bin-level, not map-level. It also offers atomic key-level operations — `computeIfAbsent`, `compute`, `merge` — which run inside that bin lock. It rejects null keys and null values because `get` returning `null` must unambiguously mean 'absent'."

---

## 2. Under the Hood

### 2.1 The two-era story (always mention this in interviews)

`ConcurrentHashMap` was completely redesigned in **JDK 8**. Senior interviewers will ask "JDK 7 vs JDK 8" — know both, but use the JDK 8 model in any concrete walk-through.

| | JDK 7 | JDK 8+ (modern) |
|---|---|---|
| Structure | `Segment[]` — array of small hashtables | Single `Node[]` table, same shape as `HashMap` |
| Locking | One `ReentrantLock` per segment (default 16) | CAS + `synchronized` on bin head node |
| Concurrent writers | At most 16 (one per segment) | Up to N (one per bin) |
| Read | Volatile read inside segment | Fully lock-free via `volatile`/`Unsafe` |
| Resize | Each segment resizes alone | All threads can help one global resize |
| Tree buckets | No | Yes — same treeify-at-8 rule as `HashMap` |
| Counter | One `int count` per segment | `LongAdder`-style striped `CounterCell[]` |

Everything below describes **JDK 8+** unless I say otherwise.

---

### 2.2 The structure

```
ConcurrentHashMap
├── Node<K,V>[] table              ← same bucket array idea as HashMap
│   ├── [0] → Node → Node          ← chain
│   ├── [1] → ForwardingNode       ← table is being resized; "go look at nextTable"
│   ├── [2] → TreeBin → TreeNode   ← treeified bucket (≥ 8 nodes + table ≥ 64)
│   └── [3] → null
├── Node<K,V>[] nextTable          ← non-null only during a resize
├── volatile int sizeCtl           ← multi-purpose control word (see 2.7)
└── CounterCell[] counterCells     ← striped counter for size() (see 2.9)
```

The bucket array uses `volatile` reads via `Unsafe` (now `VarHandle`) so any reader sees the latest published node without locking.

---

### 2.3 Special node types (this is where senior questions live)

`ConcurrentHashMap` has four `Node` subtypes, each marked by a special hash value:

| Type | Hash value | Meaning |
|---|---|---|
| `Node` | `≥ 0` | Normal entry in a linked list |
| `TreeBin` | `-2` | Wraps the root of a Red-Black tree for a treeified bucket |
| `ForwardingNode` | `-1` | Placeholder during resize — "this bucket already moved to `nextTable`" |
| `ReservationNode` | `-3` | Placeholder while `computeIfAbsent` is running its function on an empty bin |

The negative hash values mean a single sign check tells the algorithm "this isn't a normal entry — handle specially". Clever and cheap.

---

### 2.4 Read (`get`) — lock-free

```java
public V get(Object key) {
    int h = spread(key.hashCode());
    Node<K,V>[] tab = table;
    Node<K,V> e = tabAt(tab, (tab.length - 1) & h);   // volatile read
    // walk the chain or tree using volatile reads
}
```

- `spread(h)` is the same `(h ^ h >>> 16) & 0x7fffffff` mixing as `HashMap`, but masks the sign bit (negative hashes are reserved for special nodes).
- `tabAt` is a `volatile` read of `table[i]` via `VarHandle`. **No lock, no memory barrier beyond the volatile read.**
- Nodes' `val` and `next` fields are also `volatile`, so the reader sees a consistent snapshot of any node a writer has just published.
- If the bucket is a `ForwardingNode` (resize in progress) → forward the read to `nextTable`. Reads never block during resize.

**Bottom line:** `get` is essentially free of synchronization cost. This is why `ConcurrentHashMap` shines as a cache — hot reads scale to all cores.

---

### 2.5 Write (`put`) — CAS + per-bin `synchronized`

The write loop (simplified):

```java
for (;;) {
    Node<K,V>[] tab = table;
    int i = (tab.length - 1) & hash;
    Node<K,V> f = tabAt(tab, i);

    if (f == null) {
        // Case A: empty bin — install via CAS, no lock at all
        if (casTabAt(tab, i, null, new Node<>(hash, key, value))) break;
        // CAS failed — another thread won, retry
    } else if (f.hash == MOVED) {
        // Case B: resize in progress — help with the transfer, then retry
        tab = helpTransfer(tab, f);
    } else {
        // Case C: bin has a real head — synchronize on it
        synchronized (f) {
            if (tabAt(tab, i) == f) {     // re-check under lock
                // walk the chain or tree, insert or replace
            }
        }
        break;
    }
}
addCount(1L, ...);   // updates the striped counter; may trigger resize
```

Three rules to memorize:
1. **Empty bin → CAS.** No lock taken. CAS failure means another thread won; retry.
2. **Non-empty bin → `synchronized` on the head node.** Only threads hitting the same bin contend.
3. **Encountering a `ForwardingNode` → help with the resize**, then retry the put.

So lock contention is bounded by **the number of threads hitting the same bin**, not by total writers. With a healthy hash distribution and a reasonably sized table, real-world contention is near zero.

---

### 2.6 Treeify is the same as `HashMap`

- A bin's chain grows past 8 nodes **and** the table has ≥ 64 buckets → that bin is wrapped in a `TreeBin` containing a Red-Black tree.
- A `TreeBin` itself has a `LockSupport`-based writer lock for tree restructuring, but readers can still walk it lock-free (using a fallback linked-list view while the writer is rebalancing).
- Same DoS-defense rationale as in `HashMap` — treeify almost never fires under good hashing.

---

### 2.7 The `sizeCtl` state machine

`sizeCtl` is a single `volatile int` that does four jobs depending on its sign:

| `sizeCtl` value | Meaning |
|---|---|
| `> 0` | Next resize threshold (capacity × loadFactor) |
| `0` | Default — use default capacity |
| `-1` | Table is being initialized |
| `< -1` | Resize in progress; the low bits encode "number of helping threads + 1" |

Initialization uses CAS to flip `sizeCtl` from `0` to `-1`, so even concurrent constructors race-safely run the init only once. Resize uses CAS to atomically register/unregister helping threads.

---

### 2.8 Multi-threaded cooperative resize

This is the most beautiful part of the design.

- When any writer pushes the map past the threshold, it allocates `nextTable` (double size).
- It then claims a **range of buckets** (a "transfer stride") to migrate from `table` to `nextTable`.
- As it transfers each old bucket, it replaces the old slot with a **`ForwardingNode`** pointing to `nextTable`.
- **Any other thread that arrives** mid-resize — whether for a `put`, `remove`, or even a `get` — sees a `ForwardingNode` and either:
  - Reads through it to `nextTable` (no help needed), or
  - For writers, claims its own stride and **helps the transfer**.

So resize doesn't block the map — it gets *faster* under load because more threads pitch in. When the last bucket is moved, `table` is atomically replaced by `nextTable`.

---

### 2.9 `size()` is approximate — and that's intentional

A single atomic counter would be a contention hotspot. `ConcurrentHashMap` uses a **`LongAdder`-style striped counter** (`CounterCell[]`):

- Each writer increments **one cell** of `counterCells`, hashed by the thread.
- `size()` sums the cells.
- Under heavy concurrent writes, the answer can drift — accurate at quiet moments, approximate at peak.

So **never use `chm.size()` in a hot path or for correctness checks** (like "if (chm.size() < limit) chm.put(...)" — that's a race). Use atomic ops like `computeIfAbsent` or `merge` instead.

---

### 2.10 Why null keys and null values are banned

This is a top interview question.

```java
V v = map.get(key);
if (v == null) { /* absent... or present with null value? */ }
```

In a single-threaded `HashMap`, you can disambiguate with `containsKey(key)`. But on a concurrent map, `containsKey` then `get` is **two separate operations** — between them another thread could insert or remove the key. The only way to fix this would be locking. So the API designers made the simpler choice: **null can never appear, so `get == null` always means "absent"**.

This makes `computeIfAbsent`, `merge`, etc. unambiguous and lock-free for the absent path.

---

### 2.11 The atomic ops (`compute`, `computeIfAbsent`, `merge`)

These are the killer features. All of them run **atomically per bin** — the user's function executes while holding the bin lock, so no other thread can race on the same key.

**`computeIfAbsent(key, fn)`** — the canonical thread-safe lazy-init / cache-loader:
```java
User u = userCache.computeIfAbsent(id, this::loadFromDb);
```
Exactly one thread runs `loadFromDb(id)` per key. Others wait on the bin lock and then read the cached value.

**`merge(key, value, mergeFn)`** — atomic increment / aggregate:
```java
counts.merge(endpoint, 1L, Long::sum);    // safe atomic counter
```
No `synchronized`, no `AtomicLong` — one bin-level lock, done.

**`compute(key, biFn)`** — full read-modify-write under the bin lock.

**Pitfall:** the function you pass to `computeIfAbsent` **must not** call back into the same map on the same key — it's already holding that bin's lock, so you can deadlock or stack-overflow.

---

### 2.12 The mental model for iteration

- `keySet()`, `values()`, `entrySet()` return **weakly consistent** views.
- Iterators **never throw `ConcurrentModificationException`**.
- They **may** show entries inserted after iteration began. They **may** miss some. They will never crash.
- Internally they capture a reference to the current `table` and walk it; if they hit a `ForwardingNode`, they follow it to `nextTable`.

---

### 2.13 One-line summary

| Aspect | Answer |
|---|---|
| Read cost | Lock-free (`volatile` reads) |
| Write cost on empty bin | CAS, no lock |
| Write cost on contended bin | `synchronized` on head node |
| Resize | Cooperative — all threads help |
| Null key/value | **Not allowed**; both throw NPE |
| `size()` | Approximate under load |
| `computeIfAbsent` / `merge` | Atomic per key |
| Iteration | Weakly consistent, never throws CME |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| Shared mutable map across handlers | Plain `Map` in a module — safe (single thread) | `ConcurrentHashMap` (sharing `HashMap` corrupts) |
| Lazy-cache lookup | `if (!cache.has(k)) cache.set(k, await load(k))` | `cache.computeIfAbsent(k, this::load)` |
| Counter | `counts.set(k, (counts.get(k) ?? 0) + 1)` | `counts.merge(k, 1L, Long::sum)` |
| Null value in cache | `cache.set(k, null)` works | Throws `NullPointerException` |
| Iteration during writes | Spec-defined visibility | Weakly consistent — no `CME`, may miss entries |

### Where the comparison breaks down

- **Atomicity is real in Java.** In Node, `if (!cache.has(k)) cache.set(k, load(k))` is safe by accident — the event loop is single-threaded, so nothing happens between `has` and `set`. In Java, the same pattern on multiple threads will run `load(k)` many times for the same key and may store stale values. `computeIfAbsent` exists to fix exactly this race.
- **No nulls.** Caches in JS often store `null` to mean "we checked and there's nothing in the DB". That's an NPE in `ConcurrentHashMap`. Use a sentinel like `Optional.empty()` wrapped, or a dedicated `MISSING` marker object.
- **`size()` isn't truth.** In JS `map.size` is always exact. In Java, `chm.size()` is approximate under load. Never use it for capacity guards.
- **Reads never block, writes don't block reads.** In JS this doesn't apply because there are no real threads. In Java, this is what makes `ConcurrentHashMap` the right cache backbone — readers scale to all CPU cores.

---

## 4. Production-Grade Code

```java
package com.shop.cache;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Function;

public final class UserCache {

    public record User(String id, String email, Instant fetchedAt) {}

    private final ConcurrentMap<String, User> byId = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Long> hitsByEndpoint = new ConcurrentHashMap<>();
    private final LongAdder totalCacheLoads = new LongAdder();

    private final Function<String, User> dbLoader;
    private final Duration ttl;

    public UserCache(Function<String, User> dbLoader, Duration ttl) {
        this.dbLoader = Objects.requireNonNull(dbLoader);
        this.ttl = Objects.requireNonNull(ttl);
    }

    /**
     * Atomic get-or-load. Exactly one thread runs dbLoader per id at a time.
     * Other threads requesting the same id wait on the bin lock, then read the cached value.
     */
    public User getOrLoad(String id) {
        return byId.compute(id, (k, current) -> {
            if (current != null && !isStale(current)) return current;
            totalCacheLoads.increment();
            return dbLoader.apply(k);     // runs inside the bin lock — atomic per key
        });
    }

    private boolean isStale(User u) {
        return u.fetchedAt().plus(ttl).isBefore(Instant.now());
    }

    /** Atomic counter — no synchronized, no AtomicLong. */
    public void recordHit(String endpoint) {
        hitsByEndpoint.merge(endpoint, 1L, Long::sum);
    }

    public long hits(String endpoint) {
        return hitsByEndpoint.getOrDefault(endpoint, 0L);
    }

    /**
     * Weakly consistent iteration — safe even if other threads are mutating.
     * Never throws ConcurrentModificationException.
     */
    public List<User> snapshotByEmailDomain(String domain) {
        List<User> out = new ArrayList<>();
        for (User u : byId.values()) {                 // weakly consistent iterator
            if (u.email().endsWith("@" + domain)) out.add(u);
        }
        return out;
    }

    /** Approximate size — fine for metrics, NOT for correctness checks. */
    public int approximateSize() {
        return byId.size();
    }

    public long loadCount() {
        return totalCacheLoads.sum();
    }

    /** Bulk eviction — safe concurrent removal. */
    public int evictStale() {
        Instant cutoff = Instant.now().minus(ttl);
        int removed = 0;
        for (Map.Entry<String, User> e : byId.entrySet()) {
            if (e.getValue().fetchedAt().isBefore(cutoff)) {
                // remove(k, v) is atomic — only removes if the value still matches
                if (byId.remove(e.getKey(), e.getValue())) removed++;
            }
        }
        return removed;
    }
}
```

What this snippet shows:
- **`compute` for atomic get-or-load** with staleness check — the user's function runs inside the bin lock, so only one thread loads per key.
- **`merge` for the hit counter** — no `synchronized`, no `AtomicLong`, just atomic per-key increment.
- **`LongAdder`** for a global counter that's hotter than per-key — same striping idea as the map's internal counter.
- **Weakly consistent iteration** in `snapshotByEmailDomain` — safe with concurrent writers.
- **`remove(k, v)` overload** — only removes if the value still matches, so concurrent updates don't lose data.
- **No nulls anywhere.** All maps are typed in a way that rules out nulls.

---

## 5. Top 3 MNC Interview Questions

**Q1: How is `ConcurrentHashMap` different in JDK 8 from JDK 7?**
- *What they're testing:* whether you know the modern design, not the textbook one.
- *Ideal answer:* "JDK 7 used a `Segment[]` — an array of 16 small `Hashtable`s, each with its own `ReentrantLock`. So at most 16 writers could run concurrently, regardless of how many cores you had. JDK 8 removed segments entirely. It uses the same `Node[]` bucket array as `HashMap`, with the same treeify-at-8 rule. Reads are completely lock-free via `volatile`. For writes, if the bin is empty it uses CAS to install a node — no lock. Only when there's a real collision does it `synchronized` on the head node of that bin. So contention is bin-level instead of segment-level, which scales to hundreds of writers. JDK 8 also added cooperative resize — any thread arriving during a resize helps with the transfer — and atomic key-level operations like `computeIfAbsent` and `merge` that run under the bin lock."

**Q2: Why does `ConcurrentHashMap` reject null keys and null values when `HashMap` allows them?**
- *What they're testing:* whether you understand the concurrency ambiguity, not just the API.
- *Ideal answer:* "Because there's no atomic way to disambiguate. If `get(k)` returns `null`, did the key not exist, or did it exist with a null value? In single-threaded `HashMap` you fix this by calling `containsKey` first, but in a concurrent map that's two separate operations — another thread can change the state between them. To make `containsKey` + `get` atomic, you'd need to lock, and that would kill the lock-free read path that makes the class fast. So the design chose to ban null and keep the simple invariant: `get == null` always means 'absent'. That's also what makes `computeIfAbsent`, `merge`, and `putIfAbsent` clean and lock-free for the absent path."

**Q3: How does `computeIfAbsent` give thread safety, and what's the trap?**
- *What they're testing:* whether you know it's atomic per key, and the recursive deadlock trap.
- *Ideal answer:* "`computeIfAbsent(k, fn)` runs the function while holding `synchronized` on that bin's head node. So if many threads ask for the same key concurrently, exactly one runs the function, and the others wait on the bin lock and then read the cached result. It replaces the classic `if (!has) put(load())` race in one atomic op. The trap is twofold. First, if your function calls back into the same map on the same key — even transitively — you can deadlock or stack-overflow because the bin lock isn't recursive across nested compute calls. Second, the function runs **under the lock**, so don't do slow I/O inside `computeIfAbsent` on a hot bin — other writers to that bin will queue. For slow loaders, prefer `CompletableFuture` values: store `CompletableFuture<User>` in the map and let other threads chain off it."

---

## 6. Memorize this

> **Memorize this:** `ConcurrentHashMap` (JDK 8+) is `HashMap`'s structure with **lock-free volatile reads**, **CAS on empty bins**, and **`synchronized` on the head node of contended bins**; resize is cooperative across threads; `size()` is approximate via a striped counter; null keys/values are banned because `get == null` must unambiguously mean "absent"; and `computeIfAbsent` / `merge` are atomic per key under the bin lock.
