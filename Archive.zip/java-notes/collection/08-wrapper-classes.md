**Priority: Interview-critical** — full deep-dive below. (The Integer cache and unboxing NPE are at the top of every MNC interview's "gotcha" question bank.)

# Wrapper Classes & Autoboxing

---

## 1. Core Mechanism

A **wrapper class** is the **object form** of a primitive. Every primitive has one: `int → Integer`, `long → Long`, `double → Double`, etc. Wrappers live on the **heap**; primitives live on the **stack** or directly inside object fields.

Why they exist:
- **Generics can't hold primitives.** `List<int>` is illegal because of type erasure — generics work only on objects. You write `List<Integer>` instead.
- **Nulls.** A primitive `int` cannot be `null`. A DB column that allows nulls or a JSON field that may be missing has to be `Integer`, not `int`.
- **Static helper methods.** `Integer.parseInt`, `Long.bitCount`, `Boolean.parseBoolean` etc. need a class to live on.
- **Polymorphism.** You can't put a primitive into an `Object` parameter, but you can put a wrapper.

The 8 wrappers — pure trivia, but you need it:

| Primitive | Wrapper | Bits | Range |
|---|---|---|---|
| `byte` | `Byte` | 8 | -128 to 127 |
| `short` | `Short` | 16 | ±32K |
| `int` | `Integer` | 32 | ±2.1B |
| `long` | `Long` | 64 | ±9.2 quintillion |
| `float` | `Float` | 32 | IEEE 754 |
| `double` | `Double` | 64 | IEEE 754 |
| `boolean` | `Boolean` | 1 | true/false |
| `char` | `Character` | 16 | UTF-16 code unit |

All wrappers are **`final`** (cannot be extended) and **immutable** (no setter, value is `final` inside).

> **Interview definition (say this out loud):** "Wrapper classes are the immutable object versions of Java's eight primitives. They exist because generics can't hold primitives due to type erasure, because nulls need an object reference, and because static methods need a class to live on. Boxing wraps a primitive into a wrapper and allocates on the heap; unboxing extracts the primitive. Two traps to remember: `Integer` values from −128 to 127 are cached and share identity, so `==` works by accident in that range and breaks outside it; and unboxing a `null` wrapper throws `NullPointerException`."

---

## 2. Under the Hood

### 2.1 Autoboxing and unboxing — what the compiler actually does

These two lines look magical:
```java
Integer x = 42;          // autoboxing
int y = x;               // unboxing
```

The compiler quietly rewrites them to:
```java
Integer x = Integer.valueOf(42);
int y = x.intValue();
```

So **autoboxing = call `valueOf(primitive)`**. **Unboxing = call `xxxValue()`**.

Three consequences:
- Every autoboxing **may allocate an `Integer` object on the heap** (unless the cache hits — see 2.2).
- Every unboxing **may throw `NullPointerException`** if the wrapper is `null`.
- The compiler injects these everywhere — including arithmetic, comparison, and method calls. A loop like `Integer sum = 0; for (int i = 0; i < n; i++) sum += i;` allocates `n` `Integer` objects.

---

### 2.2 The Integer cache (the #1 most-asked trick question)

`Integer.valueOf(int)` does this:

```java
public static Integer valueOf(int i) {
    if (i >= IntegerCache.low && i <= IntegerCache.high)
        return IntegerCache.cache[i + (-IntegerCache.low)];
    return new Integer(i);
}
```

- The JVM pre-creates one `Integer` object for every value from **−128 to 127** at startup.
- `valueOf` for any number in that range returns the **same cached instance**.
- For any number outside, it allocates a **new** `Integer` every time.

So:
```java
Integer a = 127, b = 127;
System.out.println(a == b);     // true  — same cached instance
Integer c = 128, d = 128;
System.out.println(c == d);     // false — two different heap objects
System.out.println(c.equals(d)); // true — equals compares values
```

**Why −128 to 127?** That's the `byte` range — covers the most common loop counters, status codes, ages, retry counts. Tuning was added in Java 7: `-XX:AutoBoxCacheMax=N` can raise the upper limit (lower stays at −128).

---

### 2.3 Caches for the other wrappers

| Wrapper | Cached range | Tunable? |
|---|---|---|
| `Byte` | All 256 values | n/a — full range |
| `Short` | −128 to 127 | No |
| `Integer` | −128 to 127 | Yes (`-XX:AutoBoxCacheMax`) |
| `Long` | −128 to 127 | **No** — surprising |
| `Character` | 0 to 127 | No |
| `Boolean` | `TRUE`, `FALSE` (two static fields) | n/a |
| `Float`, `Double` | **Not cached** — every box allocates | n/a |

So `Long.valueOf(200) == Long.valueOf(200)` is `false`, and `Double.valueOf(1.0) == Double.valueOf(1.0)` is also `false`. Always use `.equals()` or `compare`.

---

### 2.4 `==` vs `.equals()` on wrappers

| What you write | What it does |
|---|---|
| `int a == int b` | Primitive value comparison — fast, always correct |
| `Integer a == Integer b` | **Reference comparison** — true only if same heap object |
| `Integer a == int b` | One side unboxes — value comparison, but **NPE if `a` is null** |
| `a.equals(b)` | Value comparison — but **NPE if `a` is null** |
| `Objects.equals(a, b)` | Null-safe value comparison — **always use this for nullable wrappers** |
| `Integer.compare(a, b)` | Returns `-1`/`0`/`+1` — null-unsafe but allocation-free |

The rule: **never use `==` on wrappers**. Either unbox to a primitive first, or use `Objects.equals`.

---

### 2.5 Unboxing `null` → `NullPointerException`

This is the most common production NPE caused by wrappers:

```java
Integer flag = map.get("retries");   // map.get returns null if absent
if (flag > 0) { ... }                // unboxes flag → NPE if null
```

The compiler inserts `flag.intValue()` for the `> 0` check. Null `flag` → NPE.

**Defense:** either use the primitive when null is impossible, or guard:
```java
if (flag != null && flag > 0) { ... }
// or
int safe = Optional.ofNullable(flag).orElse(0);
```

Same trap with arithmetic: `Integer x = null; int y = x + 1; // NPE`.

---

### 2.6 Memory and performance cost

A primitive `int` is 4 bytes, inline. An `Integer` on a 64-bit JVM with compressed oops:
- Object header: 12 bytes
- `int value` field: 4 bytes
- Padding to 8-byte alignment: 0 bytes
- **Total: 16 bytes** — 4× the size of the primitive
- Plus the **reference** to it (4 or 8 bytes), so the carrying field uses another slot.

For `Long` / `Double` the gap is smaller (header dwarfs the payload less), but boxing is always more expensive — heap allocation, GC pressure, cache misses (pointer chase).

**Hot loops:** never use wrappers as accumulators.
```java
Long sum = 0L;                    // BAD — boxes every iteration
for (int i = 0; i < 1_000_000; i++) sum += i;

long sum = 0L;                    // GOOD — primitive, zero allocation
for (int i = 0; i < 1_000_000; i++) sum += i;
```

The bad version allocates ~1 million `Long` objects. Easy 100× slowdown.

---

### 2.7 Why generics force you into wrappers

Generics use **type erasure**: at runtime `List<Integer>` is just `List`. The element type collapses to `Object`. Primitives are **not** subtypes of `Object`, so they can't be elements. That's why:

- `List<int>` is illegal — `int` doesn't extend `Object`.
- `Map<String, int>` is illegal.
- You must say `List<Integer>`, paying the boxing cost.

**Workaround for performance:** primitive-specialized collections from third-party libraries (Eclipse Collections, fastutil, HPPC) — they use raw arrays inside instead of `Object[]`. For high-throughput numeric work, this matters.

**Streams have built-in escape hatches:** `IntStream`, `LongStream`, `DoubleStream` — operate on primitives directly, no boxing.

---

### 2.8 `parseInt` vs `valueOf` (commonly confused)

- **`Integer.parseInt("42")`** → returns a primitive `int`. No boxing.
- **`Integer.valueOf("42")`** → returns an `Integer`. Boxes (and uses the cache).
- **`Integer.parseInt(null)`** → `NumberFormatException`. Not NPE.
- **`Integer.parseInt("")`** → `NumberFormatException`.
- **`Integer.parseInt("3.14")`** → `NumberFormatException` (no decimals).
- **`Integer.parseInt(" 42")`** → `NumberFormatException` (no whitespace trim).

So always parse into a primitive when you can, and trim/validate input first.

---

### 2.9 Immutability and identity

All wrappers are **immutable**. There is no `setValue`. So once you box `42`, that `Integer` object will always be 42. This makes them safe as `HashMap` keys, safe to share across threads, safe in `final` fields.

But because they're objects, **identity is independent of value**. Two different `Integer(42)` allocations are different objects, even though both have value 42 — exactly what the cache works around for small values.

---

### 2.10 One-line summary table

| Topic | Answer |
|---|---|
| Why wrappers exist | Generics can't hold primitives; nulls; static helpers |
| Boxing | `Integer.valueOf(primitive)` — may use cache |
| Unboxing | `wrapper.intValue()` — NPE if null |
| Integer cache | −128 to 127, tunable upward |
| `Long` cache | −128 to 127, **not** tunable |
| `Float` / `Double` cache | **None** |
| `==` on wrappers | Reference comparison — never use |
| `.equals()` on wrappers | Value comparison — NPE-unsafe if left is null |
| `Objects.equals(a, b)` | Null-safe value comparison — always prefer |
| Memory cost (Integer) | ~16 bytes + reference vs 4 bytes for `int` |
| Hot loops | Never use wrappers as accumulators |
| Streams | `IntStream` / `LongStream` / `DoubleStream` avoid boxing |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| Default number type | `number` (IEEE 754 double) | `int`, `long`, `double` — multiple precisions |
| Nullable number | `number \| null \| undefined` | `Integer` (nullable); `int` (not) |
| Auto-coerce primitive ↔ object | Engine does it silently, value-wise | Compiler injects `valueOf` / `xxxValue` |
| Identity vs value | `===` is value (for numbers) | `==` on wrappers is reference, not value |
| Cache of small numbers | Engine-internal (V8 SMI) | JDK-spec: Integer cache −128..127 |
| Big integers | `BigInt` | `BigInteger`, `BigDecimal` |

### Where the comparison breaks down

- **Node has one number type; Java has six.** A Node dev typing `let x = 1` doesn't think about boxing. In Java, `int x = 1` (primitive) is cheap; `Integer x = 1` (wrapper) is heap-allocated. The choice matters for hot paths.
- **`==` betrays you in Java.** In JS, `1 === 1` is always `true`. In Java, `Integer a = 200; Integer b = 200; a == b` is `false`. The wrapper cache makes it `true` for −128..127, which is *worse* than always-false — code "works" in tests and fails in production for the value 128.
- **Null unboxing is silent until it fires.** In JS, `null + 1` is `1` (coercion to 0). In Java, `Integer x = null; int y = x + 1;` throws NPE. Reading a nullable column from JDBC into an `int` will crash; into an `Integer` it won't.
- **No `BigInt` literal.** JS has `42n`. Java needs `new BigInteger("42")` and uses verbose methods (`add`, `multiply`) because there's no operator overloading.
- **Floating-point money.** Same bug in both worlds — `0.1 + 0.2 != 0.3`. JS devs use libraries like `decimal.js`. Java has `BigDecimal` built in. For money, **always** use `BigDecimal`, never `double`.

---

## 4. Production-Grade Code

```java
package com.shop.pricing;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.IntStream;

public final class WrapperPatterns {

    public record LineItem(String sku, int quantity, BigDecimal unitPrice) {}
    public record Discount(String code, Integer percentOff) {}    // nullable percent

    /** Use primitive accumulators for hot loops — never Long or Double. */
    public static long sumQuantities(List<LineItem> items) {
        long total = 0L;                       // primitive — no boxing
        for (LineItem item : items) total += item.quantity();
        return total;
    }

    /** Same idea via IntStream — avoids the implicit boxing of stream().mapToInt(...). */
    public static int totalItems(List<LineItem> items) {
        return items.stream()
                .mapToInt(LineItem::quantity)  // IntStream — primitive specialization
                .sum();
    }

    /** Null-safe wrapper comparison — Objects.equals avoids NPE on either side. */
    public static boolean sameDiscount(Discount a, Discount b) {
        return Objects.equals(a.percentOff(), b.percentOff());
    }

    /** Defensive unboxing — supply a default for nullable wrappers. */
    public static int effectivePercent(Discount d) {
        // Optional.ofNullable + orElse is the cleanest null-safe unbox.
        return Optional.ofNullable(d.percentOff()).orElse(0);
    }

    /** Parsing user input safely — parseInt throws NumberFormatException on garbage. */
    public static int parseRetries(String raw, int fallback) {
        if (raw == null || raw.isBlank()) return fallback;
        try {
            return Integer.parseInt(raw.trim());     // primitive return, no boxing
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    /** Money never uses double — BigDecimal with explicit scale and rounding mode. */
    public static BigDecimal applyDiscount(BigDecimal total, Integer percentOff) {
        int pct = Optional.ofNullable(percentOff).orElse(0);
        BigDecimal factor = BigDecimal.valueOf(100 - pct)
                .divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP);
        return total.multiply(factor).setScale(2, RoundingMode.HALF_UP);
    }

    /** Demonstrates the Integer-cache trap as a runnable assertion. */
    public static void cacheGotcha() {
        Integer a = 127, b = 127;
        Integer c = 128, d = 128;
        assert a == b : "cached, identity holds";
        assert c != d : "outside cache, distinct objects";
        assert c.equals(d) : "equals compares value";
    }

    /** Frequency counter on enums — boxing-free via int[] indexed by ordinal. */
    public enum Status { PAID, PENDING, FAILED }
    public static int[] countByStatus(List<Status> events) {
        int[] counts = new int[Status.values().length];      // primitive array
        for (Status s : events) counts[s.ordinal()]++;        // no Integer involved
        return counts;
    }
}
```

What this snippet shows:
- **Primitive accumulators** (`long total = 0L`) — no boxing in hot loops.
- **`IntStream` / `mapToInt`** — primitive-specialized stream to avoid `Stream<Integer>` boxing.
- **`Objects.equals`** — null-safe wrapper comparison.
- **`Optional.ofNullable(x).orElse(default)`** — the cleanest defensive unbox.
- **`Integer.parseInt`** for primitive parsing, wrapped in try/catch on user input.
- **`BigDecimal` for money** — never `double`, ever.
- A runnable demo of the Integer-cache gotcha, so it's locked in.
- Primitive `int[]` indexed by `ordinal()` for high-throughput counters — beats `Map<Status, Integer>` by an order of magnitude.

---

## 5. Top 3 MNC Interview Questions

**Q1: What's the output of this code?**
```java
Integer a = 127, b = 127;
Integer c = 128, d = 128;
System.out.println(a == b);   // ?
System.out.println(c == d);   // ?
```
- *What they're testing:* whether you know the Integer cache and the difference between `==` and `.equals` on wrappers.
- *Ideal answer:* "The first prints `true`, the second prints `false`. The compiler autoboxes both pairs via `Integer.valueOf`. For values from −128 to 127 the JDK caches a single `Integer` instance per value at startup and `valueOf` returns the cached reference, so `a` and `b` point to the same object and `==` returns `true`. For 128 we're outside the cache, so each `valueOf(128)` allocates a fresh `Integer`, and `==` compares references — `false`. The cache exists because most loop counters and status codes live in that range, so it avoids a huge amount of allocation. The rule in production is: never use `==` on wrappers; use `.equals` or `Objects.equals`."

**Q2: When does unboxing throw `NullPointerException`, and how do you prevent it?**
- *What they're testing:* whether you know the silent NPE hot spots and the defensive patterns.
- *Ideal answer:* "Unboxing happens whenever the compiler needs a primitive but you've given it a wrapper — assignment to an `int`, arithmetic with a wrapper, comparison with a primitive, or returning a primitive from a method that holds a wrapper. The compiler inserts `wrapper.intValue()`, which throws NPE if the wrapper is null. The classic case is reading a nullable column from JDBC, or `map.get(key)` returning null, then doing `if (count > 0)`. Fixes: declare the field as a primitive if it can never be null; otherwise null-check before unboxing, use `Optional.ofNullable(x).orElse(0)`, or use `Objects.equals` for comparisons. Never assume a wrapper returned from another method is non-null without checking."

**Q3: Why does Java need wrapper classes? Why can't generics hold primitives?**
- *What they're testing:* whether you understand type erasure and the cost-benefit of wrappers.
- *Ideal answer:* "Generics in Java use **type erasure** — at runtime `List<Integer>` is just `List` and the element type collapses to `Object`. Primitives are not subtypes of `Object`, so they can't be stored in a generic container. Wrappers solve that: `Integer` is an `Object` subclass, so `List<Integer>` works. They also let you represent `null` — useful for optional fields and database columns — and they hold static helper methods like `Integer.parseInt`. The cost is real — every box allocates ~16 bytes on the heap, plus GC pressure — so for hot numeric work I use primitive arrays or `IntStream` / `LongStream` directly. The Eclipse Collections or fastutil libraries give you `IntList` etc. when collection semantics matter and you can't afford boxing."

---

## 6. Memorize this

> **Memorize this:** Wrappers are heap-allocated, immutable object versions of primitives; autoboxing calls `valueOf` (cached −128..127 for `Integer`/`Long`/`Short`, full range for `Byte`, none for `Float`/`Double`); never use `==` on wrappers, never use them in hot loops, and unboxing a `null` always throws NPE.
