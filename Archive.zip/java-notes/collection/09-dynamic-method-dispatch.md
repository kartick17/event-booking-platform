**Priority: Interview-critical** — full deep-dive below. (Classic OOP foundation; the JVM internals here separate junior answers from senior ones.)

# Dynamic Method Dispatch

---

## 1. Core Mechanism

**Dynamic method dispatch** (also called **runtime polymorphism** or **late binding**) is how Java picks which method body to actually run when you call a method on an object — based on the **actual object type at runtime**, not the reference type written in the source.

```java
Animal a = new Dog();
a.sound();     // prints "Bark" — Dog.sound runs, not Animal.sound
```

The compiler only checks that `Animal` *has* a `sound()` method. The JVM, at the moment of the call, looks at the real object (`Dog`) and dispatches to `Dog.sound()`.

Why it exists:
- Lets you write code against an interface or parent class and let the actual object decide behavior — the foundation of polymorphism, strategy pattern, dependency injection, and almost every clean architecture.
- Without it, every framework that takes "any `Repository`" or "any `MessageHandler`" would need a giant switch on concrete types.

> **Interview definition (say this out loud):** "Dynamic method dispatch is Java's runtime polymorphism — when I call `ref.method()`, the JVM looks up the method on the **actual object's class**, not the reference's declared type. It works through the `invokevirtual` bytecode and a per-class method table (vtable) that maps each overrideable method to its concrete implementation. `static`, `private`, and `final` methods are not dispatched dynamically because they cannot be overridden, so the compiler resolves them at compile time via `invokestatic` or `invokespecial`."

---

## 2. Under the Hood

### 2.1 The 5 invoke bytecodes (memorize these)

Every method call in Java compiles to one of these JVM instructions. Which one decides whether dispatch is static or dynamic.

| Bytecode | Used for | Dispatch | Receiver |
|---|---|---|---|
| `invokestatic` | `static` methods | Compile-time | None |
| `invokespecial` | `<init>` (constructor), `private` methods, `super.method()` | Compile-time | Stack |
| `invokevirtual` | Normal instance methods on a class | **Runtime via vtable** | Stack |
| `invokeinterface` | Methods called through an interface reference | **Runtime via itable** | Stack |
| `invokedynamic` | Lambdas, method handles, string concat (since Java 7) | Runtime via bootstrap method | Stack |

The key split:
- `invokestatic` and `invokespecial` → the method target is **fixed at compile time**. No polymorphism.
- `invokevirtual` and `invokeinterface` → the method target is **decided at runtime**. This is dynamic dispatch.

---

### 2.2 The vtable (virtual method table)

When the JVM loads a class, it builds a **vtable** in Metaspace (the JVM memory region for class metadata, replaced PermGen in Java 8). Conceptually:

```
class Animal { void sound() {...}; void sleep() {...}; }
class Dog extends Animal { @Override void sound() {...}; void fetch() {...}; }

Animal vtable:
  [0] -> Animal.sound
  [1] -> Animal.sleep

Dog vtable:
  [0] -> Dog.sound        ← override placed at SAME slot as parent's sound
  [1] -> Animal.sleep     ← inherited, same slot
  [2] -> Dog.fetch        ← new method, new slot
```

The clever bit: **the slot index for `sound()` is the same in both vtables** (index 0). So at compile time, the compiler emits `invokevirtual` with the **method-name-and-signature reference**, and the JVM resolves that to "slot 0" once. Every call after that is:

```
1. Take the object reference off the operand stack.
2. Follow its class pointer to the class's vtable.
3. Index into slot 0.
4. Jump to that method.
```

Two pointer dereferences + an indexed load. That's it.

---

### 2.3 What the object header carries

Every Java object on the heap has a **header** (12 or 16 bytes depending on compressed oops). One of those header fields is the **klass pointer** — a pointer to the class metadata, which holds the vtable.

So `obj.sound()` becomes, roughly:
- `klass = *(obj + 8)` → klass pointer from header
- `method = klass->vtable[0]` → entry for `sound`
- `call method` → with `obj` as the implicit `this`

This is **single dispatch on the receiver's class**. Java does not have multimethods — it dispatches only on the type of the object you call on, never on argument types.

---

### 2.4 What is NOT dynamically dispatched

| Method kind | Dispatch | Bytecode | Why |
|---|---|---|---|
| `static` | Compile-time | `invokestatic` | Belongs to the class, not an instance — no receiver to dispatch on |
| `private` | Compile-time | `invokespecial` | Not visible to subclasses, so cannot be overridden |
| `final` | Effectively compile-time (still `invokevirtual` but JIT can devirtualize) | `invokevirtual` | Cannot be overridden, so the target is known |
| Constructor `<init>` | Compile-time | `invokespecial` | A constructor belongs to one specific class |
| `super.method()` | Compile-time | `invokespecial` | Explicitly asks for the parent's version |

**Classic trap:**
```java
class Parent { static void hello() { print("parent"); } }
class Child extends Parent { static void hello() { print("child"); } }

Parent p = new Child();
p.hello();           // prints "parent" — static methods are bound to declared type
```
This isn't overriding — it's **method hiding**. `static` methods do not participate in dynamic dispatch.

---

### 2.5 `invokeinterface` and the itable

Interface dispatch is trickier than class dispatch. A class can implement many interfaces, each with its own vtable layout, so a single fixed slot index doesn't work.

The JVM uses an **itable** (interface method table): essentially a list of `(interface, vtable)` pairs per class. To call an interface method:

1. Find the right interface's vtable in the itable (linear scan or hash, depending on JVM).
2. Then index into the vtable like a normal virtual call.

So `invokeinterface` is slightly slower than `invokevirtual` in theory. In practice, the JIT compiler **inlines and devirtualizes** most calls and the difference vanishes for hot code.

---

### 2.6 JIT devirtualization and inlining (the senior answer)

The JIT (just-in-time compiler — converts bytecode to native machine code) is aggressive about removing virtual dispatch when it can prove the target:

- **Monomorphic call site**: if only one concrete class has ever been seen at a call site, the JIT replaces the vtable lookup with a direct call to that method — and often **inlines** the method body. A guard check is inserted to deoptimize if a new class shows up later.
- **Bimorphic call site**: same trick with two possible types and an if-else.
- **Megamorphic call site** (3+ types): falls back to a real vtable lookup.

So in practice, a well-warmed JVM running well-typed code pays almost zero overhead for dynamic dispatch. This is why "virtual is slow" is a junior-grade myth.

The flip side: code with many polymorphic types at the same call site (huge `instanceof` chains, deep interface hierarchies) **does** hurt JIT optimization. Keep call sites focused.

---

### 2.7 Constructors and `super()`

Constructors are dispatched with `invokespecial` because they belong to a specific class. **A constructor never participates in dynamic dispatch.**

But here's a classic trap: **calling an overrideable method from a constructor.**

```java
class Parent {
    Parent() { init(); }                     // calls overrideable method
    void init() { print("Parent.init"); }
}
class Child extends Parent {
    int x = 42;
    @Override void init() { print("Child.init x=" + x); }   // x is 0 here!
}
new Child();   // prints "Child.init x=0"
```

The `init()` call inside `Parent`'s constructor **does** dispatch dynamically to `Child.init()`. But `Child`'s field initializers haven't run yet, so `x` is still 0. Rule: never call overrideable methods from constructors.

---

### 2.8 One-line summary

| Question | Answer |
|---|---|
| What gets dispatched dynamically? | Instance methods that are not `static`, not `private`, not `final` |
| What bytecode is used? | `invokevirtual` for classes, `invokeinterface` for interfaces |
| Where does the dispatch table live? | In class metadata in Metaspace |
| What does the JVM look at? | Klass pointer in the object header → vtable → slot |
| Is virtual dispatch slow? | No — JIT devirtualizes monomorphic and bimorphic call sites |
| Does dispatch consider argument types? | No — Java is single dispatch on the receiver only |

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| How method lookup works | Prototype chain walk | Vtable indexed lookup |
| Late binding | Always (every property is dynamic) | Only for instance methods |
| Override | Just assign a property on the child prototype | `@Override` checked at compile time |
| Compile-time type check | None in JS; structural in TS | Nominal — explicit class/interface |
| Dispatch on argument types | No (single dispatch) | No (single dispatch) |
| Inlining / devirtualization | V8 hidden classes + inline caches | JIT monomorphic/bimorphic guards |

### Where the comparison breaks down

- **JS dispatches everything dynamically, even static-looking calls.** `MyClass.foo` is just a property lookup at runtime. Java's `static` methods are resolved at compile time — different class. There's no JS analog to the `static`/`final`/`private` non-dispatch rules.
- **No vtables in JS.** V8 builds **hidden classes** (inline caches) to optimize property lookups, but the language has no formal "method table" concept. Java's vtable is a JVM-spec-level structure with predictable layout.
- **Java's `@Override` is checked at compile time.** Misspell the method name in JS and you've silently added a new property. In Java, `@Override` on a method that doesn't override anything is a compile error.
- **NestJS DI mirrors the Java polymorphism pattern.** When NestJS injects a `Logger` and the actual instance is `ConsoleLogger`, calling `logger.log()` runs `ConsoleLogger.log` — same idea. The difference is *how*: NestJS uses constructor injection + JS prototype chain; Spring uses constructor injection + JVM vtable.
- **TypeScript interfaces are structural, Java's are nominal.** In TS, "anything with a `log(msg)` method" can satisfy `Logger`. In Java, the class must literally `implements Logger`. This is what makes Java's interface dispatch deterministic enough to compile to `invokeinterface`.

---

## 4. Production-Grade Code

```java
package com.shop.payments;

import java.math.BigDecimal;
import java.util.*;

public final class PaymentDispatch {

    /** Sealed permits ensures the compiler (and JIT) can see all concrete types. */
    public sealed interface PaymentProcessor
            permits CardProcessor, UpiProcessor, NetBankingProcessor {

        Receipt charge(BigDecimal amount, String accountRef);

        /** Default method — also dispatched virtually. */
        default boolean supports(BigDecimal amount) {
            return amount.signum() > 0;
        }
    }

    public record Receipt(String txnId, BigDecimal amount, String channel) {}

    public static final class CardProcessor implements PaymentProcessor {
        @Override public Receipt charge(BigDecimal amount, String accountRef) {
            return new Receipt("CARD-" + UUID.randomUUID(), amount, "CARD");
        }
    }

    public static final class UpiProcessor implements PaymentProcessor {
        @Override public Receipt charge(BigDecimal amount, String accountRef) {
            return new Receipt("UPI-" + UUID.randomUUID(), amount, "UPI");
        }
        @Override public boolean supports(BigDecimal amount) {
            return amount.compareTo(new BigDecimal("100000")) <= 0;  // UPI cap
        }
    }

    public static final class NetBankingProcessor implements PaymentProcessor {
        @Override public Receipt charge(BigDecimal amount, String accountRef) {
            return new Receipt("NB-" + UUID.randomUUID(), amount, "NB");
        }
    }

    /**
     * Strategy injected at runtime. The compiler only sees PaymentProcessor.
     * The JVM uses invokeinterface → itable → vtable to dispatch charge().
     * A warm JIT will devirtualize this if the call site is monomorphic.
     */
    public Receipt process(PaymentProcessor processor, BigDecimal amount, String ref) {
        if (!processor.supports(amount)) {
            throw new IllegalArgumentException("processor rejected amount");
        }
        return processor.charge(amount, ref);          // dynamic dispatch lives here
    }

    /** Trap demo: never call an overrideable method from a constructor. */
    static class Base {
        Base() { describe(); }                          // dispatches to subclass — too early
        void describe() { System.out.println("Base"); }
    }
    static class Derived extends Base {
        private final String label;
        Derived(String label) { this.label = label; }   // 'label' is still null when Base() runs
        @Override void describe() { System.out.println("Derived: " + label); }
    }
    // new Derived("hi") prints "Derived: null", NOT "Derived: hi"

    /** Method hiding (static), NOT overriding — for revision. */
    static class Util {
        static String version() { return "v1"; }
    }
    static class V2Util extends Util {
        static String version() { return "v2"; }       // HIDES, not overrides
    }
    public static void hidingDemo() {
        Util u = new V2Util();
        System.out.println(u.version());               // prints "v1" — static binding
    }
}
```

What this snippet shows:
- **`sealed interface` + `permits`** — restricts the set of subtypes. The JIT (and humans) know all possible dispatch targets, so optimization is easier and `switch` over the sealed type is exhaustive.
- **Default interface methods are virtually dispatched too** — `UpiProcessor.supports` overrides the default exactly like any other method.
- The **constructor trap** with `Derived("hi")` printing `Derived: null`. Walk through it once and you'll never write it again.
- The **method-hiding** demo — `static` methods bind to the **declared** type. Forgetting this is a typical interview trap.

---

## 5. Top 3 MNC Interview Questions

**Q1: What is dynamic method dispatch and how does it work at the JVM level?**
- *What they're testing:* whether you can describe the vtable mechanism, not just say "polymorphism".
- *Ideal answer:* "Dynamic method dispatch means when I call `ref.method()`, the JVM uses the actual object's class — not the reference's declared type — to pick the method body. The compiler emits `invokevirtual` for instance methods and `invokeinterface` for interface calls. When a class is loaded, the JVM builds a vtable in Metaspace — a table indexed by method slot. Each object's header has a klass pointer to its class metadata. So the dispatch is: read klass pointer from the object header, index into the vtable at the slot the compiler computed for that method, jump to the address there. Overrides occupy the same slot as the parent's method, so the lookup is always one indexed load. The JIT often eliminates this entirely by devirtualizing monomorphic call sites and inlining the target."

**Q2: Why aren't `static`, `private`, and `final` methods dynamically dispatched?**
- *What they're testing:* whether you understand the connection between overrideability and dispatch.
- *Ideal answer:* "Because they can't be overridden, so there's nothing to decide at runtime. `static` belongs to the class, not an instance — there's no receiver to dispatch on, and the bytecode is `invokestatic`. `private` is not visible to subclasses, so the compiler uses `invokespecial` with a fixed target. `final` can technically use `invokevirtual`, but the JIT trivially devirtualizes it because no subclass can replace it. The trap is that this means `static` methods follow **method hiding** rules, not overriding: `Parent p = new Child(); p.staticMethod()` always runs the **parent's** version because dispatch is resolved by the declared reference type at compile time."

**Q3: Is virtual method call slow in Java, and what does the JIT do about it?**
- *What they're testing:* whether you understand JIT optimization beyond "Java is fast now".
- *Ideal answer:* "It's not slow once the JIT has warmed up. Each call site is profiled; if only one concrete type has ever been seen, it's monomorphic — the JIT replaces the vtable lookup with a direct call and usually inlines the method body. A guard is inserted that deoptimizes if a new type ever shows up. Bimorphic sites get the same treatment with an if-else. Only megamorphic call sites — three or more concrete types — fall back to the real indexed vtable load, which is still just two dereferences and a jump. So in practice, well-typed code with focused call sites pays close to zero dispatch cost. The cost is real when you build code with huge interface hierarchies and many implementations at the same call site, because the JIT can't inline."

---

## 6. Memorize this

> **Memorize this:** Dynamic method dispatch = `invokevirtual` / `invokeinterface` resolved at runtime via the object's klass pointer → vtable → method slot; `static`, `private`, `final`, constructors, and `super.method()` are bound at compile time via `invokestatic` / `invokespecial`; the JIT devirtualizes monomorphic call sites away, so virtual dispatch is near-free in hot code.
