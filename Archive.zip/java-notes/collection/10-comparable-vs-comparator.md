# `Comparable` vs `Comparator` — Internals & Difference

**Priority: Interview-critical**

## 1. Core Mechanism

- Java has two ways to define **"which object comes first"** when you sort.
- **`Comparable<T>`** → the class itself says how to compare its own instances. One **natural order** baked into the class. Method: `int compareTo(T other)`.
- **`Comparator<T>`** → an **external** object that knows how to compare two things. You can have many comparators for the same class (by price, by name, by date). Method: `int compare(T a, T b)`.
- **Why both exist:**
  - `Comparable` answers: *"what is the default sort order of this type?"* (e.g. `Integer` sorts numerically, `String` sorts lexicographically).
  - `Comparator` answers: *"I want a different order, without touching the class."* (e.g. sort `Employee` by salary today, by name tomorrow).
  - Also lets you sort classes you **don't own** (third-party, JDK types) — you cannot add `Comparable` to them, but you can write a `Comparator` for them.
- **Return value contract** (same for both):
  - negative → `a` comes before `b`
  - zero → equal in ordering
  - positive → `a` comes after `b`

> **Interview definition (say this out loud):**
> `Comparable` is the class's own natural ordering using `compareTo`, so it ties the sort logic to the type itself. `Comparator` is an external strategy using `compare`, so you can plug in many orderings for the same type — including for classes you don't own.

---

## 2. Under the Hood

### 2.1 The contracts (the rules nobody reads but interviewers love)

Both methods must obey three rules, or `TreeMap` / `TreeSet` / `Arrays.sort` will silently misbehave:

| Rule | Meaning |
|---|---|
| **Reflexive** | `compare(a, a) == 0` |
| **Antisymmetric** | `sign(compare(a, b)) == -sign(compare(b, a))` |
| **Transitive** | if `a > b` and `b > c`, then `a > c` |
| **Consistent with equals (strongly recommended)** | `compareTo(b) == 0` ⇔ `a.equals(b)` |

The last one is the **trap**. If `compareTo` returns 0 but `equals` returns `false`, your object will **disappear** inside a `TreeSet` (the tree thinks it's a duplicate). This is the classic `BigDecimal` bug: `new BigDecimal("1.0").equals(new BigDecimal("1.00"))` is `false`, but `compareTo` is `0`.

### 2.2 Where they sit in the JDK

- `Comparable<T>` lives in `java.lang` (same package as `String`, `Integer`) — that's how built-in types like `Integer`, `String`, `LocalDate` get their natural order for free.
- `Comparator<T>` lives in `java.util` — it's a `@FunctionalInterface`, so you can write it as a lambda or method reference.
- All JDK sorted structures (`TreeMap`, `TreeSet`, `PriorityQueue`, `Collections.sort`, `Arrays.sort`, `Stream.sorted`) use **one of these two** under the hood. They first check if you passed a `Comparator`. If not, they cast the element to `Comparable` and call `compareTo`. If the element is not `Comparable`, you get a `ClassCastException` at runtime.

### 2.3 The sort algorithm under the hood (this is what senior interviewers probe)

| Method | Algorithm | Stable? | Complexity |
|---|---|---|---|
| `Arrays.sort(int[])` (primitives) | **Dual-Pivot Quicksort** | No | O(n log n) avg, O(n²) worst |
| `Arrays.sort(Object[])` | **TimSort** (since Java 7) | **Yes** | O(n log n) worst |
| `Collections.sort(List)` | Delegates to `List.sort` → **TimSort** | **Yes** | O(n log n) worst |
| `Stream.sorted()` | TimSort on a buffered array | **Yes** | O(n log n) |

**TimSort** = merge sort + insertion sort hybrid. It detects already-sorted runs and merges them. Real production data is often partially sorted, so TimSort wins. Because TimSort is **stable**, equal elements (per your `compare`) keep their original order — this is why you can chain comparators (sort by department, then by salary) and the earlier ordering is preserved.

**Memory cost:** TimSort needs up to **n/2 extra array slots** for the merge buffer, allocated on the heap. Quicksort on primitives is in-place. So sorting 10M `Integer` objects vs 10M `int` has a very different memory profile — boxing + TimSort buffer = real GC pressure.

### 2.4 The `Comparator` combinator chain (Java 8+)

`Comparator` got superpowers in Java 8. These are **static + default** methods on the interface:

```java
Comparator<Employee> byDeptThenSalaryDesc =
    Comparator.comparing(Employee::department)
              .thenComparing(Employee::salary, Comparator.reverseOrder())
              .thenComparing(Employee::name, Comparator.nullsLast(Comparator.naturalOrder()));
```

Each call **wraps** the previous comparator in a new one. `thenComparing` only runs if the previous comparator returned 0. This is just function composition — like Lodash's `_.orderBy`, but type-safe.

**Cost to know:** `Comparator.comparing(Employee::salary)` allocates a new lambda (a `Function`) on first use. The JVM caches it via `invokedynamic` / `LambdaMetafactory`, so subsequent calls reuse the same instance. But each `thenComparing` allocates a new wrapper `Comparator` object. In a hot path, build the comparator **once**, store it in a `static final` field, and reuse.

### 2.5 Why `Comparator` is a `@FunctionalInterface` but `Comparable` is not

- `Comparator.compare(a, b)` takes two args — pure function, easy to write as a lambda: `(a, b) -> a.x - b.x`.
- `Comparable.compareTo(other)` takes one arg — but `this` is implicit. A lambda has no `this` of the target type, so it cannot implement `Comparable`. That's why you'll never see `Comparable` written as a lambda.

### 2.6 The classic `a - b` trap (overflow)

```java
// BUG: overflows when a is large positive and b is large negative
Comparator<Integer> bad = (a, b) -> a - b;

// CORRECT
Comparator<Integer> good = Integer::compare;        // does Integer.compare(a,b)
Comparator<Integer> alsoGood = Comparator.naturalOrder();
```

`Integer.compare(a, b)` uses a safe subtraction that handles `MIN_VALUE` / `MAX_VALUE`. Interviewers love asking this — saying "I'd use `Integer.compare`" instead of `a - b` is a senior signal.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JavaScript | Java |
|---|---|---|
| Default sort order on a type | None — JS sorts by string conversion by default (`[10, 2, 1].sort()` → `[1, 10, 2]`) | `Comparable.compareTo` baked into the type |
| External sort function | `arr.sort((a, b) => a.price - b.price)` | `list.sort(Comparator.comparingInt(x -> x.price))` |
| Sort stability | Stable since ES2019 | Stable for object sort (TimSort); **not** for primitive sort |
| Multi-key sort | Manually: `(a,b) => a.dept.localeCompare(b.dept) \|\| a.salary - b.salary` | `Comparator.comparing(...).thenComparing(...)` — chainable, type-safe |
| Reverse | `arr.sort().reverse()` (two passes) | `comparator.reversed()` (one pass) |
| Null handling | Up to you, no helper | `Comparator.nullsFirst(...)` / `nullsLast(...)` built in |

**Where the comparison breaks down:**
- JS has **no concept of "natural order"** on user types. Java does (`Comparable`). This is why a `TreeSet<Employee>` requires either `Employee implements Comparable<Employee>` or a `Comparator` passed at construction — JS `Set` doesn't care.
- In JS, `arr.sort((a,b) => a - b)` works fine because JS numbers are 64-bit doubles. In Java, `(a, b) -> a - b` on `int` **overflows** and returns the wrong sign. This is the single most common Java sort bug.
- JS sort is always external (callback). Java has both. An interviewer who hears "I'd just pass a comparator everywhere" will probe whether you understand the natural-order use case (e.g., `TreeMap` keys, sorted collections, `compareTo`-driven equality in `BigDecimal`).

---

## 4. Production-Grade Code

```java
package com.acme.hr.sort;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public final class EmployeeSorting {

    public record Employee(
            Long id,
            String name,
            String department,
            BigDecimal salary,
            LocalDate joinedOn
    ) implements Comparable<Employee> {

        @Override
        public int compareTo(Employee other) {
            // Natural order = by id. Stable, unique, never null -> safe default
            // for TreeSet / TreeMap keys. Keep natural order consistent with equals.
            return Long.compare(this.id, other.id);
        }
    }

    // Build once, reuse. Each thenComparing allocates a wrapper -> do not rebuild per request.
    public static final Comparator<Employee> BY_DEPT_THEN_SALARY_DESC =
            Comparator.comparing(Employee::department, Comparator.nullsLast(Comparator.naturalOrder()))
                      .thenComparing(Employee::salary, Comparator.nullsLast(Comparator.reverseOrder()))
                      .thenComparingLong(Employee::id); // tiebreaker so order is fully deterministic

    public static List<Employee> rankForPayrollReport(List<Employee> employees) {
        Objects.requireNonNull(employees, "employees");
        return employees.stream()
                        .sorted(BY_DEPT_THEN_SALARY_DESC)
                        .toList();
    }

    // Example: sorting a type you do NOT own (java.time.LocalDate already has natural
    // order, but imagine a third-party DTO with no Comparable) -> use a Comparator.
    public static Comparator<Employee> byTenureLongestFirst(LocalDate today) {
        return Comparator.comparing(
                (Employee e) -> e.joinedOn() == null ? today : e.joinedOn()
        ); // earlier joinedOn = longer tenure = comes first
    }
}
```

Key things to notice for interviews:
- `Long.compare(...)` — overflow-safe, no `a - b`.
- `BY_DEPT_THEN_SALARY_DESC` is `static final` — built once. Don't rebuild comparator chains inside hot loops.
- Explicit **null handling** via `nullsLast` — `Comparator.comparing` will NPE on a null key otherwise.
- Final `thenComparingLong(Employee::id)` — **tiebreaker** for deterministic order, important for paginated APIs (otherwise page 2 may repeat rows from page 1).
- `compareTo` is **consistent with equals** for `Employee` (both keyed by `id`) — safe to use in `TreeSet`.

---

## 5. Top 3 MNC Interview Questions

### Q1. What is the difference between `Comparable` and `Comparator`, and when would you choose one over the other?
- **What they're testing:** Whether you understand "natural order vs external strategy", and that one is internal to the class while the other is plug-in.
- **Ideal answer:** `Comparable` is implemented by the class itself and defines its natural order — one ordering per type, used by default in `TreeSet`, `TreeMap`, `Collections.sort`. `Comparator` is an external object, so I can have many orderings for the same class and I can sort classes I don't own. I use `Comparable` when the type has an obvious default order — like `id` for an entity. I use `Comparator` whenever the order is a use-case choice — like sort by salary on one screen, by name on another. `Comparator` is a functional interface, so I can write it as a lambda and chain with `thenComparing`.

### Q2. You sort a `List<Integer>` with `(a, b) -> a - b` and it works for small numbers but breaks for some inputs. Why?
- **What they're testing:** Integer overflow awareness — a classic senior-vs-junior trap.
- **Ideal answer:** Subtraction overflows in `int`. If `a` is a large positive and `b` is a large negative, `a - b` wraps around and returns the wrong sign, so the sort order is broken. The fix is `Integer.compare(a, b)` or `Comparator.naturalOrder()` — both do a safe sign comparison without subtraction. I never write `a - b` in a comparator in production code.

### Q3. You put objects in a `TreeSet` and some of them silently disappear. What's going on?
- **What they're testing:** `compareTo` vs `equals` consistency, and that `TreeSet` uses `compareTo`, not `equals`.
- **Ideal answer:** `TreeSet` decides uniqueness using `compareTo`, not `equals`. If two different objects return `0` from `compareTo`, the tree treats them as duplicates and drops the second one. The classic case is `BigDecimal` — `"1.0"` and `"1.00"` have `compareTo == 0` but `equals == false`, so a `TreeSet<BigDecimal>` will lose one of them. The fix is to make `compareTo` consistent with `equals`, or pass a `Comparator` whose `compare == 0` exactly matches `equals`.

---

## 6. Memorize this

> **Memorize this:** `Comparable` = one **natural** order baked into the class (`compareTo`, internal); `Comparator` = many **external** strategies (`compare`, lambda-friendly, chainable) — and both must be consistent with `equals` or `TreeSet`/`TreeMap` will silently eat your objects.
