# What an Exception Is; Exception vs Error

> **Priority: Basic** — quick bullets only.

- An exception is an **object** (a subclass of `Throwable`) that the JVM creates and throws when something goes wrong. Normal flow stops; the JVM looks for a `catch` block that matches the type.
- **`Exception`** = application-level problem. Your code caused it or can react to it (file missing, bad input, DB down). You handle these.
- **`Error`** = JVM-level disaster (`OutOfMemoryError`, `StackOverflowError`). The runtime itself is in trouble. You do **not** catch these — you cannot recover in a sane way; you fix the root cause (memory leak, infinite recursion).
- Both extend `Throwable`, so the syntax could catch both — the difference is a **convention about recoverability**, enforced by design, not by the JVM.

*Next: [02 — the full exception hierarchy](02-exception-hierarchy.md).*
