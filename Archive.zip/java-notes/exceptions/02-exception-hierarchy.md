# The Exception Hierarchy — Throwable → Error / Exception → RuntimeException

> **Priority: Interview-critical** — full deep-dive below.

---

## 1. Core Mechanism

- Every throwable thing in Java is an object of a class under `Throwable`. It is a real class hierarchy, not error codes or strings.
- **Why it exists:** the hierarchy encodes *who is responsible*. `Error` → the JVM/environment. `RuntimeException` → a programming bug. Other `Exception`s → an expected, recoverable condition. Catch clauses match by type, so the hierarchy IS the routing system.

```
Throwable
├── Error                      → JVM-level disasters. Don't catch.
│   ├── OutOfMemoryError
│   ├── StackOverflowError
│   └── NoClassDefFoundError
└── Exception                  → application-level problems
    ├── IOException            → CHECKED
    ├── SQLException           → CHECKED
    ├── InterruptedException   → CHECKED
    └── RuntimeException       → UNCHECKED
        ├── NullPointerException
        ├── IllegalArgumentException
        ├── IllegalStateException
        ├── ClassCastException
        └── IndexOutOfBoundsException
```

> **Interview definition (say this out loud):**
> "Everything throwable extends `Throwable`, which splits into `Error` — JVM-level failures we don't handle — and `Exception`. Inside `Exception`, everything under `RuntimeException` is unchecked and models bugs; the rest is checked and models recoverable conditions."

---

## 2. Under the Hood (JVM Internals)

- The exception **object lives on the heap** like any object. During propagation it stays reachable (the JVM holds it), carrying its recorded stack trace up through the unwinding frames. That's why you can log the full trace far above the throw point.
- `catch` matching is an **`instanceof` check by hierarchy**: `catch (IOException e)` catches `FileNotFoundException` too, because it's a subclass. Order matters — a subclass `catch` after its superclass `catch` is unreachable code and won't compile.
- `Throwable` carries four key fields: the message, the `cause` (another `Throwable` — see chaining, note 11), the captured stack trace, and a list of **suppressed** exceptions (note 09).
- `Error` and `Exception` are technically identical to the JVM — the split is pure convention plus compiler treatment (`Error` is unchecked). You *can* write `catch (OutOfMemoryError e)`; it compiles; it is almost always wrong.

---

## 3. The Node.js / NestJS Bridge

| Concept | Node / JS | Java |
|---|---|---|
| What can be thrown | Anything — `throw "oops"`, `throw 42` | Only `Throwable` subclasses; `throw "oops"` won't compile |
| Hierarchy | `Error`, `TypeError`, `RangeError` — flat, rarely subclassed by apps | Deep hierarchy; apps define custom exception trees routinely |
| Catch by type | One `catch (e)`, then manual `instanceof` checks | Multiple typed `catch` blocks; JVM routes by type |

**Where the comparison breaks down:** in JS you filter errors *inside* the catch; in Java the type system routes *before* your code runs. Interviewers probe whether you know catch-order rules and that subclasses are caught by superclass handlers.

---

## 4. Production-Grade Code

```java
public class PaymentGatewayClient {

    public Receipt charge(PaymentRequest request) {
        try {
            return callGateway(request);
        } catch (GatewayTimeoutException e) {      // most specific first — or it won't compile
            throw new RetryablePaymentException("Gateway timed out", e);
        } catch (GatewayException e) {             // superclass catch: everything else from the gateway
            throw new PaymentFailedException("Gateway rejected payment", e);
        }
    }

    private Receipt callGateway(PaymentRequest request) throws GatewayException {
        throw new GatewayTimeoutException("no response in 5s");
    }

    // A small domain hierarchy — the app-level mirror of Java's own design
    static class GatewayException extends Exception {
        GatewayException(String msg) { super(msg); }
    }
    static class GatewayTimeoutException extends GatewayException {
        GatewayTimeoutException(String msg) { super(msg); }
    }
    static class RetryablePaymentException extends RuntimeException {
        RetryablePaymentException(String msg, Throwable cause) { super(msg, cause); }
    }
    static class PaymentFailedException extends RuntimeException {
        PaymentFailedException(String msg, Throwable cause) { super(msg, cause); }
    }
    record PaymentRequest(String orderId, long amountCents) {}
    record Receipt(String transactionId) {}
}
```

---

## 5. Top 3 MNC Interview Questions

**Q1: Draw/describe the exception hierarchy.**
- **What they're testing:** whether you know where `RuntimeException` sits (under `Exception`, not beside it).
- **Ideal answer:** "`Throwable` at the root, splitting into `Error` and `Exception`. `RuntimeException` extends `Exception` — so unchecked exceptions are still `Exception`s, just exempt from compiler checks. `Error` covers JVM failures like `OutOfMemoryError`. Catch matching walks this hierarchy, so a `catch (Exception e)` also catches every `RuntimeException`."

**Q2: Can you catch an `Error`? Should you?**
- **What they're testing:** knowing the difference between "compiles" and "correct".
- **Ideal answer:** "Yes, it compiles — `Error` is a `Throwable` like any other and the JVM treats it identically. But no, you shouldn't: an `OutOfMemoryError` means the heap is exhausted; any recovery code may itself fail to allocate. The only defensible pattern is a top-level catch that logs and dies cleanly."

**Q3: Why does the compiler reject a `catch (FileNotFoundException)` placed after `catch (IOException)`?**
- **What they're testing:** catch-order and hierarchy-based matching.
- **Ideal answer:** "`FileNotFoundException` extends `IOException`, so the first handler already catches it — the second block is provably unreachable, and Java treats unreachable code as a compile error, not a warning."

---

## Memorize this

> **`Throwable` → `Error` (JVM, don't touch) + `Exception` (yours); `RuntimeException` lives UNDER `Exception` and is the unchecked branch; `catch` routes by `instanceof`, most specific first.**

*Next: [03 — checked vs unchecked](03-checked-vs-unchecked.md).*
