# Checked vs Unchecked Exceptions

> **Priority: Interview-critical** — full deep-dive below.

---

## 1. Core Mechanism

- **Checked** = extends `Exception` but NOT `RuntimeException`. The compiler forces every caller to either `catch` it or declare it with `throws`. Meant for **recoverable, expected failures** — file missing, network down, DB unreachable.
- **Unchecked** = extends `RuntimeException` (or `Error`). The compiler ignores it. Meant for **programming bugs** — null, bad argument, wrong state. You fix these, you don't catch them.
- **Why the split exists:** Java's designers wanted failure modes visible in the type system. A method signature with `throws IOException` *documents* that it can fail and *forces* the caller to decide what to do. No other mainstream language pushed this as far — and it stays controversial (see note 14).

> **Interview definition (say this out loud):**
> "Checked exceptions are compiler-enforced — catch or declare — and model recoverable conditions like I/O failure. Unchecked exceptions extend `RuntimeException` and model bugs. The distinction is purely compile-time: at runtime the JVM treats them identically."

---

## 2. Under the Hood

### 2.1 The JVM does not know the difference

`javac` (the compiler) checks `throws` clauses. The bytecode for throwing checked and unchecked exceptions is the **same single instruction: `athrow`**. Proof: Kotlin and Scala compile to the same JVM bytecode and have no checked exceptions at all. This is THE senior-level point on this topic.

### 2.2 Consequences of "compiler-only"

- Reflection, bytecode tricks, and generics-type-erasure loopholes can throw a checked exception without declaring it ("sneaky throw"). Lombok's `@SneakyThrows` does exactly this.
- `throws` clauses are metadata for the compiler and for documentation — the JVM never verifies them at runtime.

### 2.3 Where each is designed to live

| Situation | Right choice | Why |
|---|---|---|
| Environmental failure (I/O, network, DB) | Checked | Caller can realistically retry / fall back |
| Caller passed garbage | `IllegalArgumentException` (unchecked) | It's a bug; forcing catch = noise |
| Object used in wrong order/state | `IllegalStateException` (unchecked) | Also a bug |
| Business rule violated (insufficient funds) | Team choice — modern style: unchecked custom, handled at API boundary | Checked would infect every signature up the stack |

Modern framework reality: **Spring, Hibernate, and most modern libraries use unchecked almost exclusively.** Spring even wraps JDBC's checked `SQLException` into unchecked `DataAccessException` (note 23). Know the theory of checked, but know the industry moved away from it.

---

## 3. The Node.js / NestJS Bridge

- Node has **no checked exceptions**. Every JS throw is "unchecked". Nothing forces you to handle an error — you find out in production.
- In Java, `IOException` won't even compile until you decide: handle or declare. Method signatures document failure modes — closest JS analogue is a TypeScript `Result<T, E>` union type convention, but that's a library pattern, not the language.
- **Where the comparison breaks down:** coming from Node you'll be tempted to catch-and-ignore checked exceptions to make the compiler shut up (`catch (e) {}`). That's the #1 Java-newcomer smell. Either handle meaningfully, or wrap in an unchecked exception and rethrow.

---

## 4. Production-Grade Code

```java
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;

public class InvoiceImporter {

    /** Checked: caller MUST decide what to do about a missing file — retry, fallback, or fail. */
    public String readInvoiceFile(Path path) throws IOException {
        if (!Files.exists(path)) {
            throw new IOException("Invoice file not found: " + path);
        }
        return Files.readString(path);
    }

    /** Unchecked: a negative attempt count is a BUG in the caller, not a runtime condition. */
    public Duration retryDelay(int attempt) {
        if (attempt < 0) {
            throw new IllegalArgumentException("attempt must be >= 0, got " + attempt);
        }
        return Duration.ofSeconds(1L << Math.min(attempt, 5)); // capped exponential backoff
    }

    /** The modern boundary pattern: catch checked at the edge, wrap unchecked, keep the cause. */
    public String importInvoice(Path path) {
        try {
            return readInvoiceFile(path);
        } catch (IOException e) {
            throw new InvoiceImportException("Failed to import " + path, e);
        }
    }

    static class InvoiceImportException extends RuntimeException {
        InvoiceImportException(String msg, Throwable cause) { super(msg, cause); }
    }
}
```

---

## 5. Top 3 MNC Interview Questions

**Q1: Difference between checked and unchecked exceptions, and how does the JVM treat them?**
- **What they're testing:** whether you know it's compile-time only.
- **Ideal answer:** "Checked extend `Exception` but not `RuntimeException`; the compiler forces catch-or-declare — they model recoverable conditions. Unchecked extend `RuntimeException` and model bugs. Key point: the JVM makes no distinction — identical `athrow` bytecode. It's purely a `javac` feature, which is why Kotlin on the same JVM dropped checked exceptions entirely."

**Q2: Why does Spring convert `SQLException` to unchecked `DataAccessException`?**
- **What they're testing:** whether you understand checked exceptions' cost in layered apps.
- **Ideal answer:** "A checked `SQLException` would force every layer — repository, service, controller — to declare or catch it, coupling all of them to JDBC. Most DB errors aren't recoverable at the call site anyway. Spring wraps it into an unchecked, vendor-neutral hierarchy so only the layer that can actually react handles it."

**Q3: When would YOU create a checked vs unchecked custom exception?**
- **What they're testing:** judgment, not definitions.
- **Ideal answer:** "Checked only when the immediate caller can realistically recover — a retryable payment gateway timeout, for example. Everything else unchecked, handled at a boundary like `@ControllerAdvice`. In practice my custom exceptions are almost all unchecked — matching what Spring and Hibernate do — because checked exceptions leak through every signature and fight with lambdas and streams."

---

## Memorize this

> **Checked vs unchecked exists only in the compiler — the JVM runs one `athrow` for everything; checked = recoverable-by-caller, unchecked = bug, and the modern Spring world is almost entirely unchecked.**

*Next: [04 — try/catch/finally flow](04-try-catch-finally.md).*
