# try / catch / finally — Flow and Rules

> **Priority: Basic** — you know this from JS. Only the Java-specific rules below.

- Syntax and flow are the same as JavaScript. Differences are in the rules, not the shape.
- **Catch blocks are typed and ordered**: most specific type first; a subclass catch after its superclass catch is a *compile error* (unreachable code).
- Legal shapes: `try+catch`, `try+finally`, `try+catch+finally`, and try-with-resources (note 08). A bare `try` alone won't compile.
- `finally` runs on every exit — normal return, caught exception, uncaught exception flying through. It does NOT run if the JVM dies first (`System.exit()`, `kill -9`, fatal `Error`).
- Rethrow freely: `catch (X e) { log(...); throw e; }` — logging then rethrowing is normal; catching and *swallowing* is the anti-pattern.

```java
try {
    process(order);
} catch (ValidationException e) {   // specific first
    return badRequest(e.getMessage());
} catch (Exception e) {             // broad last — boundary only
    log.error("order {} failed", order.id(), e);
    throw e;
} finally {
    metrics.recordAttempt(order.id());   // side effects only — never return/throw here
}
```

- The traps (`return` inside `finally`, lost exceptions) are interview material — full deep-dive in [note 12](12-finally-traps.md).

*Next: [05 — throw vs throws](05-throw-vs-throws.md).*
