# throw vs throws

> **Priority: Basic** — quick bullets only.

- **`throw`** = the action. A statement inside a method body that throws one exception object *now*: `throw new IllegalStateException("not initialized");`
- **`throws`** = the declaration. Part of a method *signature* listing checked exceptions the method may propagate: `public String read(Path p) throws IOException`. It throws nothing itself — it's a contract for callers and the compiler.
- `throws` is only *required* for checked exceptions. You may list unchecked ones for documentation, but the compiler doesn't care and callers aren't forced to handle them.
- Overriding rule (small interview trap): an overriding method may declare **fewer or narrower** checked exceptions than the parent, never broader ones — otherwise callers holding a parent reference would face undeclared checked exceptions.

```java
interface Store { byte[] load(String key) throws IOException; }

class S3Store implements Store {
    @Override
    public byte[] load(String key) throws FileNotFoundException {  // narrower: OK
        if (key.isBlank()) throw new IllegalArgumentException("blank key"); // unchecked: no declaration needed
        throw new FileNotFoundException(key);
    }
}
```

*Next: [06 — common built-in exceptions](06-common-built-in-exceptions.md).*
