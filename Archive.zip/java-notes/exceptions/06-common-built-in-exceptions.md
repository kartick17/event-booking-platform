# Common Built-in Exceptions — What Each One Really Signals

> **Priority: Dev-important, Interview-light** — short notes.

Knowing which standard exception to throw (and what a thrown one *means*) is daily-development skill. All below are unchecked unless marked.

| Exception | Signals | You'll see it when |
|---|---|---|
| `NullPointerException` | Used a null reference | Since Java 14, "Helpful NPEs" tell you *which* variable was null — read the message |
| `IllegalArgumentException` | Caller passed a bad value | Best exception to throw for input guards |
| `IllegalStateException` | Right args, wrong time — object not in a valid state for this call | Calling `start()` twice; using a closed resource |
| `ClassCastException` | Bad downcast | Raw types, pre-generics code, careless `(User) obj` |
| `NumberFormatException` | `Integer.parseInt("abc")` | Parsing user/config input — extends `IllegalArgumentException` |
| `IndexOutOfBoundsException` | Bad list/array index | Subtypes: `ArrayIndexOutOfBounds…`, `StringIndexOutOfBounds…` |
| `UnsupportedOperationException` | Method exists but this implementation refuses | Mutating `List.of(...)` — immutable collections throw this |
| `ConcurrentModificationException` | Collection structurally changed during iteration | Removing from a list inside a for-each — single-threaded code triggers it too, name is misleading |
| `ArithmeticException` | Integer `/ 0` | Only integer division — `1.0 / 0` gives `Infinity`, no exception |
| `IOException` (checked) | I/O failed | Files, sockets, streams |
| `InterruptedException` (checked) | Thread was asked to stop while blocked | `sleep()`, `join()`, blocking queues — never swallow it (note 16) |

**Throwing guidance:** for argument guards prefer `Objects.requireNonNull(x, "x")` and `IllegalArgumentException`; for lifecycle misuse `IllegalStateException`. Don't invent a custom exception where a standard one says it better.

**One interview question:**
**Q: Difference between `IllegalArgumentException` and `IllegalStateException`?**
**A:** "Bad input vs bad timing. `IllegalArgumentException` — the parameter value is wrong no matter what state the object is in. `IllegalStateException` — the same call with the same args would be fine, but the object isn't in a state to accept it, like writing to a closed connection."

*Next: [07 — multi-catch](07-multi-catch.md).*
