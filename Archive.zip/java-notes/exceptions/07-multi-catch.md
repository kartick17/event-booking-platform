# Multi-catch — `catch (IOException | SQLException e)`

> **Priority: Basic** — quick bullets only.

- One catch block, several unrelated exception types, same handling — no duplicated code:

```java
try {
    exportReport(reportId);
} catch (IOException | SQLException e) {   // Java 7+
    log.error("export {} failed", reportId, e);
    throw new ReportExportException(reportId, e);
}
```

- The caught variable `e` is **implicitly final** — you can't reassign it inside the block.
- The types must **not** be in the same hierarchy: `catch (IOException | FileNotFoundException e)` is a compile error — the subclass is already covered.
- The compiler types `e` as the **nearest common supertype** for method calls, but tracks the real alternatives for rethrow analysis ("precise rethrow"): `catch (Exception e) { throw e; }` can still satisfy a `throws IOException, SQLException` clause if those are the only things the try can throw.
- Use it when handling is *identical*. If each type needs different handling, keep separate catch blocks.

*Next: [08 — try-with-resources](08-try-with-resources.md).*
