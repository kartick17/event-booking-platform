# Try-with-resources and AutoCloseable

> **Priority: Interview-critical** — full deep-dive below.

---

## 1. Core Mechanism

- Try-with-resources (Java 7+) declares resources (things that must be closed — files, connections, streams) in the `try` header. The compiler guarantees `close()` is called, in **reverse order of declaration**, whether the block succeeds or throws.
- A resource is anything implementing **`AutoCloseable`** — one method: `void close() throws Exception`.
- **Why it exists:** the old `finally { stream.close(); }` pattern was verbose and *buggy* — if both the body and `close()` threw, the `close()` exception silently replaced the real one. Try-with-resources fixes both problems (see suppressed exceptions, note 09).

> **Interview definition (say this out loud):**
> "Try-with-resources auto-closes any `AutoCloseable` declared in the try header, in reverse declaration order, on every exit path. If both the body and `close()` throw, the body's exception wins and the close exception is attached as suppressed — the opposite of the old finally pattern, which lost the original."

---

## 2. Under the Hood

### 2.1 It's pure compiler desugaring

The JVM has no notion of try-with-resources. The compiler expands

```java
try (var in = Files.newInputStream(path)) {
    process(in);
}
```

into roughly:

```java
var in = Files.newInputStream(path);
Throwable primary = null;
try {
    process(in);
} catch (Throwable t) {
    primary = t;
    throw t;
} finally {
    if (in != null) {
        if (primary != null) {
            try { in.close(); }
            catch (Throwable suppressed) { primary.addSuppressed(suppressed); }
        } else {
            in.close();   // no body exception → close() exception propagates normally
        }
    }
}
```

Key mechanics visible in the desugaring:

- **Body exception is primary**; `close()` failure becomes `addSuppressed(...)` on it.
- If the body succeeded but `close()` throws, the `close()` exception propagates as the main one.
- Multiple resources → nested copies of this structure → **reverse-order closing**, and a failure closing one resource does not prevent closing the others.

### 2.2 `AutoCloseable` vs `Closeable`

| | `AutoCloseable` (java.lang, Java 7) | `Closeable` (java.io, Java 5) |
|---|---|---|
| `close()` throws | `Exception` | `IOException` |
| Idempotency | Not required (but recommended) | Required — repeated `close()` must be harmless |
| Use | Anything: DB connections, locks, spans | I/O streams |

### 2.3 Java 9 refinement

An effectively-final variable declared before the try can be used directly: `try (connection) { ... }` — no need to redeclare in the header.

---

## 3. The Node.js / NestJS Bridge

- Closest JS analogue: **explicit resource management** (`using` / `await using`, TC39 stage 3, `Symbol.dispose`) — directly inspired by this feature. Before that, Node had only `try/finally` with manual `stream.destroy()` / `client.release()`.
- Pool release in Node (`const client = await pool.connect(); try { ... } finally { client.release(); }`) is exactly the pattern try-with-resources automates.
- **Where the comparison breaks down:** Java's version handles the double-failure case (body throws AND close throws) with suppression built in. Manual finally-based cleanup — in either language — loses one of the two exceptions unless you write careful code nobody actually writes.

---

## 4. Production-Grade Code

```java
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

public class OrderExportJob {

    private final DataSource dataSource;

    public OrderExportJob(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** Three resources, one header. Closed in reverse: rs → ps → conn. */
    public List<String> loadPendingOrderIds() {
        var sql = "SELECT order_id FROM orders WHERE status = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = prepare(conn, sql, "PENDING");
             ResultSet rs = ps.executeQuery()) {

            var ids = new ArrayList<String>();
            while (rs.next()) {
                ids.add(rs.getString("order_id"));
            }
            return ids;
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to load pending orders", e);
        }
    }

    private PreparedStatement prepare(Connection c, String sql, String status) throws SQLException {
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, status);
        return ps;
    }

    /** Custom AutoCloseable — works in try-with-resources like any stream. */
    static class JobLock implements AutoCloseable {
        private final Path lockFile;
        JobLock(Path lockFile) throws java.io.IOException {
            this.lockFile = lockFile;
            Files.createFile(lockFile);              // fails if another run holds the lock
        }
        @Override public void close() throws java.io.IOException {
            Files.deleteIfExists(lockFile);          // idempotent close — safe to call twice
        }
    }

    public void runExclusive(Path lockFile) throws java.io.IOException {
        try (var lock = new JobLock(lockFile)) {
            loadPendingOrderIds().forEach(System.out::println);
        } // lock released even if the export throws
    }
}
```

---

## 5. Top 3 MNC Interview Questions

**Q1: Body throws, then `close()` also throws — what does the caller see?**
- **What they're testing:** suppressed-exception mechanics; most candidates only know old-finally behavior.
- **Ideal answer:** "The body's exception propagates as primary; the `close()` exception is attached to it via `addSuppressed()` and shows in the stack trace as 'Suppressed:'. That's the reverse of a manual finally-close, where the close exception would replace and lose the original. If only `close()` throws, it propagates normally."

**Q2: In what order do multiple resources close, and why that order?**
- **What they're testing:** whether you understand dependency between resources.
- **Ideal answer:** "Reverse declaration order. Later resources are usually built on earlier ones — a `ResultSet` from a `Statement` from a `Connection` — so you tear down in reverse dependency order. And a failure closing one doesn't skip the others; those failures get suppressed onto the primary."

**Q3: Difference between `AutoCloseable` and `Closeable`?**
- **What they're testing:** API-design detail.
- **Ideal answer:** "`Closeable` is older, from java.io, throws `IOException`, and requires idempotent close. `AutoCloseable` came in Java 7 as the general try-with-resources hook, throws broad `Exception`, idempotency recommended but not required. `Closeable` extends `AutoCloseable`, so streams work in try-with-resources automatically."

---

## Memorize this

> **Try-with-resources = compiler-generated finally that closes in reverse order and attaches `close()` failures as suppressed — the body's exception always wins.**

*Next: [09 — suppressed exceptions](09-suppressed-exceptions.md).*
