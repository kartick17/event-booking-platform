# Suppressed Exceptions

> **Priority: Interview-critical** — full deep-dive below (short topic, but it's THE follow-up question to try-with-resources).

---

## 1. Core Mechanism

- A suppressed exception is a *secondary* failure attached to the primary exception instead of replacing it. Stored in a list inside `Throwable`, added via `addSuppressed()`, read via `getSuppressed()`.
- **Why it exists (Java 7):** before this, when a try body threw AND the cleanup in `finally` threw, one exception had to vanish — and it was always the *original*, more important one. Suppression lets Java keep both.

> **Interview definition (say this out loud):**
> "When a try-with-resources body throws and `close()` also throws, the close exception doesn't replace the primary — it's attached to it as a suppressed exception. Both appear in the stack trace, so no failure information is lost."

---

## 2. Under the Hood

- `Throwable` holds a `List<Throwable> suppressedExceptions`. `addSuppressed()` appends; the JVM prints each entry under a `Suppressed:` heading in the stack trace, indented under the primary.
- **Who adds them:** compiler-generated try-with-resources code (note 08's desugaring) is the main producer. You can call `t.addSuppressed(other)` manually — useful when aggregating failures (e.g., "primary source failed AND fallback failed").
- Rules: you can't suppress an exception onto itself (`IllegalArgumentException`); constructors can disable suppression per-instance (`super(msg, cause, /*enableSuppression*/ false, /*writableStackTrace*/ true)`) — used by JVM-internal pre-allocated exceptions.
- **Suppressed vs cause — the trap:**

| | Cause (chaining, note 11) | Suppressed |
|---|---|---|
| Relationship | *Led to* — B happened because of A | *Happened alongside* — B failed during handling/cleanup of A |
| Set via | Constructor / `initCause()` | `addSuppressed()` |
| Cardinality | One | Many (a list) |
| Trace label | `Caused by:` | `Suppressed:` |

---

## 3. The Node.js / NestJS Bridge

- Closest JS equivalents: `AggregateError` (from `Promise.any`) holds many errors — similar "multiple failures, keep all" idea. `error.cause` (ES2022, `new Error("x", { cause: e })`) is Java's *chaining*, not suppression.
- The TC39 `using` proposal introduces `SuppressedError` — a direct copy of Java's concept.
- **Where the comparison breaks down:** in day-to-day Node there's no standard place for "cleanup also failed" — it's usually just a second `console.error`. In Java it travels *inside* the primary exception to whatever logs it.

---

## 4. Production-Grade Code

```java
import java.util.List;

public class MultiRegionPublisher {

    /** Try each region; if ALL fail, throw ONE exception carrying every failure. */
    public void publish(String event, List<RegionClient> regions) {
        RuntimeException failure = null;
        for (RegionClient region : regions) {
            try {
                region.send(event);
                return;                                   // first success wins
            } catch (RuntimeException e) {
                if (failure == null) {
                    failure = new IllegalStateException("All regions failed for event " + event);
                }
                failure.addSuppressed(e);                 // keep EVERY region's stack trace
            }
        }
        if (failure != null) throw failure;
    }

    /** Reading them back — e.g. to decide if any failure was retryable. */
    public boolean anyTimeout(Throwable t) {
        for (Throwable s : t.getSuppressed()) {
            if (s instanceof java.util.concurrent.TimeoutException) return true;
        }
        return false;
    }

    interface RegionClient { void send(String event); }
}
```

Stack trace shape you'll see in logs:

```
java.lang.IllegalStateException: All regions failed for event order.created
    at MultiRegionPublisher.publish(...)
    Suppressed: java.net.ConnectException: eu-west-1 refused
        at ...
    Suppressed: java.util.concurrent.TimeoutException: us-east-1 timed out
        at ...
```

---

## 5. Top 3 MNC Interview Questions

**Q1: What's a suppressed exception and when does Java create one automatically?**
- **What they're testing:** try-with-resources follow-up depth.
- **Ideal answer:** "It's a secondary exception attached to the primary via `addSuppressed()` instead of replacing it. Java adds them automatically in try-with-resources: body throws, then `close()` throws — the close failure becomes suppressed on the body's exception. Both print in the trace, the primary first, suppressed indented below."

**Q2: Suppressed exception vs cause?**
- **What they're testing:** the classic confusion pair.
- **Ideal answer:** "Cause is *why* — this exception exists because that one happened; set in the constructor; one per exception; prints as 'Caused by'. Suppressed is *also-failed* — an independent failure during cleanup or aggregation; added with `addSuppressed()`; can be many; prints as 'Suppressed'."

**Q3: Old-style `finally { close(); }` — what was actually wrong with it?**
- **What they're testing:** whether you know the historical bug this feature fixed.
- **Ideal answer:** "If the body threw and then `close()` in finally also threw, the finally exception replaced the in-flight one — you lost the real root cause and debugged the wrong thing. Try-with-resources inverts that: body exception stays primary, close failure rides along as suppressed."

---

## Memorize this

> **Suppressed = "also failed during cleanup", kept in a list on the primary exception; cause = "failed because of". Try-with-resources adds suppressed automatically; old finally-close silently lost the original.**

*Next: [10 — custom exceptions](10-custom-exceptions.md).*
