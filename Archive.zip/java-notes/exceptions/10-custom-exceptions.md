# Custom Exceptions — How to Write Good Ones

> **Priority: Dev-important, Interview-light** — short notes; judgment matters more than syntax.

**The rules of a good custom exception:**

- **Extend `RuntimeException`** by default (matches Spring/Hibernate style; keeps signatures clean). Extend `Exception` (checked) only when the *immediate caller* can realistically recover — rare.
- **Always provide the `(String message, Throwable cause)` constructor.** Losing the cause is the worst custom-exception bug.
- **Name = what went wrong**, ending in `Exception`: `OrderNotFoundException`, `PaymentDeclinedException`. Not `OrderException` (too vague), not `OrderError`.
- **Carry structured data** as fields — the handler shouldn't parse the message string.
- Create one **per distinct failure the caller handles differently** — not one per method. If two failures are handled identically, one exception class is enough. A small hierarchy (`PaymentException` ← `PaymentDeclinedException`, `PaymentTimeoutException`) lets handlers choose their granularity.
- Don't create a custom exception where a standard one already says it: bad argument → `IllegalArgumentException`.

```java
/** Unchecked, cause-preserving, carries structured data for the handler. */
public class OrderNotFoundException extends RuntimeException {

    private final String orderId;

    public OrderNotFoundException(String orderId) {
        super("Order not found: " + orderId);
        this.orderId = orderId;
    }

    public OrderNotFoundException(String orderId, Throwable cause) {
        super("Order not found: " + orderId, cause);
        this.orderId = orderId;
    }

    public String orderId() { return orderId; }
}
```

In Spring, this class later maps to a 404 in one place via `@ExceptionHandler` (note 20) — that's the payoff of a precise custom exception: the controller code never mentions HTTP at all.

**One interview question:**
**Q: Checked or unchecked for your custom exceptions?**
**A:** "Unchecked by default — same call Spring made with `DataAccessException`. Checked exceptions propagate through every signature and fight with lambdas. I use checked only when the direct caller is expected to recover, like a retryable gateway timeout."

*Next: [11 — exception chaining](11-exception-chaining.md).*
