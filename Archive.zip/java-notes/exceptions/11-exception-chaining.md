# Exception Chaining — Wrapping with a Cause

> **Priority: Dev-important, Interview-light** — short notes; this is a daily habit, not a deep topic.

- Chaining = wrapping a low-level exception in a higher-level one **while keeping the original as `cause`**: `throw new OrderImportException("Import failed for " + id, e);`
- **Why:** each layer should speak its own language (controller shouldn't see `SQLException`), but the root cause must survive to the logs. The chain prints as nested `Caused by:` blocks — you read it *bottom-up*: the deepest `Caused by` is the real problem.
- Mechanics: `Throwable` has one `cause` field, set via constructor or `initCause()` (once only — second call throws). `getCause()` walks one level; loop it to reach the root.
- **The cardinal sin — cause dropped:**

```java
} catch (SQLException e) {
    throw new OrderImportException("import failed");        // ❌ root cause GONE from logs forever
}
} catch (SQLException e) {
    throw new OrderImportException("import failed", e);     // ✅ full chain preserved
}
```

- Second sin — **log AND rethrow**: the same error appears twice in logs (once from your `log.error`, once when the boundary logs the rethrown one). Pick one: either handle-and-log, or wrap-and-rethrow. The boundary logs.
- Don't over-wrap: re-wrapping at every layer (`ServiceException` wrapping `RepositoryException` wrapping `DataException` wrapping `SQLException`) makes traces unreadable. Wrap when crossing an abstraction boundary — translate meaning, not just class name.
- JS equivalent you already know: `new Error("import failed", { cause: e })` (ES2022) — Java had this since 1.4.

**One interview question:**
**Q: How do you find the root cause of a wrapped exception in logs?**
**A:** "Read the trace bottom-up — the last `Caused by:` is the original failure. Programmatically, loop `getCause()` until null; Spring and Apache Commons have `getRootCause` helpers for exactly this."

*Next: [12 — finally traps](12-finally-traps.md).*
