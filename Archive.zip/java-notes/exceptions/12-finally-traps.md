# `finally` Traps — return/throw Inside finally, Swallowed Exceptions

> **Priority: Interview-critical** — full deep-dive below. Small topic, huge trap-question density.

---

## 1. Core Mechanism

- `finally` runs on **every** exit from the try — normal completion, `return`, caught exception, uncaught exception flying through.
- The trap: if `finally` itself completes *abruptly* (its own `return`, `throw`, `break`, or `continue`), that abrupt completion **replaces whatever was in flight** — the original return value or the original exception is silently discarded.
- **Why it works this way:** `finally` is defined to have the last word on how the block completes. Useful for cleanup; catastrophic when you return or throw from it.

> **Interview definition (say this out loud):**
> "A `return` or `throw` inside `finally` overrides the try block's result — including silently discarding an in-flight exception. That's why abrupt statements in `finally` are banned in every serious style guide; `finally` is for side-effect cleanup only."

---

## 2. Under the Hood

- The compiler implements `finally` by **duplicating its bytecode** onto every exit path of the try/catch (normal path, each catch, plus a catch-all handler for uncaught throwables that runs finally then rethrows).
- On the exception path, the in-flight exception is held in a local slot while the finally code runs. If finally completes normally → the exception is rethrown from the slot. If finally returns/throws → the slot is never rethrown. **The original exception isn't logged, isn't suppressed — it's gone.** (Contrast: try-with-resources *keeps* both via suppression — note 09.)
- Return values behave the same: the try's return value is stored in a slot, finally runs, and a `return` in finally overwrites the slot.
- `finally` does **not** run when the JVM dies first: `System.exit()`, a fatal `Error` killing the process, `kill -9`, or the thread being a daemon at JVM shutdown.

The three classic puzzles:

```java
static int a() {
    try { return 1; }
    finally { return 2; }          // returns 2 — try's 1 is discarded
}

static int b() {
    int x = 1;
    try { return x; }              // return VALUE (1) is captured here
    finally { x = 99; }            // too late — does NOT affect the returned 1
}

static int c() {
    try { throw new IllegalStateException("real bug"); }
    finally { return 3; }          // returns 3 — the exception VANISHES
}
```

`b` is the subtlest: the return value is evaluated and captured *before* finally runs; later mutation of the variable changes nothing (for primitives — mutating a *field of a returned object* in finally IS visible, since the slot holds a reference).

---

## 3. The Node.js / NestJS Bridge

- JavaScript has **exactly the same semantics** — `return` in `finally` also wins in JS. Difference is cultural: JS linters (`no-unsafe-finally`) ban it and nobody writes it; in Java it's a standing interview trap, so you must be able to *explain* it, not just avoid it.
- The capture-before-finally rule (`b` above) also matches JS behavior for primitives vs object mutation.

---

## 4. Production-Grade Code

What correct `finally` usage looks like — side effects only, and cleanup that can itself fail gets its own guarded catch:

```java
import java.util.concurrent.locks.ReentrantLock;

public class InventoryReservationService {

    private final ReentrantLock stockLock = new ReentrantLock();

    public boolean reserve(String sku, int quantity) {
        stockLock.lock();
        long startNanos = System.nanoTime();
        try {
            return tryReserve(sku, quantity);      // may throw — lock still released
        } finally {
            stockLock.unlock();                    // THE canonical finally use case
            recordLatencySafely(sku, System.nanoTime() - startNanos);
        }
    }

    /** Cleanup that can fail must not throw from finally — it would eat the real exception. */
    private void recordLatencySafely(String sku, long nanos) {
        try {
            metricsSink(sku, nanos);
        } catch (RuntimeException metricsFailure) {
            System.err.println("metrics write failed for " + sku + ": " + metricsFailure);
        }
    }

    private boolean tryReserve(String sku, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("quantity must be > 0");
        return true;
    }

    private void metricsSink(String sku, long nanos) { /* push to metrics backend */ }
}
```

Rules encoded above: `lock()/unlock()` is the textbook finally pattern; anything in finally that can throw is wrapped so it can never replace the business exception.

---

## 5. Top 3 MNC Interview Questions

**Q1: `try` returns 1, `finally` returns 2 — what does the method return, and why?**
- **What they're testing:** the override rule.
- **Ideal answer:** "2. `finally` code is compiled onto every exit path, and an abrupt completion in finally — return, throw, break — replaces whatever the try was completing with. Same rule means a throw in finally discards an in-flight exception without a trace, which is the dangerous version of this puzzle."

**Q2: `try` throws an exception, `finally` returns a value — what does the caller see?**
- **What they're testing:** the swallowed-exception case, the one that causes production mysteries.
- **Ideal answer:** "The caller sees a normal return — the exception is silently discarded, not logged, not suppressed. The finally's return replaces the abrupt completion. This is why `no-return-in-finally` is a hard rule: it converts failures into fake successes."

**Q3: When does `finally` NOT run?**
- **What they're testing:** edge-case knowledge.
- **Ideal answer:** "When the JVM never reaches the exit path: `System.exit()` inside the try, the process being killed, a fatal `Error` like `OutOfMemoryError` taking the JVM down, or an infinite loop. For a normal return or any exception — checked, unchecked, even rethrown — finally always runs."

---

## Memorize this

> **`finally` has the last word: its own `return`/`throw` replaces — and silently destroys — the try's return value or in-flight exception; return values are captured BEFORE finally runs; finally is for side-effect cleanup only.**

*Next: [13 — stack traces](13-stack-traces.md).*
