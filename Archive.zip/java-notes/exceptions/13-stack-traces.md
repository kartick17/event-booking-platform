# Stack Traces — Reading Them, getCause, Logging

> **Priority: Dev-important, Interview-light** — short notes; this is a daily debugging skill.

**Anatomy of a trace:**

```
com.shop.OrderImportException: Import failed for order 42        ← primary (thrown LAST)
    at com.shop.ImportService.importOrder(ImportService.java:31) ← where it was thrown
    at com.shop.ImportJob.run(ImportJob.java:12)                 ← callers, top = deepest
Caused by: java.sql.SQLException: connection refused              ← the ROOT cause
    at com.shop.OrderRepo.load(OrderRepo.java:55)
    ... 2 more                                                    ← frames shared with above, elided
Suppressed: java.io.IOException: close failed                     ← cleanup also failed (note 09)
```

**How to read it — the only algorithm you need:**
1. Jump to the **last `Caused by:`** — that's the root failure.
2. In its frames, find the **first line in YOUR package** — that's where to look.
3. Read upward through the wrappers only if you need the request context.

**Key API points:**
- The trace is captured at **construction** (`fillInStackTrace()` inside the `Throwable` constructor), not at throw. Cost detail in note 18.
- `getCause()` walks one level down the chain; `getStackTrace()` gives `StackTraceElement[]` (class, method, file, line) programmatically.
- `printStackTrace()` writes to stderr — **never use it in real code**; it bypasses your logging system (no timestamps, no correlation IDs, wrong stream).
- **Logging rule:** pass the exception as the **last argument** to SLF4J — `log.error("import failed for order {}", orderId, e);` — the full chain prints. `log.error("failed: " + e)` prints only the message and loses the entire trace.
- Missing stack traces in production (`NullPointerException` with zero frames)? That's the JIT's `OmitStackTraceInFastThrow` — a hot, repeatedly-thrown exception got replaced with a pre-allocated trace-less instance. Restart or `-XX:-OmitStackTraceInFastThrow` to see it again; the *earliest* occurrences in the logs have the full trace.
- Since Java 14, NPE messages name the exact null variable ("Helpful NullPointerExceptions") — read the message before the frames.

**One interview question:**
**Q: Where should an exception be logged in a layered app?**
**A:** "Once, at the boundary that handles it — in Spring, the `@ControllerAdvice`. Layers below either rethrow or wrap with a cause; if every layer logs, one failure shows five times and pages five people."

*Next: [14 — best practices](14-best-practices.md).*
