# Exception Handling Best Practices

> **Priority: Dev-important, Interview-light** — but "how do you handle exceptions in your service?" IS a common open question; this file is your answer script.

**The ten rules:**

1. **Fail fast.** Validate at the top of the method (`Objects.requireNonNull`, argument guards) — an exception near the cause is worth ten near the symptom.
2. **Never swallow.** `catch (Exception e) {}` is the worst line of Java. If you truly must ignore (rare), comment why and name the variable `ignored`.
3. **Catch narrow.** `catch (NumberFormatException e)`, not `catch (Exception e)`. Broad catches belong at boundaries only (request handler, job runner, thread top).
4. **Wrap with cause when crossing layers** — `throw new OrderImportException(msg, e)` — never bare-message rewrap (note 11).
5. **Log once, at the boundary.** Layers below rethrow; the `@ControllerAdvice`/job wrapper logs. Log-and-rethrow duplicates every failure.
6. **Don't use exceptions for control flow.** No `catch (NumberFormatException)` as an `isNumeric()` check inside a loop — exceptions cost stack-trace capture (note 18) and hide logic. Check first, or return `Optional`.
7. **Unchecked by default for custom exceptions**; checked only when the direct caller recovers (note 10).
8. **`finally`/try-with-resources for cleanup, never for logic** — no return/throw in finally (note 12); prefer try-with-resources over manual close (note 08).
9. **Preserve `InterruptedException`.** Never swallow it — either rethrow or `Thread.currentThread().interrupt()` before wrapping (note 16).
10. **Design messages for the 3 AM reader.** Include the identifying values: `"Order 42 not found for customer 17"`, not `"not found"`. But never include secrets/PII — messages end up in logs and API responses.

**Anti-pattern gallery (spot these in code review):**

```java
catch (Exception e) { }                          // 1. swallowed — failure becomes silence
catch (Exception e) { e.printStackTrace(); }     // 2. bypasses logging, then CONTINUES as if fine
catch (Exception e) { throw new RuntimeException("error"); }   // 3. cause lost
catch (Exception e) { log.error("failed", e); throw e; }       // 4. double logging
if (user == null) throw new Exception("no user");              // 5. raw Exception type — uncatchable precisely
```

**One interview question:**
**Q: Your exception-handling strategy in a Spring microservice?**
**A:** "Fail fast with guard clauses; domain-specific unchecked exceptions thrown from services; nothing caught in intermediate layers except to wrap with cause at abstraction boundaries; one `@ControllerAdvice` maps exception types to HTTP statuses and Problem Details, and that's the single place that logs. Resources via try-with-resources everywhere."

*Next: [15 — exceptions with lambdas and streams](15-exceptions-in-lambdas-streams.md).*
