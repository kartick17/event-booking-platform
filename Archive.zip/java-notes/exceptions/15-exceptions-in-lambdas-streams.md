# Checked Exceptions with Lambdas and Streams

> **Priority: Interview-critical** — full deep-dive below. This is where checked-exception theory meets modern-Java reality, and interviewers love the collision.

---

## 1. Core Mechanism

- The functional interfaces behind lambdas — `Function<T,R>`, `Consumer<T>`, `Supplier<T>`, `Predicate<T>` — declare **no checked exceptions** on their single method. So a lambda body that throws a checked exception **does not compile** inside `map()`, `forEach()`, etc.
- **Why:** streams came in Java 8, long after checked exceptions; forcing `throws` through every functional interface would have poisoned the whole API. The designers chose clean signatures and pushed the problem to you.

```java
paths.stream()
     .map(p -> Files.readString(p))   // ❌ won't compile: readString throws IOException
     .toList();
```

> **Interview definition (say this out loud):**
> "Standard functional interfaces declare no checked exceptions, so a checked-throwing call can't sit directly in a lambda. The standard fixes are: extract a helper that wraps into an unchecked exception, or use a 'sneaky' wrapper. It's the strongest practical argument against checked exceptions in modern Java."

---

## 2. Under the Hood

### 2.1 Why exactly it fails

A lambda implements the interface's single abstract method. `Function.apply(T)` declares `throws` nothing, and an implementation can't throw broader checked exceptions than its interface method (same override rule as note 05). So the compile error is ordinary override-rule enforcement — nothing lambda-special.

### 2.2 The three real-world patterns

| Pattern | How | Trade-off |
|---|---|---|
| **Wrap in unchecked** (default choice) | Helper method catches checked, rethrows `UncheckedIOException`/custom | Honest, visible; stream dies on first failure |
| **Sneaky throw** | Generic-erasure trick rethrows checked as-if-unchecked (`@SneakyThrows` in Lombok) | No wrapper object, original type preserved — but callers can't catch it as checked; controversial in review |
| **Collect successes and failures** | Lambda returns a result object (`record Result(T value, Exception error)`) instead of throwing | Batch keeps going; you decide about failures at the end — right for bulk jobs |

`UncheckedIOException` exists in the JDK precisely for this — the `Files.lines()` stream itself throws it when the underlying read fails mid-stream.

### 2.3 Streams make it worse than loops

A for-loop can just declare `throws IOException` on its method. Inside a stream, the exception must cross the lambda boundary → the stream machinery → back to your code. Also: an exception thrown mid-stream **abandons the rest of the elements** — no built-in "continue with the next one". In a parallel stream it also cancels other workers at an arbitrary point.

---

## 3. The Node.js / NestJS Bridge

- In JS this problem **cannot exist**: no checked exceptions, so `paths.map(p => fs.readFileSync(p))` throws at runtime and that's that.
- The "Result object" pattern is exactly `Promise.allSettled()` — collect `{status, value/reason}` per item, decide later. If you liked `allSettled` in Node, pattern 3 is its Java twin.
- **Where the comparison breaks down:** Java makes you choose a strategy *at compile time*. Coming from Node you'll reach for quick swallowing (`catch { return null; }`) inside the lambda — that turns failures into silent `null`s flowing down the stream. Wrap or collect; never null-out.

---

## 4. Production-Grade Code

```java
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ContractLoader {

    /** Pattern 1 — wrap into unchecked. Stream stays clean; first failure aborts the batch. */
    public List<String> loadAllOrFail(List<Path> paths) {
        return paths.stream()
                    .map(this::readContract)          // helper hides the try/catch
                    .toList();
    }

    private String readContract(Path path) {
        try {
            return Files.readString(path);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed reading contract " + path, e);
        }
    }

    /** Pattern 3 — per-item results. Batch completes; failures reported together. */
    public record LoadResult(Path path, String content, Exception error) {
        boolean ok() { return error == null; }
    }

    public Map<Boolean, List<LoadResult>> loadAllReportFailures(List<Path> paths) {
        return paths.stream()
                    .map(p -> {
                        try {
                            return new LoadResult(p, Files.readString(p), null);
                        } catch (IOException e) {
                            return new LoadResult(p, null, e);
                        }
                    })
                    .collect(Collectors.partitioningBy(LoadResult::ok));
        // result.get(true) = loaded, result.get(false) = failed with reasons
    }
}
```

---

## 5. Top 3 MNC Interview Questions

**Q1: Why can't you call a method that throws `IOException` inside `stream().map()`?**
- **What they're testing:** whether you know it's the functional interface's signature, not a stream limitation.
- **Ideal answer:** "`map` takes a `Function`, whose `apply` declares no checked exceptions — and an implementation can't throw broader checked exceptions than the interface method, same rule as method overriding. So it's a plain compile error. Fix: a helper that wraps into `UncheckedIOException`, or a result-object pattern for batch flows."

**Q2: What happens when an element throws midway through a stream?**
- **What they're testing:** stream failure semantics.
- **Ideal answer:** "The pipeline stops — remaining elements are never processed, and there's no built-in retry-or-skip. In a parallel stream, other workers get cancelled at an arbitrary point. That's why for bulk jobs I map each element to a success-or-failure record and partition at the end, like `Promise.allSettled`."

**Q3: What's a sneaky throw and would you use it?**
- **What they're testing:** depth plus judgment.
- **Ideal answer:** "A generics trick — because of type erasure, a generic `throws T` method can rethrow a checked exception without declaring it; Lombok's `@SneakyThrows` packages it. The JVM doesn't mind since checked-ness is compiler-only. I avoid it in shared code: callers can't catch what javac says can't be thrown. Wrapping is more honest."

---

## Memorize this

> **Functional interfaces declare no checked exceptions, so checked-throwing calls can't live in lambdas — wrap into unchecked (`UncheckedIOException`), or return per-item results like `Promise.allSettled`; a mid-stream throw abandons all remaining elements.**

*Next: [16 — exceptions in threads and ExecutorService](16-exceptions-in-threads-executorservice.md).*
