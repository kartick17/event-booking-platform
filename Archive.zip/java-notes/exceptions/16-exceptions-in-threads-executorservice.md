# Exceptions in Threads and ExecutorService

> **Priority: Interview-critical** — full deep-dive below. Connects your `basic java/` concurrency notes to exception handling.

---

## 1. Core Mechanism

- An exception thrown in one thread **does not cross to another thread**. Your `try/catch` around `executor.submit(...)` catches nothing from the task — the submit returns immediately; the task fails later, elsewhere.
- Where the exception *goes* depends on how the task was started:
  - **Raw `Thread` / `execute()`** → thread dies; the `UncaughtExceptionHandler` (a last-resort callback per thread) fires; default prints to stderr.
  - **`submit()` → `Future`** → the exception is **captured and stored** inside the Future — completely *silent* until someone calls `get()`, which rethrows it wrapped in `ExecutionException`.
- **Why:** each thread has its own stack; unwinding (note 02) can only walk one stack. Some thread boundary object must carry the failure across — that object is the `Future`.

> **Interview definition (say this out loud):**
> "Exceptions don't propagate across threads. With `execute()` the thread dies and the uncaught-exception handler fires; with `submit()` the exception is stored in the `Future` and only resurfaces as an `ExecutionException` when you call `get()` — if nobody calls `get()`, the failure is silently swallowed."

---

## 2. Under the Hood

### 2.1 `submit()` vs `execute()` — the silent-swallow trap

`FutureTask.run()` wraps the task body: `catch (Throwable t) { setException(t); }`. The throwable is stored in the Future's state — **nothing is logged, no handler fires, the pool thread survives and takes the next task.** A fire-and-forget `submit()` whose Future is discarded = failures vanish. This is the #1 production bug with executors.

`execute(Runnable)` has no Future to store into → the exception escapes `run()` → the worker thread dies → `UncaughtExceptionHandler` fires → the pool replaces the dead thread (thread churn, but visible errors).

**Same method, different behavior:** `ThreadPoolExecutor` — `execute` → handler; `submit` → silent Future. Know this asymmetry.

### 2.2 `Future.get()` and `ExecutionException`

- `get()` rethrows the stored failure wrapped in `ExecutionException`; call `getCause()` for the real one.
- `get()` itself also throws `InterruptedException` (the *waiting* thread got interrupted) and, with timeout, `TimeoutException` — three failure modes, three different meanings.
- `CancellationException` (unchecked) if the task was cancelled.

### 2.3 `InterruptedException` — the special one

- Thrown by blocking calls (`sleep`, `join`, `get`, `queue.take`) when another thread calls `interrupt()`. It's cooperative cancellation — Java never kills threads, it *asks*.
- Catching it **clears the thread's interrupted flag**. If you swallow it, the cancellation signal is destroyed — the pool/framework above you no longer knows shutdown was requested.
- Rule: either rethrow it, or restore the flag: `Thread.currentThread().interrupt();` then wrap/return.

### 2.4 `UncaughtExceptionHandler`

Per-thread (`thread.setUncaughtExceptionHandler`), or global default (`Thread.setDefaultUncaughtExceptionHandler`) — set the global one in every service's main() to route stray thread deaths into your logging. For pools, set it via a `ThreadFactory`. Remember it does NOT fire for `submit()` failures (they're captured by the Future first).

---

## 3. The Node.js / NestJS Bridge

| Concept | Node | Java |
|---|---|---|
| Failure carrier across async boundary | Rejected `Promise` | `Future` holding the exception |
| Unhandled failure | `unhandledRejection` event fires automatically | **Nothing fires** — un-`get()`-ed Future is silent |
| Last-resort hook | `process.on('uncaughtException')` | `Thread.setDefaultUncaughtExceptionHandler` |
| Cancellation | `AbortController` signal | `interrupt()` + `InterruptedException` |

**Where the comparison breaks down:** Node *warns you* about unhandled rejections by default. Java's un-consumed `Future` never complains — no log line, ever. Coming from Node, this is the instinct to unlearn: in Java **you** must guarantee every submitted task's outcome is observed (call `get()`, or wrap the task body in its own try/catch that logs).

---

## 4. Production-Grade Code

```java
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class NotificationDispatcher {

    private final ExecutorService pool = Executors.newFixedThreadPool(8, runnable -> {
        Thread t = new Thread(runnable, "notif-worker");
        // catches execute()-path failures AND anything escaping run(); NOT submit() failures
        t.setUncaughtExceptionHandler((thread, ex) ->
                System.err.printf("thread %s died: %s%n", thread.getName(), ex));
        return t;
    });

    /** Correct fan-out: every Future is consumed, every failure observed exactly once. */
    public int sendAll(List<String> userIds) throws InterruptedException {
        List<Future<Boolean>> futures = userIds.stream()
                .map(id -> pool.submit(() -> sendOne(id)))
                .toList();

        int delivered = 0;
        for (int i = 0; i < futures.size(); i++) {
            try {
                if (futures.get(i).get(5, TimeUnit.SECONDS)) delivered++;
            } catch (ExecutionException e) {
                // the TASK failed — real cause is inside
                System.err.printf("send to %s failed: %s%n", userIds.get(i), e.getCause().toString());
            } catch (TimeoutException e) {
                futures.get(i).cancel(true);          // true → interrupt the running task
                System.err.printf("send to %s timed out%n", userIds.get(i));
            }
            // InterruptedException NOT caught: WE were asked to stop — propagate it up
        }
        return delivered;
    }

    private boolean sendOne(String userId) throws InterruptedException {
        try {
            Thread.sleep(50);                          // simulated blocking push call
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();        // restore the flag — never swallow
            throw e;
        }
    }
}
```

---

## 5. Top 3 MNC Interview Questions

**Q1: A task submitted to an ExecutorService throws — what happens?**
- **What they're testing:** the submit/execute asymmetry and the silent Future.
- **Ideal answer:** "Depends on submission. With `submit()`, `FutureTask` catches everything and stores it in the Future — nothing logged, worker survives; it resurfaces as `ExecutionException` on `get()`, and if nobody calls `get()`, it's silently lost. With `execute()`, the exception escapes, the worker dies, the `UncaughtExceptionHandler` fires, and the pool replaces the thread."

**Q2: How do you properly handle `InterruptedException`?**
- **What they're testing:** cooperative cancellation understanding — most candidates say "just catch it".
- **Ideal answer:** "It means another thread requested cancellation while I was blocked. Catching it clears the interrupted flag, so I must not swallow it: either propagate it, or catch, run cleanup, call `Thread.currentThread().interrupt()` to restore the flag, and exit fast. Swallowing it destroys the shutdown signal for everything above me — pools stop being able to shut down."

**Q3: Why doesn't try/catch around `executor.submit()` catch the task's exception?**
- **What they're testing:** the thread-boundary mental model.
- **Ideal answer:** "`submit()` only enqueues and returns a Future — it has already returned by the time the task runs on another thread, and stack unwinding can't cross stacks. The failure is delivered through the Future: my catch must go around `future.get()`, or inside the task itself."

---

## Memorize this

> **Exceptions never cross threads: `execute()` → thread dies + handler fires; `submit()` → failure hides in the Future until `get()` throws `ExecutionException` — and an un-`get()`-ed Future swallows it forever. `InterruptedException` = restore the flag or rethrow.**

*Next: [17 — CompletableFuture exceptions](17-completablefuture-exceptions.md).*
