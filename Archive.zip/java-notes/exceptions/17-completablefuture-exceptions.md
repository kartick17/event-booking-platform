# Exceptions in CompletableFuture — exceptionally, handle, whenComplete

> **Priority: Interview-critical** — full deep-dive below. Directly maps to Promise error handling you already know.

---

## 1. Core Mechanism

- A `CompletableFuture` completes in one of two states: **value** or **exception**. An exception thrown in any stage skips all following value-stages (`thenApply`, `thenAccept`…) and flows down the chain until an **error-aware stage** handles it — exactly like a rejected Promise skipping `.then()` callbacks until a `.catch()`.
- The three error-aware operators:

| Operator | Runs on | Can recover? | Promise equivalent |
|---|---|---|---|
| `exceptionally(fn)` | failure only | yes — returns substitute value | `.catch(fn)` |
| `handle((val, ex) -> …)` | both | yes — transforms either case | `.then(v => …, e => …)` |
| `whenComplete((val, ex) -> …)` | both | **no** — observes, passes through | `.finally()` + peek |

- **Why:** async chains span threads; normal try/catch can't follow (note 16). These operators put the catch *into the chain itself*.

> **Interview definition (say this out loud):**
> "A failed stage bypasses all value-stages until an error-aware operator: `exceptionally` is the async catch and can substitute a fallback value, `handle` sees both outcomes and transforms them, `whenComplete` only observes and lets the result pass through unchanged."

---

## 2. Under the Hood

### 2.1 The wrapping rule — `CompletionException`

Inside error operators, the exception you receive is usually wrapped in **`CompletionException`** (unchecked) — unwrap with `getCause()` before `instanceof` checks. `future.join()` throws `CompletionException`; `future.get()` throws checked `ExecutionException` — same cause, different wrapper. Wrap-check must handle both raw and wrapped: an exception thrown *directly inside* a stage's lambda may arrive unwrapped to the next handler, while one propagated from an earlier stage arrives wrapped. Defensive unwrap:

```java
static Throwable unwrap(Throwable t) {
    return (t instanceof CompletionException || t instanceof ExecutionException)
            && t.getCause() != null ? t.getCause() : t;
}
```

### 2.2 Placement matters

Error operators handle failures from stages **above them only**. `f.thenApply(a).exceptionally(e -> fallback).thenApply(b)` — the `exceptionally` rescues failures of `f` and `a`; a failure in `b` flows past it downstream. Putting `exceptionally` at the end = global catch; after each risky stage = per-step recovery.

### 2.3 Which thread runs the handler?

Same rules as any stage: non-`Async` variants run on the thread that completed the previous stage (or the caller if already complete); `exceptionallyAsync`/`handleAsync` hop to a pool (`ForkJoinPool.commonPool()` or your executor). Don't put blocking recovery I/O in a non-async handler on someone else's thread.

### 2.4 Fan-in failures

`CompletableFuture.allOf(f1, f2, f3)` fails as soon as *any* input fails — but the other futures **keep running** (no auto-cancellation, unlike some Promise libraries). The `allOf` future's exception is the first failure; others are only visible on their own futures. `anyOf` completes with the first *outcome* — even if that first outcome is a failure while others would have succeeded.

---

## 3. The Node.js / NestJS Bridge

- Mapping you already know: `exceptionally` ≈ `.catch`, `handle` ≈ two-arg `.then`, `whenComplete` ≈ `.finally` with access to the result, `CompletableFuture.failedFuture(e)` ≈ `Promise.reject(e)`.
- **Where the comparison breaks down:**
  - **No unhandled-rejection safety net.** Node prints unhandled rejections; a CompletableFuture chain with no error operator and no `join()` fails in total silence — same trap as note 16's Future.
  - **Wrapping**: Promises hand you the original error; CompletableFuture hands you `CompletionException`-wrapped causes — every `instanceof` check needs unwrapping first.
  - **Threads**: `.then` in Node always runs on the one event loop; here each stage may run on a different thread — recovery code touching shared state needs the same thread-safety care as any concurrent code.

---

## 4. Production-Grade Code

```java
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ProductPageService {

    private final ExecutorService ioPool = Executors.newFixedThreadPool(16);

    record Price(String sku, long cents) {}
    record Reviews(String sku, double avgRating) {}
    record ProductPage(Price price, Reviews reviews) {}

    /** Two remote calls; reviews are optional (fallback), price is mandatory (propagate). */
    public CompletableFuture<ProductPage> loadPage(String sku) {
        CompletableFuture<Price> price = CompletableFuture
                .supplyAsync(() -> fetchPrice(sku), ioPool)
                .orTimeout(2, TimeUnit.SECONDS);            // fails the future with TimeoutException

        CompletableFuture<Reviews> reviews = CompletableFuture
                .supplyAsync(() -> fetchReviews(sku), ioPool)
                .completeOnTimeout(new Reviews(sku, 0.0), 500, TimeUnit.MILLISECONDS)
                .exceptionally(ex -> {                       // reviews are non-critical → degrade
                    log("reviews degraded for " + sku + ": " + unwrap(ex).getMessage());
                    return new Reviews(sku, 0.0);
                });

        return price.thenCombine(reviews, ProductPage::new)
                    .whenComplete((page, ex) -> {            // observe-only: metrics + logging
                        if (ex != null) log("page load failed for " + sku + ": " + unwrap(ex));
                    });
        // no exceptionally at the end: a price failure MUST propagate to the caller
    }

    static Throwable unwrap(Throwable t) {
        return t instanceof CompletionException && t.getCause() != null ? t.getCause() : t;
    }

    private Price fetchPrice(String sku) { return new Price(sku, 4999); }
    private Reviews fetchReviews(String sku) { return new Reviews(sku, 4.6); }
    private void log(String msg) { System.err.println(msg); }
}
```

Design encoded: optional dependency degrades via `exceptionally`; mandatory dependency propagates; `whenComplete` observes both without altering either; timeouts via `orTimeout` (fail) vs `completeOnTimeout` (default value).

---

## 5. Top 3 MNC Interview Questions

**Q1: `exceptionally` vs `handle` vs `whenComplete`?**
- **What they're testing:** the recover-vs-observe distinction.
- **Ideal answer:** "`exceptionally` runs only on failure and substitutes a recovery value — the async catch. `handle` always runs, gets `(value, exception)`, and its return replaces the outcome either way. `whenComplete` also sees both but can't change the result — pure observation for logging and metrics; the original value or failure continues downstream."

**Q2: What exception type do you actually receive, and how do you check its type?**
- **What they're testing:** the CompletionException wrapping trap.
- **Ideal answer:** "Usually `CompletionException` wrapping the real cause — `join()` throws that too, while `get()` throws checked `ExecutionException` with the same cause. So type checks must unwrap via `getCause()` first, and defensively, because an exception thrown directly in the previous stage's lambda can arrive unwrapped while a propagated one arrives wrapped."

**Q3: One input of `allOf` fails — what happens to the rest?**
- **What they're testing:** fan-in semantics.
- **Ideal answer:** "`allOf` completes exceptionally with that first failure, but the other futures keep running — there's no automatic cancellation. If the others' failures matter, I have to inspect each future individually; if their work should stop, I have to cancel them explicitly."

---

## Memorize this

> **Failure skips value-stages until an error-aware stage: `exceptionally` recovers, `handle` transforms both cases, `whenComplete` only observes — and everything arrives wrapped in `CompletionException`, so unwrap before checking types; a chain nobody joins fails in silence.**

*Next: [18 — cost of exceptions](18-cost-of-exceptions.md).*
