# The Cost of Exceptions — fillInStackTrace and Hot Paths

> **Priority: Interview-critical** — full deep-dive below. THE "senior signal" performance question on exceptions.

---

## 1. Core Mechanism

- Three separately-priced operations: **entering a try** (free), **creating** an exception (expensive), **throwing** it (moderately expensive).
- The dominant cost is **creation**: the `Throwable` constructor calls `fillInStackTrace()`, which walks the *entire* current call stack and records every frame. Cost scales with stack depth — in a Spring app, easily 100+ frames.
- **Why it matters:** this is the technical reason behind "don't use exceptions for control flow". A parse-failure exception in a tight loop can be ~1000× slower than an `if` check.

> **Interview definition (say this out loud):**
> "The try block itself is free — it's just an exception-table entry consulted only on a throw. The real cost is constructing the exception: `fillInStackTrace()` captures every stack frame, so cost grows with stack depth. Throwing adds stack unwinding. That's why exceptions must stay exceptional, not be a return mechanism."

---

## 2. Under the Hood

### 2.1 Why `try` is free

The compiler emits an **exception table** per method — `(from_pc, to_pc, handler_pc, type)` entries mapping bytecode ranges to handlers. No instructions execute on the happy path; the table is consulted only when something is thrown. (Caveat for completeness: a try block can constrain some JIT optimizations across its boundary, but that's noise compared to throw costs.)

### 2.2 Where creation cost goes

`fillInStackTrace()` is a native call that walks the thread's stack and stores frame data (class, method, bytecode index) inside the `Throwable`; the `StackTraceElement[]` objects you see are materialized lazily on first `getStackTrace()`/print. Deeper stack → linearly more work. Creating an exception at 100 frames depth ≈ hundreds of times the cost of a plain object allocation.

### 2.3 The throw itself: unwinding

`athrow` → JVM checks the current method's exception table → no match → pop frame, repeat in caller. Deep unwinding also defeats inlining-based optimizations along the way. Moderately expensive, but usually dwarfed by creation.

### 2.4 The two escape hatches

| Technique | What it does | Where you meet it |
|---|---|---|
| **`OmitStackTraceInFastThrow`** (JIT, on by default) | A built-in exception (NPE, ClassCast…) thrown very often from the same hot compiled code gets replaced by a **pre-allocated, trace-less singleton** | Production logs showing `NullPointerException` with *no stack frames* — the trace isn't missing, it was optimized away; earliest occurrences in the log still have it. Disable: `-XX:-OmitStackTraceInFastThrow` |
| **Override `fillInStackTrace()` / super-constructor flag** | Custom exception skips trace capture entirely (`super(msg, cause, true, /*writableStackTrace*/ false)`) | Libraries using exceptions as internal signals (e.g., Scala's control-flow exceptions, some parsers) — near-plain-object cost |

### 2.5 What "exceptional use" means in numbers

Rough orders of magnitude (JMH-style folk numbers, good enough for interviews): plain object allocation ~ns; exception creation with deep stack ~µs; an `if`-check alternative ~sub-ns. A validation loop over a million inputs using catch-as-check turns microseconds into seconds.

---

## 3. The Node.js / NestJS Bridge

- V8 has the same shape: `new Error()` captures the stack at construction (`Error.captureStackTrace`), capped by `Error.stackTraceLimit` (default 10 frames). Java captures the *whole* stack by default — deeper and pricier.
- Node folklore "don't throw in hot paths" exists for the same reason; Java adds the JIT fast-throw wrinkle (trace-less singletons) that Node has no equivalent for.
- **Where the comparison breaks down:** in Node you can globally cheapen errors (`Error.stackTraceLimit = 0`); in Java the knob is per-exception-class (the `writableStackTrace` constructor flag), which is cleaner — you cheapen only the control-flow signals, never real errors.

---

## 4. Production-Grade Code

```java
import java.util.Optional;

public class SkuParser {

    /** ❌ Exception as control flow: creation cost paid on EVERY malformed input. */
    public static boolean isValidSkuSlow(String raw) {
        try {
            Integer.parseInt(raw.substring(4));
            return true;
        } catch (NumberFormatException | IndexOutOfBoundsException e) {
            return false;                      // trace captured, then thrown away — pure waste
        }
    }

    /** ✅ Check-first: same semantics, ~1000× cheaper on the failure path. */
    public static boolean isValidSku(String raw) {
        if (raw == null || raw.length() < 5) return false;
        for (int i = 4; i < raw.length(); i++) {
            if (!Character.isDigit(raw.charAt(i))) return false;
        }
        return true;
    }

    /** ✅ Expected-absence modeled as Optional, not as an exception. */
    public static Optional<Integer> parseSkuNumber(String raw) {
        return isValidSku(raw) ? Optional.of(Integer.parseInt(raw.substring(4)))
                               : Optional.empty();
    }

    /** Trace-less exception for internal signaling ONLY — near-plain-object cost. */
    static final class ParseAbort extends RuntimeException {
        ParseAbort(String msg) {
            super(msg, null, /*enableSuppression*/ false, /*writableStackTrace*/ false);
        }
    }
}
```

Decision rule encoded: expected failure → `boolean`/`Optional`/result object; unexpected failure → real exception with full trace (debuggability is worth microseconds); high-frequency internal signal → trace-less exception, used sparingly and documented.

---

## 5. Top 3 MNC Interview Questions

**Q1: Are exceptions expensive in Java? Break down where the cost is.**
- **What they're testing:** whether you can go past "yes, slow" to the three-part answer.
- **Ideal answer:** "Try blocks are free — just exception-table metadata checked only on a throw. Creation is the expensive part: `fillInStackTrace()` walks and records every frame, scaling with stack depth. The throw adds stack unwinding. So the rule is about *frequency*: a rare exception is irrelevant; one per loop iteration is a performance bug."

**Q2: Production shows `NullPointerException` with no stack trace — what happened?**
- **What they're testing:** real-war-story knowledge of fast-throw.
- **Ideal answer:** "The JIT's `OmitStackTraceInFastThrow`: an implicit exception thrown repeatedly from the same hot compiled code gets replaced with a pre-allocated singleton without a trace. The first occurrences in the logs — before the method got hot — still carry the full trace, so scroll back in time; or disable the optimization with `-XX:-OmitStackTraceInFastThrow` temporarily."

**Q3: How would you make an exception cheap if you HAD to throw it frequently?**
- **What they're testing:** knowledge of the `writableStackTrace` escape hatch plus the judgment that it's a last resort.
- **Ideal answer:** "Use the four-arg `Throwable` constructor with `writableStackTrace=false` — skips `fillInStackTrace()` entirely, making it a near-plain object. Some frameworks do this for control-flow signals. But first I'd challenge the design: frequent expected outcomes should be `Optional`, booleans, or result objects — a trace-less exception is still a goto in disguise."

---

## Memorize this

> **`try` is free (exception-table metadata); creating the exception is the cost (`fillInStackTrace()` scales with stack depth); trace-less NPEs in production = JIT fast-throw. Expected outcomes get `Optional`/booleans — exceptions stay exceptional.**

*Next: [19 — Error types you'll actually meet](19-error-types-oome-sofe.md).*
