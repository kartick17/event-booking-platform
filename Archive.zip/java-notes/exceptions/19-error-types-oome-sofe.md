# Error Types You'll Actually Meet — OutOfMemoryError, StackOverflowError & Friends

> **Priority: Dev-important, Interview-light** — short notes; know what each means and what to DO, not internals trivia.

`Error` = the JVM or its resources are broken. You don't catch these in business code — you diagnose and fix the cause.

| Error | Means | Usual cause | What to do |
|---|---|---|---|
| `OutOfMemoryError: Java heap space` | Heap exhausted | Memory leak (collections that only grow, unbounded caches), or genuinely undersized heap | Heap dump (`-XX:+HeapDumpOnOutOfMemoryError`), analyze with Eclipse MAT; raise `-Xmx` only if it's real load |
| `OutOfMemoryError: Metaspace` | Class-metadata space full | Classloader leak — common with hot-redeploy on app servers, dynamic proxy/bytecode generation gone wild | Find the leaking classloader; `-XX:MaxMetaspaceSize` only delays it |
| `OutOfMemoryError: unable to create native thread` | OS refused a new thread | Thread leak — pools created per-request and never shut down | Count threads (`jstack`); fix pool lifecycle. Note: heap can be nearly empty when this fires |
| `OutOfMemoryError: GC overhead limit exceeded` | GC runs constantly, reclaims almost nothing | Heap almost-full-but-not-quite — same causes as heap space | Treat exactly like heap space |
| `StackOverflowError` | One thread's stack full | Unbounded recursion (often accidental: `toString()`/`equals()` cycles between two classes, JSON serialization of cyclic object graphs) | Fix the recursion; `-Xss` raises stack size only for legitimately deep algorithms |
| `NoClassDefFoundError` | Class was there at compile time, missing/failed at runtime | Dependency missing from the runtime classpath; OR the class's static initializer threw earlier (first failure shows as `ExceptionInInitializerError`, later loads as NoClassDefFound) | Check packaging first; then check logs for an earlier initializer failure |
| `ExceptionInInitializerError` | A `static {}` block or static field init threw | Config read/DB call in a static initializer failed | Read its `getCause()` — the real exception is inside |
| `AssertionError` | An `assert` failed (only with `-ea` enabled) | Broken invariant | It's a bug — fix the logic |

**Why you don't catch `OutOfMemoryError`:** by the time it's thrown, allocations are failing — your recovery code may itself need memory and die half-way, leaving corrupted state. The one acceptable pattern: a top-level handler that attempts a log line and exits, letting the orchestrator (Kubernetes, systemd) restart the process. Same logic for `StackOverflowError` — the thread's stack is unusable.

**Difference from Node:** Node just dies on OOM ("JavaScript heap out of memory") with no catchable hook; Java *lets* you catch it, and knowing you shouldn't is the interview point. Java also gives you the diagnostic ecosystem — heap dumps, `jstack`, MAT — Node's equivalent (`--heapsnapshot-signal`) is younger and less standard.

**One interview question:**
**Q: `ClassNotFoundException` vs `NoClassDefFoundError`?**
**A:** "`ClassNotFoundException` is a checked exception from *reflective* loading — `Class.forName` with a name that isn't on the classpath. `NoClassDefFoundError` is an `Error`: the class existed at compile time but can't be loaded at runtime — missing dependency, or its static initializer already failed once."

*Next: [20 — @ControllerAdvice global exception handling](20-controlleradvice-global-exception-handling.md).*
