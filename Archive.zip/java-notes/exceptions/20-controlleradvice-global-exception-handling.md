# Global Exception Handling — @ControllerAdvice + @ExceptionHandler

> **Priority: Interview-critical** — full deep-dive below. Every Spring Boot interview touches this.

---

## 1. Core Mechanism

- `@ControllerAdvice` marks a class whose `@ExceptionHandler` methods apply to **all** controllers — one global place where exceptions become HTTP responses. `@RestControllerAdvice` = the same + `@ResponseBody` (return values serialize to JSON).
- `@ExceptionHandler(SomeException.class)` marks a method that handles that exception type (and its subclasses) after any controller throws it.
- **Why:** controllers should throw domain exceptions (`OrderNotFoundException`) and never mention HTTP. One advice class owns the exception→status→body mapping and is the single place that logs. Without it, every controller repeats try/catch — the JS-equivalent of a NestJS global exception filter.

> **Interview definition (say this out loud):**
> "`@ControllerAdvice` is Spring's global exception boundary: exceptions thrown from any controller are routed to the matching `@ExceptionHandler` method, which turns them into a proper HTTP response. Matching picks the most specific handler by exception type, and it's the one place in the app that logs failures."

---

## 2. Under the Hood

### 2.1 Where in the pipeline it fires

Request flow: Filter chain → `DispatcherServlet` → interceptors → controller. When the controller (or argument binding/validation before it) throws, `DispatcherServlet` catches and consults its **`HandlerExceptionResolver`** chain. The relevant resolver, `ExceptionHandlerExceptionResolver`, looks up `@ExceptionHandler` methods — first on the throwing controller itself, then across `@ControllerAdvice` beans.

**Boundary consequence:** exceptions thrown in **filters** (e.g., a JWT filter) never reach the DispatcherServlet's resolvers — `@ControllerAdvice` can't catch them. That's why Spring Security has its own `AuthenticationEntryPoint`/`AccessDeniedHandler`. Standard trap question.

### 2.2 Handler matching

- Most specific exception type wins: a handler for `OrderNotFoundException` beats one for `RuntimeException`.
- Cause unwrapping: if no handler matches the thrown type, Spring tries the exception's *cause*.
- Advice ordering across multiple advice classes via `@Order`; scope can be narrowed: `@ControllerAdvice(basePackages = "...", annotations = ..., assignableTypes = ...)`.

### 2.3 The pre-controller exceptions you must map

Failures *before* your code runs also route here — this is what separates a polished API from a default-500 one:

| Exception | When | Right status |
|---|---|---|
| `MethodArgumentNotValidException` | `@Valid` body failed (note 25) | 400 |
| `HttpMessageNotReadableException` | Malformed/unparseable JSON | 400 |
| `MethodArgumentTypeMismatchException` | `/orders/abc` where `{id}` is Long | 400 |
| `MissingServletRequestParameterException` | Required query param absent | 400 |
| `HttpRequestMethodNotSupportedException` | POST to GET-only route | 405 |
| `NoResourceFoundException` | No route matched | 404 |

Shortcut: extend **`ResponseEntityExceptionHandler`** — a Spring base class with all these pre-wired; override the pieces you want to customize.

### 2.4 What a handler method can receive/return

Parameters injectable: the exception, `HttpServletRequest`/`WebRequest`, `Locale`, etc. Returns: `ResponseEntity<T>` (full control), `ProblemDetail` (note 22), a POJO (+`@ResponseStatus` on the method), or a view name in MVC apps.

---

## 3. The Node.js / NestJS Bridge

| Concept | NestJS | Spring |
|---|---|---|
| Global mapping | Exception filter (`@Catch()`, `useGlobalFilters`) | `@RestControllerAdvice` |
| Per-type handling | `@Catch(NotFoundException)` | `@ExceptionHandler(OrderNotFoundException.class)` |
| Built-in HTTP exceptions | `NotFoundException`, `BadRequestException` thrown from services | `ResponseStatusException` (note 21) |
| Express equivalent | `app.use((err, req, res, next) => …)` last-middleware | `HandlerExceptionResolver` chain |

**Where the comparison breaks down:** NestJS filters catch exceptions from guards and middleware too; Spring's advice does NOT see filter-chain exceptions (security lives outside). And NestJS encourages throwing HTTP exceptions from services; in Spring the idiom is domain exceptions from services, HTTP mapping only in the advice — cleaner layering.

---

## 4. Production-Grade Code

```java
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /** Domain exception → 404. Controller never mentions HTTP. */
    @ExceptionHandler(OrderNotFoundException.class)
    public ProblemDetail orderNotFound(OrderNotFoundException e) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, e.getMessage());
        pd.setTitle("Order not found");
        pd.setProperty("orderId", e.orderId());
        return pd;                                   // client mistake: no error-log, maybe debug
    }

    /** Validation failure → 400 with per-field errors (note 25 has the full version). */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail invalidBody(MethodArgumentNotValidException e) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        pd.setProperty("errors", e.getBindingResult().getFieldErrors().stream()
                .map(f -> f.getField() + ": " + f.getDefaultMessage())
                .toList());
        return pd;
    }

    /** Catch-all LAST: specific handlers above win. The ONLY place that error-logs. */
    @ExceptionHandler(Exception.class)
    public ProblemDetail unexpected(Exception e) {
        log.error("Unhandled exception", e);          // full stack trace, once, here
        var pd = ProblemDetail.forStatusAndDetail(
                HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected error occurred");
        return pd;                                    // NEVER leak e.getMessage() on 500s
    }
}

class OrderNotFoundException extends RuntimeException {
    private final String orderId;
    OrderNotFoundException(String orderId) {
        super("Order not found: " + orderId);
        this.orderId = orderId;
    }
    String orderId() { return orderId; }
}
```

Rules encoded: 4xx = client's problem, log at debug or not at all; 5xx = our problem, full trace logged, generic message returned (internal details never leak to clients).

---

## 5. Top 3 MNC Interview Questions

**Q1: How does Spring route an exception from a controller to your handler?**
- **What they're testing:** pipeline knowledge, not annotation recall.
- **Ideal answer:** "`DispatcherServlet` catches whatever the handler chain throws and runs its `HandlerExceptionResolver`s; `ExceptionHandlerExceptionResolver` finds the best `@ExceptionHandler` — controller-local ones first, then `@ControllerAdvice` beans — choosing the most specific exception type, unwrapping causes if nothing matches directly. The handler's return value is rendered as the response."

**Q2: Why doesn't your `@ControllerAdvice` catch exceptions from your security filter?**
- **What they're testing:** the filter-vs-servlet boundary.
- **Ideal answer:** "Filters run before the `DispatcherServlet`, and the advice mechanism lives inside the DispatcherServlet's resolver chain — an exception in a filter never reaches it. Security failures are handled by Spring Security's own hooks: `AuthenticationEntryPoint` for 401s and `AccessDeniedHandler` for 403s; or you re-dispatch to a controller via `HandlerExceptionResolver` injected into the filter."

**Q3: Where do you log — service, controller, or advice?**
- **What they're testing:** operational maturity.
- **Ideal answer:** "Once, in the advice. Services throw enriched domain exceptions with causes; nothing in between logs-and-rethrows, or every incident appears five times. In the advice: 5xx gets the full stack trace and a generic client message; 4xx is the client's mistake — at most debug level, and no internal details in either case."

---

## Memorize this

> **`@RestControllerAdvice` = the app's exception→HTTP boundary inside DispatcherServlet's resolver chain — most-specific handler wins, filters are outside its reach, 5xx logs the trace + returns a generic body, 4xx returns detail + skips the error log.**

*Next: [21 — ResponseStatusException](21-responsestatusexception.md).*
