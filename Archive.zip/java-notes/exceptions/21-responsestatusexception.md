# ResponseStatusException and @ResponseStatus

> **Priority: Dev-important, Interview-light** — short notes; know when to use which of the three mapping styles.

Three ways to map an exception to an HTTP status — in order of preference for real projects:

**1. `@ControllerAdvice` handler (note 20) — the default choice.**
Domain exception stays HTTP-free; mapping lives in one place. Use for anything reused across endpoints.

**2. `@ResponseStatus` on a custom exception — quick and static.**

```java
@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Order not found")
public class OrderNotFoundException extends RuntimeException { ... }
```

- Declarative, zero handler code. Costs: the exception class is now coupled to HTTP (annotation on a domain class), status is fixed at compile time, and the response body is the servlet-container default error page/JSON — no custom body. Also fine on an `@ExceptionHandler` *method* instead of the exception class.

**3. `ResponseStatusException` — throw status inline, no custom class.**

```java
@GetMapping("/orders/{id}")
public Order get(@PathVariable String id) {
    return repo.findById(id)
        .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Order not found: " + id));
}
```

- Spring 5+. Good for one-off cases, prototypes, small controllers — the NestJS feel (`throw new NotFoundException(...)`).
- Costs: HTTP leaks into wherever you throw it (never throw it from services — that couples the service layer to the web layer), scattered status decisions, no type to catch specifically, and `reason`/`message` handling differs from your ProblemDetail format — inconsistent error bodies unless you also map it in the advice.

**Rule of thumb:** services throw domain exceptions → advice maps them (style 1). `ResponseStatusException` only inside controllers for cases too trivial to deserve a class. `@ResponseStatus` for simple apps or as metadata on handler methods.

**One interview question:**
**Q: Why not just throw `ResponseStatusException` everywhere like NestJS's HttpException?**
**A:** "It couples every layer to HTTP. A service throwing 404s can't be reused by a Kafka consumer or a scheduled job — those have no HTTP status. Domain exceptions from services, HTTP mapping once in the advice, keeps the layers independent."

*Next: [22 — Problem Details, RFC 7807](22-problem-details-rfc7807.md).*
