# Error Response Design — Problem Details (RFC 7807 / RFC 9457)

> **Priority: Dev-important, Interview-light** — short notes; this is API-design hygiene interviewers appreciate but rarely drill.

- **Problem Details** = the IETF standard JSON shape for HTTP error bodies (RFC 7807, updated as RFC 9457). Instead of every team inventing `{ "error": ... }` vs `{ "message": ... }`, one predictable format with content type **`application/problem+json`**:

```json
{
  "type": "https://api.shop.com/problems/insufficient-stock",
  "title": "Insufficient stock",
  "status": 409,
  "detail": "Requested 5 units of SKU-123, only 2 available",
  "instance": "/api/orders",
  "sku": "SKU-123",
  "available": 2
}
```

- Fields: `type` (URI identifying the *kind* of problem — machine-readable, ideally resolves to docs), `title` (short human summary, stable per type), `status` (mirrors HTTP status), `detail` (this occurrence's specifics), `instance` (which request), plus **any custom extension fields** (`sku`, `available`, `errors[]`…).
- Clients switch on `type` (stable contract), humans read `detail`. That's the whole idea.

**Spring support (Spring 6 / Boot 3) — built in:**

- `ProblemDetail` class: `ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, "…")`, custom fields via `setProperty("sku", …)`. Return it straight from an `@ExceptionHandler` — Spring sets `application/problem+json` (see note 20's code).
- `ErrorResponseException`: a throwable that *carries* a ProblemDetail.
- Set `spring.mvc.problemdetails.enabled=true` and Spring's own pre-controller errors (400s, 405s…) come out as Problem Details automatically.

**Design rules:**
- One error shape for the WHOLE API — including validation errors (an `errors` extension array, note 25) and 500s.
- 500s: generic detail only ("An unexpected error occurred") — internal messages, class names, and stack traces never leak into the body. Include a correlation ID extension so support can find the log line.
- Keep `title` constant per `type`; vary only `detail`. Clients key logic off `type`/`status`, never parse `detail`.

**Node bridge:** you've probably hand-built `{ statusCode, message, error }` in NestJS — that's its default trio. Problem Details is the standardized version; NestJS needs a library/interceptor for it, Spring Boot 3 ships it.

**One interview question:**
**Q: How do you design error responses for a public REST API?**
**A:** "RFC 7807 Problem Details — Spring Boot 3 has it built in as `ProblemDetail`. Machine-readable `type` URI per error kind, human `detail` per occurrence, extension fields for structured data like field errors, one consistent shape across the whole API, and generic bodies with a correlation ID for 500s so nothing internal leaks."

*Next: [23 — Spring's exception translation](23-spring-dataaccessexception-translation.md).*
