# Spring's Exception Translation — DataAccessException over JDBC/Hibernate

> **Priority: Interview-critical** — full deep-dive below. Ties your jdbc/ and jpa/ notes together.

---

## 1. Core Mechanism

- Spring converts every persistence failure — JDBC's checked `SQLException`, Hibernate's `HibernateException`, JPA's `PersistenceException` — into one **unchecked, vendor-neutral hierarchy** rooted at `DataAccessException`.
- **Why:**
  1. `SQLException` is checked → would infect every layer's signatures (note 03).
  2. `SQLException` is opaque — the real meaning hides in vendor-specific error codes (`getErrorCode()`, `getSQLState()`); Postgres and Oracle use different codes for "duplicate key". Spring translates codes into *meaningfully named* exceptions.
  3. Vendor-neutral: switch Postgres→Oracle, your catch blocks still work.

> **Interview definition (say this out loud):**
> "Spring translates checked, vendor-specific `SQLException`s and Hibernate exceptions into one unchecked `DataAccessException` hierarchy — so a duplicate key is a `DuplicateKeyException` whether it came from Postgres or Oracle, no layer is forced to declare throws, and only the layer that can react catches."

---

## 2. Under the Hood

### 2.1 The translation machinery

- **JDBC path (`JdbcTemplate`):** every `SQLException` goes through a `SQLExceptionTranslator`. Default: `SQLErrorCodeSQLExceptionTranslator` — looks up the vendor error code in `sql-error-codes.xml` (per-database mappings shipped inside spring-jdbc); falls back to SQL-state-based translation.
- **JPA/Hibernate path:** the `@Repository` annotation makes the bean eligible for a **`PersistenceExceptionTranslationPostProcessor`**, which wraps it in a proxy; the proxy catches `PersistenceException`/`HibernateException` and runs them through `PersistenceExceptionTranslator`. **This is the actual technical meaning of `@Repository`** — it's not just documentation; the classic interview nugget.
- **Spring Data JPA repositories:** translation is built into the repository proxy — you get `DataAccessException` subclasses automatically.

### 2.2 The hierarchy — the subclasses worth knowing

| Exception | Meaning | Typical trigger |
|---|---|---|
| `DuplicateKeyException` | Unique constraint violated | Insert with existing unique value — catch this for "email already registered" |
| `DataIntegrityViolationException` | Any constraint broken (parent of the above) | FK violation, NOT NULL, check constraint |
| `OptimisticLockingFailureException` | Row changed under you | JPA `@Version` mismatch — retry or report conflict (HTTP 409) |
| `PessimisticLockingFailureException` / `CannotAcquireLockException` | Lock not obtainable / deadlock victim | `SELECT FOR UPDATE` contention |
| `QueryTimeoutException` | Statement exceeded timeout | Slow query + `@Transactional(timeout=…)` |
| `DataAccessResourceFailureException` | Can't reach the database | DB down, pool exhausted, network |
| `EmptyResultDataAccessException` | Expected ≥1 row, got 0 | `JdbcTemplate.queryForObject`, old `getById` misses |
| `IncorrectResultSizeDataAccessException` | Expected 1 row, got many | Non-unique lookup |
| `TransientDataAccessException` (branch) | **Retryable** — same call may succeed later | Deadlock, timeout, connection blip |
| `NonTransientDataAccessException` (branch) | **Don't retry** — same call fails again | Bad SQL, constraint violation |

The transient/non-transient split is the hierarchy's hidden gem: retry logic can catch `TransientDataAccessException` generically instead of enumerating deadlock/timeout types.

### 2.3 Interplay with @Transactional

Translation happens at the repository proxy; the translated unchecked exception then flies through the service and — being a `RuntimeException` — **triggers rollback** in the `@Transactional` interceptor by default (note 24). The two mechanisms compose: translate at the data layer, roll back at the transaction boundary, map to HTTP at the advice.

---

## 3. The Node.js / NestJS Bridge

- Raw `pg` in Node gives you `error.code === '23505'` for unique violations — you've probably written that string check. `DuplicateKeyException` IS that check, done once by the framework, for every vendor.
- TypeORM/Prisma partially do this (`PrismaClientKnownRequestError` with `code: 'P2002'`) — but you still switch on codes; Spring gives you a *type* per meaning, so the catch block is the switch.
- **Where the comparison breaks down:** Node ORMs translate their own errors only; Spring's translation is uniform across raw JDBC, JPA, and any `@Repository`-annotated custom DAO — one hierarchy regardless of access technology.

---

## 4. Production-Grade Code

```java
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class CustomerRegistrationService {

    private final CustomerRepository repository;

    public CustomerRegistrationService(CustomerRepository repository) {
        this.repository = repository;
    }

    /** Vendor-neutral catch: works identically on Postgres, MySQL, Oracle. */
    public Customer register(String email, String name) {
        try {
            return repository.save(new Customer(email, name));
        } catch (DuplicateKeyException e) {
            // constraint violation translated into a MEANING — map to domain exception
            throw new EmailAlreadyRegisteredException(email, e);
        }
    }

    /** The transient branch = generically retryable. */
    public Customer updateWithRetry(Customer customer) {
        for (int attempt = 1; ; attempt++) {
            try {
                return repository.save(customer);
            } catch (OptimisticLockingFailureException | TransientDataAccessException e) {
                if (attempt >= 3) throw e;
            }
        }
    }

    // --- collaborators, minimal for the snippet ---
    public record Customer(String email, String name) {}
    public interface CustomerRepository { Customer save(Customer c); }
    public static class EmailAlreadyRegisteredException extends RuntimeException {
        EmailAlreadyRegisteredException(String email, Throwable cause) {
            super("Email already registered: " + email, cause);
        }
    }
}
```

The advice layer (note 20) then maps `EmailAlreadyRegisteredException` → 409. Full chain: Postgres error 23505 → `SQLException` → `DuplicateKeyException` → domain exception → HTTP 409 — each layer speaking its own language, causes preserved throughout.

---

## 5. Top 3 MNC Interview Questions

**Q1: Why does Spring wrap `SQLException` into unchecked exceptions?**
- **What they're testing:** checked-exception economics in layered systems.
- **Ideal answer:** "Three reasons. Checked `SQLException` would force every layer to declare or catch it, coupling everything to JDBC. Its real meaning hides in vendor-specific error codes, so Spring translates codes into named types like `DuplicateKeyException` — vendor-neutral and readable. And most DB failures aren't recoverable at the call site, which is exactly the case where unchecked is right — only the boundary that can react handles it."

**Q2: What does `@Repository` actually DO, technically?**
- **What they're testing:** whether you know it's more than a stereotype label.
- **Ideal answer:** "Besides marking the bean for component scanning, it activates persistence exception translation: `PersistenceExceptionTranslationPostProcessor` wraps the bean in a proxy that catches JPA and Hibernate exceptions and rethrows them as `DataAccessException` subclasses. `@Service` and `@Component` don't do that — it's the one stereotype annotation with real behavior attached."

**Q3: How would you implement retry for database deadlocks cleanly?**
- **What they're testing:** knowledge of the transient/non-transient split.
- **Ideal answer:** "Catch `TransientDataAccessException` — Spring's hierarchy splits into transient, meaning the same call may succeed on retry (deadlock victim, timeout, connection blip), and non-transient, meaning don't bother (bad SQL, constraint violation). So one catch covers all retryable cases; in practice I'd use Spring Retry's `@Retryable(retryFor = TransientDataAccessException.class)` — and make sure the retry re-runs the whole transaction, not just the statement."

---

## Memorize this

> **`@Repository` = proxy that translates vendor `SQLException`/Hibernate errors into the unchecked `DataAccessException` hierarchy — named meanings (`DuplicateKeyException`), vendor-neutral, split into transient (retry) vs non-transient (don't).**

*Next: [24 — exceptions and @Transactional rollback](24-transactional-rollback-rules.md).*
