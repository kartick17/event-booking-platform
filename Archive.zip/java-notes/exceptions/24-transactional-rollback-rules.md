# Exceptions and @Transactional — Which Exceptions Roll Back

> **Priority: Interview-critical** — full deep-dive below. Top-5 Spring interview question, and a real production-bug factory.

---

## 1. Core Mechanism

- The default rule: **`@Transactional` rolls back on unchecked exceptions (`RuntimeException` and `Error`) — NOT on checked exceptions.** A checked exception escaping a transactional method **commits** the transaction.
- Override per method: `@Transactional(rollbackFor = Exception.class)` — or `noRollbackFor` to exempt specific unchecked types.
- **Why this default:** it's the EJB-inherited convention — checked exceptions were meant to be *expected, recoverable business outcomes* ("insufficient funds" — the work done so far might still be valid), unchecked meant *bugs* (state is suspect, undo everything). Modern code rarely honors that theory, which is exactly why the default bites people.

> **Interview definition (say this out loud):**
> "By default Spring rolls back only on `RuntimeException` and `Error`. A checked exception escaping the method commits whatever happened before it — the classic partial-commit bug. `rollbackFor = Exception.class` overrides it; and the check happens in the transaction proxy, so an exception caught inside the method never triggers rollback at all — though it may already have been marked rollback-only underneath."

---

## 2. Under the Hood

### 2.1 Where the decision happens

`@Transactional` works via an AOP proxy (ties into your `jdbc/13` bean-lifecycle note): `TransactionInterceptor` wraps the method — begin → invoke → commit, with `catch (Throwable t)` consulting **`rollbackOn(t)`**: instanceof `RuntimeException` or `Error` → rollback; otherwise → commit; `rollbackFor`/`noRollbackFor` adjust the check. The decision is made **only on exceptions that cross the proxy boundary.**

Consequences (each is an interview trap):

- **Caught inside = no rollback decision.** `try { … } catch (Exception e) { log; }` inside the transactional method → interceptor sees normal return → commit.
- **Self-invocation bypasses everything.** `this.otherTransactionalMethod()` doesn't pass through the proxy — no new transaction, no rollback semantics for that call.
- **Thrown after the method returns** (e.g., in response serialization) → transaction already committed.

### 2.2 The rollback-only trap — `UnexpectedRollbackException`

Inner `@Transactional(propagation = REQUIRED)` method throws `RuntimeException` → its interceptor marks the **shared** transaction **rollback-only** → outer method *catches* the exception thinking it handled it → outer interceptor tries to commit → finds the rollback-only flag → throws **`UnexpectedRollbackException`**. You "handled" the exception, the transaction died anyway, and the caller gets a confusing error. Fixes: don't catch what you can't recover, or give the inner method `REQUIRES_NEW` so its failure rolls back only its own transaction.

### 2.3 Rollback ≠ undo in memory

Rollback discards DB changes; **managed JPA entities keep their mutated Java state** — the persistence context is invalidated but your objects aren't reverted. Reusing such entities after catching = subtle corruption. Also: rollback can't un-send an email or un-call an external API — side effects need transactional outbox / compensation patterns.

### 2.4 Checked-exception commit in practice

```java
@Transactional
public void transfer(...) throws InsufficientFundsException {
    accountRepo.debit(from, amount);           // executed
    if (!hasFunds(to)) throw new InsufficientFundsException(); // checked → COMMITS the debit!
    accountRepo.credit(to, amount);
}
```

The debit persists. This single example is why many teams standardize on `rollbackFor = Exception.class` company-wide, or use only unchecked domain exceptions (note 10's advice composes here).

---

## 3. The Node.js / NestJS Bridge

- In Node you managed transactions explicitly: `await client.query('BEGIN')` … `catch { await client.query('ROLLBACK') }` — YOUR catch block decided, and any thrown error hit it. TypeORM's `dataSource.transaction(async em => …)` rolls back on **any** rejection — no checked/unchecked concept.
- **Where the comparison breaks down:** Java's checked/unchecked split creates a rollback distinction Node cannot express — *the surprise is that some exceptions commit*. And the proxy mechanics (self-invocation, catch-inside) have no Node equivalent since Node's transaction wrapper is an explicit function call you can't accidentally bypass.

---

## 4. Production-Grade Code

```java
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransferService {

    private final AccountRepository accounts;
    private final AuditWriter audit;

    public TransferService(AccountRepository accounts, AuditWriter audit) {
        this.accounts = accounts;
        this.audit = audit;
    }

    /** rollbackFor covers the checked exception — without it, a thrown
        InsufficientFundsException would COMMIT the debit. */
    @Transactional(rollbackFor = Exception.class)
    public void transfer(long fromId, long toId, long amountCents) throws InsufficientFundsException {
        accounts.debit(fromId, amountCents);
        if (accounts.balance(toId) < 0) {
            throw new InsufficientFundsException(fromId);
        }
        accounts.credit(toId, amountCents);
        audit.recordTransfer(fromId, toId, amountCents);   // REQUIRES_NEW: survives our rollback
    }

    public static class InsufficientFundsException extends Exception {
        InsufficientFundsException(long accountId) { super("Insufficient funds in " + accountId); }
    }

    public interface AccountRepository {
        void debit(long id, long cents);
        void credit(long id, long cents);
        long balance(long id);
    }

    @Service
    public static class AuditWriter {
        /** Own transaction: audit row commits even if the transfer rolls back.
            Its failure also doesn't mark the transfer rollback-only IF the caller catches. */
        @Transactional(propagation = Propagation.REQUIRES_NEW)
        public void recordTransfer(long from, long to, long cents) {
            // insert audit row
        }
    }
}
```

Note `AuditWriter` is a **separate bean** — as an inner call on `this`, `REQUIRES_NEW` would be silently ignored (self-invocation).

---

## 5. Top 3 MNC Interview Questions

**Q1: Which exceptions cause rollback by default, and how do you change it?**
- **What they're testing:** the core rule + the override.
- **Ideal answer:** "Unchecked only — `RuntimeException` and `Error`. Checked exceptions commit, which surprises everyone: throw a checked exception mid-method and everything before it persists. Override with `rollbackFor = Exception.class`, or exempt types with `noRollbackFor`. The decision runs in the transaction proxy, so only exceptions that escape the method count."

**Q2: You catch the exception inside the transactional method — does it roll back?**
- **What they're testing:** proxy-boundary understanding.
- **Ideal answer:** "No — the interceptor sees a normal return and commits. One nasty variant: if the exception came from an *inner* transactional method sharing the transaction, that inner proxy already marked it rollback-only, so my commit throws `UnexpectedRollbackException` — I 'handled' the exception but the transaction was already doomed. Fix: don't catch what you can't recover, or isolate the inner work with `REQUIRES_NEW`."

**Q3: Transaction rolled back — are your entity objects reverted too?**
- **What they're testing:** rollback scope beyond the DB.
- **Ideal answer:** "No. Rollback discards database changes; the in-memory entities keep their modified state and the persistence context is invalidated — reusing those objects afterward is a corruption risk. And non-DB side effects — emails, HTTP calls, messages — aren't undone either; those need an outbox pattern or compensation logic."

---

## Memorize this

> **Default rollback = unchecked only; checked exceptions COMMIT (fix: `rollbackFor = Exception.class`). Decision lives in the proxy — catch-inside commits, inner failure can mark rollback-only (`UnexpectedRollbackException`), and rollback never reverts entity objects or emails.**

*Next: [25 — validation exceptions](25-validation-exceptions.md).*
