# Validation Exceptions — MethodArgumentNotValidException & ConstraintViolationException

> **Priority: Dev-important, Interview-light** — short notes; the practical point is knowing WHICH exception fires WHERE, because they need separate handlers.

**The setup:** Bean Validation (Jakarta Validation, implemented by Hibernate Validator) — annotations like `@NotNull`, `@Size`, `@Email`, `@Positive` on fields/parameters; Spring triggers validation and throws when violated.

**The two exceptions and where each fires:**

| | `MethodArgumentNotValidException` | `ConstraintViolationException` |
|---|---|---|
| Fires when | `@Valid` on a **`@RequestBody` DTO** fails | `@Validated` on the **class** + constraints on **params/path vars/query params** fail; also service-layer method validation and JPA flush-time entity validation |
| Thrown by | Spring MVC argument binding (before your controller runs) | The validator engine itself |
| Extends | `Exception` (checked, Spring web type) | `RuntimeException` (Jakarta type) |
| Violations in | `getBindingResult().getFieldErrors()` | `getConstraintViolations()` |
| Default status | 400 automatically | **500 unless you map it** ← the gotcha |

The gotcha in bold is the practical takeaway: forget a `ConstraintViolationException` handler and a bad query param returns 500 instead of 400.

```java
@RestController
@Validated                              // enables param-level validation → ConstraintViolationException
class OrderController {

    @PostMapping("/orders")
    Order create(@Valid @RequestBody CreateOrderRequest req) { ... }   // body → MethodArgumentNotValidException

    @GetMapping("/orders")
    List<Order> list(@RequestParam @Min(1) int page) { ... }           // param → ConstraintViolationException
}

record CreateOrderRequest(
        @NotBlank String customerId,
        @Size(min = 1, max = 100) List<@Valid OrderLine> lines) {}     // @Valid cascades into nested objects

record OrderLine(@NotBlank String sku, @Positive int quantity) {}
```

**Both handlers in the advice (note 20), same Problem Details shape:**

```java
@ExceptionHandler(MethodArgumentNotValidException.class)
ProblemDetail invalidBody(MethodArgumentNotValidException e) {
    var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
    pd.setProperty("errors", e.getBindingResult().getFieldErrors().stream()
            .map(f -> Map.of("field", f.getField(), "message", f.getDefaultMessage()))
            .toList());
    return pd;
}

@ExceptionHandler(ConstraintViolationException.class)
ProblemDetail invalidParams(ConstraintViolationException e) {
    var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
    pd.setProperty("errors", e.getConstraintViolations().stream()
            .map(v -> Map.of("field", v.getPropertyPath().toString(), "message", v.getMessage()))
            .toList());
    return pd;                                       // without this handler: 500, not 400
}
```

**Extras worth knowing:**
- `@Valid` (Jakarta) cascades into nested objects; `@Validated` (Spring) enables method-level validation and validation groups.
- Validation on JPA entities also runs at flush time — a constraint violation can surface as `ConstraintViolationException` from deep inside a `@Transactional` commit. Validate at the edge (DTOs) so this stays a safety net, not the primary check.
- NestJS bridge: this is `ValidationPipe` + `class-validator` — `@Valid @RequestBody` ≈ `@Body()` with global ValidationPipe; the decorators even look alike (`@IsNotEmpty` ↔ `@NotBlank`).

**One interview question:**
**Q: `@Valid` vs `@Validated`?**
**A:** "`@Valid` is the Jakarta standard — triggers validation on a request body or cascades into nested objects. `@Validated` is Spring's variant — put it on the class to enable validation of method parameters like `@RequestParam`, and it supports validation groups. Body failures throw `MethodArgumentNotValidException` (auto-400); param failures throw `ConstraintViolationException`, which returns 500 unless you map it yourself."

---

**🎉 Series complete — all 25 exception topics covered. Suggested revision order before an interview: 03 → 08/09 → 12 → 16 → 18 → 24 → 20.**
