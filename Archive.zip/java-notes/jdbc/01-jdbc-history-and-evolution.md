# JDBC — History and Evolution

**Priority: Dev-important, Interview-light** — short notes, not full blueprint. Interviewers rarely grill JDBC history; they care about `PreparedStatement`, pooling, and how Spring hides JDBC. But "which driver type do you use?" and "why don't we call `Class.forName` anymore?" do come up, so keep this table handy.

## What JDBC is

JDBC (Java Database Connectivity) is Java's standard low-level API for talking to any SQL database through a pluggable **driver** (a vendor JAR that speaks the database's wire protocol). Sun shipped it in **JDK 1.1 (Feb 1997)** to solve one problem: write database code once, swap the vendor driver, keep the code. It is the layer *under* everything you will use — JPA, Hibernate, and Spring's `JdbcTemplate` all sit on JDBC.

Think of it like the Node world's `pg` / `mysql2` driver packages — except Java standardized the driver *interface* in the JDK itself, so every vendor driver has the same API.

## Version timeline

| Version | Year / Java | What it added |
|---|---|---|
| 1.0 / 1.2 | 1997, JDK 1.1 | Core API: `DriverManager`, `Connection`, `Statement`, `ResultSet` |
| 2.0 / 2.1 | 1999, J2SE 1.2 | Scrollable/updatable `ResultSet`, **batch updates**, `DataSource` + connection pooling API, distributed (XA) transactions |
| 3.0 | 2001, J2SE 1.4 (JSR 54) | **Savepoints** (partial rollback), retrieving auto-generated keys, `PreparedStatement` pooling |
| 4.0 | 2006, Java 6 (JSR 221) | **Auto driver loading** via `ServiceLoader` — no more `Class.forName("com.mysql...")`. Richer `SQLException` subclasses, SQL/XML support |
| 4.1 | 2011, Java 7 | `Connection`/`Statement`/`ResultSet` become `AutoCloseable` → **try-with-resources** |
| 4.2 | 2014, Java 8 | **`java.time` support** (`LocalDate`, `LocalDateTime` map to SQL types), `REF CURSOR`, large-update counts (`executeLargeUpdate`) |
| 4.3 | 2017, Java 9 | Sharding keys, connection builders. **Still the current version in 2026** — no JDBC 5 exists |

Since 4.3, evolution moved *around* JDBC, not inside it: pooling went to libraries (**HikariCP** is the de facto standard, Spring Boot's default), reactive access got a separate spec (**R2DBC**, because JDBC is blocking by design), and **virtual threads (Java 21)** made blocking JDBC calls cheap again — one virtual thread per query, no reactive rewrite needed.

## Driver types (classic interview trivia)

| Type | Name | Status |
|---|---|---|
| 1 | JDBC-ODBC bridge | Dead — removed in Java 8 |
| 2 | Native C library wrapper | Legacy |
| 3 | Middleware/network server | Rare |
| 4 | **Pure Java, speaks DB wire protocol directly** | What everyone uses (`postgresql.jar`, `mysql-connector-j`) |

## Old vs modern, in code

```java
// 1998 style — manual driver load, manual close, leak-prone
Class.forName("org.postgresql.Driver");                     // obsolete since JDBC 4.0
Connection c = DriverManager.getConnection(url, user, pw);  // no pooling

// Modern style — pooled DataSource, try-with-resources, java.time
try (Connection conn = dataSource.getConnection();          // HikariCP pool behind this
     PreparedStatement ps = conn.prepareStatement(
         "SELECT id, placed_at FROM orders WHERE customer_id = ?")) {
    ps.setLong(1, customerId);
    try (ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            LocalDateTime placedAt = rs.getObject("placed_at", LocalDateTime.class); // JDBC 4.2
        }
    }
} // everything auto-closed, connection returns to pool — JDBC 4.1
```

## One interview question

**Q:** "Why don't we write `Class.forName(...)` for the driver anymore, and why `DataSource` over `DriverManager`?"

**Ideal answer:** Since JDBC 4.0, drivers self-register through the `ServiceLoader` mechanism (the driver JAR declares itself in `META-INF/services`), so loading is automatic. And `DriverManager` opens a raw physical connection every call — expensive (TCP + auth handshake, ~tens of ms). `DataSource` is an interface a pool like HikariCP implements, so `getConnection()` hands you a reused connection in microseconds. In production you only ever see `DataSource`; Spring Boot auto-configures one.

> **Memorize this:** JDBC API froze at 4.3 (2017); the real evolution was 4.0 auto-loading, 4.1 try-with-resources, 4.2 `java.time` — everything after (pooling, reactive, virtual threads) happened in libraries around it, not in JDBC itself.

Sources: [Wikipedia — JDBC](https://en.wikipedia.org/wiki/Java_Database_Connectivity), [Herong — JDBC Version History](https://www.herongyang.com/JDBC/Overview-JDBC-Version.html), [JSR 221](https://jcp.org/en/jsr/detail?id=221)
