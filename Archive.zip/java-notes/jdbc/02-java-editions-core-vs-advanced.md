# Java Editions & Core Java vs Advanced Java

> **Priority: Basic** — quick map only. No deep dive needed for a 2+ year dev.

## Java editions

- **Java SE (Standard Edition)** — the language itself + JVM + standard library (collections, streams, threads, file I/O, JDBC). When people say "core Java", they mean this.
- **Java EE (Enterprise Edition)** — specs built on top of SE for server apps: Servlets, JSP, JPA, JMS, EJB. Oracle gave it away in 2017; it is now **Jakarta EE** (packages renamed `javax.*` → `jakarta.*` — this rename shows up in real migration work).
- **Java ME (Micro Edition)** — old mobile/embedded edition. Dead in practice. Skip it.

## Core Java vs Advanced Java

- "Advanced Java" is mostly an **Indian course-catalog term**, not an industry term. It usually means Servlets, JSP, and JDBC — the pre-Spring way of building web apps. No MNC interviewer will ask you to write a JSP in 2026.
- What replaced it: **Spring Boot** sits on top of those same EE specs. You still meet them, but indirectly — Tomcat implements the Servlet spec, Hibernate implements JPA, Bean Validation runs your `@Valid` checks.
- Where interviews actually go deep: **core Java** (JVM memory, collections internals, concurrency, generics) and **Spring**. That is where to spend your prep time.
- Node.js bridge: SE ≈ Node runtime + stdlib; Jakarta EE ≈ a standards body publishing interfaces that frameworks like Express/NestJS would implement.

## Memorize this

> SE is the language and runtime ("core Java"); EE/Jakarta is a set of server-side specs on top ("advanced Java" in course-speak) — and today you consume those specs through Spring Boot, not directly.

**Next likely topics:** JDK vs JRE vs JVM (how bytecode runs), or JVM memory areas (stack, heap, metaspace).
