# JDBC Internals

**Priority: Interview-critical** — full deep-dive. JDBC internals feed directly into interview staples: SQL injection, pooling, and what `@Transactional` actually does to a connection.

## 1. Core Mechanism

- JDBC is a set of **interfaces** in the JDK (`Connection`, `PreparedStatement`, `ResultSet`). The database vendor ships a JAR that **implements** them and speaks the database's wire protocol (the binary format on the TCP socket).
- Your code calls the interface. The driver JAR does the real work. That's the whole trick — swap driver, keep code.
- It exists because in 1997 every database had its own C API. JDBC made one Java-side contract for all of them.
- Everything above it — Hibernate, JPA, `JdbcTemplate`, jOOQ — is a wrapper that ends in these same calls.

> **Interview definition (say this out loud):** "JDBC is the JDK's standard interface layer for SQL databases — vendors ship type-4 drivers that implement `Connection`, `PreparedStatement` and `ResultSet` over their own wire protocol, and every higher abstraction like JPA or JdbcTemplate bottoms out in those three objects."

## 2. Under the Hood

### 2.1 Driver loading — how `DriverManager` finds the driver

- The driver JAR contains file `META-INF/services/java.sql.Driver` with its class name inside (e.g. `org.postgresql.Driver`).
- On first use, `DriverManager` uses **`ServiceLoader`** (JDK's plugin lookup mechanism) to scan the classpath, load each declared driver class, and let it self-register in a static list.
- `getConnection(url)` then walks that list asking each driver `acceptsURL("jdbc:postgresql://...")`. The URL prefix picks the driver.
- That's why `Class.forName(...)` died in JDBC 4.0 — it existed only to force the driver class's static initializer to run and self-register. `ServiceLoader` does it automatically now.

### 2.2 What a `Connection` really is — and why it's expensive

- A physical `Connection` = **one TCP socket** + negotiated session state on the server (auth done, transaction settings, prepared-statement cache, temp buffers).
- Opening one costs: TCP handshake + TLS handshake + auth exchange + server spawning a backend process (Postgres forks one per connection). Tens of milliseconds and real server memory.
- A JDBC call is **blocking**: the calling thread writes bytes to the socket and sleeps in a socket read until the reply arrives. No event loop involved. The thread is parked, not spinning.
- This is why pooling is non-negotiable, and why one `Connection` must never be shared by two threads at once — the wire protocol interleaves and corrupts.

### 2.3 `PreparedStatement` — parse once, bind many

Statement execution on the server has phases: **parse** (SQL text → query plan) → **bind** (attach parameter values) → **execute**.

- `Statement` sends the full SQL text every time → server re-parses every time. Values are glued into the string → **SQL injection** risk.
- `PreparedStatement` sends the SQL skeleton (`... WHERE id = ?`) once; the server parses and keeps the plan. Later calls send **only the parameter values, as protocol-level data, in a separate message from the SQL text**. Values are never part of the SQL string, so injection is structurally impossible — not "escaped", just never parsed as SQL.
- Two cache layers make this fast:
  - **Server-side prepared statement**: the parsed plan lives in the DB session.
  - **Driver/pool statement cache**: the driver (or pool) keeps the `PreparedStatement` object keyed by SQL string, so the same query text reuses the same server-side plan.
- Batch (`addBatch`/`executeBatch`) piggybacks many bind+execute messages into fewer network round trips — the win is fewer round trips, not less SQL.

### 2.4 `ResultSet` — a cursor, not an array

- `ResultSet` is a **live cursor** over the socket, not an in-memory list. `next()` may read the next row off the wire.
- **`fetchSize`** controls how many rows the driver pulls per network round trip.
- Trap: MySQL's driver and Postgres in autocommit mode buffer the **entire result set into heap** by default. A 10M-row query = `OutOfMemoryError`. Fix: Postgres needs `setFetchSize(n)` + `autoCommit=false` to stream; MySQL needs `Integer.MIN_VALUE` fetch size or `useCursorFetch=true`.
- The `ResultSet` dies when its `Statement` or `Connection` closes — you can't return it from a method that closes the connection. Map rows to objects before leaving the try-with-resources block.

### 2.5 Transactions at the JDBC level

- There is no `beginTransaction()` in JDBC. A transaction starts implicitly; the control knob is **`setAutoCommit(false)`** (stop committing after every statement), then `commit()` or `rollback()`.
- Isolation level is a **connection property**: `conn.setTransactionIsolation(TRANSACTION_READ_COMMITTED)` — sent to the server as session state.
- Spring's `@Transactional` is, at the bottom, exactly this: proxy grabs a connection from the pool, `setAutoCommit(false)`, binds the connection to the current thread in a `ThreadLocal` (so every repository call in that thread reuses **the same connection**), then `commit()`/`rollback()` and returns it to the pool. That single fact explains most `@Transactional` behavior questions.

### 2.6 Connection pool internals (HikariCP)

- The pool pre-opens N physical connections and keeps them alive.
- `dataSource.getConnection()` does **no I/O** — it hands you a pooled connection in ~microseconds. HikariCP's core is the `ConcurrentBag`: it first checks a thread-local list (the connection you used last time, cache-warm), then the shared lock-free list, then waits with a timeout (`connectionTimeout`, default 30s → then `SQLTimeoutException`).
- What you receive is a **proxy wrapper** around the physical connection. Its `close()` is overridden: it does not close the socket — it resets state (autocommit back to true, clear warnings) and returns the connection to the bag. That's why try-with-resources + pool works.
- Pool also runs housekeeping: evicts idle connections (`idleTimeout`), retires old ones (`maxLifetime`, keep it under the DB/firewall timeout), and tests liveness (JDBC4 `isValid()` ping).
- Sizing rule interviewers like: pool size ≈ `cores * 2` — small pools beat big ones because the DB can only really run ~cores queries at once; more connections just queue inside the DB.

## 3. The Node.js / NestJS Bridge

| Concept | Node / `pg` | Java / JDBC |
|---|---|---|
| Driver | `pg`, `mysql2` npm packages | Vendor JAR implementing `java.sql.Driver` |
| Pool | `new pg.Pool({max: 10})` | HikariCP `DataSource` |
| Get connection | `pool.connect()` | `dataSource.getConnection()` |
| Release | `client.release()` | `connection.close()` (proxy returns it to pool) |
| Parameterized query | `query('... WHERE id = $1', [id])` | `PreparedStatement` with `?` + setters |
| Streaming rows | `pg-cursor` / `query-stream` | `setFetchSize(n)` on the statement |
| Transaction | `BEGIN` / `COMMIT` sent as SQL | `setAutoCommit(false)` + `commit()` |

**Where the comparison breaks down:**

- **Blocking model.** `pg` is async — the query registers a callback and the event loop moves on. JDBC **parks the calling thread** until the row bytes arrive. Java affords this because each request has its own thread; with Java 21 virtual threads, a parked JDBC call costs almost nothing.
- **Who holds the transaction.** In `pg` you must manually run `BEGIN`/`COMMIT` on one checked-out client. In Spring, the framework pins the connection to the **thread** via `ThreadLocal` — that's why moving work to another thread inside `@Transactional` silently escapes the transaction. No Node equivalent; classic trap question.
- **`close()` semantics.** In Node, `release()` and `end()` are different methods. In JDBC, `close()` on a pooled connection is a lie by design — the proxy intercepts it. Interviewers probe whether you know the pool proxies the connection.

## 4. Production-Grade Code

```java
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class OrderRepository {

    public record OrderSummary(long id, String status, LocalDateTime placedAt) {}

    private final DataSource dataSource;

    public OrderRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static DataSource buildPool(String url, String user, String password) {
        var config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setUsername(user);
        config.setPassword(password);
        config.setMaximumPoolSize(10);          // ~cores * 2, not hundreds
        config.setMaxLifetime(1_800_000);       // 30 min, below DB-side timeout
        config.setConnectionTimeout(5_000);     // fail fast instead of 30s default
        return new HikariDataSource(config);
    }

    public List<OrderSummary> findRecentByCustomer(long customerId, int limit) {
        var sql = """
                SELECT id, status, placed_at
                FROM orders
                WHERE customer_id = ?
                ORDER BY placed_at DESC
                LIMIT ?
                """;
        var results = new ArrayList<OrderSummary>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, customerId);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // map inside the try block — ResultSet dies with the connection
                    results.add(new OrderSummary(
                            rs.getLong("id"),
                            rs.getString("status"),
                            rs.getObject("placed_at", LocalDateTime.class)));
                }
            }
            return results;
        } catch (SQLException e) {
            // SQLException is checked; wrap so callers aren't forced to declare it
            throw new IllegalStateException("Query failed for customer " + customerId, e);
        }
    }

    public void markShipped(List<Long> orderIds) {
        var sql = "UPDATE orders SET status = 'SHIPPED' WHERE id = ?";
        try (Connection conn = dataSource.getConnection()) {
            conn.setAutoCommit(false);          // manual transaction boundary
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                for (Long id : orderIds) {
                    ps.setLong(1, id);
                    ps.addBatch();              // one round trip for the whole batch
                }
                ps.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();                // without this, pool reset may discard silently
                throw new IllegalStateException("Batch update failed, rolled back", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Could not obtain connection", e);
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: How does `PreparedStatement` prevent SQL injection — is it just escaping?**

**What they're testing:** whether you know the wire protocol separates SQL from data, or you just memorized "use PreparedStatement".

**Ideal answer:** "No, it's not escaping. The driver sends the SQL skeleton with placeholders to the server once, and the server parses it into a plan. Parameter values travel later in separate protocol messages as typed data — they are never concatenated into SQL text, so the parser never sees them. Injection is structurally impossible, not filtered. Bonus: the parsed plan is cached server-side, so repeated queries skip parsing — it's faster too."

**Q2: What actually happens when you call `dataSource.getConnection()` and then `close()` with HikariCP?**

**What they're testing:** do you know pooling internals, or do you think `close()` closes a socket.

**Ideal answer:** "`getConnection()` does no network I/O — HikariCP hands me an already-open physical connection from its bag, checking a thread-local slot first, in microseconds. If none is free it waits up to `connectionTimeout`, then throws. What I get is a proxy: calling `close()` doesn't touch the socket — the proxy resets autocommit and state, and returns the connection to the pool. The pool separately retires connections on `maxLifetime` and pings them with `isValid()`."

**Q3: Your service loads a 10-million-row report and dies with `OutOfMemoryError`. The query is fine in `psql`. Why?**

**What they're testing:** do you know `ResultSet` buffering behavior differs by driver and settings.

**Ideal answer:** "By default many drivers materialize the whole result set in heap — Postgres does this in autocommit mode, MySQL always. `ResultSet` can be a streaming cursor, but you must ask: on Postgres set `fetchSize` and turn autocommit off so it uses a server-side cursor; on MySQL use `Integer.MIN_VALUE` fetch size or `useCursorFetch=true`. Then rows arrive in chunks per round trip and heap stays flat. Also process rows as they stream instead of collecting them into a list."

## 6. Memorize this

> **Memorize this:** JDBC = three interfaces over a blocking socket — driver found by `ServiceLoader`, `PreparedStatement` sends data separate from SQL (no injection, plan cached), `ResultSet` is a cursor sized by `fetchSize`, transactions are just `autoCommit=false` on a connection, and the pool hands out proxies whose `close()` returns instead of closes.
