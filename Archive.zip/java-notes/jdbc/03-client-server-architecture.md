# Client-Server Architecture

> **Priority: Basic** — you build client-server systems daily in Node. Only the Java-course angle matters here.

## Why Java courses teach it before JDBC

- **What it means in this course context:** your Java program is the *client*; the database (MySQL/Postgres) is the *server*. JDBC is the wire between them. Same picture as your Node app + `pg` driver.
- **2-tier vs 3-tier:** 2-tier = client talks straight to the DB (old desktop apps, or a plain JDBC program). 3-tier = client → app server (Spring Boot) → DB. Everything you have built in Express/NestJS is 3-tier.
- **Why 3-tier won:** the middle tier owns business logic, connection pooling, security, and caching. Clients stay thin. You cannot pool or secure well when every client holds its own DB connection.
- **Java-specific note:** each DB connection in Java is a TCP socket held by the JDBC driver. Connections are expensive to open, so real apps always use a pool (HikariCP is the Spring Boot default). Same idea as `pg.Pool` in Node.

## Memorize this

> JDBC makes your Java program a database client over TCP; real systems put an app tier in between (3-tier) so connections can be pooled and logic centralized.

**Next likely topics:** JDBC architecture (DriverManager, driver types), or JDBC connection & Statement vs PreparedStatement.
