# JDBC Drivers and Their Types

**Priority: Dev-important, Interview-light** — short notes. "List the 4 driver types" is classic MNC screening trivia (especially service-company rounds), but it's memorization, not depth. Learn the table, know why Type 4 won, move on.

## What a driver is

A JDBC driver is a JAR that implements the JDK's `java.sql` interfaces (`Driver`, `Connection`, `Statement`, `ResultSet`) for one specific database. Your code talks to the interfaces; the driver translates those calls into the database's **wire protocol** (the byte format the DB server understands on the TCP socket). The 4 "types" are historical categories based on *how* that translation happens — how many layers sit between your Java call and the database.

## The 4 types

| Type | Name | How it works | Pros | Cons | Status |
|---|---|---|---|---|---|
| **1** | JDBC-ODBC Bridge | Java → ODBC (Windows' old C database API) → DB | Worked with anything that had an ODBC driver | Needs native ODBC install on every machine, slow (two translation hops), not portable | **Dead** — removed from the JDK in Java 8 |
| **2** | Native-API driver | Java → vendor's native C client library (via JNI) → DB | Faster than Type 1 | Must install the vendor's C library on every machine; JNI crashes take down the whole JVM | Legacy (old Oracle OCI driver) |
| **3** | Network-protocol driver | Java → middleware server (translates to any DB) → DB | Pure Java on the client; one client for many DBs | Extra network hop; you must run and maintain the middleware server | Rare, mostly dead |
| **4** | **Thin / pure Java driver** | Java speaks the DB's wire protocol **directly** over TCP | Pure Java — one JAR, no native install, portable, fastest path | One driver per database (nobody cares) | **The standard.** Everything you'll ever use |

Examples of Type 4: `org.postgresql:postgresql`, `com.mysql:mysql-connector-j`, Oracle thin driver (`ojdbc11`), `com.microsoft.sqlserver:mssql-jdbc`.

Memory hook: **types 1–3 all needed something extra installed** (ODBC, a C library, a middleware server). Type 4 needs only the JAR on the classpath — that's why it won.

## Node.js bridge

Type 4 is exactly what `pg` and `mysql2` are in Node: a pure-language library that speaks the database's protocol directly over a socket. Types 1–3 have no modern Node equivalent — they're relics of the 1990s, when writing a full wire-protocol client in Java was considered too hard, so people bridged to existing C code instead.

## How the right driver gets picked (quick recap)

```java
// You never name the driver class. The JDBC URL prefix selects it:
Connection conn = DriverManager.getConnection(
        "jdbc:postgresql://db-host:5432/orders", user, password);
// "jdbc:postgresql:" → DriverManager asks each ServiceLoader-registered
// driver acceptsURL(...) — the Postgres driver claims it.
```

## One interview question

**Q:** "Which JDBC driver type do you use in production, and why did the other types die out?"

**Ideal answer:** "Type 4 — the pure Java thin driver. It implements the database's wire protocol directly in Java, so it's just one JAR on the classpath: no native libraries, no ODBC setup, no middleware server, and it works identically in any container or OS. Types 1–3 all depended on extra native or server-side components, which made deployment fragile and JNI errors could crash the JVM. Type 1 was actually removed from the JDK in Java 8."

> **Memorize this:** 4 driver types = ODBC bridge, native C wrapper, middleware, pure Java — only Type 4 (pure Java, speaks the wire protocol directly, just a JAR) survived, because the other three all needed something installed beyond the classpath.
