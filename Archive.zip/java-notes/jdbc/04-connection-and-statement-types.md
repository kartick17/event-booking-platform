# JDBC Connection & Statement vs PreparedStatement vs CallableStatement

**Priority: Interview-critical** — full deep-dive. "Difference between Statement and PreparedStatement" is one of the most-asked JDBC questions in MNC rounds, and `Connection` setup is the context they wrap it in.

## 1. Core Mechanism

- A **`Connection`** is your live session with the database: one TCP socket plus server-side session state (auth, transaction mode, temp data). Everything else happens *through* it.
- From a `Connection` you create one of three statement objects to run SQL:
  - **`Statement`** — sends raw SQL text. Built by string concatenation. Legacy.
  - **`PreparedStatement`** — sends SQL with `?` placeholders once; values travel separately. The default choice.
  - **`CallableStatement`** — calls a **stored procedure** (SQL code saved inside the database), with support for `OUT` parameters (values the procedure sends back).
- The hierarchy is literal inheritance: `CallableStatement` extends `PreparedStatement` extends `Statement`.
- Why three exist: `Statement` came first (1997), `PreparedStatement` fixed its injection and re-parse problems, `CallableStatement` covered stored procedures which need a different call syntax.

> **Interview definition (say this out loud):** "Statement sends raw SQL text and re-parses every time; PreparedStatement pre-compiles a parameterized plan on the server and sends values separately — so it's both injection-proof and faster on repeat; CallableStatement extends it to invoke stored procedures with IN/OUT parameters."

## 2. Under the Hood

### 2.1 The three-way comparison

| | `Statement` | `PreparedStatement` | `CallableStatement` |
|---|---|---|---|
| SQL sent as | Full text, every execution | Skeleton once, then values only | `{call proc_name(?, ?)}` escape syntax |
| Server parsing | Every single call | Once; plan cached in session | Procedure already compiled in DB |
| SQL injection | **Vulnerable** (string concat) | Safe — values never enter SQL text | Safe — same binding mechanism |
| Parameters | None — you build the string | `setLong(1, …)`, `setString(2, …)` (1-indexed!) | Same, **plus** `registerOutParameter` + getters for results |
| Use when | DDL, one-off admin SQL | **Everything** — all app queries | Stored procedures only |

### 2.2 Why PreparedStatement is faster — the protocol view

- The server executes SQL in phases: **parse** (text → syntax tree) → **plan** (tree → execution strategy) → **bind** (attach values) → **execute**.
- `Statement` pays parse + plan on every call. `PreparedStatement` pays them once; every later `executeQuery()` sends a tiny bind+execute message referencing the stored plan.
- Second cache layer: the driver or pool caches the `PreparedStatement` object itself keyed by SQL string. Same SQL text from the pool's connection → same server-side plan, even across "different" `prepareStatement` calls.
- Corollary: this only pays off if the SQL **text** is identical. Concatenating values into the string (even in a PreparedStatement's SQL) creates a new text per call and kills both caches — the classic mistake is `"WHERE id IN (" + ids + ")"`.

### 2.3 Why injection is structurally impossible

- With `PreparedStatement`, the parameter value goes to the server as **typed protocol data in a separate message** after parsing is already done. The SQL parser literally never sees the value.
- `setString(1, "'; DROP TABLE orders; --")` is stored as a 25-character string value — the quotes and semicolons are data bytes, not syntax. Nothing to escape, nothing to bypass.
- Contrast with escaping: escaping tries to sanitize text that *will* be parsed. Binding means the text is *never* parsed. Different guarantee class.

### 2.4 CallableStatement mechanics

- Syntax uses JDBC's escape form: `conn.prepareCall("{call settle_invoice(?, ?, ?)}")` — or `{? = call fn(?)}` for functions returning a value.
- Three parameter modes: **IN** (you set), **OUT** (procedure fills; you must `registerOutParameter(idx, Types.NUMERIC)` *before* executing), **INOUT** (both).
- After `execute()`, you read OUT values with `cs.getBigDecimal(idx)` — from the **statement**, not a ResultSet.
- A procedure can also return result sets *and* update counts; you walk them with `getMoreResults()`. Ugly API, rarely needed.
- Modern reality: stored-procedure-heavy design faded (logic lives in services now), but banks/insurance MNCs still run on them — that's why the question survives.

### 2.5 Connection creation and its settings

- `DriverManager.getConnection(url, user, pw)` = new physical socket every call (expensive). `DataSource.getConnection()` = borrowed from pool (microseconds). Production is always the latter.
- Key knobs that live on `Connection`: `setAutoCommit(false)` (transaction boundary), `setTransactionIsolation(...)`, `setReadOnly(true)` (hint — driver may route to a replica or optimize).
- All three statement types, and every `ResultSet`, die when their `Connection` closes. Lifetime is strictly nested: Connection ⊃ Statement ⊃ ResultSet.

## 3. The Node.js / NestJS Bridge

| Concept | Node / `pg` | Java / JDBC |
|---|---|---|
| Raw query, values glued in | `` client.query(`... WHERE id = ${id}`) `` (bad) | `Statement` (bad, same reason) |
| Parameterized query | `client.query('... WHERE id = $1', [id])` | `PreparedStatement` with `?` |
| Explicit prepared statement | `query({name: 'fetch-user', text: ..., values: ...})` | Automatic — driver caches by SQL string |
| Stored procedure call | `client.query('CALL settle_invoice($1)', [x])` | `CallableStatement` with `{call ...}` |

**Where the comparison breaks down:**

- In `pg`, parameterized queries use *unnamed* one-shot prepares unless you pass a `name` — reuse is opt-in. In JDBC, statement caching is handled by the driver/pool config and keyed by SQL text — reuse is automatic.
- `pg` has no OUT-parameter API — Postgres returns procedure output as rows. `CallableStatement`'s `registerOutParameter` exists because Oracle/SQL Server/DB2 procedures return values *outside* any result set. If the interviewer is from a bank, they mean Oracle.
- Placeholders: `pg` uses `$1, $2` (named position, reusable in the text). JDBC uses positional `?` — the same value used twice must be bound twice.

## 4. Production-Grade Code

```java
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Optional;
import javax.sql.DataSource;

public class InvoiceRepository {

    public record Invoice(long id, String customerEmail, BigDecimal amount) {}

    private final DataSource dataSource;

    public InvoiceRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /* PreparedStatement — the default for ALL application queries. */
    public Optional<Invoice> findById(long invoiceId) {
        var sql = "SELECT id, customer_email, amount FROM invoices WHERE id = ?";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, invoiceId);                       // params are 1-indexed
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(new Invoice(
                        rs.getLong("id"),
                        rs.getString("customer_email"),
                        rs.getBigDecimal("amount")));       // BigDecimal for money, never double
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Lookup failed for invoice " + invoiceId, e);
        }
    }

    /* PreparedStatement INSERT + generated key retrieval. */
    public long create(String customerEmail, BigDecimal amount) {
        var sql = "INSERT INTO invoices (customer_email, amount) VALUES (?, ?)";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, customerEmail);
            ps.setBigDecimal(2, amount);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getLong(1);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Insert failed for " + customerEmail, e);
        }
    }

    /* CallableStatement — legacy stored procedure with an OUT parameter.
       Procedure signature: settle_invoice(IN invoice_id BIGINT, OUT settled_amount NUMERIC) */
    public BigDecimal settleViaStoredProc(long invoiceId) {
        try (Connection conn = dataSource.getConnection();
             CallableStatement cs = conn.prepareCall("{call settle_invoice(?, ?)}")) {
            cs.setLong(1, invoiceId);
            cs.registerOutParameter(2, Types.NUMERIC);      // must register BEFORE execute
            cs.execute();
            return cs.getBigDecimal(2);                     // OUT value read from statement, not ResultSet
        } catch (SQLException e) {
            throw new IllegalStateException("settle_invoice failed for " + invoiceId, e);
        }
    }

    /* Plain Statement — acceptable ONLY for fixed DDL/admin SQL with zero user input. */
    public void truncateStagingTable() {
        try (Connection conn = dataSource.getConnection();
             Statement st = conn.createStatement()) {
            st.executeUpdate("TRUNCATE TABLE invoice_staging");
        } catch (SQLException e) {
            throw new IllegalStateException("Truncate failed", e);
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: Statement vs PreparedStatement — give me all the differences.**

**What they're testing:** whether you know *both* benefits (security and performance) and can explain the mechanism, not just recite "PreparedStatement is better".

**Ideal answer:** "Three differences. Security: Statement builds SQL by concatenation, so user input becomes SQL — injection. PreparedStatement sends values as separate protocol data the parser never sees. Performance: Statement forces the server to re-parse and re-plan every call; PreparedStatement parses once and reuses the cached plan, and the driver caches the statement object by SQL text. Usability: typed setters handle escaping, dates, and encoding for me. Statement survives only for fixed DDL like TRUNCATE."

**Q2: If PreparedStatement is 'pre-compiled', where exactly does the compilation live?**

**What they're testing:** hand-wavers say "it's compiled"; seniors know the two cache layers.

**Ideal answer:** "Two places. The database session holds the server-side prepared statement — the parsed plan — created on first prepare. And the driver or connection pool holds a client-side cache of PreparedStatement objects keyed by exact SQL text, so the same query reuses the same server plan across borrowings. Both keys are the SQL string, which is why dynamically concatenated SQL — like building an IN-list — defeats the caching completely."

**Q3: When would you use CallableStatement, and how do OUT parameters work?**

**What they're testing:** exposure to legacy enterprise systems (Oracle/DB2 stored procedures).

**Ideal answer:** "Only for stored procedures — common in banking and insurance systems where logic lives in the database. I prepare it with the escape syntax `{call proc(?, ?)}`, set IN parameters like any PreparedStatement, but for OUT parameters I must call `registerOutParameter` with the SQL type *before* executing. After `execute()`, I read the OUT values from the statement itself with getters, not from a ResultSet. It inherits from PreparedStatement, so binding is injection-safe too."

## 6. Memorize this

> **Memorize this:** `Statement` re-parses text every call and invites injection; `PreparedStatement` parses once and ships values as protocol data the parser never sees (safe + cached); `CallableStatement` adds `{call ...}` + `registerOutParameter` for stored procedures — and the three are a literal inheritance chain.
