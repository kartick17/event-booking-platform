# JDBC Architecture (DriverManager, Driver Types)

> **Priority: Interview-critical** — JDBC driver questions are a staple in MNC Java rounds, and `DriverManager` vs `DataSource` is a real senior filter.

## 1. Core Mechanism

- JDBC (Java Database Connectivity) is **not a library — it is a spec**. The `java.sql` package holds only **interfaces**: `Connection`, `Statement`, `PreparedStatement`, `ResultSet`, `Driver`.
- The **driver jar** you add (e.g. `mysql-connector-j`, `postgresql`) provides the **implementations** of those interfaces. Your code only touches the interfaces, so swapping MySQL for Postgres barely changes your code.
- `DriverManager` is the factory (class that hands out objects) that picks the right driver for your URL and gives you a `Connection`.
- **Why it exists:** before JDBC, every database had its own client API. JDBC gives one standard API so app code stops caring which database is behind it.

> **Interview definition (say this out loud):** "JDBC is a specification — a set of interfaces in `java.sql` — and each database vendor ships a driver jar that implements them. My code programs against the interfaces; `DriverManager` or a pooled `DataSource` resolves the actual driver at runtime from the JDBC URL."

## 2. Under the Hood

### 2.1 How a driver registers itself

- **Legacy way (pre-Java 6):** `Class.forName("com.mysql.cj.jdbc.Driver")`. This loads the driver class, and its **static initializer block** runs `DriverManager.registerDriver(new Driver())`. The whole trick was: class loading triggers static blocks.
- **Modern way (JDBC 4.0+, Java 6+):** the driver jar contains a file `META-INF/services/java.sql.Driver` naming its driver class. `DriverManager` uses **`ServiceLoader`** (Java's plugin-discovery mechanism) to find and register every driver on the classpath automatically. `Class.forName` in modern code is a copy-paste fossil.

### 2.2 How `DriverManager.getConnection(url)` picks a driver

- It loops over all registered drivers and calls each driver's `connect(url, props)`.
- Each driver checks the **URL prefix**: the MySQL driver accepts `jdbc:mysql://...`, the Postgres driver accepts `jdbc:postgresql://...`. A driver that does not recognize the prefix returns `null`, and `DriverManager` tries the next one.
- The winning driver opens a **TCP socket** to the database, does the handshake and authentication, and returns its own `Connection` implementation wrapping that socket.

### 2.3 The four driver types

| Type | Name | How it works | Status |
|------|------|--------------|--------|
| 1 | JDBC-ODBC bridge | Translates JDBC calls to ODBC (old Windows C API) | Removed in Java 8. Only a history question. |
| 2 | Native-API driver | Part Java, part native C library via JNI (Java-to-C bridge) | Dead. Needs native libs installed on every machine. |
| 3 | Network-protocol driver | Talks to a middleware server, which talks to the DB | Rare. Extra hop, extra server to run. |
| 4 | Thin / pure-Java driver | 100% Java; speaks the database's own wire protocol directly over TCP | **What everyone uses.** `mysql-connector-j`, Postgres JDBC — all Type 4. |

- Why Type 4 won: nothing to install besides the jar, fully portable, and no JNI overhead.

### 2.4 `DriverManager` vs `DataSource` — the senior answer

- `DriverManager.getConnection()` opens a **new physical connection every call**: TCP handshake + TLS + DB authentication + session setup. That can cost tens of milliseconds — brutal per request.
- `DataSource` is an interface designed to hide connection creation. Pool libraries implement it: **HikariCP** (Spring Boot's default) keeps warm connections and lends them out. Calling `close()` on a pooled connection does not close the socket — the pool's **proxy** intercepts it and returns the connection to the pool.
- `DataSource` also enables things `DriverManager` cannot: distributed transactions (`XADataSource`) and container-managed lookup (JNDI).
- Rule: `DriverManager` is for demos and course exercises. Production code — always a pooled `DataSource`.

## 3. The Node.js / NestJS Bridge

| Concept | Node / Postgres | Java / JDBC |
|---------|-----------------|-------------|
| Driver | `pg`, `mysql2` npm packages | Driver jar (`postgresql`, `mysql-connector-j`) |
| Standard API | None — `pg` and `mysql2` each have their own API | One standard: `java.sql` interfaces for every DB |
| Getting a connection | `new pg.Client()` + `connect()` | `DriverManager.getConnection(url, user, pass)` |
| Pooling | `pg.Pool` | `DataSource` implemented by HikariCP |
| Connection config | Connection string / config object | JDBC URL: `jdbc:postgresql://host:5432/db` |

**Where the comparison breaks down:**
- In Node there is no shared interface — switching `pg` to `mysql2` means rewriting query code. In Java, the interface layer is the whole point of JDBC; only the URL and driver jar change.
- `pg` is async (event loop); JDBC is **blocking** — the calling thread waits on the socket. Java is fine with this because each request has its own thread (or a virtual thread). Do not say "blocking is bad" in a Java interview — that is a Node reflex.

## 4. Production-Grade Code

```java
import java.sql.SQLException;
import java.time.Instant;
import java.util.Optional;
import javax.sql.DataSource;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public final class OrderRepository {

    public record OrderSummary(long id, String customerEmail, Instant createdAt) {}

    private final DataSource dataSource;

    public OrderRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static DataSource createPool(String url, String user, String password) {
        var config = new HikariConfig();
        config.setJdbcUrl(url);               // driver resolved from URL prefix via ServiceLoader
        config.setUsername(user);
        config.setPassword(password);
        config.setMaximumPoolSize(10);        // size for DB capacity, not request count
        config.setConnectionTimeout(3_000);   // fail fast when pool is exhausted
        return new HikariDataSource(config);
    }

    public Optional<OrderSummary> findById(long orderId) {
        var sql = """
                SELECT o.id, c.email, o.created_at
                FROM orders o
                JOIN customers c ON c.id = o.customer_id
                WHERE o.id = ?
                """;
        // try-with-resources: close() runs in reverse order even on exceptions;
        // for a pooled connection, close() returns it to the pool
        try (var connection = dataSource.getConnection();
             var statement = connection.prepareStatement(sql)) {
            statement.setLong(1, orderId);
            try (var resultSet = statement.executeQuery()) {
                if (!resultSet.next()) {
                    return Optional.empty();
                }
                return Optional.of(new OrderSummary(
                        resultSet.getLong("id"),
                        resultSet.getString("email"),
                        resultSet.getTimestamp("created_at").toInstant()));
            }
        } catch (SQLException e) {
            // SQLException is checked; wrap so callers aren't forced to handle JDBC details
            throw new IllegalStateException("Failed to load order " + orderId, e);
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: How does `DriverManager` know which driver to use? Do we still need `Class.forName`?**
- *What they're testing:* whether you know the ServiceLoader mechanism or just copied old tutorials.
- *Ideal answer:* "Since JDBC 4.0, drivers self-register: the jar ships a `META-INF/services/java.sql.Driver` file, and `DriverManager` loads it via `ServiceLoader`. At `getConnection`, it asks each registered driver whether it accepts the URL prefix — `jdbc:mysql:` goes to the MySQL driver. `Class.forName` was the old trick to force the driver's static registration block to run; it's unnecessary today."

**Q2: What are the four JDBC driver types, and which is used in practice?**
- *What they're testing:* a classic screening question; they want a confident short answer, not a lecture.
- *Ideal answer:* "Type 1 is the JDBC-ODBC bridge, removed in Java 8. Type 2 uses native libraries via JNI. Type 3 goes through a middleware server. Type 4 is pure Java and speaks the database's wire protocol directly over TCP — every modern driver, MySQL or Postgres, is Type 4, because it needs nothing installed beyond the jar."

**Q3: Why does Spring use `DataSource` instead of `DriverManager`?**
- *What they're testing:* whether you understand connection cost and pooling — real production awareness.
- *Ideal answer:* "`DriverManager` opens a new physical connection every time — TCP handshake, auth, session setup — which is far too slow per request. `DataSource` abstracts connection creation so a pool like HikariCP can sit behind it, handing out warm connections. Calling `close()` on a pooled connection just returns it to the pool via a proxy. Spring Boot auto-configures a `HikariDataSource` from `spring.datasource.*` properties."

## 6. Memorize this

> **Memorize this:** JDBC is interfaces in `java.sql`; the driver jar is a Type-4 pure-Java implementation, auto-registered via `ServiceLoader`, picked by `DriverManager` from the URL prefix — and production code replaces `DriverManager` with a pooled `DataSource` (HikariCP).

**Next likely topics:** Statement vs PreparedStatement vs CallableStatement, or ResultSet types & transaction handling in JDBC.
