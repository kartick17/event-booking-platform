# execute vs executeUpdate vs executeQuery

> **Priority: Interview-critical** — the "difference between the three execute methods" question shows up in nearly every JDBC screening round.

## 1. Core Mechanism

- All three live on `Statement` (and `PreparedStatement`). All three send SQL to the database. The difference is the **contract about what comes back**.
- **`executeQuery(sql)`** → returns a **`ResultSet`**. Use for `SELECT` — anything that produces rows.
- **`executeUpdate(sql)`** → returns an **`int`** — the number of rows affected. Use for `INSERT`, `UPDATE`, `DELETE`, and DDL (`CREATE TABLE` etc., which returns 0).
- **`execute(sql)`** → returns a **`boolean`** — `true` if the first result is a `ResultSet`, `false` if it is an update count. Use when you don't know what the SQL returns, or when it can return **multiple results** (stored procedures).
- **Why three methods:** the driver enforces intent. Calling `executeQuery` with an `UPDATE` throws `SQLException` — a fail-fast guard instead of silent wrong behavior.

> **Interview definition (say this out loud):** "`executeQuery` returns a `ResultSet` for statements that produce rows, `executeUpdate` returns the affected row count for DML and DDL, and `execute` is the generic form — it returns a boolean telling you whether the first result is a `ResultSet` or an update count, and you then pull results with `getResultSet()` or `getUpdateCount()`."

## 2. Under the Hood

- **Same wire call, different unwrapping.** The database does not see three different operations — the driver sends the SQL either way. The three methods differ in how the driver validates and unwraps the response. On mismatch (rows came back but you called `executeUpdate`), the **driver** throws; the DB already did the work.
- **`execute()` and the multi-result loop.** A stored procedure can return several `ResultSet`s and update counts. The protocol:
  1. `boolean hasResultSet = stmt.execute(sql)`
  2. If `true` → `stmt.getResultSet()`; if `false` → `stmt.getUpdateCount()`
  3. `stmt.getMoreResults()` to advance; **done when** `getMoreResults()` is `false` **and** `getUpdateCount()` is `-1`. That `-1` sentinel is a favorite trick question.
- **`PreparedStatement` overloads take no SQL string** — SQL was fixed at `prepareStatement(sql)`. Calling the string-taking `execute(sql)` on a `PreparedStatement` throws. Under the hood (Postgres), a prepared statement uses the extended protocol — parse once, bind + execute per call — which is where the performance and SQL-injection benefits come from.
- **Generated keys:** `executeUpdate` alone does not give you the new auto-increment id. You need `prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)` then `getGeneratedKeys()` — itself a small `ResultSet`.
- **JDBC 4.2 extras:** `executeLargeUpdate()` returns `long` for row counts beyond `int` range; `executeBatch()` runs many statements in one round trip.

## 3. The Node.js / NestJS Bridge

| Concept | Node (`pg`) | Java / JDBC |
|---------|-------------|-------------|
| Run a SELECT | `pool.query(sql)` → `result.rows` | `executeQuery(sql)` → `ResultSet` |
| Run an UPDATE | same `pool.query(sql)` → `result.rowCount` | `executeUpdate(sql)` → `int` |
| Unknown / multi-result SQL | same `pool.query(sql)` | `execute(sql)` + `getMoreResults()` loop |

**Where the comparison breaks down:**
- `pg` has **one** method; every result carries both `rows` and `rowCount`, and you read whichever you want. JDBC makes you **declare intent up front** and throws on mismatch. Interviewers use this to check you know the contracts, not just "run query, get result".
- A `ResultSet` is a **live cursor** tied to the open connection — not a materialized array like `result.rows`. Close the connection and the `ResultSet` dies.

## 4. Production-Grade Code

```java
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import javax.sql.DataSource;

public final class InvoiceRepository {

    private final DataSource dataSource;

    public InvoiceRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** executeQuery: statement that produces rows. */
    public Optional<String> findStatus(long invoiceId) {
        var sql = "SELECT status FROM invoices WHERE id = ?";
        try (var conn = dataSource.getConnection();
             var stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, invoiceId);
            try (var rs = stmt.executeQuery()) {
                return rs.next() ? Optional.of(rs.getString("status")) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Status lookup failed for invoice " + invoiceId, e);
        }
    }

    /** executeUpdate: DML returning a row count; generated key fetched explicitly. */
    public long create(long customerId, long amountCents) {
        var sql = "INSERT INTO invoices (customer_id, amount_cents, status) VALUES (?, ?, 'OPEN')";
        try (var conn = dataSource.getConnection();
             var stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, customerId);
            stmt.setLong(2, amountCents);
            int rows = stmt.executeUpdate();
            if (rows != 1) {
                throw new IllegalStateException("Expected 1 insert, got " + rows);
            }
            try (var keys = stmt.getGeneratedKeys()) {
                keys.next();
                return keys.getLong(1);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Invoice creation failed", e);
        }
    }

    /** execute: multi-result protocol, e.g. a maintenance script or stored procedure. */
    public void runMaintenance(String script) {
        try (var conn = dataSource.getConnection();
             var stmt = conn.createStatement()) {
            boolean hasResultSet = stmt.execute(script);
            while (true) {
                if (hasResultSet) {
                    try (var rs = stmt.getResultSet()) {
                        while (rs.next()) { /* consume so the driver can advance */ }
                    }
                } else if (stmt.getUpdateCount() == -1) {
                    break; // -1 with no ResultSet means no more results
                }
                hasResultSet = stmt.getMoreResults();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Maintenance script failed", e);
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: What is the difference between `execute`, `executeQuery`, and `executeUpdate`?**
- *What they're testing:* the standard screening question — they want the return types, crisp.
- *Ideal answer:* "`executeQuery` returns a `ResultSet` and is for statements that produce rows. `executeUpdate` returns an `int` row count for `INSERT`/`UPDATE`/`DELETE`, and 0 for DDL. `execute` handles anything — it returns `true` if the first result is a `ResultSet`, `false` for an update count, and I pull results via `getResultSet()` or `getUpdateCount()`. The driver enforces this: calling `executeQuery` on an `UPDATE` throws `SQLException`."

**Q2: What does `executeUpdate` return for a `CREATE TABLE`? And for a `DELETE` matching no rows?**
- *What they're testing:* edge-case knowledge — separates memorized answers from used-it answers.
- *Ideal answer:* "Zero in both cases, but for different reasons. DDL has no affected rows, so the spec says return 0. A `DELETE` matching nothing also returns 0 — so I never treat 0 as an error for DML; I compare it to the count I expected."

**Q3: When would you actually use `execute()`?**
- *What they're testing:* whether you know the multi-result protocol or think `execute` is a leftover.
- *Ideal answer:* "When I can't know in advance what the SQL returns — dynamic SQL, migration scripts, or stored procedures returning multiple result sets. I loop: check the boolean, consume the `ResultSet` or read the update count, then `getMoreResults()`; I stop when `getMoreResults()` is false and `getUpdateCount()` is -1."

## 6. Memorize this

> **Memorize this:** `executeQuery` → `ResultSet` (rows), `executeUpdate` → `int` row count (DML, 0 for DDL), `execute` → `boolean` for anything — then `getResultSet()`/`getUpdateCount()`, and the end-of-results signal is `getMoreResults() == false && getUpdateCount() == -1`.

**Next likely topics:** Statement vs PreparedStatement vs CallableStatement, or ResultSet types (scrollable, updatable) & fetch size.
