# ResultSet — Types, Concurrency & fetchSize

**Priority: Interview-critical** — full deep-dive. ResultSet type constants are standard MNC trivia, and `fetchSize` is where seniors separate from juniors (the OOM-on-big-query question).

## 1. Core Mechanism

- A **`ResultSet`** is a **cursor** (a moving pointer over query results), not a list. It starts *before* the first row; each `next()` advances one row and returns `false` when rows run out.
- You read the current row with typed getters: `getLong("id")`, `getString(2)` — by column label or 1-based index.
- Rows may still be **on the wire or on the server** when you start reading. How many arrive per network round trip is controlled by `fetchSize`.
- It exists because result sets can be bigger than memory. A cursor lets Java process a billion rows with a flat heap — *if* configured right.
- Lifetime rule: a `ResultSet` dies when its `Statement` or `Connection` closes. Never return one from a method that closes the connection — map to objects first.

> **Interview definition (say this out loud):** "A ResultSet is a server-backed cursor over query results, not an in-memory collection — its type controls cursor movement, its concurrency controls in-place updates, and fetchSize controls how many rows the driver pulls per round trip, which is the knob that decides whether a big query streams or blows the heap."

## 2. Under the Hood

### 2.1 The three ResultSet types

Set when creating the statement: `conn.prepareStatement(sql, type, concurrency)`.

| Type constant | Cursor movement | How it's implemented | Cost |
|---|---|---|---|
| `TYPE_FORWARD_ONLY` (**default**) | `next()` only | True streaming cursor possible | Cheapest — always use this |
| `TYPE_SCROLL_INSENSITIVE` | `previous()`, `absolute(n)`, `first()`, `last()` | Driver **buffers the whole result client-side** (a snapshot); doesn't see later DB changes | Full result in heap — memory trap |
| `TYPE_SCROLL_SENSITIVE` | Same scrolling | Re-reads rows so committed DB changes *are* visible | Rarely truly supported; drivers silently downgrade to INSENSITIVE |

- Check what you actually got with `rs.getType()` — drivers downgrade silently and set a `SQLWarning`, not an exception.
- Scroll-insensitive "sees no changes" isn't a transaction feature — it's literally reading its own client-side copy.

### 2.2 Concurrency modes

| Constant | Meaning |
|---|---|
| `CONCUR_READ_ONLY` (**default**) | Getters only |
| `CONCUR_UPDATABLE` | `rs.updateString(...)` + `rs.updateRow()` writes the current row back; also `insertRow()`, `deleteRow()` |

- Updatable needs a query the driver can map to one table with a primary key — no joins, no aggregates, usually `SELECT *` from one table.
- Verdict for interviews: know it exists, say you'd use a normal `UPDATE` statement instead — updatable ResultSets bypass your SQL review, batch poorly, and lock rows longer.

### 2.3 Holdability

- `HOLD_CURSORS_OVER_COMMIT` — cursor survives `commit()`; `CLOSE_CURSORS_AT_COMMIT` — dies on commit.
- Matters only when reading and committing inside one loop (e.g. commit every 10k rows during a migration while still iterating). Default varies by vendor (Oracle holds, others vary) — one line, move on.

### 2.4 fetchSize — the deep part

`statement.setFetchSize(n)` = "driver, pull n rows per network round trip."

**The trade-off:** round trips vs heap.
- Heap per fetch ≈ `fetchSize × avg row bytes` (plus per-row object overhead). 10k rows × 2 KB = ~20 MB buffered per trip — fine. `fetchSize = 0/unbounded` on a 10M-row query = OOM.
- Round trips = `totalRows / fetchSize`. fetchSize 10 on 1M rows = 100k round trips × network latency — glacial. This is Oracle's classic problem: **default fetchSize is 10**.

**Per-driver reality (this is what interviewers fish for):**

| Driver | Default behavior | How to actually stream |
|---|---|---|
| **PostgreSQL** | fetchSize 0 = **buffer everything in heap** | `setFetchSize(n)` **AND** `autoCommit=false` — the server-side cursor (portal) only lives inside a transaction; in autocommit the driver ignores fetchSize and buffers all |
| **MySQL** | **Always buffers everything**, fetchSize hint ignored | Either `setFetchSize(Integer.MIN_VALUE)` = row-by-row streaming (locks the connection until fully read), or `useCursorFetch=true` in the URL for real chunked fetch |
| **Oracle** | Streams, but default fetchSize **10** — very chatty | Just raise it: 100–1000 typical |

- Why buffering is the default: it frees server resources fast and makes the common small-query case snappy. Streaming pins a server-side cursor (and often a transaction) open for as long as you iterate.
- While a MySQL connection streams row-by-row, it can execute **nothing else** — return it to the pool late and slow consumers become pool starvation.

### 2.5 Reading values correctly

- **Column index vs label:** label (`getLong("id")`) is refactor-safe and self-documenting; index is marginally faster. Use labels.
- **NULL trap:** primitive getters can't return null — `getInt` on a NULL column returns **0**. Either check `rs.wasNull()` right after, or use `rs.getObject("col", Integer.class)` which returns a real `null`.
- **Modern types:** `rs.getObject("placed_at", LocalDateTime.class)` (JDBC 4.2) — skip old `java.sql.Timestamp` conversions.

## 3. The Node.js / NestJS Bridge

| Concept | Node / `pg` | Java / JDBC |
|---|---|---|
| Default result shape | `result.rows` — always a full array in memory | `ResultSet` cursor — *can* stream |
| Streaming | opt-in: `pg-query-stream` / `pg-cursor` | same cursor API; enable with `fetchSize` + driver rules |
| Chunk size | `cursor.read(100)` — explicit per read | `setFetchSize(100)` — driver fetches ahead automatically |
| Iteration | `for await (const row of stream)` | `while (rs.next())` — blocking, no await |

**Where the comparison breaks down:**

- `pg`'s default (`result.rows`) is honest — you *know* it's all in memory. JDBC's `ResultSet` *looks* like a stream but may secretly be a full buffer (Postgres autocommit, MySQL default). The API shape doesn't tell you the memory behavior; the driver config does. That gap is exactly the OOM interview question.
- Node streaming is pull-based and async (backpressure via the event loop). JDBC is pull-based and **blocking** — `rs.next()` parks the thread when the buffer is empty until the next chunk arrives.
- No Node equivalent of scrollable or updatable cursors — nobody misses them.

## 4. Production-Grade Code

```java
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.function.Consumer;
import javax.sql.DataSource;

public class TransactionExporter {

    public record TxnRow(long id, String account, java.math.BigDecimal amount, LocalDate bookedOn) {}

    private static final int STREAM_FETCH_SIZE = 5_000;   // ~rows per round trip; tune vs row width

    private final DataSource dataSource;

    public TransactionExporter(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** Streams an arbitrarily large table with flat heap — rows pushed to the consumer as they arrive. */
    public long exportSince(LocalDate cutoff, Consumer<TxnRow> sink) {
        var sql = """
                SELECT id, account_no, amount, booked_on
                FROM ledger_transactions
                WHERE booked_on >= ?
                ORDER BY id
                """;
        try (Connection conn = dataSource.getConnection()) {
            conn.setAutoCommit(false);                     // REQUIRED on Postgres or fetchSize is ignored
            long count = 0;
            try (PreparedStatement ps = conn.prepareStatement(
                    sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
                ps.setFetchSize(STREAM_FETCH_SIZE);
                ps.setObject(1, cutoff);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        // getObject with a class handles NULL correctly; getInt would return 0
                        sink.accept(new TxnRow(
                                rs.getLong("id"),
                                rs.getString("account_no"),
                                rs.getBigDecimal("amount"),
                                rs.getObject("booked_on", LocalDate.class)));
                        count++;
                    }
                }
                conn.commit();                             // closes the server-side cursor cleanly
                return count;
            } catch (SQLException e) {
                conn.rollback();
                throw new IllegalStateException("Export failed after streaming rows", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Could not obtain connection", e);
        }
    }
}
```

Key lines: `TYPE_FORWARD_ONLY` + `CONCUR_READ_ONLY` (cheapest cursor), `autoCommit=false` before executing (Postgres streaming rule), fetchSize as a constant with the tuning comment, rows pushed to a `Consumer` instead of collected into a `List`.

## 5. Top 3 MNC Interview Questions

**Q1: What ResultSet types exist, and what's the cost of a scrollable one?**

**What they're testing:** trivia recall *plus* whether you know scrollable = client-side buffering.

**Ideal answer:** "Three types: FORWARD_ONLY, the default — next() only; SCROLL_INSENSITIVE — free cursor movement over a client-side snapshot that doesn't see later DB changes; SCROLL_SENSITIVE — scrolling that re-reads committed changes, which most drivers don't truly support and silently downgrade. The catch: scroll-insensitive means the driver buffers the entire result in heap to allow backward movement. So scrollable plus a big query is an OOM. For paging I'd use LIMIT/OFFSET or keyset pagination in SQL, never a scrollable cursor."

**Q2: You set `fetchSize(500)` on Postgres but the app still loads all rows into memory. Why?**

**What they're testing:** do you know fetchSize is a *hint* with driver-specific rules, or do you think it's a universal switch.

**Ideal answer:** "The connection is in autocommit. Postgres implements fetchSize with a server-side cursor, and that cursor only lives inside a transaction — in autocommit mode the driver ignores the hint and buffers everything. Fix: `setAutoCommit(false)`, then fetchSize works and rows arrive 500 per round trip. MySQL is worse — it ignores fetchSize entirely unless you pass `Integer.MIN_VALUE` for row-by-row streaming or set `useCursorFetch=true`. Oracle streams by default but its fetchSize default of 10 makes it chatty — raise it."

**Q3: `getInt` returned 0 — was the column 0 or NULL?**

**What they're testing:** the primitive-NULL trap; whether you've actually read production data with JDBC.

**Ideal answer:** "You can't tell from the return value — Java primitives can't be null, so `getInt` maps SQL NULL to 0. Two fixes: call `rs.wasNull()` immediately after the getter — it reports whether the last read was NULL — or better, use `rs.getObject("col", Integer.class)`, which returns a real null. Same trap applies to getLong, getDouble and getBoolean; it's a classic source of silent data bugs in reports."

## 6. Memorize this

> **Memorize this:** ResultSet is a cursor — FORWARD_ONLY streams, SCROLL_* secretly buffers everything client-side; `fetchSize` sets rows-per-round-trip but each driver has a rule (Postgres: needs autoCommit off, MySQL: needs `Integer.MIN_VALUE` or `useCursorFetch`, Oracle: default 10 too small); and `getInt` on NULL returns 0 — check `wasNull()` or use `getObject`.
