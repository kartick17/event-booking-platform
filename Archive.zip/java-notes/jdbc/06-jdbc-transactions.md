# JDBC Transactions (autoCommit, Savepoints, Isolation Levels)

> **Priority: Interview-critical** — transactions and isolation levels are a guaranteed topic in any backend interview, and the JDBC layer is where Spring's `@Transactional` magic actually bottoms out.

## 1. Core Mechanism

- A JDBC `Connection` is always in one of two modes. **autoCommit = true** (the default): every single statement runs in its own tiny transaction and commits the moment it finishes. **autoCommit = false**: statements pile up in one open transaction until you call `commit()` or `rollback()`.
- **Savepoint** = a named bookmark inside an open transaction. You can roll back to it without throwing away the whole transaction.
- **Isolation level** = how much one running transaction can see of another's uncommitted or fresh changes. Set per connection with `setTransactionIsolation(...)`.
- **Why it exists:** multi-statement operations (debit one account, credit another) must be all-or-nothing, and concurrent transactions must not corrupt each other's view of the data.

> **Interview definition (say this out loud):** "JDBC connections auto-commit each statement by default; for a real unit of work I set `autoCommit(false)`, run my statements, and `commit()` — or `rollback()` on failure. Isolation levels control what concurrent transactions see of each other, trading consistency against concurrency, and savepoints let me roll back part of a transaction instead of all of it."

## 2. Under the Hood

### 2.1 What autoCommit actually does

- With autoCommit on, the **driver** brackets every statement in its own transaction — for Postgres each statement is effectively its own implicit transaction; nothing for you to commit.
- `setAutoCommit(false)` does not "start a transaction" immediately. The Postgres driver, for example, sends `BEGIN` lazily before your **first statement**. `commit()` / `rollback()` then send literal `COMMIT` / `ROLLBACK` over the wire.
- Classic trap: switch autoCommit off, forget `commit()`, close the connection → the driver/DB **rolls back** your work silently (spec says behavior is implementation-defined, so never rely on close committing).
- **Pool caveat:** connection state (autoCommit, isolation) sticks to the physical connection. HikariCP resets both to its configured defaults when a connection is returned — but if you ever hand-roll pooling, a "dirty" connection leaks your transaction mode to the next borrower.

### 2.2 Isolation levels and the three anomalies

The three anomalies first — recite them in this order:
- **Dirty read** — you read data another transaction has written but **not committed** (it might roll back).
- **Non-repeatable read** — you read the same **row** twice, and it changed between reads (someone committed an update).
- **Phantom read** — you run the same **query** twice, and new rows appeared (someone committed an insert matching your `WHERE`).

| JDBC constant | Dirty read | Non-repeatable read | Phantom read | Notes |
|---|---|---|---|---|
| `TRANSACTION_READ_UNCOMMITTED` | possible | possible | possible | Postgres doesn't really support it — silently upgrades to READ COMMITTED |
| `TRANSACTION_READ_COMMITTED` | blocked | possible | possible | **Postgres default** |
| `TRANSACTION_REPEATABLE_READ` | blocked | blocked | possible | **MySQL InnoDB default**; InnoDB mostly blocks phantoms too via gap locks |
| `TRANSACTION_SERIALIZABLE` | blocked | blocked | blocked | Full safety; DB may abort transactions with serialization errors — retry logic needed |

- Set isolation **before** the transaction starts; changing it mid-transaction is undefined or an error depending on the driver.
- Senior point: know your **DB defaults** (Postgres = READ COMMITTED, MySQL = REPEATABLE READ). Interviewers love asking why the same code behaves differently on the two databases.

### 2.3 Savepoints on the wire

- `conn.setSavepoint("bulkRow42")` → sends `SAVEPOINT bulkRow42`. `conn.rollback(sp)` → `ROLLBACK TO SAVEPOINT bulkRow42` — statements after the savepoint are undone, everything before it stays pending. `releaseSavepoint(sp)` frees it.
- Real use case: batch import where one bad row should not kill the whole batch — savepoint before each row, roll back to it on failure, keep going, commit the survivors.

### 2.4 The bridge to Spring `@Transactional`

- `@Transactional` is exactly this machinery, automated: the transaction interceptor grabs a connection from the pool, calls `setAutoCommit(false)`, binds the connection to the current thread (a `ThreadLocal`), and your repositories all reuse that bound connection. Commit or rollback happens in the proxy when your method returns or throws. Knowing the JDBC layer means you can explain *what Spring actually does* — that is the senior answer.

## 3. The Node.js / NestJS Bridge

| Concept | Node (`pg` / TypeORM) | Java / JDBC |
|---|---|---|
| Default mode | Each `pool.query()` auto-commits | Same — autoCommit is true by default |
| Start a transaction | `client.query('BEGIN')` | `conn.setAutoCommit(false)` (driver sends BEGIN lazily) |
| Commit / rollback | `client.query('COMMIT' / 'ROLLBACK')` | `conn.commit()` / `conn.rollback()` |
| Managed transaction | `dataSource.transaction(async em => ...)` | Spring `@Transactional` |
| Isolation | `BEGIN ISOLATION LEVEL SERIALIZABLE` | `conn.setTransactionIsolation(...)` |

**Where the comparison breaks down:**
- In `pg` you **must** use one checked-out `client` for the whole transaction — `pool.query('BEGIN')` then `pool.query(...)` is a classic bug because each call may grab a different connection. JDBC makes this impossible to get wrong: the transaction *is* the `Connection` object.
- Node transaction helpers pass you a scoped client/manager explicitly. Spring hides the connection in a `ThreadLocal` — invisible until it bites you (that is the self-invocation trap, a later topic).

## 4. Production-Grade Code

```java
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;

public final class LedgerService {

    public record Transfer(long fromAccountId, long toAccountId, long amountCents) {}

    private final DataSource dataSource;

    public LedgerService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /** All-or-nothing money transfer: the canonical manual JDBC transaction. */
    public void transfer(Transfer t) {
        try (var conn = dataSource.getConnection()) {
            conn.setAutoCommit(false);
            // set BEFORE first statement — mid-transaction changes are undefined
            conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
            try {
                debit(conn, t.fromAccountId(), t.amountCents());
                credit(conn, t.toAccountId(), t.amountCents());
                conn.commit();
            } catch (SQLException e) {
                conn.rollback(); // without this, close() behavior is driver-defined
                throw new IllegalStateException("Transfer failed, rolled back", e);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Could not obtain connection", e);
        }
    }

    /** Savepoint pattern: one bad row must not kill the whole batch. */
    public int importPayments(List<Transfer> batch) {
        int imported = 0;
        try (var conn = dataSource.getConnection()) {
            conn.setAutoCommit(false);
            for (var t : batch) {
                var savepoint = conn.setSavepoint();
                try {
                    debit(conn, t.fromAccountId(), t.amountCents());
                    credit(conn, t.toAccountId(), t.amountCents());
                    imported++;
                } catch (SQLException rowFailure) {
                    conn.rollback(savepoint); // undo this row only, keep earlier rows pending
                }
            }
            conn.commit();
            return imported;
        } catch (SQLException e) {
            throw new IllegalStateException("Batch import failed", e);
        }
    }

    private void debit(Connection conn, long accountId, long amountCents) throws SQLException {
        var sql = "UPDATE accounts SET balance_cents = balance_cents - ? WHERE id = ? AND balance_cents >= ?";
        try (var stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, amountCents);
            stmt.setLong(2, accountId);
            stmt.setLong(3, amountCents);
            if (stmt.executeUpdate() != 1) {
                throw new SQLException("Insufficient funds or unknown account " + accountId);
            }
        }
    }

    private void credit(Connection conn, long accountId, long amountCents) throws SQLException {
        var sql = "UPDATE accounts SET balance_cents = balance_cents + ? WHERE id = ?";
        try (var stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, amountCents);
            stmt.setLong(2, accountId);
            if (stmt.executeUpdate() != 1) {
                throw new SQLException("Unknown account " + accountId);
            }
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: What does autoCommit mean in JDBC, and what happens if you disable it and close the connection without committing?**
- *What they're testing:* whether you know the default behavior and the silent-rollback trap.
- *Ideal answer:* "By default every statement commits itself the moment it runs. For a multi-statement unit of work I call `setAutoCommit(false)`, then `commit()` or `rollback()` explicitly. If I close without committing, the outcome is implementation-defined — most drivers roll back — so I always commit or roll back explicitly, and with a pool I rely on it resetting the autoCommit flag when the connection is returned."

**Q2: Explain the transaction isolation levels and the anomalies each one prevents.**
- *What they're testing:* the classic recital — plus whether you know real DB defaults.
- *Ideal answer:* "Three anomalies: dirty read (seeing uncommitted data), non-repeatable read (a row changes between my reads), phantom read (new rows appear for the same query). READ UNCOMMITTED allows all three; READ COMMITTED blocks dirty reads — that's the Postgres default; REPEATABLE READ also blocks non-repeatable reads — that's MySQL's default; SERIALIZABLE blocks all three but can abort transactions under contention, so it needs retry logic."

**Q3: What is a savepoint and when have you used one?**
- *What they're testing:* whether you know partial rollback exists — most candidates only know full rollback.
- *Ideal answer:* "A savepoint is a bookmark inside an open transaction; `rollback(savepoint)` undoes only what came after it. My use case is batch imports: I set a savepoint before each row, and if one row fails I roll back to its savepoint and continue, so one bad record doesn't destroy the whole batch. At the end I commit the survivors in one transaction."

## 6. Memorize this

> **Memorize this:** autoCommit=true means every statement is its own transaction; real work = `setAutoCommit(false)` → statements → `commit()`/`rollback()`; anomalies are dirty → non-repeatable → phantom, killed in that order by READ COMMITTED (Postgres default) → REPEATABLE READ (MySQL default) → SERIALIZABLE; savepoints give partial rollback.

**Next likely topics:** Statement vs PreparedStatement vs CallableStatement, or connection pooling internals (HikariCP) → then Spring `@Transactional`.
