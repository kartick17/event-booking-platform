# Request/Response and the OSI / TCP-IP Model

**Priority: Dev-important, Interview-light** — short notes. OSI trivia shows up in screening rounds ("which layer is TCP?"), but nobody deep-dives it in a Java interview. Learn the table, know where JDBC and HTTP sit, move on.

## The idea in one paragraph

Every request/response you make — an HTTP call, a JDBC query — is just application bytes handed down a stack of layers. Each layer wraps the data with its own header (**encapsulation**), the wire carries it, and the receiving side unwraps in reverse. OSI is the 7-layer textbook model; TCP/IP is the 4-layer model the real internet uses. Interviewers ask OSI; engineers think TCP/IP.

## The layers, with a JDBC query as the example

A `ps.executeQuery()` to Postgres travels like this:

| OSI layer | TCP/IP layer | What happens to your query | Real things here |
|---|---|---|---|
| 7 Application | Application | Driver encodes SQL + params into the **Postgres wire protocol** message | HTTP, JDBC wire protocols, DNS, TLS handshake messages |
| 6 Presentation | (folded into App) | Encoding & encryption — UTF-8 bytes, **TLS** encrypts the message | TLS/SSL, charsets, compression |
| 5 Session | (folded into App) | Session state — your DB session (auth, transaction mode) lives here conceptually | Login sessions, TLS session resumption |
| 4 Transport | Transport | **TCP** chops bytes into segments, adds ports (client:54321 → server:5432), guarantees order + delivery | TCP, UDP |
| 3 Network | Internet | **IP** adds source/destination IP addresses, routes packet hop by hop | IP, ICMP (ping), routers |
| 2 Data Link | Link | Frames with **MAC addresses** for the next hop only | Ethernet, Wi-Fi, switches |
| 1 Physical | Link | Actual electrons / light / radio | Cables, NICs |

Response comes back the same way, unwrapped bottom-up. The driver reads row bytes off the socket → that's your `ResultSet`.

Memory hooks:
- 7-layer order: **"All People Seem To Need Data Processing"** (Application → Physical).
- Port = which *program* on the machine (layer 4). IP = which *machine* (layer 3). MAC = which *next hop* (layer 2).

## What matters for a backend dev

- **You live at layer 7 and touch layer 4.** App code = layer 7. Timeouts, ports, keep-alive, connection pooling = layer 4 concerns. Everything below is the OS and network gear.
- **TCP connection = the 3-way handshake** (SYN → SYN-ACK → ACK) before any data. Plus TLS handshake on top. That startup cost is *the* reason JDBC connection pools and HTTP keep-alive exist — pay the handshake once, reuse the pipe.
- **One JDBC `Connection` = one TCP socket** = one (clientIP, clientPort, serverIP, serverPort) pair. Two threads writing to it would interleave segments of different messages — that's the layer-view of why connections aren't thread-safe.
- **HTTP vs JDBC:** both are layer-7 protocols over TCP. HTTP is text-ish, stateless, one req→res per exchange. JDBC wire protocols are binary and **stateful** — the server remembers your session (prepared statements, transaction). That statefulness is why DB connections are pooled and pinned, while HTTP requests can go to any server behind a load balancer.

## Node bridge

Same stack, same layers. `pg` in Node opens the identical TCP socket to port 5432 and speaks the identical Postgres wire protocol as the JDBC driver. Only difference is layer-7-and-above ergonomics: Node reads the socket via the event loop (async), the JDBC driver blocks a thread on the socket read. The network doesn't know or care which language sent the bytes.

## One interview question

**Q:** "Walk me through what happens at the network level when your service runs a database query."

**Ideal answer:** "The driver encodes the SQL into the database's wire protocol — that's application layer. TLS encrypts it, then TCP splits it into segments with source and destination ports and guarantees ordered delivery — transport layer. IP routes each packet to the DB host's address — network layer — and Ethernet frames handle each physical hop. The DB's reply climbs back up the same stack, and the driver parses row bytes into a ResultSet. The key production insight: the TCP plus TLS handshake before any of this is expensive, which is exactly why we hold connections open in a pool instead of reconnecting per query."

> **Memorize this:** Req/res = bytes wrapped layer by layer — app protocol (HTTP/JDBC, L7) → TLS (L6) → TCP ports + ordering (L4) → IP routing (L3) → frames on the wire (L2/1); pools and keep-alive exist because the L4+TLS handshake is the expensive part.
