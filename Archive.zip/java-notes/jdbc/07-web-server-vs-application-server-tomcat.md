# Web Server vs Application Server vs Tomcat

> **Priority: Dev-important, Interview-light** — short notes. The one question that does get asked: "is Tomcat a web server or app server?"

## The three categories

- **Web server** — serves static files and handles raw HTTP (parsing, TLS, keep-alive). No business logic. Examples: nginx, Apache httpd.
- **Application server** — runs *your code* to produce dynamic responses. In the Java world this historically meant a full **Jakarta EE server** (WildFly, WebLogic, WebSphere): Servlets + EJB + JMS + distributed transactions, the whole spec stack.
- **Tomcat sits in between: it is a servlet container.** It implements only the web-facing specs — Servlet, JSP, WebSocket, Expression Language — not full EE. It can serve static files like a web server and run Java code like an app server. Calling it a "lightweight application server" is acceptable in an interview if you say *servlet container* first.

## How Tomcat handles a request

- An NIO connector accepts the socket, then hands the request to a worker thread from a pool (default max 200). One thread carries the request through your whole code path — the **thread-per-request** model.
- This is the deep contrast with Node's single event loop, and it is why blocking JDBC calls are fine in Java.

## Modern deployment flipped the relationship

- Old model: install Tomcat on a server, deploy your app into it as a WAR file.
- Spring Boot model: Tomcat is **embedded** as a jar inside your app — `java -jar app.jar` starts your code, and your code starts Tomcat. Same shape as Node, where Express starts its own `http` server.
- nginx still often sits in front in both worlds, for TLS and static assets.

## Tuning embedded Tomcat (Spring Boot)

```properties
# application.properties
server.port=8080
server.tomcat.threads.max=200        # worker pool ceiling — one thread per in-flight request
server.tomcat.threads.min-spare=10
server.tomcat.accept-count=100       # queue length once all threads are busy
server.tomcat.connection-timeout=20s
```

## Interview question

**Q: Is Tomcat a web server or an application server?**
- *What they're testing:* whether you know the servlet-container middle category, or just guess one of the two.
- *Ideal answer:* "Strictly it's a servlet container — it implements the Servlet, JSP, and WebSocket specs but not the full Jakarta EE stack like EJB or JMS, which is what full app servers like WildFly or WebLogic provide. It can serve static content like a web server too. In modern Spring Boot apps it's embedded as a library inside the jar, so the app starts Tomcat rather than being deployed into it."

## Memorize this

> **Memorize this:** Tomcat is a servlet container — more than a web server, less than a full Jakarta EE app server — and in Spring Boot it lives *inside* your jar, running one worker thread per request.

**Next likely topics:** Servlet lifecycle (init, service, destroy), or Servlet request flow (web.xml vs annotations, ServletContext).
