# Servlet Lifecycle (init, service, destroy)

> **Priority: Interview-critical** — a guaranteed question in any Java web round; the thread-safety trap inside it is the real senior filter.

## 1. Core Mechanism

- A servlet is a Java class that handles HTTP requests **inside a container** (Tomcat). You never call `new` on it, and you never call its methods — the container does. This is your first taste of IoC (inversion of control — the framework calls you).
- Lifecycle, in order:
  1. **Load & instantiate** — container loads the class and creates **exactly one instance**.
  2. **`init(ServletConfig)`** — called **once**, before any request. Setup goes here.
  3. **`service(req, resp)`** — called **once per request**, each on a different worker thread. `HttpServlet.service()` dispatches to `doGet`/`doPost`/etc. by HTTP method.
  4. **`destroy()`** — called **once** when the container shuts down or redeploys the app. Cleanup goes here.
- **Why it exists:** the container owns threads, sockets, and lifecycles so your class holds only the request-handling logic. Every Java web framework — including Spring MVC — is built on top of this contract.

> **Interview definition (say this out loud):** "The container creates a single servlet instance, calls `init()` once before serving anything, then calls `service()` for every request — each on a different thread from the worker pool — and `destroy()` once at shutdown. So a servlet is one shared object handling many concurrent requests, which is why instance state must be thread-safe."

## 2. Under the Hood

### 2.1 One instance, many threads — the trap

- The container does **not** create a servlet per request. One instance, and Tomcat's worker pool (~200 threads) calls `service()` on it **concurrently**.
- Consequence: **instance fields are shared across all requests**. An `int counter` field or a mutable `SimpleDateFormat` field is a race condition. Store per-request state in local variables; store shared state only in thread-safe types (`AtomicLong`, `ConcurrentHashMap`) or immutable objects.
- `SingleThreadModel` (one-thread-at-a-time servlets) existed once — deprecated and removed. Know the name only to say it's dead.

## 2.2 Instantiation and `init()`

- The container instantiates via reflection using the **no-arg constructor** — which is why setup lives in `init()`, not the constructor: only at `init()` time does the container hand you the `ServletConfig` (your init-params) and, through it, the `ServletContext` (the shared app-wide object).
- **Lazy by default:** instantiation + `init()` happen on the **first request**, unless you set `loadOnStartup` — then it happens at deploy time. Set it for servlets with heavy init so the first user doesn't eat the cost.
- Spec guarantee: `init()` fully completes before any `service()` call. If `init()` throws, the servlet is out of service — requests get 500/404.

### 2.3 `service()` dispatch chain

- `HttpServlet.service()` reads the HTTP method and dispatches: GET → `doGet`, POST → `doPost`, etc. You override the `doXxx` methods, not `service()` itself.
- Default `doGet`/`doPost` (if you don't override) return **405 Method Not Allowed** — a decent trivia point.

### 2.4 `destroy()` — what it does and does not guarantee

- Called once, when the app is undeployed or Tomcat shuts down gracefully. The container first stops routing new requests, waits for in-flight `service()` calls to finish (bounded by a timeout), then calls `destroy()`.
- **Not called** on a JVM crash or `kill -9`. Never rely on `destroy()` for correctness — only for tidy resource release (closing pools, stopping executors).

### 2.5 Registration and the Spring bridge

- Old way: `<servlet>` + `<servlet-mapping>` in `web.xml`. Modern way: `@WebServlet("/path")` annotation. Same lifecycle either way.
- **Spring MVC is one servlet.** `DispatcherServlet` implements this exact lifecycle: its `init()` builds/refreshes the Spring `WebApplicationContext`, and its `service()` routes every request to your `@Controller` methods. All of Spring web sits on this contract — and note your `@Controller` beans are also singletons serving concurrent requests, so the same thread-safety rule follows you into Spring.

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java Servlet |
|---|---|---|
| Setup once at start | `onModuleInit()` / bootstrap code | `init(ServletConfig)` |
| Handle a request | route handler / `@Get()` method | `service()` → `doGet()` / `doPost()` |
| Cleanup at shutdown | `onModuleDestroy()` / SIGTERM hook | `destroy()` |
| Instance model | One handler, one event-loop thread | One instance, **many** threads |
| Register a route | `app.get('/orders', fn)` | `@WebServlet("/orders")` |

**Where the comparison breaks down:**
- In Node, module-level mutable state is safe from data races — one thread touches it. In a servlet, an instance field is hit by 200 threads at once; the same "keep a counter in a variable" habit that works in Express is a **bug** in Java. This is the exact trap interviewers set.
- NestJS lifecycle hooks are per-module and optional sugar; the servlet lifecycle is a **spec contract** with hard guarantees (init-before-service, one instance) that the whole ecosystem builds on.

## 4. Production-Grade Code

```java
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;
import javax.sql.DataSource;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@WebServlet(urlPatterns = "/health", loadOnStartup = 1) // init at deploy, not first request
public final class HealthCheckServlet extends HttpServlet {

    // shared across ALL request threads — must be thread-safe or effectively final
    private volatile DataSource dataSource;              // written in init, read by many threads
    private final AtomicLong requestCount = new AtomicLong(); // NOT a plain long field

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config); // preserves the config for getServletContext() etc.
        var hikari = new HikariConfig();
        hikari.setJdbcUrl(config.getInitParameter("jdbcUrl"));
        hikari.setMaximumPoolSize(2); // health checks need almost nothing
        this.dataSource = new HikariDataSource(hikari);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        long served = requestCount.incrementAndGet();
        // per-request state lives in locals — never in instance fields
        boolean dbUp;
        try (var conn = dataSource.getConnection()) {
            dbUp = conn.isValid(2);
        } catch (Exception e) {
            dbUp = false;
        }
        resp.setStatus(dbUp ? 200 : 503);
        resp.setContentType("application/json");
        resp.getWriter().write(
                "{\"db\":\"%s\",\"served\":%d}".formatted(dbUp ? "up" : "down", served));
    }

    @Override
    public void destroy() {
        // graceful shutdown only — never runs on kill -9, so don't rely on it for correctness
        if (dataSource instanceof HikariDataSource hikari) {
            hikari.close();
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: Walk me through the servlet lifecycle. How many times is each method called?**
- *What they're testing:* the baseline recital, with the counts — candidates blur "once" vs "per request".
- *Ideal answer:* "The container loads the class and creates one instance, calls `init()` exactly once before any request, then `service()` once per request — each on a different pool thread — and `destroy()` exactly once at shutdown or redeploy. `service()` in `HttpServlet` dispatches to `doGet` or `doPost` based on the HTTP method. By default this all happens lazily on the first request unless `loadOnStartup` is set."

**Q2: Is a servlet thread-safe? What happens if I declare an instance variable in one?**
- *What they're testing:* the one-instance-many-threads trap — the real senior filter in this topic.
- *Ideal answer:* "No — the container uses a single instance and calls `service()` from many worker threads concurrently, so any mutable instance field is shared state and a race condition. I keep per-request data in local variables, and shared state either immutable or in thread-safe types like `AtomicLong` or `ConcurrentHashMap`. The old `SingleThreadModel` workaround is deprecated and gone."

**Q3: Why does `init()` exist when Java already has constructors?**
- *What they're testing:* whether you understand container-managed lifecycles rather than just memorizing method names.
- *Ideal answer:* "The container instantiates the servlet by reflection through the no-arg constructor, so at construction time there's no container context available. `init(ServletConfig)` runs after that, when the container can hand over the config and `ServletContext` — so anything needing container resources, like reading init-params or building a connection pool, belongs in `init()`. The spec also guarantees `init()` completes before the first `service()` call."

## 6. Memorize this

> **Memorize this:** One servlet instance — `init()` once, `service()` per request on many concurrent threads, `destroy()` once at graceful shutdown — so per-request state goes in locals, never in instance fields.

**Next likely topics:** ServletConfig vs ServletContext, or session tracking (cookies, HttpSession, URL rewriting).
