# ServletConfig vs ServletContext

> **Priority: Interview-critical** — a fixed screening question in MNC Java rounds; the "how does Spring use ServletContext" follow-up is a senior differentiator.

## 1. Core Mechanism

- **`ServletConfig`** — one object **per servlet**. Holds that servlet's own init-params (small config values). The container hands it to you in `init(ServletConfig)`. Private to that servlet.
- **`ServletContext`** — one object **per web application**. Shared by every servlet, filter, and listener in the app. Holds app-wide params, shared attributes, and container facilities (resources, dispatchers).
- Bridge between them: `config.getServletContext()` — the per-servlet object gives you the app-wide one.
- **Why both exist:** some config belongs to one servlet (its own settings); some belongs to the whole app (DB URL, shared caches). Two scopes, two objects.

> **Interview definition (say this out loud):** "`ServletConfig` is per-servlet — one instance each, carrying that servlet's init-params. `ServletContext` is per-application — a single shared object all servlets see, used for app-wide parameters and shared attributes. Config is private configuration; context is the application's shared memory."

## 2. Under the Hood

### 2.1 Creation timing and count

- `ServletContext` is created **at deploy time, before any servlet exists**. It dies when the app is undeployed.
- `ServletConfig` is created **per servlet, at that servlet's `init()` time** — so lazily, unless `loadOnStartup` forces it early.
- Trivia the old-school interviewers love: in a **distributed** app (one webapp on several JVM nodes), there is one `ServletContext` **per JVM** — it is not cluster-shared.

### 2.2 Params vs attributes — don't mix them up

| | Init params | Attributes |
|---|---|---|
| What | Read-only **strings** from config | Live **objects** set at runtime |
| ServletConfig | `<init-param>` inside `<servlet>` / `@WebServlet(initParams=...)` | — (config has no attributes) |
| ServletContext | `<context-param>` in `web.xml` | `setAttribute(name, obj)` / `getAttribute(name)` |

- Params are deploy-time strings; attributes are runtime objects. Saying "I'll set an init-param at runtime" is a fail.

### 2.3 Context attributes = shared mutable state

- `ServletContext.setAttribute` is the servlet-spec way for servlets to **share objects** — a `DataSource`, a cache, feature flags.
- Same warning as servlet fields: attributes are read and written by **many request threads concurrently**. Store immutable or thread-safe objects there; the context itself does not synchronize your object.
- `ServletContextListener` (`@WebListener`) gets `contextInitialized`/`contextDestroyed` callbacks — the standard place to build shared resources at startup and close them at shutdown.

### 2.4 The Spring bridge (senior answer)

- Classic Spring MVC bootstraps through exactly this machinery: **`ContextLoaderListener` is a `ServletContextListener`** — at `contextInitialized` it builds the Spring `WebApplicationContext` and stores it **as a `ServletContext` attribute** (key: `WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE`). `DispatcherServlet.init()` then finds it there.
- So "where does Spring live inside Tomcat?" has a literal answer: **inside a ServletContext attribute**. Dropping this in an interview signals you know the layer under the framework.

## 3. The Node.js / NestJS Bridge

| Concept | Node / Express / NestJS | Java Servlet |
|---|---|---|
| Per-handler config | Options passed to one route/module | `ServletConfig` init-params |
| App-wide shared object | `app.locals`, or a NestJS singleton provider | `ServletContext` attributes |
| App-wide config values | `process.env` / config module | `<context-param>` |
| Startup/shutdown hooks | bootstrap code, `onModuleInit/Destroy` | `ServletContextListener` |

**Where the comparison breaks down:**
- `app.locals` is touched by one thread; `ServletContext` attributes are hit by hundreds of threads concurrently — the object you store must be thread-safe.
- In NestJS, sharing is done by DI (inject a provider). The servlet spec has **no DI** — the context attribute map *is* the sharing mechanism. Spring adds DI on top, and (in classic setups) is itself bootstrapped through a context attribute.

## 4. Production-Grade Code

```java
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.sql.DataSource;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/** Builds app-wide resources once, shares them via ServletContext attributes. */
@WebListener
public final class AppBootstrapListener implements ServletContextListener {

    static final String DATA_SOURCE_ATTR = "app.dataSource";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        var ctx = sce.getServletContext();
        var hikari = new HikariConfig();
        hikari.setJdbcUrl(ctx.getInitParameter("jdbcUrl")); // <context-param>: app-wide string
        hikari.setMaximumPoolSize(10);
        ctx.setAttribute(DATA_SOURCE_ATTR, new HikariDataSource(hikari)); // attribute: live object
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        var ds = sce.getServletContext().getAttribute(DATA_SOURCE_ATTR);
        if (ds instanceof HikariDataSource hikari) {
            hikari.close();
        }
    }
}

@WebServlet(
        urlPatterns = "/reports/orders",
        initParams = @jakarta.servlet.annotation.WebInitParam(name = "maxRows", value = "500"))
final class OrderReportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // ServletConfig: this servlet's private knob
        int maxRows = Integer.parseInt(getServletConfig().getInitParameter("maxRows"));
        // ServletContext: the app-wide shared object, built by the listener before any init()
        var dataSource = (DataSource) getServletContext()
                .getAttribute(AppBootstrapListener.DATA_SOURCE_ATTR);

        try (var conn = dataSource.getConnection();
             var stmt = conn.prepareStatement("SELECT id FROM orders ORDER BY id DESC LIMIT ?")) {
            stmt.setInt(1, maxRows);
            try (var rs = stmt.executeQuery()) {
                var out = resp.getWriter();
                resp.setContentType("text/plain");
                while (rs.next()) {
                    out.println(rs.getLong("id"));
                }
            }
        } catch (Exception e) {
            resp.sendError(500, "Report failed");
        }
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: What is the difference between `ServletConfig` and `ServletContext`?**
- *What they're testing:* the standard recital — scope, count, timing.
- *Ideal answer:* "`ServletConfig` is one per servlet and carries that servlet's own init-params; it's handed over in `init()`. `ServletContext` is one per web application, created at deploy time before any servlet, and shared by all servlets, filters, and listeners — it holds app-wide context-params and runtime attributes. Config is private, context is shared; and `config.getServletContext()` links the two."

**Q2: How do two servlets share data?**
- *What they're testing:* whether you know the attribute mechanism and its thread-safety catch.
- *Ideal answer:* "Through `ServletContext` attributes — one servlet or a `ServletContextListener` calls `setAttribute` with a live object, others read it with `getAttribute`. Typical case: a listener builds a connection pool at `contextInitialized` and parks it in the context. Since many request threads touch attributes concurrently, whatever I store must be immutable or thread-safe."

**Q3: How does Spring itself use the `ServletContext`?**
- *What they're testing:* senior filter — layer-below-the-framework knowledge.
- *Ideal answer:* "Classic Spring MVC bootstraps through it: `ContextLoaderListener` is a `ServletContextListener` that builds the root `WebApplicationContext` in `contextInitialized` and stores it as a `ServletContext` attribute. `DispatcherServlet` finds it there during its own `init()`. So the Spring container literally lives in a context attribute — the same sharing mechanism from Q2."

## 6. Memorize this

> **Memorize this:** `ServletConfig` = one per servlet, private init-params, arrives at `init()`; `ServletContext` = one per webapp, created at deploy, shared params + attributes — and classic Spring parks its whole `ApplicationContext` inside a `ServletContext` attribute.

**Next likely topics:** Session tracking (cookies, HttpSession, URL rewriting), or RequestDispatcher forward vs sendRedirect.
