# JSP + MVC Evolution → Why DispatcherServlet Won

> **Priority: Interview-critical** — the evolution story is a favorite "architecture narrative" question, and the DispatcherServlet request flow is one of the top 5 Spring interview questions.

## 1. Core Mechanism

- **JSP (JavaServer Pages)** = HTML with embedded Java. Written so designers didn't have to touch servlet code. At runtime it **is** a servlet (see section 2).
- **The evolution, in three steps:**
  1. **Model 1:** the JSP does everything — renders HTML *and* holds business logic and DB calls. Quick to write, unmaintainable at scale.
  2. **Model 2 (MVC):** split the roles. Servlet = **controller** (handles the request, calls business logic), JavaBean = **model** (the data), JSP = **view** (renders it). Flow: servlet does the work, puts the model in a request attribute, forwards to a JSP.
  3. **Front Controller:** Model 2 still meant one servlet per URL, each duplicating the same plumbing (parsing, validation, routing to views). The fix: **one** servlet receives *every* request and delegates to handlers. Spring's `DispatcherServlet` is exactly this — and it won.
- **Why it won:** cross-cutting concerns (routing, security hooks, content negotiation, exception mapping) live in one place instead of being copy-pasted into fifty servlets.

> **Interview definition (say this out loud):** "Java web MVC evolved from JSPs holding all logic (Model 1), to servlet-controller-plus-JSP-view (Model 2), to the Front Controller pattern — a single servlet routing every request to handlers. `DispatcherServlet` is Spring's front controller: it owns the request pipeline and delegates to controller methods through `HandlerMapping` and `HandlerAdapter`."

## 2. Under the Hood

### 2.1 A JSP is a servlet — literally

- On first request, Tomcat's **Jasper** engine translates the `.jsp` into a `.java` servlet source file, compiles it to a `.class`, loads it, and runs the normal servlet lifecycle on it (`_jspService()` plays the role of `service()`).
- Your `<%= order.getId() %>` becomes an `out.write(...)` call inside generated Java. Scriptlets are just code pasted into `_jspService`.
- That first-request translate-and-compile cost is why production setups precompiled JSPs. Classic trivia: "what happens to a JSP at runtime?" → *it becomes a servlet.*

### 2.2 Why Model 2 wasn't enough

- One servlet per URL means the URL space lives in `web.xml`, plumbing is duplicated per servlet, and there is no single choke point for auth, logging, or error handling. Filters helped but only for wrap-around concerns — routing and view selection stayed scattered.

### 2.3 The DispatcherServlet request flow — memorize this chain

One request, in order:

1. Tomcat worker thread delivers the request to **`DispatcherServlet`** (mapped to `/`), which runs `doDispatch()`.
2. **`HandlerMapping`** — finds *which* handler matches the URL + HTTP method. For you that means the `@GetMapping`/`@PostMapping` method on a `@Controller` (found and indexed at startup by `RequestMappingHandlerMapping`).
3. **Interceptors** — registered `HandlerInterceptor`s run `preHandle` (think Express middleware around the handler).
4. **`HandlerAdapter`** — actually invokes your method. This is where argument resolution happens: `@PathVariable`, `@RequestBody` (deserialized by Jackson), validation.
5. **Return value handling — the fork:**
   - `@ResponseBody` / `@RestController` → an **`HttpMessageConverter`** (Jackson) writes JSON straight to the response. No view involved. This is the modern path.
   - Plain `@Controller` returning a view name → **`ViewResolver`** maps `"orderList"` to a template (JSP/Thymeleaf), which renders with the model.
6. **`HandlerExceptionResolver`** — any exception is routed to `@ExceptionHandler` / `@ControllerAdvice` instead of leaking a stack trace.

### 2.4 Why this design survived JSP's death

- JSP as a view technology is dead (JSON APIs + React/Vue took over), but nothing in the front-controller pipeline cares: step 5 just swapped ViewResolver for MessageConverter. The architecture outlived its original view layer — that is the "why DispatcherServlet won" punchline.

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java / Spring MVC |
|---|---|---|
| Front controller | Express `app` / Nest's router — built-in | `DispatcherServlet` — arrived after years of pain |
| Route matching | `app.get('/orders/:id', fn)` | `HandlerMapping` + `@GetMapping("/orders/{id}")` |
| Middleware | `app.use(fn)` | `HandlerInterceptor` (+ servlet `Filter` below it) |
| Body parsing / serialization | `express.json()` | `HttpMessageConverter` (Jackson) |
| Template views | EJS / Handlebars | JSP (legacy) / Thymeleaf |
| Error middleware | `(err, req, res, next)` | `@ControllerAdvice` / `HandlerExceptionResolver` |

**Where the comparison breaks down:**
- Express was born as a front controller — Node devs never lived the servlet-per-URL world, so the *reason* for the pattern is invisible from Node. Interviewers asking "why front controller?" want the history: centralizing cross-cutting concerns.
- JSP **compiles to a class** and runs the servlet lifecycle; EJS is interpreted per render. Different beast under the same "template" label.
- Spring's pipeline is spec'd into named, swappable strategy interfaces (`HandlerMapping`, `HandlerAdapter`, `ViewResolver`) — you can replace any stage. Express middleware is one flat chain.

## 4. Production-Grade Code

```java
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.Instant;
import java.util.NoSuchElementException;
import java.util.Optional;

/** The modern endpoint: DispatcherServlet -> HandlerMapping -> this method -> Jackson. */
@RestController
class OrderController {

    record OrderView(long id, String status, Instant createdAt) {}

    private final OrderQueryService orders;

    OrderController(OrderQueryService orders) { // constructor DI, same as NestJS
        this.orders = orders;
    }

    @GetMapping("/api/orders/{id}")
    ResponseEntity<OrderView> byId(@PathVariable long id) {
        // return value goes through HttpMessageConverter (Jackson) — no view layer
        return orders.findById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new NoSuchElementException("order " + id));
    }
}

/** Step 6 of the pipeline: exceptions become responses in ONE place — the front-controller win. */
@RestControllerAdvice
class ApiExceptionHandler {

    record ApiError(String message) {}

    @ExceptionHandler(NoSuchElementException.class)
    ResponseEntity<ApiError> notFound(NoSuchElementException e) {
        return ResponseEntity.status(404).body(new ApiError(e.getMessage()));
    }
}

interface OrderQueryService {
    Optional<OrderController.OrderView> findById(long id);
}
```

## 5. Top 3 MNC Interview Questions

**Q1: Explain what happens when a request hits a Spring MVC application.**
- *What they're testing:* the DispatcherServlet flow — the single most-asked Spring MVC question.
- *Ideal answer:* "Tomcat hands the request to `DispatcherServlet`, the front controller. It asks `HandlerMapping` which controller method matches the URL and HTTP method, runs interceptor `preHandle`s, then a `HandlerAdapter` invokes the method — resolving `@PathVariable` and `@RequestBody` arguments on the way in. For a `@RestController`, the return value is serialized by an `HttpMessageConverter` like Jackson; for a view controller, a `ViewResolver` renders the template. Exceptions route through `HandlerExceptionResolver` to `@ControllerAdvice`."

**Q2: What is the Front Controller pattern, and why is it better than one servlet per URL?**
- *What they're testing:* whether you know the *reason* the architecture exists, not just its name.
- *Ideal answer:* "One servlet receives every request and delegates to handlers, instead of mapping each URL to its own servlet. That centralizes everything cross-cutting — routing, security hooks, content negotiation, exception handling — in one pipeline rather than duplicated across servlets. It also makes routing dynamic: handlers are discovered from annotations at startup instead of hardcoded in `web.xml`. `DispatcherServlet` is Spring's implementation."

**Q3: What actually happens to a JSP at runtime?**
- *What they're testing:* classic trivia — separates "used JSP" from "read about JSP".
- *Ideal answer:* "It's translated into a servlet. On first request, Tomcat's Jasper engine generates a `.java` servlet from the JSP, compiles and loads it, and the page logic runs inside `_jspService()` under the normal servlet lifecycle. That's why the first hit is slow and why teams precompiled JSPs for production. So 'JSP vs servlet' is really 'generated servlet vs hand-written servlet'."

## 6. Memorize this

> **Memorize this:** JSP compiles into a servlet; Model 2 split controller (servlet) from view (JSP); DispatcherServlet won by being the single front controller — `HandlerMapping` finds the method, `HandlerAdapter` invokes it, then `HttpMessageConverter` (JSON) or `ViewResolver` (template) writes the response.

**Next likely topics:** Servlet Filters vs Spring Interceptors, or session tracking (cookies, HttpSession).
