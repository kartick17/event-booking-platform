# Static vs Dynamic Components

> **Priority: Basic** — you serve static and dynamic content daily in Node. Quick bullets only.

- **Static component** = files sent to the browser exactly as stored — HTML, CSS, JS, images. No server code runs. Same response for every user. In a Java webapp these sit in the WAR (in Spring Boot: `src/main/resources/static/`), or better, in front on nginx/CDN.
- **Dynamic component** = response is **generated per request** by code — servlets, JSP, Spring controllers returning JSON. Different user or data → different response. This is why Tomcat exists: nginx alone can't run Java.
- **Node bridge:** `express.static('public')` vs your route handlers. Identical split.
- **Only interview angle:** "why put nginx in front of Tomcat?" → let the web server handle static files, TLS, and compression cheaply; save Tomcat's worker threads for dynamic (Java) work. Course-speak version: web server = static, servlet container = dynamic.

## Memorize this

> **Memorize this:** Static = served as-is (web server territory); dynamic = generated per request by code (servlet container territory) — split them so worker threads only do real work.

**Next likely topics:** Servlet Filters vs Spring Interceptors, or session tracking (cookies, HttpSession).
