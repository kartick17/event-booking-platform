# Servlet Filters vs Spring Interceptors

> **Priority: Interview-critical** — "Filter vs Interceptor" is a fixed Spring interview question, and "where does Spring Security sit?" hides inside it.

## 1. Core Mechanism

- **Servlet `Filter`** — a servlet-spec component that wraps the request **before it reaches any servlet**, including `DispatcherServlet`. Lives at the container level. Chain style: do work → `chain.doFilter(req, res)` → work on the way back out.
- **Spring `HandlerInterceptor`** — a Spring MVC construct that runs **inside** `DispatcherServlet`, around the controller method: `preHandle` (before), `postHandle` (after handler, before view render), `afterCompletion` (always, like `finally`).
- **Why both exist:** they sit at different layers. A filter sees the raw HTTP request but has no idea which controller will run. An interceptor runs *after* `HandlerMapping`, so it knows exactly which handler method is about to execute — and can read its annotations.

> **Interview definition (say this out loud):** "A filter is a servlet-spec wrapper that runs before the request even reaches `DispatcherServlet` — container level, raw HTTP. An interceptor is Spring's hook inside the dispatch pipeline, running around the chosen controller method with access to the handler itself. Rule of thumb: raw HTTP concerns go in filters — that's where Spring Security lives — and handler-aware concerns go in interceptors."

## 2. Under the Hood

### 2.1 The full onion, in order

```
Tomcat worker thread
 → Filter 1 → Filter 2 → ... (each calls chain.doFilter)
   → DispatcherServlet.doDispatch()
     → HandlerMapping picks the handler
     → interceptor.preHandle()          (false = stop here)
       → HandlerAdapter → your @GetMapping method
     → interceptor.postHandle()         (skipped if handler threw)
     → view render / (JSON already written inside the handler step)
     → interceptor.afterCompletion()    (ALWAYS runs, gets the exception)
   ← response unwinds back out through the filters in reverse
```

### 2.2 Filters — the details that matter

- The chain call is the control point: **don't call `chain.doFilter` and you short-circuit** — write the response yourself (how auth filters reject with 401).
- Filters can **wrap** the request/response (`HttpServletRequestWrapper`) to modify bodies — request logging, compression, caching a re-readable body. Interceptors cannot do this.
- In Spring Boot: a `Filter` bean auto-registers for all URLs; use `FilterRegistrationBean` to control URL patterns and order. Extend **`OncePerRequestFilter`** so forwards and async dispatches don't run your filter twice.
- **Spring Security is a filter chain.** `FilterChainProxy` (registered through `DelegatingFilterProxy`) runs ~15 security filters *before* `DispatcherServlet` — because auth must happen before any routing or controller logic. This one fact is the senior marker for this topic.

### 2.3 Interceptors — the details that matter

- `preHandle` returns `boolean`; the `handler` parameter is a `HandlerMethod` — you can inspect the controller method's annotations (custom `@RequiresRole`, rate-limit tags). Filters can never do this.
- **The `postHandle` trap:** for `@RestController`, the JSON is written by the `HttpMessageConverter` *inside* the handler-adapter step — so by `postHandle` the response body is already gone. `postHandle`'s `ModelAndView` parameter only matters for template views. To touch JSON responses, use `ResponseBodyAdvice` instead.
- `afterCompletion` always runs and receives any exception — the right place for timing metrics and cleanup.
- Registered via `WebMvcConfigurer.addInterceptors(...)` with path patterns.

### 2.4 Exception handling differs by layer — the second trap

- Exceptions thrown in **controllers/interceptors** are caught inside `DispatcherServlet` and routed to `@ControllerAdvice`.
- Exceptions thrown in **filters** happen *before/outside* `DispatcherServlet` — `@ControllerAdvice` never sees them. They fall to the container's error handling (Spring Boot's `/error` + `ErrorController`). Many real-world "why is my JSON error handler not firing for auth errors?" bugs are exactly this.

### 2.5 Which to use

| Concern | Use |
|---|---|
| Auth tokens, CORS, compression, request/response body wrapping, correlation IDs | **Filter** (raw HTTP, must run before routing) |
| Per-handler metrics, checking controller annotations, tenant/locale setup, audit by endpoint | **Interceptor** (needs to know the handler) |
| Modify JSON response bodies | Neither — `ResponseBodyAdvice` |

## 3. The Node.js / NestJS Bridge

| Concept | NestJS | Java / Spring |
|---|---|---|
| Raw middleware (runs before routing) | Nest **Middleware** / Express `app.use` | Servlet `Filter` |
| Allow/deny before handler | Nest **Guard** (`canActivate` → boolean) | `preHandle` returning boolean |
| Around-handler logic | Nest **Interceptor** | `HandlerInterceptor` (+ AOP for full around) |
| Transform response body | Nest Interceptor's `map()` | `ResponseBodyAdvice` |

**Where the comparison breaks down:**
- NestJS Guards/Interceptors know the handler via `ExecutionContext` — same idea as `HandlerMethod`. But Nest runs everything in **one** framework layer; in Java, filters belong to the *container* and interceptors to *Spring* — two layers with **different exception handling**. That split does not exist in Nest and is exactly where the interview traps live.
- A Nest interceptor can rewrite the response body because nothing is written until the observable resolves; Spring's `postHandle` is too late for JSON. Don't carry the Nest intuition over.

## 4. Production-Grade Code

```java
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import java.util.UUID;

/** FILTER: raw-HTTP concern — correlation id must exist before anything else runs. */
@Component
class CorrelationIdFilter extends OncePerRequestFilter { // OncePerRequest: safe across forwards

    static final String HEADER = "X-Correlation-Id";

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp,
                                    FilterChain chain) throws java.io.IOException, jakarta.servlet.ServletException {
        var correlationId = req.getHeader(HEADER) != null ? req.getHeader(HEADER)
                : UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId); // visible in every log line of this request
        resp.setHeader(HEADER, correlationId);
        try {
            chain.doFilter(req, resp); // forget this call = request never reaches the app
        } finally {
            MDC.remove("correlationId"); // pooled thread serves the next request — must clean up
        }
    }
}

/** INTERCEPTOR: handler-aware concern — timing metrics tagged by controller method. */
class HandlerTimingInterceptor implements HandlerInterceptor {

    private static final String START_ATTR = "timing.start";

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) {
        req.setAttribute(START_ATTR, System.nanoTime()); // request attr, not a field — thread-safe
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest req, HttpServletResponse resp,
                                Object handler, Exception ex) {
        if (handler instanceof HandlerMethod method && req.getAttribute(START_ATTR) instanceof Long start) {
            long micros = (System.nanoTime() - start) / 1_000;
            // handler identity is the whole reason this isn't a filter
            System.out.printf("%s.%s took %dus (failed=%b)%n",
                    method.getBeanType().getSimpleName(), method.getMethod().getName(),
                    micros, ex != null);
        }
    }
}

@Configuration
class WebConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new HandlerTimingInterceptor())
                .addPathPatterns("/api/**");
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: What is the difference between a servlet Filter and a Spring Interceptor? When do you use each?**
- *What they're testing:* the layer model — most candidates only say "both are like middleware".
- *Ideal answer:* "A filter is servlet-spec, runs at the container level before the request reaches `DispatcherServlet`, sees raw HTTP, and can wrap the request or short-circuit by not calling `chain.doFilter`. An interceptor runs inside `DispatcherServlet` after handler mapping, so it knows which controller method will run and can read its annotations. Raw HTTP concerns — auth, CORS, correlation IDs, body wrapping — go in filters; handler-aware concerns — per-endpoint metrics, annotation checks — go in interceptors."

**Q2: Where does Spring Security fit in this picture?**
- *What they're testing:* the senior marker — whether you know Security is *not* interceptor-based.
- *Ideal answer:* "Spring Security is a filter chain. A `DelegatingFilterProxy` hands requests to `FilterChainProxy`, which runs the security filters — authentication, session, authorization — all before `DispatcherServlet`. It's built as filters because security must run before any routing or controller code, and because it must also protect non-Spring resources. Consequence: an exception thrown there never reaches `@ControllerAdvice` — it's handled by the container error path."

**Q3: Can `postHandle` modify the JSON body returned by a `@RestController`?**
- *What they're testing:* the classic trap — response-writing timing.
- *Ideal answer:* "No. For `@ResponseBody`, the `HttpMessageConverter` writes JSON to the response inside the handler-adapter step, so by `postHandle` the body is already committed — its `ModelAndView` argument only matters for template views. To transform JSON responses I'd implement `ResponseBodyAdvice`, which hooks in just before the converter writes."

## 6. Memorize this

> **Memorize this:** Filters wrap the *servlet* (container level, before `DispatcherServlet` — Spring Security lives there, and `@ControllerAdvice` can't catch their exceptions); interceptors wrap the *handler* (inside the dispatch, handler-aware) — and `postHandle` is too late to touch a JSON body.

**Next likely topics:** Session tracking (cookies, HttpSession), or Spring Bean lifecycle & IoC container.
