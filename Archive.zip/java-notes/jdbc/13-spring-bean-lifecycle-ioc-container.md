# Spring Bean Lifecycle & IoC Container

> **Priority: Interview-critical** — the #1 Spring interview topic; the "where do proxies get created" detail ties together `@Transactional`, AOP, and everything after.

## 1. Core Mechanism

- **IoC container** = Spring's `ApplicationContext`. You declare classes (`@Component`, `@Service`, `@Bean` methods); the container **creates the objects, wires their dependencies, and manages their whole life**. You never call `new` on your services — same inversion you know from NestJS.
- **Bean** = any object the container manages. Default scope: **singleton** — one instance per container, shared everywhere it's injected.
- **Lifecycle in one line:** definition found → instantiated → dependencies injected → callbacks and post-processors run (proxies appear here) → bean in use → destroy callbacks at shutdown.
- **Why it exists:** wiring by hand couples every class to its dependencies' construction. The container centralizes construction, so cross-cutting machinery (proxies, transactions, config injection) can be layered on during creation.

> **Interview definition (say this out loud):** "The IoC container instantiates a bean, injects its dependencies, runs the Aware callbacks, then `BeanPostProcessor`s wrap initialization — `@PostConstruct` and `afterPropertiesSet` run in between — and the *after-initialization* post-processor step is where AOP proxies are created. At context shutdown, `@PreDestroy` runs. Singletons are built eagerly at startup, one instance per container."

## 2. Under the Hood

### 2.1 Container startup phases (before any of your beans exist)

1. **Read bean definitions** — component scan finds `@Component` classes, `@Configuration` classes contribute `@Bean` methods. Result: a registry of *recipes* (`BeanDefinition`s), no objects yet.
2. **`BeanFactoryPostProcessor`** runs — it edits the **recipes** themselves. Example: the property-placeholder processor resolves `${db.url}` in definitions.
3. **Eager singleton instantiation** — the container walks definitions in dependency order and builds every singleton (unless `@Lazy`).

### 2.2 Per-bean lifecycle — the recital, in exact order

1. **Instantiate** — constructor runs. Constructor injection happens here.
2. **Populate** — field/setter `@Autowired` dependencies injected.
3. **Aware callbacks** — `BeanNameAware`, `ApplicationContextAware` etc., if implemented.
4. **`BeanPostProcessor.postProcessBeforeInitialization`** — every BPP sees every bean.
5. **Init callbacks**, in this order: `@PostConstruct` → `InitializingBean.afterPropertiesSet()` → `@Bean(initMethod=...)`.
6. **`BeanPostProcessor.postProcessAfterInitialization`** — **AOP proxies are created here** (`AbstractAutoProxyCreator` returns a proxy *instead of* your object). This is why `@Transactional`/`@Async` beans injected elsewhere are proxies, not your raw class.
7. **In use** — for singletons, concurrently by many threads.
8. **Destruction** (context close only): `@PreDestroy` → `DisposableBean.destroy()` → `destroyMethod`.

### 2.3 `BeanFactoryPostProcessor` vs `BeanPostProcessor`

| | Operates on | When | Example |
|---|---|---|---|
| `BeanFactoryPostProcessor` | Bean **definitions** (recipes) | Once, before any bean is built | `${...}` placeholder resolution |
| `BeanPostProcessor` | Bean **instances** | Around every bean's init | AOP proxy creator, `@Autowired` processor |

- Bonus depth: `@Autowired` itself is implemented by a BPP-family processor (`AutowiredAnnotationBeanPostProcessor`) — injection is not container magic, it's a post-processor.

### 2.4 Facts interviewers probe

- **Spring singleton ≠ GoF singleton.** One per *container*, not per JVM — enforced by a registry (a `ConcurrentHashMap` called `singletonObjects`), not by a private constructor.
- **Thread safety is your problem.** One singleton instance serves all request threads — same rule as servlets: no mutable instance state without protection.
- **Circular dependencies:** A needs B, B needs A. With **constructor injection it always fails** — you cannot construct either first. With field/setter injection Spring historically resolved it via the **three-level cache** (exposing a half-built "early reference"). Spring Boot 2.6+ **rejects circular references by default** — the modern answer is "restructure the code."
- **Prototype scope trap:** the container creates a prototype on every request for it but **never destroys it** — `@PreDestroy` does not run for prototypes. And injecting a prototype into a singleton freezes one instance forever (fix: `ObjectProvider`).

### 2.5 Scopes

| Scope | One instance per | Notes |
|---|---|---|
| `singleton` | container | default, eager, thread-shared |
| `prototype` | injection/request for it | no destroy callbacks |
| `request` | HTTP request | web only; injected via proxy |
| `session` | HTTP session | web only |
| `application` | `ServletContext` | ties back to note 09 |

## 3. The Node.js / NestJS Bridge

| Concept | NestJS | Spring |
|---|---|---|
| Container | Nest's DI container (modules) | `ApplicationContext` |
| Declare a bean | `@Injectable()` + module `providers` | `@Component` / `@Service` / `@Bean` |
| Default scope | Singleton | Singleton |
| Other scopes | `Scope.REQUEST`, `Scope.TRANSIENT` | `request`, `prototype` |
| Init hook | `onModuleInit()` | `@PostConstruct` |
| Destroy hook | `onModuleDestroy()` | `@PreDestroy` |
| Factory provider | `useFactory` | `@Bean` method |

**Where the comparison breaks down:**
- **Nest never wraps your providers.** Spring's lifecycle has a hook (`postProcessAfterInitialization`) where the container **replaces your object with a proxy** — that's the foundation of `@Transactional`, `@Async`, `@Cacheable`. Nothing equivalent exists in Nest; this is the biggest mental-model addition.
- Nest singletons live on one thread; Spring singletons are hammered by hundreds of threads — statelessness is a hard rule, not a style choice.
- Nest handles circular deps with `forwardRef()`; Spring's modern stance is "fail fast, redesign".
- Spring also supports field and setter injection; constructor injection is still the recommended style (immutability, testability) — same instinct you already have.

## 4. Production-Grade Code

```java
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** A singleton bean using the standard lifecycle hooks. */
@Service
public class PricingCacheService {

    private final PricingClient pricingClient;               // constructor injection: step 1
    private final Map<String, Long> priceCache = new ConcurrentHashMap<>(); // thread-safe: shared by all request threads

    public PricingCacheService(PricingClient pricingClient) {
        this.pricingClient = pricingClient;
        // DON'T warm the cache here — other beans/proxies may not be ready yet
    }

    @PostConstruct                                           // step 5: dependencies injected, safe to use them
    void warmUp() {
        pricingClient.fetchAll().forEach(p -> priceCache.put(p.sku(), p.cents()));
    }

    @PreDestroy                                              // step 8: graceful shutdown only
    void flush() {
        priceCache.clear();
    }

    public long priceOf(String sku) {
        return priceCache.getOrDefault(sku, -1L);
    }
}

interface PricingClient {
    record Price(String sku, long cents) {}
    List<Price> fetchAll();
}

/** Custom BeanPostProcessor: sees EVERY bean around its init phase (step 4 and 6). */
@Configuration
class LifecycleAuditConfig {

    @Bean
    static BeanPostProcessor initAuditor() { // static: BPPs must be created before regular beans
        return new BeanPostProcessor() {
            @Override
            public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
                // AOP infrastructure runs at this same phase — returning a different
                // object here is exactly how Spring swaps in @Transactional proxies
                if (bean instanceof PricingCacheService) {
                    System.out.println("Bean ready (post-init, post-proxy): " + beanName);
                }
                return bean;
            }
        };
    }
}
```

## 5. Top 3 MNC Interview Questions

**Q1: Walk me through the Spring bean lifecycle.**
- *What they're testing:* the recital, and whether you know where proxies appear — that detail separates senior from memorized.
- *Ideal answer:* "Container startup first: definitions are scanned, `BeanFactoryPostProcessor`s adjust them, then singletons build eagerly. Per bean: constructor runs with constructor injection, remaining properties are populated, Aware callbacks fire, then `BeanPostProcessor` before-init, then `@PostConstruct` → `afterPropertiesSet` → custom init method, then `BeanPostProcessor` after-init — which is where AOP proxies replace the raw bean. At context close, `@PreDestroy` and destroy methods run, singletons only."

**Q2: What's the difference between `BeanFactoryPostProcessor` and `BeanPostProcessor`?**
- *What they're testing:* precision — most candidates blur these two.
- *Ideal answer:* "`BeanFactoryPostProcessor` runs once at startup and modifies bean *definitions* — the recipes — before anything is instantiated; property placeholder resolution is the classic example. `BeanPostProcessor` runs against every bean *instance*, before and after its init callbacks. The interesting ones are Spring's own: `@Autowired` is implemented by one, and the AOP auto-proxy creator is another — it returns a proxy from `postProcessAfterInitialization` instead of the original bean."

**Q3: How does Spring handle circular dependencies?**
- *What they're testing:* the three-level cache story plus the modern default — dated answers fail here.
- *Ideal answer:* "With constructor injection it can't — neither bean can be constructed first, so the context fails fast. With field or setter injection, Spring historically broke the cycle using its three-level singleton cache: it exposes an early reference to a half-initialized bean so the other side can inject it. But Spring Boot 2.6+ rejects circular references by default, and the right fix is restructuring — extract the shared piece into a third bean — rather than flipping `allow-circular-references`."

## 6. Memorize this

> **Memorize this:** Definitions → `BeanFactoryPostProcessor` (edits recipes) → per bean: constructor → inject → Aware → BPP-before → `@PostConstruct` → BPP-after (**proxies born here**) → in use → `@PreDestroy`; singletons are one-per-container, thread-shared, and eager.

**Next likely topics:** AOP & proxies (JDK dynamic vs CGLIB), or `@Transactional` internals — both build directly on the proxy point above.
