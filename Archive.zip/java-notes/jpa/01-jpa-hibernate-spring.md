# JPA, Hibernate & Spring — The Three Layers

**Priority: Interview-critical** — full deep-dive. "JPA vs Hibernate vs Spring Data JPA" is the opening question of nearly every Java backend interview, and the persistence context underneath it is where they separate seniors from annotation-users.

## 1. Core Mechanism

- **JPA** (Jakarta Persistence API) is a **specification** — interfaces and annotations only (`EntityManager`, `@Entity`, `@OneToMany`), no working code. It defines *how* Java objects map to tables (ORM) and how they're saved and loaded.
- **Hibernate** is the dominant **implementation** of that spec — the actual engine that generates SQL, tracks changes, and manages caching. (EclipseLink is the other one; nobody asks about it.)
- **Spring Data JPA** is a **convenience layer on top** — you write a repository *interface*, Spring generates the implementation that calls the `EntityManager` for you.
- Stack, top to bottom: **your code → Spring Data JPA → JPA interfaces → Hibernate → JDBC → driver → DB**. Every layer bottoms out in the JDBC you already studied.
- Why the split exists: same reason as JDBC — code against the standard (JPA), swap the engine (Hibernate) without rewriting. In practice nobody swaps, but the layering is the question.

> **Interview definition (say this out loud):** "JPA is the specification — just interfaces and annotations. Hibernate is the implementation that actually generates the SQL and manages the persistence context. Spring Data JPA sits on top and generates repository implementations, so I write an interface and get CRUD plus derived queries for free. I code against JPA, Hibernate does the work, Spring removes the boilerplate."

## 2. Under the Hood

### 2.1 Who provides what

| Layer | You touch | It provides |
|---|---|---|
| JPA (spec) | `@Entity`, `@Id`, `@OneToMany`, `EntityManager`, JPQL | the contract |
| Hibernate | usually nothing directly (`Session` = its extended `EntityManager`) | SQL generation, dirty checking, lazy proxies, caches, dialects |
| Spring Data JPA | `interface OrderRepository extends JpaRepository<Order, Long>` | runtime proxy implementing your interface, query derivation, pagination |

### 2.2 The persistence context — the concept everything hangs on

- The **persistence context** is a per-transaction, in-memory map of every entity loaded or saved in that transaction — the **first-level cache**. One per `EntityManager`, and in Spring, one per `@Transactional` method (bound to the thread, like the JDBC connection).
- It's an **identity map**: loading the same row twice in one transaction returns the **same Java object**, the second `find` doesn't even hit the DB.
- Entities inside it are **managed** — the context watches them. That's not a metaphor; it keeps a **snapshot** of each entity's state at load time.

### 2.3 Entity lifecycle states

| State | Meaning | Gets there by |
|---|---|---|
| **Transient (new)** | plain object, DB knows nothing | `new Order(...)` |
| **Managed** | in the persistence context, changes tracked | `persist()`, `find()`, query results |
| **Detached** | was managed; context closed or evicted | transaction ended; entity returned to controller |
| **Removed** | marked for DELETE at flush | `remove()` |

- `merge(detached)` copies a detached object's state onto a managed copy and returns **the managed copy** — the argument stays detached; using the argument afterward is a classic bug.

### 2.4 Dirty checking & flush — why there's no `update()` call

- At **flush time** (before commit, and before queries that need fresh data), Hibernate compares every managed entity against its load-time snapshot. Any difference → it generates the `UPDATE` itself.
- So inside a transaction: `Order o = repo.findById(id); o.setStatus(SHIPPED);` — **that's the whole update**. No `save()` needed. The `save()` you see everywhere is only required for *new* or *detached* entities.
- Writes are **queued and batched at flush** (write-behind), in a fixed order (inserts, updates, deletes) — SQL doesn't run when your line of code runs. Debugging consequence: constraint violations surface at commit, far from the code that caused them.
- Cost: snapshots double memory per loaded entity, and flush is O(entities in context) — loading 100k rows into a persistence context for a batch job is how JPA batch jobs die. Fix: process in chunks and `clear()` the context.

### 2.5 Lazy loading, proxies, and the N+1 problem

- `@ManyToOne` defaults to **eager**, `@OneToMany` to **lazy**. A lazy field holds a **proxy** (a generated subclass) instead of real data; first access triggers a `SELECT`.
- **`LazyInitializationException`**: touch a lazy field *after* the transaction/context closed (in the controller, in a JSON serializer) → the proxy has no session to load from. Fix at the query, not by making things eager.
- **N+1**: load 100 orders, then loop touching `order.getCustomer()` → 1 query + 100 single-row queries. The #1 ORM performance killer. Fixes, best first:
  - **fetch join**: `select o from Order o join fetch o.customer` — one SQL join.
  - **`@EntityGraph`** on the repository method — declarative fetch join.
  - `@BatchSize(size=50)` / `default_batch_fetch_size` — loads lazies in `IN (...)` batches; turns N+1 into N/50+1.
- Second-level cache (cross-transaction, opt-in per entity) exists — mention it, but say most teams prefer explicit caching (Redis/Caffeine) over Hibernate L2.

### 2.6 How Spring Data JPA does its magic

- Your repository interface gets a runtime **JDK dynamic proxy**; calls route to `SimpleJpaRepository`, a plain class using the `EntityManager` underneath.
- **Query derivation** parses method names — `findByStatusAndCreatedAtAfter(Status s, Instant t)` — into JPQL at startup (so typos fail at boot, not at runtime). Complex ones: `@Query("...")` with JPQL, or `nativeQuery = true` for raw SQL.
- Everything requires the **thread-bound** `EntityManager` that `@Transactional` opened — same ThreadLocal pattern as the JDBC connection. No transaction on a lazy access = `LazyInitializationException`. It all connects.

## 3. The Node.js / NestJS Bridge

| Concept | Node (TypeORM / Prisma) | Java (JPA/Hibernate) |
|---|---|---|
| Entity definition | TypeORM `@Entity()` decorators | `@Entity` annotations (TypeORM copied JPA) |
| Repository | `dataSource.getRepository(Order)` / Prisma client | `interface extends JpaRepository` |
| Query builder escape hatch | `createQueryBuilder()` / `$queryRaw` | JPQL `@Query` / native query |
| Relations loading | `relations: ['customer']` / `include: {customer: true}` | fetch join / `@EntityGraph` |
| Migrations | TypeORM migrations / `prisma migrate` | Flyway/Liquibase (`ddl-auto` only for dev) |

**Where the comparison breaks down — this is the big one:**

- **Prisma is stateless; JPA is stateful.** Prisma: query returns plain data, you edit it, you must call `update()` explicitly. JPA: query returns *managed* objects under surveillance; mutating them inside a transaction writes to the DB **with no update call**. Coming from Prisma, dirty checking feels like spooky action at a distance — and it's exactly what interviewers test.
- **Identity map:** two Prisma queries for the same row = two independent objects. Two JPA `find`s in one transaction = the same object, one SQL query.
- TypeORM sits in between (it has an EntityManager and persist semantics) but its default patterns are explicit-save; nobody leans on dirty checking the way JPA code does.
- **Lazy loading across the boundary:** returning a Prisma object to the serializer is always safe — data is plain. Returning a JPA entity to Jackson can trigger lazy loads mid-serialization or blow up with `LazyInitializationException` — the reason DTOs-at-the-boundary is standard Java practice.

## 4. Production-Grade Code

```java
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Entity
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // override the eager default — eager @ManyToOne is a hidden join on every load
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    private String status;
    private BigDecimal total;
    private Instant placedAt;

    protected Order() {}                       // JPA needs a no-arg constructor (proxy subclassing)

    public Long getId() { return id; }
    public Customer getCustomer() { return customer; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}

@Entity
class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String email;

    protected Customer() {}
    public String getEmail() { return email; }
}

interface OrderRepository extends JpaRepository<Order, Long> {

    // derived query — parsed and validated at startup
    List<Order> findByStatusAndPlacedAtAfter(String status, Instant cutoff);

    // fetch join — kills the N+1 when customers will be accessed
    @Query("select o from Order o join fetch o.customer where o.status = :status")
    List<Order> findWithCustomerByStatus(@Param("status") String status);
}

@Service
class OrderService {

    private final OrderRepository orders;

    OrderService(OrderRepository orders) {
        this.orders = orders;
    }

    /** Dirty checking in action: no save() call anywhere. */
    @Transactional
    public void markShipped(long orderId) {
        Order order = orders.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("No order " + orderId));
        order.setStatus("SHIPPED");
        // managed entity + transaction commit -> Hibernate flushes UPDATE automatically
    }

    /** DTO at the boundary — entities never leave the transaction. */
    public record OrderView(long id, String status, String customerEmail) {}

    @Transactional(readOnly = true)            // readOnly skips dirty-check snapshots = less memory
    public List<OrderView> shippedOrders() {
        return orders.findWithCustomerByStatus("SHIPPED").stream()
                .map(o -> new OrderView(o.getId(), o.getStatus(), o.getCustomer().getEmail()))
                .toList();                     // customer already fetched — no lazy trigger, no N+1
    }
}
```

Three deliberate exhibits: `markShipped` has no save (dirty checking), the fetch join feeds `getCustomer()` safely, and DTO mapping happens *inside* the transaction so nothing lazy escapes.

## 5. Top 3 MNC Interview Questions

**Q1: What's the difference between JPA, Hibernate, and Spring Data JPA?**

**What they're testing:** the layering — the most-asked warmup, and a filter for people who think "JPA" is a product.

**Ideal answer:** "JPA is only a specification — interfaces and annotations, no runnable code. Hibernate is the implementation that does the real work: SQL generation, the persistence context, dirty checking, lazy loading. Spring Data JPA is a layer above both — I declare a repository interface, and Spring generates the implementation at runtime as a proxy over the EntityManager, including queries derived from method names. So the stack is: my interface → Spring's proxy → JPA's EntityManager → Hibernate → JDBC."

**Q2: You modified an entity inside a @Transactional method and never called save() — yet the database updated. Explain.**

**What they're testing:** persistence context + dirty checking — the single concept that proves you understand JPA rather than just use it.

**Ideal answer:** "That's dirty checking. Anything loaded inside the transaction is *managed* — it lives in the persistence context, which stored a snapshot of its state at load time. At flush, just before commit, Hibernate diffs every managed entity against its snapshot and generates UPDATEs for the changes itself. save() is only needed to make *new* or detached objects managed. Corollaries: SQL runs at flush, not at my setter line, so constraint errors appear at commit; and huge batch loads bloat the context with snapshots, so batch jobs need periodic flush-and-clear."

**Q3: What's the N+1 problem and how do you fix it?**

**What they're testing:** the #1 real-world ORM performance issue; they want named fixes, not "optimize it".

**Ideal answer:** "Load N orders, then access a lazy relation on each — Hibernate fires one query for the list plus N single-row queries for the relation. Invisible in dev with 10 rows, deadly with 10 thousand. Fixes: a JPQL fetch join — `join fetch o.customer` — collapses it to one query; @EntityGraph does the same declaratively on a repository method; and batch fetching (`@BatchSize` or the global setting) turns N queries into N-over-batch-size IN-queries when a join would be too wide. I'd detect it by watching SQL logs or a tool like datasource-proxy in tests."

## 6. Memorize this

> **Memorize this:** JPA = spec, Hibernate = engine, Spring Data = generated repositories — and the engine's heart is the persistence context: a per-transaction identity map that snapshots managed entities and auto-flushes their diffs as UPDATEs (no save needed), while lazy proxies outside a transaction throw LazyInitializationException and inside a loop cause N+1 (fix: fetch join / @EntityGraph / batch size).
