# Maven — Structure & Build Tool

**Priority: Dev-important, Interview-light** — short notes. Maven matters every single day at work, but interviews rarely go past "explain the lifecycle" and "what's `provided` scope". Learn the three tables, move on.

## What it is

Maven is Java's standard build tool: it compiles, tests, packages, and manages **dependencies** (downloads JARs and their JARs from a central repository). Its philosophy is **convention over configuration** — the folder layout and build steps are fixed; you only declare what's different about your project. Node parallel: `package.json` + npm scripts + `node_modules`, but with a rigid, standardized project shape.

## Standard directory layout (fixed — don't fight it)

```
my-service/
├── pom.xml                      ← the manifest (package.json equivalent)
├── src/
│   ├── main/
│   │   ├── java/                ← production code (packages: com/weloin/orders/...)
│   │   └── resources/           ← config on classpath: application.yml, logback.xml
│   └── test/
│       ├── java/                ← tests, mirror package structure
│       └── resources/           ← test-only config
└── target/                      ← ALL build output (gitignored) — classes, jars, reports
```

## pom.xml — the parts that matter

```xml
<project>
    <groupId>com.weloin</groupId>            <!-- org namespace -->
    <artifactId>order-service</artifactId>   <!-- project name -->
    <version>1.4.2</version>                 <!-- these 3 = "GAV coordinates", the unique ID -->
    <packaging>jar</packaging>               <!-- jar | war | pom -->

    <properties>
        <maven.compiler.release>21</maven.compiler.release>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>42.7.3</version>
            <scope>runtime</scope>           <!-- see scopes table -->
        </dependency>
    </dependencies>
</project>
```

- Dependencies are **transitive** — you pull HikariCP, Maven pulls what HikariCP needs. Version conflicts are resolved by "**nearest wins**" (closest to your project in the tree), not highest version — a classic source of weird bugs; debug with `mvn dependency:tree`.
- Downloaded JARs live in one shared local cache: `~/.m2/repository` — a global, deduplicated `node_modules`.
- Spring Boot projects inherit a **parent POM** that pins tested versions of everything, so most dependencies need no `<version>` — that's the "BOM/dependency management" idea.

## Build lifecycle — the interview table

`mvn <phase>` runs **every phase up to and including it**, in order:

| Phase | What happens |
|---|---|
| `validate` | POM sanity checks |
| `compile` | `src/main/java` → `target/classes` |
| `test` | runs unit tests (Surefire); **failure stops the build** |
| `package` | makes the JAR/WAR in `target/` |
| `verify` | integration tests (Failsafe) |
| `install` | copies the artifact into `~/.m2` (local repo) |
| `deploy` | uploads to the remote company repository (Nexus/Artifactory) |

So `mvn package` = validate + compile + test + package. Daily commands: `mvn clean package` (fresh build), `mvn clean install -DskipTests` (the honest classic). Each phase is executed by **plugins** — Maven itself is just the orchestrator (compiler plugin compiles, Surefire runs tests, Spring Boot's plugin makes the runnable fat JAR).

## Dependency scopes — the other interview table

| Scope | On compile classpath | Packaged into JAR/WAR | Example |
|---|---|---|---|
| `compile` (default) | yes | yes | Spring, HikariCP |
| `provided` | yes | **no** — the runtime supplies it | servlet-api (Tomcat has it) — the classic exam answer |
| `runtime` | no | yes | JDBC driver (you code against `java.sql`, need the driver only at runtime) |
| `test` | test code only | no | JUnit, Mockito |

## Node bridge

| npm world | Maven world |
|---|---|
| `package.json` | `pom.xml` |
| `dependencies` / `devDependencies` | scopes (`compile` / `test`) |
| `node_modules` per project | shared `~/.m2/repository` |
| `npm install` | dependencies resolve on any build |
| `npm run build` (script you define) | fixed lifecycle phases |
| `package-lock.json` | no lockfile — versions pinned in POM / parent BOM |
| npm registry | Maven Central + company Nexus/Artifactory |

Biggest breaks: no lockfile (reproducibility comes from explicit versions + BOMs), and lifecycle is standardized instead of per-project scripts — any Java dev can build any Maven project with `mvn clean package` without reading docs. Gradle is the main alternative (Groovy/Kotlin scripts, faster, flexible) — Maven still dominates enterprises because rigidity = uniformity.

## One interview question

**Q:** "What's the difference between `mvn package` and `mvn install`? And what does `provided` scope mean?"

**Ideal answer:** "Phases are cumulative: `package` runs everything through compiling and testing and produces the JAR in `target/`. `install` goes one step further and copies that artifact into my local `~/.m2` repository so other projects on my machine can depend on it; `deploy` pushes it to the company's remote repo for everyone. `provided` scope means I compile against the library, but it's not packaged, because the runtime environment supplies it — the textbook example is the Servlet API in a WAR: Tomcat already has it, and shipping a second copy causes conflicts."

> **Memorize this:** Maven = convention over configuration — fixed layout (`src/main/java` → `target/`), GAV coordinates in `pom.xml`, cumulative lifecycle (compile → test → package → install → deploy), transitive deps resolved nearest-wins into `~/.m2`, and `provided` = compile against it but the server ships it.
