# Servlets — Internals & Why They Exist

**Priority: Interview-critical** — full deep-dive. Servlet lifecycle and the "is a servlet thread-safe?" trap are MNC staples, and Spring MVC is literally one big servlet — you can't explain `DispatcherServlet` without this.

## 1. Core Mechanism

- A **servlet** is a Java class that handles an HTTP request and writes an HTTP response. It runs inside a **servlet container** (a server like Tomcat that owns sockets, HTTP parsing, and threads for you).
- You never write a `main()` loop or open a port. The container calls *your* code — classic inversion of control, years before Spring.
- **Why it was needed:** before servlets (1997), dynamic web pages used **CGI** — the web server spawned a whole new OS process per request, ran a script, and killed it. Process spawn per request = brutally slow. Servlets flipped it: **one JVM stays alive, one servlet instance stays loaded, each request is just a thread** calling a method. Orders of magnitude cheaper.
- Modern relevance: you'll never write a raw servlet at work — but Spring MVC's `DispatcherServlet` *is* one, Tomcat is still the default engine inside Spring Boot, and interviewers use servlets to test if you understand what Spring sits on.

> **Interview definition (say this out loud):** "A servlet is a container-managed Java class that handles HTTP — the container keeps one instance and dispatches every request to it on a pooled thread. It replaced CGI's process-per-request with thread-per-request in a long-lived JVM, and it's the foundation Spring MVC's DispatcherServlet is built on."

## 2. Under the Hood

### 2.1 What the container (Tomcat) actually does

Request path, in order:

1. **Connector** — NIO acceptor holds the server socket on port 8080, accepts TCP connections, reads bytes, parses them into HTTP (method, headers, body).
2. Parsed request is handed to a **worker thread pool** (Tomcat default: max 200 threads).
3. The worker wraps everything in `HttpServletRequest` / `HttpServletResponse` objects.
4. **Mapping**: URL pattern → which servlet. Then the **filter chain** (see 2.4) runs, then your servlet's `service()`.
5. Your code writes to the response's output stream; the container flushes it back down the socket.

So the container = HTTP server + thread manager + lifecycle manager + URL router. In Node terms: it's the `http` module, the event loop's job, and Express routing, all in one external product.

### 2.2 Lifecycle — the guaranteed interview question

| Phase | Method | When | How many times |
|---|---|---|---|
| Load + instantiate | constructor | First request, or at startup (`loadOnStartup`) | **Once** |
| Init | `init(ServletConfig)` | Right after construction | **Once** — open resources here |
| Serve | `service(req, res)` → routes to `doGet`/`doPost`/… | Every request, **on many threads at once** | Thousands, concurrently |
| Destroy | `destroy()` | Container shutdown / redeploy | **Once** — close resources here |

The load-bearing fact: **one instance, many threads**. The container does *not* create a servlet per request. Every concurrent request runs `service()` on the *same object* simultaneously.

### 2.3 The thread-safety consequence

- **Instance fields are shared by all requests.** A mutable instance field (`private int count;`, a `SimpleDateFormat`, a non-thread-safe cache) = race condition under load. This is *the* classic trap question.
- Safe options: local variables (each thread has its own stack), effectively-final injected dependencies that are themselves thread-safe (`DataSource`, Spring singletons), `AtomicLong`/concurrent collections for real shared state.
- The dead answer: `SingleThreadModel` interface — serialized requests per instance; deprecated and removed. Naming it as *deprecated* scores points; proposing it loses them.
- Same model applies to Spring: `@RestController` beans are singletons serving concurrent requests — the servlet rule never went away, Spring just hides it.
- One more trap: `HttpServletRequest`/`Response` objects are **recycled** by Tomcat after the request ends (object pooling to reduce GC). Stash a reference in a field or another thread and you'll read *someone else's request* later.

### 2.4 Filters, listeners, sessions — the supporting cast

- **`Filter`** — wraps servlet execution: `doFilter(req, res, chain)` runs code before, calls `chain.doFilter(...)`, runs code after. Auth, logging, CORS live here. This is Express middleware, almost exactly — including "forget to call the chain = request hangs/stops".
- **`ServletContext`** — one per web app; app-wide attributes and config.
- **`HttpSession`** — server-side per-user state keyed by the `JSESSIONID` cookie. Sticky and memory-bound; modern services skip it for stateless JWT or external session stores.
- **Async (Servlet 3.0+)** — `req.startAsync()` frees the worker thread while slow work happens elsewhere, completing the response later. It's how long-polling/SSE avoided eating the 200-thread pool. With **virtual threads (Java 21)**, plain blocking code gets the same scalability, so async servlets matter less now.

### 2.5 Spec evolution — one-glance table

| Servlet spec | Year / platform | What it added |
|---|---|---|
| 2.5 | 2006 | Everything in `web.xml` (XML deployment descriptor) |
| 3.0 | 2009 | `@WebServlet` annotations (bye `web.xml`), async support |
| 3.1 | 2013 | Non-blocking request/response I/O |
| 4.0 | 2017 | HTTP/2, server push |
| **5.0+** | 2020+, Jakarta EE | **Package rename `javax.servlet` → `jakarta.servlet`** (Oracle kept the `javax` trademark). Spring Boot 3 requires `jakarta.*` — the #1 migration breakage |

### 2.6 Where Spring fits

- Spring MVC = **one servlet**, `DispatcherServlet`, mapped to `/*` — the "front controller" pattern. It receives every request, then does its own routing to your `@GetMapping` methods via handler mappings.
- Spring Boot **embeds** Tomcat as a library (`spring-boot-starter-web`), instead of deploying a WAR *into* an external Tomcat. Same container, inverted packaging.
- So the full chain: Tomcat connector → worker thread → filter chain (Spring Security lives here) → `DispatcherServlet.service()` → your controller.

## 3. The Node.js / NestJS Bridge

| Concept | Node / Express | Java / Servlets |
|---|---|---|
| HTTP server | `http.createServer()` — in your process | Tomcat — container runs *you* |
| Route handler | `app.get('/orders', (req, res) => …)` | `doGet(HttpServletRequest, HttpServletResponse)` |
| Middleware | `app.use((req, res, next) => …)` + `next()` | `Filter` + `chain.doFilter()` |
| Request/response objects | fresh closure per request | container-recycled objects, one servlet instance |
| Concurrency | one thread, event loop interleaves | thread pool, one thread per request |
| App-wide state | module scope (single thread → safe-ish) | `ServletContext` / instance fields (**many threads → unsafe**) |

**Where the comparison breaks down:**

- **The shared-state hazard is inverted.** In Node, module-level mutable state is fine because one thread touches it. In a servlet, instance/static mutable state is touched by 200 threads at once — same code shape, race condition. This is the exact trap in the "is a servlet thread-safe?" question.
- **Blocking is fine here.** An Express handler that blocks stalls every user. A servlet's `doGet` can block on JDBC happily — only its own thread waits. That's *why* thread-per-request and blocking JDBC co-evolved.
- **Who owns the process:** Node apps *are* the server; classic servlet apps are guests deployed *into* a server. Spring Boot's embedded Tomcat moved Java to the Node-style model — app owns the process.

## 4. Production-Grade Code

```java
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicLong;
import javax.sql.DataSource;

@WebServlet(urlPatterns = "/orders/status", loadOnStartup = 1)
public class OrderStatusServlet extends HttpServlet {

    // Shared by ALL request threads — everything here must be thread-safe:
    private DataSource dataSource;                              // thread-safe by contract
    private final AtomicLong servedCount = new AtomicLong();    // AtomicLong, NOT long

    @Override
    public void init() throws ServletException {
        // once, before any request — fetch container-managed resources
        dataSource = (DataSource) getServletContext().getAttribute("app.dataSource");
        if (dataSource == null) {
            throw new ServletException("DataSource not initialized in ServletContext");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        servedCount.incrementAndGet();

        String rawId = req.getParameter("orderId");             // local vars = per-thread = safe
        long orderId;
        try {
            orderId = Long.parseLong(rawId);
        } catch (NumberFormatException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "orderId must be numeric");
            return;
        }

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT status FROM orders WHERE id = ?")) {
            ps.setLong(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                    return;
                }
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().write(
                        "{\"orderId\":%d,\"status\":\"%s\"}".formatted(orderId, rs.getString("status")));
            }
        } catch (SQLException e) {
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public void destroy() {
        // once at shutdown; pool itself is closed by whoever created it (a ServletContextListener)
    }
}
```

Read it as a thread-safety exhibit: the two instance fields are an immutable-after-init reference and an `AtomicLong`; every mutable thing is a local variable. Swap `AtomicLong` for `private long count++` and you have the interview bug.

## 5. Top 3 MNC Interview Questions

**Q1: Walk me through the servlet lifecycle.**

**What they're testing:** recall, plus whether you stress the "once vs per-request" split.

**Ideal answer:** "The container loads the class and constructs **one** instance, calls `init()` once — that's where you set up resources — then calls `service()` for every request, which routes to `doGet` or `doPost`. Critically, `service()` runs concurrently on many pooled threads against that single instance. At shutdown or redeploy the container calls `destroy()` once for cleanup. So: constructor and init once, service thousands of times in parallel, destroy once."

**Q2: Is a servlet thread-safe?**

**What they're testing:** the singleton-plus-concurrency trap — the single best predictor of whether you understand Java server concurrency.

**Ideal answer:** "No — and the container doesn't make it safe. There's one instance serving all requests concurrently, so any mutable instance or static field is a race condition. Local variables are safe because each thread has its own stack. The rule: keep servlets stateless; shared fields must be immutable after init or explicitly thread-safe like AtomicLong or a DataSource. SingleThreadModel existed for this and was deprecated because it killed throughput. Same rule applies to Spring controllers — they're singletons too."

**Q3: If you use Spring Boot, why should you care about servlets at all?**

**What they're testing:** do you know what's under Spring, or is it magic to you.

**Ideal answer:** "Because Spring MVC *is* a servlet. Spring Boot embeds Tomcat, and all traffic enters through one servlet — the DispatcherServlet, a front controller mapped to `/*` — which then routes to my `@GetMapping` methods. Filters still run before it; that's where Spring Security sits. Tomcat's thread pool still sets my concurrency ceiling, request/response objects are still Tomcat's, and controller beans are singletons under the same thread-safety rules as raw servlets. When I tune `server.tomcat.threads.max`, I'm tuning the servlet container."

## 6. Memorize this

> **Memorize this:** A servlet is one instance in a container serving all requests on pooled threads — init once, service concurrently, destroy once — so instance state must be immutable or atomic; CGI's process-per-request died for this model, and Spring MVC is just one giant servlet (DispatcherServlet) riding it.
