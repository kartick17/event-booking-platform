# Servlet Filters & Listeners

**Priority: Interview-critical** — full deep-dive. "Filter vs Interceptor" is a top-5 Spring MVC interview question, and Spring Security is *nothing but* a filter chain. Listeners are lighter but pair naturally.

## 1. Core Mechanism

- A **`Filter`** wraps servlet execution. It sees every matching request **before** the servlet and every response **after** it, and can change or stop either. Filters form an ordered **chain**; each one decides whether to pass the request onward.
- A **Listener** is a callback for container **events** — app started, session created, request destroyed. It doesn't sit in the request path; it reacts to lifecycle moments.
- Why they exist: cross-cutting concerns (auth, logging, CORS, compression) would otherwise be copy-pasted into every servlet. Filters pull them into one reusable, ordered pipeline. Listeners exist because *something* must run at app startup/shutdown to create and destroy shared resources — there's no `main()` in a container app.
- Quick split to remember: **Filter = in the request path. Listener = outside it, event-driven.**

> **Interview definition (say this out loud):** "Filters are a chain-of-responsibility around servlet execution — each filter runs logic, then either calls `chain.doFilter()` to continue or short-circuits the request; that's where auth, logging and CORS live, and Spring Security is entirely built on it. Listeners are lifecycle callbacks — context started, session created — used to bootstrap and tear down shared resources."

## 2. Under the Hood

### 2.1 Filter chain mechanics

- At deploy time the container builds, per URL pattern, an **ordered list of filters ending in the servlet**. A request to `/orders` gets: `filter1 → filter2 → … → servlet`, materialized as a `FilterChain` object.
- Your filter's method is `doFilter(request, response, chain)`. The pattern:

```java
// code here = BEFORE the servlet (request inbound)
chain.doFilter(request, response);   // hands off to the next filter, eventually the servlet
// code here = AFTER the servlet (response outbound) — same thread, unwinding the call stack
```

- It's literally a nested call stack — first filter's "after" code runs **last** (onion model). Not two separate hook lists like some frameworks; one recursive call.
- **Short-circuit:** don't call `chain.doFilter()` — write the response yourself (e.g. 401) and return. Servlet never runs.
- **Ordering trap:** `@WebFilter` **cannot declare order** — annotation-registered filters run in *alphabetical class-name order*. Real ordering needs `web.xml` (declaration order) or programmatic registration (in Spring Boot: `FilterRegistrationBean.setOrder(n)`). Interviewers love this gap.
- **Dispatcher types:** by default filters fire only on `REQUEST`. Internal `FORWARD`/`INCLUDE`/`ERROR`/`ASYNC` dispatches skip them unless you opt in — which also means a forward can re-trigger a filter configured for it. That double-execution risk is exactly why Spring ships `OncePerRequestFilter`.

### 2.2 What a filter can actually do

| Power | How |
|---|---|
| Inspect / reject early | read headers, write 401/429, skip `chain.doFilter()` |
| Mutate the request | wrap it in an `HttpServletRequestWrapper` subclass and override getters — needed because the request body stream can be **read only once**; a wrapper can cache it |
| Mutate / capture the response | pass an `HttpServletResponseWrapper` down the chain, inspect or rewrite what the servlet wrote (compression, ETag, audit) |
| Add context | set request attributes (e.g. a trace ID) that servlets and later filters read |

### 2.3 The listener family

| Listener | Fires on | Real use |
|---|---|---|
| `ServletContextListener` | app start / shutdown | **The big one.** Build the HikariCP pool, start schedulers on `contextInitialized`; close them on `contextDestroyed` |
| `HttpSessionListener` | session created / invalidated | count active users, audit logins |
| `ServletRequestListener` | each request start / end | per-request setup/teardown, e.g. clearing a `ThreadLocal` (MDC logging context) |
| Attribute listeners (context/session/request) | attribute added/removed/replaced | rare; auditing |
| `HttpSessionBindingListener` | an object is put into / removed from a session | object self-cleanup |

- Registered via `@WebListener`, `web.xml`, or programmatically. Like everything container-managed: one instance, so thread-safety rules apply (`HttpSessionListener` methods can fire concurrently for different sessions).

### 2.4 How Spring builds on this

- **`ContextLoaderListener`** — classic Spring was bootstrapped *by a listener*: it created the `ApplicationContext` on `contextInitialized`. Boot's embedded server does the equivalent internally.
- **Spring Security = one servlet filter.** `DelegatingFilterProxy` is registered with the container; it delegates to a Spring bean (`FilterChainProxy`), which runs Spring Security's own internal chain of ~15 ordered filters (CSRF, authentication, exception translation, authorization…). One container filter outside, a whole security pipeline inside — lets security filters be Spring beans with injection.
- **`OncePerRequestFilter`** — Spring base class guaranteeing a filter executes exactly once per request even across FORWARD/ERROR dispatches (it marks the request with an attribute). Extend this for custom filters in Spring apps, not raw `Filter`.
- **Filter vs `HandlerInterceptor`** — the interview table:

| | Servlet `Filter` | Spring `HandlerInterceptor` |
|---|---|---|
| Level | container, before `DispatcherServlet` | inside Spring MVC, after routing |
| Knows which controller method? | no — just URL/headers | **yes** — gets the handler object |
| Can use Spring beans | only via `DelegatingFilterProxy`/Boot registration | natively |
| Hooks | one `doFilter` wrap | `preHandle` / `postHandle` / `afterCompletion` |
| Sees non-Spring traffic (static files, other servlets) | yes | no |
| Use for | auth, CORS, compression, request wrapping, trace IDs | controller-aware concerns: locale, model tweaks, per-handler timing |

### 2.5 Threading model

Same as servlets: filters and listeners are **singletons**; `doFilter` runs on the request's worker thread, concurrently with all other requests. Mutable instance fields = race. The whole chain — every filter plus the servlet — executes on **one thread** for a given request, which is why `ThreadLocal` tricks (security context, MDC) work across the chain.

## 3. The Node.js / NestJS Bridge

| Concept | Node / NestJS | Java / Servlets |
|---|---|---|
| Middleware | `app.use((req, res, next) => …)` | `Filter.doFilter(req, res, chain)` |
| Continue | `next()` | `chain.doFilter(req, res)` |
| Short-circuit | `res.status(401).end()`, skip `next()` | write response, skip `chain.doFilter()` |
| Ordering | registration order, explicit | `web.xml`/`setOrder()`; `@WebFilter` = alphabetical (!) |
| App startup hook | NestJS `OnModuleInit`, `main.ts` bootstrap | `ServletContextListener.contextInitialized` |
| Shutdown hook | `process.on('SIGTERM')` | `contextDestroyed` |
| Controller-aware layer | NestJS Guards / Interceptors | Spring `HandlerInterceptor` |

**Where the comparison breaks down:**

- **After-response code.** Express middleware runs strictly *before* the handler; code after `next()` usually runs before the response is sent (you hook `res.on('finish')` for that). A servlet filter genuinely *wraps* — the line after `chain.doFilter()` runs after the servlet finished, same thread, response in hand. Cleaner for timing/audit.
- **Body re-reading.** Both platforms share the "stream reads once" problem, but the fix differs: Node uses body-parser putting `req.body` on the object; Java wraps the request in a caching `HttpServletRequestWrapper`.
- **NestJS three-layer split (middleware → guards → interceptors) maps to Java's two-layer split (filters → interceptors)** — but the auth location flips: NestJS auth lives in Guards (controller-aware), Spring auth lives in *filters* (before routing). Saying "I'd put Spring auth in an interceptor" is the wrong-instinct answer interviewers listen for.

## 4. Production-Grade Code

```java
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/** Bootstraps shared resources at app start — the listener owns what filters/servlets use. */
@WebListener
public class AppBootstrapListener implements ServletContextListener {

    private HikariDataSource dataSource;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        var config = new HikariConfig();
        config.setJdbcUrl(System.getenv("DB_URL"));
        config.setUsername(System.getenv("DB_USER"));
        config.setPassword(System.getenv("DB_PASSWORD"));
        config.setMaximumPoolSize(10);
        dataSource = new HikariDataSource(config);
        // same attribute OrderStatusServlet reads in its init()
        sce.getServletContext().setAttribute("app.dataSource", dataSource);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (dataSource != null) dataSource.close();   // graceful shutdown — no leaked sockets
    }
}

/** Auth filter — short-circuits unauthenticated requests before any servlet runs.
    Registered programmatically (not @WebFilter) so its order is explicit. */
class ApiKeyAuthFilter implements Filter {

    private final String expectedApiKey;

    ApiKeyAuthFilter(String expectedApiKey) {
        this.expectedApiKey = expectedApiKey;         // immutable after construction = thread-safe
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        var req = (HttpServletRequest) request;
        var resp = (HttpServletResponse) response;

        String apiKey = req.getHeader("X-Api-Key");
        if (apiKey == null || !constantTimeEquals(apiKey, expectedApiKey)) {
            resp.sendError(HttpServletResponse.SC_UNAUTHORIZED);
            return;                                   // short-circuit: chain never continues
        }
        chain.doFilter(request, response);
    }

    // length-safe comparison; avoids leaking key length via timing
    private static boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int diff = 0;
        for (int i = 0; i < a.length(); i++) diff |= a.charAt(i) ^ b.charAt(i);
        return diff == 0;
    }
}

/** Timing + trace filter — demonstrates the 'around' shape of a filter. */
class RequestTimingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        var req = (HttpServletRequest) request;
        var resp = (HttpServletResponse) response;

        String traceId = UUID.randomUUID().toString();
        req.setAttribute("traceId", traceId);          // visible to later filters and the servlet
        resp.setHeader("X-Trace-Id", traceId);         // headers must be set BEFORE body is written

        long start = System.nanoTime();
        try {
            chain.doFilter(request, response);         // everything downstream runs here
        } finally {
            // runs AFTER the servlet, even if it threw — same thread, stack unwinding
            long millis = (System.nanoTime() - start) / 1_000_000;
            System.out.printf("%s %s -> %d (%d ms) trace=%s%n",
                    req.getMethod(), req.getRequestURI(), resp.getStatus(), millis, traceId);
        }
    }
}
```

Notes: the listener creates and closes the pool (filters/servlets only borrow it); auth filter shows short-circuit + immutable state; timing filter shows the around-wrap with `finally` so failures are still logged.

## 5. Top 3 MNC Interview Questions

**Q1: What's the difference between a Filter and a Spring HandlerInterceptor? When do you pick which?**

**What they're testing:** whether you know the two pipelines are at different levels — container vs Spring MVC.

**Ideal answer:** "A filter is a servlet-container concept — it runs before the DispatcherServlet, sees raw request/response, and covers *all* traffic including static resources; it has no idea which controller will handle the request. An interceptor runs inside Spring MVC *after* handler mapping, so it knows the exact controller method, and offers preHandle, postHandle and afterCompletion hooks. Rule of thumb: protocol-level concerns — auth, CORS, compression, request wrapping — go in filters; controller-aware concerns go in interceptors. Spring Security chose filters precisely to protect everything before routing."

**Q2: How does Spring Security actually plug into the servlet world?**

**What they're testing:** do you know it's "just filters", or is it magic.

**Ideal answer:** "Through exactly one servlet filter. Spring registers a DelegatingFilterProxy with the container, which delegates to a Spring bean called FilterChainProxy. That bean runs Spring Security's own ordered chain of filters — CSRF, username/password authentication, exception translation, authorization — each one a Spring bean, so they get dependency injection. The container sees one filter; Spring manages the fifteen inside. If authentication fails, the chain short-circuits with a 401 and my controller never runs."

**Q3: Why does Spring provide OncePerRequestFilter — when would a plain filter run twice?**

**What they're testing:** knowledge of dispatcher types — a genuinely senior detail.

**Ideal answer:** "Filters are invoked per *dispatch*, not per request. If a filter is mapped to FORWARD or ERROR dispatches — say the servlet forwards internally, or an error page renders — the same filter can execute again for the same client request. OncePerRequestFilter guards against that by setting a request attribute on first execution and skipping subsequent passes. For anything with side effects — authentication, counters, audit logs — double execution is a bug, so in Spring apps custom filters should extend OncePerRequestFilter."

## 6. Memorize this

> **Memorize this:** A filter is an onion around the servlet — code before `chain.doFilter()` runs inbound, code after runs outbound, skipping the call short-circuits; `@WebFilter` can't set order (use registration), Spring Security is one DelegatingFilterProxy hiding its own 15-filter chain, and listeners (`ServletContextListener`) are the app's startup/shutdown hooks that own shared resources.
