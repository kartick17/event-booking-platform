# ServletContext

**Priority: Dev-important, Interview-light** — short notes. `ServletContext` itself is shallow, but its twin question "ServletContext vs ServletConfig" is a screening-round regular. Learn the table, move on.

## What it is

**`ServletContext`** is the one object that represents your whole web app inside the container. One per app (per JVM) — every servlet, filter, and listener sees the same instance. It's created when the app starts, destroyed when it stops.

Three jobs:

1. **App-wide config** — read `<context-param>` values (init params for the *whole app*, not one servlet).
2. **App-wide shared state** — `setAttribute`/`getAttribute`, a thread-shared map. This is where the bootstrap listener parked the `DataSource` in the earlier notes.
3. **Talk to the container** — get resources (`getResourceAsStream("/WEB-INF/config.xml")`), the real file path, the server info, and register servlets/filters programmatically at startup.

Node mental model: it's your app's **module scope / NestJS app-level provider registry** — the place where "one per app" things live. Except in Java, 200 threads read it at once, so anything mutable you put in it must be thread-safe.

## The interview table: ServletContext vs ServletConfig

| | `ServletConfig` | `ServletContext` |
|---|---|---|
| Scope | **one servlet** | **whole app** |
| How many | one per servlet | one per app |
| Params from | `<init-param>` inside that servlet's config / `@WebServlet(initParams=...)` | `<context-param>` at app level |
| Get it | `getServletConfig()` inside the servlet | `getServletContext()` (also available *via* the config) |
| Typical use | per-servlet tuning value | shared resources, app config, cross-servlet state |

## The three attribute scopes (bigger picture)

| Scope | Object | Lives | Visible to |
|---|---|---|---|
| Request | `HttpServletRequest` attributes | one request | that request's filter chain + servlet |
| Session | `HttpSession` attributes | one user, across requests | that user's requests |
| Application | `ServletContext` attributes | app lifetime | **everyone, every thread** |

Spring parallel: these three scopes are exactly why Spring has `request`, `session`, and `singleton`/`application` bean scopes. Spring also stores its whole `ApplicationContext` *inside* the ServletContext as an attribute — that's how `DispatcherServlet` finds it.

## Snippet

```java
@Override
public void init() throws ServletException {
    // per-servlet param (ServletConfig)
    String pageSize = getServletConfig().getInitParameter("pageSize");

    // app-wide param (ServletContext)
    String appEnv = getServletContext().getInitParameter("app.environment");

    // app-wide shared object, put there by a ServletContextListener at startup
    DataSource ds = (DataSource) getServletContext().getAttribute("app.dataSource");
}
```

Thread rule: `setAttribute` on the context after startup is visible to all threads, but the *object you store* must handle concurrent use itself (store immutable things, a `DataSource`, or concurrent collections — never a bare `HashMap` you keep mutating).

## One interview question

**Q:** "Difference between ServletConfig and ServletContext? And when would you put something in the context?"

**Ideal answer:** "ServletConfig is per-servlet — one per servlet instance, carrying that servlet's own init params. ServletContext is per-application — a single object shared by every servlet, filter and listener, carrying app-level params, shared attributes, and access to container resources. I'd put app-wide singletons there — a connection pool created by a ServletContextListener at startup is the classic case. Since every request thread can read it, whatever I store must be immutable or thread-safe. Spring formalized this: it stores its ApplicationContext as a ServletContext attribute, and its bean scopes mirror the request/session/application attribute scopes."

> **Memorize this:** ServletConfig = one servlet's settings; ServletContext = the one app-wide object everyone shares — app params, shared attributes (thread-safe things only), container resources — created at startup, and the hook Spring itself hangs its ApplicationContext on.
