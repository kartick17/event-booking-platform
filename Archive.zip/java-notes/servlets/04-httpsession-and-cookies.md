# HttpSession & Cookies — Session Management

**Priority: Interview-critical** — full deep-dive. "How does the server recognize a user across requests?", session fixation, and "sessions behind a load balancer" are all standard MNC questions, and this ties servlets to Spring Security and system design.

## 1. Core Mechanism

- HTTP is **stateless** — the server forgets you after every request. Sessions bolt memory on top.
- The trick has two halves:
  - **`HttpSession`** — a server-side object (a map of attributes) the container keeps per user.
  - **Cookie** — a small key=value the server asks the browser to store and send back on every request. The session cookie carries only the **session ID** (`JSESSIONID`), which is the lookup key to the server-side map.
- So: data lives on the **server**; the browser holds only a random ticket number. That split is the whole design.
- Why it exists: login state, carts, per-user data — anything that must survive between requests from the same browser.

> **Interview definition (say this out loud):** "HTTP is stateless, so the container keeps a server-side HttpSession object per user and hands the browser only a random session ID in the JSESSIONID cookie. Every later request carries the cookie, the container looks up the session, and the servlet sees the same attribute map — state on the server, just a ticket in the browser."

## 2. Under the Hood

### 2.1 The tracking handshake

1. First request: no cookie. Code calls `req.getSession()` → container creates an `HttpSession` in its in-memory map, generates a **cryptographically random** ID, and adds `Set-Cookie: JSESSIONID=<id>; Path=/; HttpOnly` to the response.
2. Browser stores it; every subsequent request to that path sends `Cookie: JSESSIONID=<id>`.
3. Container reads the ID, finds the session, exposes it via `req.getSession()`.

- `getSession()` / `getSession(true)` = create if absent. **`getSession(false)`** = return null if none — use this on read paths so casual traffic doesn't allocate sessions.
- The ID must be unguessable — it *is* the authentication of the session. Guess it, own the account.
- **Cookies disabled?** The spec fallback is **URL rewriting**: `resp.encodeURL(url)` appends `;jsessionid=<id>` to links. Know it for the interview; nobody enables it in practice — IDs leak into logs, referrers, and screenshots.
- Third ancient option: hidden form fields. Name it, move on.

### 2.2 Session lifecycle

| Event | Mechanism |
|---|---|
| Create | first `getSession()` |
| Idle timeout | `setMaxInactiveInterval(seconds)` / `session-timeout` in config — Tomcat default **30 min**; container background thread evicts |
| Explicit end | `session.invalidate()` — logout |
| Server restart / memory pressure | Tomcat can **passivate** sessions to disk and reload — only if attributes implement `Serializable` |

- Store **small, Serializable** things: user ID, role. Not entities, not connections. Session heap = `activeUsers × bytesPerSession` — sessions are a classic OOM source on high-traffic apps.

### 2.3 Cookie anatomy — the attributes that matter

| Attribute | Meaning | Why you care |
|---|---|---|
| `HttpOnly` | JS (`document.cookie`) cannot read it | Blocks session theft via **XSS**. Always on for session cookies |
| `Secure` | sent only over HTTPS | Stops plaintext leaks. Always on in prod |
| `SameSite=Lax/Strict/None` | sent on cross-site requests or not | Primary modern **CSRF** defense; `Lax` is the browser default now; `None` requires `Secure` |
| `Path` / `Domain` | scope of where the cookie is sent | too-wide `Domain` shares your cookie with every subdomain |
| `Max-Age` / `Expires` | persistence | absent = **session cookie**, dies with the browser; JSESSIONID is deliberately this |

- CSRF exists *because* cookies are attached automatically by the browser — a form on evil.com posting to your bank rides the user's cookie. `SameSite` + CSRF tokens are the countermeasures. (JWT in a header doesn't auto-attach — that's its CSRF advantage; JWT in a cookie inherits the same problem.)

### 2.4 Session attacks

- **Session fixation:** attacker plants a known session ID in the victim's browser (link with `;jsessionid=`, subdomain cookie injection), victim logs in, attacker reuses the now-authenticated ID. **Fix: rotate the ID at login** — `req.changeSessionId()` (Servlet 3.1+). Spring Security does this automatically.
- **Session hijacking:** stealing a live ID via XSS or sniffing → blocked by `HttpOnly` + `Secure` + TLS.
- Logout must call `invalidate()` server-side — deleting the cookie client-side leaves the server session alive and replayable.

### 2.5 The scaling problem — sessions vs the load balancer

In-memory sessions live in **one Tomcat's heap**. Two servers behind a load balancer = second server has no idea who you are. Options:

| Option | How | Cost |
|---|---|---|
| **Sticky sessions** | LB routes each user to the same node (cookie-based affinity) | node dies → those sessions die; uneven load |
| **Replication** | Tomcat cluster broadcasts session changes to all nodes | network chatter, scales badly past a few nodes |
| **External store** | sessions in Redis; any node loads by ID (**Spring Session** does this transparently — `HttpSession` API unchanged) | extra hop per request; the standard answer |
| **Stateless JWT** | no server session; signed token carries the claims | no server memory, but revocation is hard and tokens can grow |

- Interview framing: sticky = quick hack, Redis via Spring Session = enterprise default, JWT = microservices default. Trade-off line for JWT: "you trade server-side memory for the revocation problem."

### 2.6 Spring hooks

- Spring Security stores the authenticated user (`SecurityContext`) **in the HttpSession** by default — form-login apps are session-based whether you noticed or not; `SessionCreationPolicy.STATELESS` turns it off for JWT APIs.
- **Spring Session** swaps the container's session manager for a Redis/JDBC-backed one — same `HttpSession` API, cluster-safe.
- Session-scoped beans (`@SessionScope`) are sugar over session attributes.

## 3. The Node.js / NestJS Bridge

| Concept | Node / Express | Java / Servlets |
|---|---|---|
| Session middleware | `express-session` | built into the container |
| Session cookie | `connect.sid` (signed) | `JSESSIONID` |
| Get/set data | `req.session.userId = 42` | `session.setAttribute("userId", 42L)` |
| External store | `connect-redis` store option | Spring Session + Redis |
| Destroy | `req.session.destroy()` | `session.invalidate()` |
| Cookie flags | `cookie: {httpOnly, secure, sameSite}` | container config / `Set-Cookie` |

**Where the comparison breaks down:**

- **Default storage:** `express-session`'s in-memory store is explicitly "dev only — use Redis in prod." Tomcat's in-heap store *is* many companies' production setup (with sticky LBs) — so Java interviews expect you to discuss replication/sticky trade-offs, not just "use Redis."
- **Signed vs random:** `connect.sid` is a value **signed** with your app secret (tamper-evident). `JSESSIONID` is pure high-entropy randomness — nothing to verify, just unguessable. Different theft models, same outcome.
- **Threading again:** two parallel requests from the same user hit the same `HttpSession` object on two threads — mutating a plain `ArrayList` stored in a session is a race. Node's single thread never taught you this reflex.

## 4. Production-Grade Code

```java
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.Serializable;

@WebServlet("/auth/login")
public class LoginServlet extends HttpServlet {

    /** Small, Serializable, immutable — the only kind of thing a session should hold. */
    public record AuthenticatedUser(long userId, String role) implements Serializable {}

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        AuthenticatedUser user = authenticate(email, password);
        if (user == null) {
            resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Bad credentials");
            return;
        }

        // Session fixation defense: rotate the ID at the privilege change.
        // Any session ID the browser held BEFORE login is now worthless.
        HttpSession session = req.getSession(true);
        req.changeSessionId();

        session.setAttribute("user", user);
        session.setMaxInactiveInterval(30 * 60);       // 30 min idle timeout

        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }

    private AuthenticatedUser authenticate(String email, String password) {
        // real impl: fetch user, verify with BCrypt/Argon2 — never plaintext compare
        return "demo@weloin.com".equals(email) && "secret".equals(password)
                ? new AuthenticatedUser(42L, "ADMIN") : null;
    }
}

@WebServlet("/auth/logout")
class LogoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
        HttpSession session = req.getSession(false);   // false: don't create one just to kill it
        if (session != null) {
            session.invalidate();                      // server-side kill — cookie deletion alone is not logout
        }
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
```

Cookie hardening lives in container config (or Spring Boot properties) rather than servlet code:

```properties
# Spring Boot equivalents — what production actually sets
server.servlet.session.cookie.http-only=true
server.servlet.session.cookie.secure=true
server.servlet.session.cookie.same-site=lax
server.servlet.session.timeout=30m
```

## 5. Top 3 MNC Interview Questions

**Q1: HTTP is stateless — how does the server know two requests came from the same user? What if cookies are disabled?**

**What they're testing:** the full tracking mechanism, not just the word "cookies".

**Ideal answer:** "On the first `getSession()` the container creates a server-side session object and returns a random ID in the JSESSIONID cookie; the browser echoes it on every request and the container maps ID back to session — data stays server-side, only the ticket travels. If cookies are off, the spec fallback is URL rewriting via `encodeURL`, which appends `;jsessionid=` to every link — but it leaks IDs into logs and referrer headers, so real systems require cookies instead. There's also the historical hidden-form-field method."

**Q2: What is session fixation and how do you prevent it?**

**What they're testing:** security depth beyond "use HTTPS".

**Ideal answer:** "The attacker gets a known session ID into the victim's browser before login — a crafted link or injected cookie. The victim authenticates, the server upgrades *that* session, and the attacker now holds a logged-in ID. Defense: rotate the session ID at the moment of login — `request.changeSessionId()` in Servlet 3.1 — so the pre-login ID dies. Spring Security does this by default. I'd stack the rest too: HttpOnly and Secure flags, SameSite, and server-side `invalidate()` on logout."

**Q3: Your app scales to three Tomcat nodes behind a load balancer — what happens to sessions?**

**What they're testing:** system-design maturity; can you compare the four options.

**Ideal answer:** "In-heap sessions break — node B doesn't know node A's users. Three fixes: sticky sessions at the LB, which is simple but loses sessions when a node dies and skews load; Tomcat session replication, which doesn't scale past a few nodes; or externalize to Redis — with Spring Session it's transparent, same HttpSession API, any node serves any user. That's my default for session-based apps. The alternative is going stateless with JWT — no server memory at all, but you take on token revocation and size problems instead."

## 6. Memorize this

> **Memorize this:** Session = server-side map, cookie = just the random JSESSIONID key to it — harden the cookie (HttpOnly, Secure, SameSite), rotate the ID at login (`changeSessionId`, kills fixation), `invalidate()` on logout, and at scale move the map to Redis (Spring Session) or drop it for JWT.
