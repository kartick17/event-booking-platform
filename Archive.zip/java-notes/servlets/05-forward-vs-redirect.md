# Forward vs Redirect

**Priority: Dev-important, Interview-light** — short notes. Asked in nearly every servlet screening round, but the whole topic fits in one table. Learn it, know the PRG pattern, done.

## The one-line difference

**Forward** = the server passes the request to another resource internally — one request, browser knows nothing. **Redirect** = the server tells the browser "go ask this other URL" — two requests, browser fully aware.

## The interview table

| | `RequestDispatcher.forward()` | `response.sendRedirect()` |
|---|---|---|
| Who hops | server, internally | browser, via HTTP |
| HTTP round trips | **1** | **2** (response 302 + new request) |
| Browser URL bar | unchanged (old URL) | changes to the new URL |
| Status code | 200 (whatever the target writes) | **302 Found** (or 303/307/301) |
| Request attributes survive? | **yes** — same request object | **no** — brand-new request |
| Request params/body survive? | yes | no (new GET, no body) |
| Target can be | only resources **inside this app** | anywhere — other apps, other domains |
| Speed | faster (no network hop) | slower (extra round trip) |
| Typical use | servlet → JSP/view rendering, internal routing | after POST success, login redirects, moved URLs |

Mechanics notes:

- Forward: `req.getRequestDispatcher("/orderView").forward(req, resp)` — the **same** request/response objects continue in the target; anything you set with `req.setAttribute(...)` before forwarding is visible there. Must be called **before** the response body is committed (flushed), else `IllegalStateException`.
- Redirect: `resp.sendRedirect("/orders/42")` — just writes `302` + `Location` header. To pass data across it you need query params, session, or a flash attribute — the request object dies.
- `include()` is the third sibling: like forward, but the target's output is *embedded* and control returns to you. Name it if asked, rarely used.

## The pattern that makes this a real question: POST-Redirect-GET (PRG)

Form POST succeeds → **redirect** to a GET page, never forward. If you forward (or render directly), the browser's "current page" is still the POST — refresh = **duplicate order submission**, back button = "resubmit form?" popup. Redirect makes the browser land on a clean GET, so refresh is harmless. This is the answer that shows production experience.

## Spring mapping

Same two verbs, string prefixes: return `"forward:/some/view"` or `"redirect:/orders/42"` from a controller. `RedirectAttributes.addFlashAttribute(...)` solves the "data across a redirect" problem — Spring stashes it in the session for exactly one request. REST APIs barely use either: you return `201 Created` + `Location` header instead, and the *client* decides to follow.

## Node bridge

Redirect is identical: `res.redirect('/orders/42')` = `sendRedirect`. Forward has no first-class Express equivalent — closest is calling another handler function directly or `next('route')`; Express never needed internal dispatch because handlers are just functions you can call. The concept only matters in Java because servlets/JSPs are container-managed resources you can't invoke directly.

## One interview question

**Q:** "User submits an order form. Forward to the confirmation page or redirect? Why?"

**Ideal answer:** "Redirect — the POST-Redirect-GET pattern. If I forward, the confirmation renders as the response to the POST itself, so a browser refresh re-sends the POST and creates a duplicate order. With a redirect, the POST handler saves the order and returns 302 to a GET confirmation URL; refresh then just repeats the harmless GET. The cost is a second round trip and losing request attributes — anything the confirmation page needs travels via the URL or a flash attribute. Forward I'd keep for internal view rendering, like servlet-to-JSP, where it's one round trip and the request attributes carry the model."

> **Memorize this:** Forward = same request handed to another resource inside the app (1 trip, URL unchanged, attributes survive); redirect = 302 telling the browser to make a new request (2 trips, URL changes, state dies) — and after a successful POST you always redirect (PRG) or refresh duplicates the submit.
