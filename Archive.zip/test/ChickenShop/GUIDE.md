# 🍗 The Chicken Shop Simulator — Full Learning Guide

A tiny, beginner-friendly Java project to learn **multithreading** for the first time.
Everything is explained with one simple real-life story: a small **fried chicken shop**.

---

## 1. What is this project?

We act out a busy chicken shop:

- **50 hungry customers** all show up at once.
- The shop has only **10 buckets of chicken**.
- The shop is tiny, so only **5 customers** fit inside at a time.
- The kitchen has **4 chefs** who cook the paid orders.
- A **manager** walks around in the background and reports what's happening.

Each customer is a **thread** (its own "person" running at the same time as the others).
The fun problem: when many people act at once, things can go wrong (two people grab the
same bucket, the shop gets overcrowded, etc.). This project shows the Java tools that
keep everything safe and correct.

> **Thread (plain English):** a worker that runs on its own, at the same time as other workers.
> **Multithreading:** many workers running together. Fast, but you must control them carefully.

---

## 2. What you will learn

By the end you can explain and use:

| Concept | Plain-English meaning | Java tools |
|---|---|---|
| Limit how many threads run at once | Only 5 people inside the shop | `synchronized`, `wait()`, `notifyAll()` |
| Protect shared data from a race | One key to touch the shelf | `ReentrantLock`, `lock()`, `unlock()`, `try/finally` |
| Reuse a team of workers | 4 chefs, not a new chef per order | `ExecutorService`, `newFixedThreadPool`, `Future` |
| Background helper that never blocks exit | A manager who goes home when staff do | daemon `Thread`, `setDaemon(true)` |
| Wait for workers to finish | Wait for all customers to leave | `Thread.join()` |
| A safe shared counter | Count orders without a full lock | `AtomicInteger` |

> **Race condition (plain English):** two threads change the same thing at the same
> moment and the result comes out wrong. The locks in this project stop that.

---

## 3. The 4 steps (the big picture)

```
Step 1 🪢  Entry Rope      -> only 5 customers inside at a time
Step 2 🔑  Cashier Key     -> only 10 buckets, no double-grabbing
Step 3 👨‍🍳 Kitchen Chefs   -> 4 chefs cook orders, hand back a receipt
Step 4 👔  Manager Daemon  -> background helper reports every second
Step 5 🎉  Grand Opening   -> all 4 pieces running together (50 customers)
```

---

## 4. Project files

```
ChickenShop/
└── src/
    ├── EntryRope.java                Step 1  (NEW FILE)
    ├── CashierKey.java               Step 2  (NEW FILE)
    ├── KitchenChefs.java             Step 3  (NEW FILE)
    ├── ManagerDaemon.java            Step 4  (NEW FILE)
    ├── ChickenShopSimulator.java     Step 5  (NEW FILE — clean split version, needs javac)
    └── ChickenShopSimulatorRun.java  Step 5  (NEW FILE — single-file version, runs with just java)
```

Every step below says clearly whether it is a **NEW FILE** or a **CHANGE to an existing file**.

---

# STEP 1 — The Entry Rope 🪢

### Concept (simple)
The shop is small. The owner puts a rope at the door. Only **5 customers** can be inside
at once. If the shop is full, the next customer must **wait outside** until someone leaves.

- `synchronized` = only one person can touch the rope at a time.
- `wait()` = stand outside and sleep until called.
- `notifyAll()` = shout "spot free!" so the waiting people wake up.

**Why `while` and not `if`?** When a waiting customer wakes up, the spot might already be
taken by someone faster. So we check the count **again** in a loop before walking in.

### Code — `src/EntryRope.java`  **(NEW FILE)**

```java
// STEP 1: THE ENTRY ROPE 🪢
// Only 5 customers allowed inside the shop at the same time.
public class EntryRope {

    private int customersInside = 0;     // how many are inside right now
    private final int MAX_INSIDE = 5;    // the shop holds at most 5

    // synchronized = only one customer runs this at a time.
    public synchronized void enter(String customerName) throws InterruptedException {
        // while (not if): re-check after waking up.
        while (customersInside >= MAX_INSIDE) {
            System.out.println("⛔ " + customerName + " waits outside (shop is full).");
            wait(); // sleep until someone calls notifyAll()
        }
        customersInside++;
        System.out.println("✅ " + customerName + " stepped inside. Inside now: " + customersInside);
    }

    public synchronized void leave(String customerName) {
        customersInside--;
        System.out.println("🚪 " + customerName + " left. Inside now: " + customersInside);
        notifyAll(); // tell waiting people a spot opened
    }

    // Tiny test: 10 customers, only 5 inside at a time.
    public static void main(String[] args) throws InterruptedException {
        EntryRope rope = new EntryRope();
        for (int i = 1; i <= 10; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> {
                try {
                    rope.enter(name);
                    Thread.sleep(500); // pretend they are eating
                    rope.leave(name);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            customer.start();
        }
    }
}
```

### How to test
```bash
java src/EntryRope.java
```
**Expect:** "Inside now:" never goes above 5. Extra customers wait, then enter as spots open.

### 🎤 Interview Summary
> "I used a `synchronized` method with `wait()` and `notifyAll()` to limit how many
> threads are active at once, like a bouncer with a 5-person rope. Waiting threads call
> `wait()` to sleep, a leaving thread calls `notifyAll()` to wake them, and I check the
> limit in a `while` loop to handle wake-ups safely."

---

# STEP 2 — The Cashier Key 🔑

### Concept (simple)
There are only **10 buckets** but 50 people grabbing at once. Without protection, two
customers could both read "1 bucket left", both take it, and you sell 11 from a shelf of
10. That bug is a **race condition**.

The fix: **one cashier key**. You must hold the key to touch the shelf. Only one person
holds it at a time, so the count stays correct.

- `ReentrantLock` = the single key.
- `lock()` = grab the key (others wait).
- `unlock()` = hand it back.
- `try/finally` = **always** hand the key back, even if the code breaks (stops deadlock).

**Key habit:** `lock()` right before `try`, `unlock()` inside `finally`.

### Code — `src/CashierKey.java`  **(NEW FILE)**

```java
// STEP 2: THE CASHIER KEY 🔑
// One lock protects the 10 buckets so two people never grab the same one.
import java.util.concurrent.locks.ReentrantLock;

public class CashierKey {

    private int buckets = 10;                              // stock on the shelf
    private final ReentrantLock key = new ReentrantLock(); // the one cashier key

    public boolean buyBucket(String customerName) {
        key.lock();                  // grab the key (wait if taken)
        try {
            if (buckets > 0) {
                buckets--;
                System.out.println("🍗 " + customerName + " bought a bucket. Left: " + buckets);
                return true;
            } else {
                System.out.println("❌ " + customerName + " — SOLD OUT, no chicken left.");
                return false;
            }
        } finally {
            key.unlock();            // ALWAYS hand the key back
        }
    }

    // Tiny test: 50 customers rush 10 buckets.
    public static void main(String[] args) {
        CashierKey shop = new CashierKey();
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> shop.buyBucket(name));
            customer.start();
        }
    }
}
```

### How to test
```bash
java src/CashierKey.java
```
**Expect:** Exactly 10 "bought a bucket" (9→0), the other 40 "SOLD OUT". Never negative,
never more than 10. Run it many times — always correct.

### 🎤 Interview Summary
> "I used a `ReentrantLock` to protect shared stock so only one thread changes the count
> at a time, which stops race conditions. I always call `lock()` before a `try` block and
> `unlock()` inside `finally`, so the lock is released even if an error is thrown."

---

# STEP 3 — The Kitchen Chefs 👨‍🍳

### Concept (simple)
A customer paid; the order goes to the kitchen. The kitchen has exactly **4 chefs**. You
don't hire a new chef for every order (slow and wasteful) — you **reuse** the same 4.
When you drop an order, you get a **ticket** (`Future`). Later you collect the **receipt**.

- `ExecutorService` = the kitchen that manages the chefs.
- `newFixedThreadPool(4)` = exactly 4 chefs, reused.
- `submit(...)` = drop an order in (returns instantly with a ticket).
- `Future` = the ticket; `future.get()` = wait for that order's result.
- `shutdown()` = close the kitchen so the program can end.

**Remember:** `submit()` does not wait; the chef cooks in the background. Always call
`shutdown()`, or the chef threads keep the program alive forever.

### Code — `src/KitchenChefs.java`  **(NEW FILE)**

```java
// STEP 3: THE KITCHEN CHEFS 👨‍🍳
// A pool of 4 chefs cooks 10 orders and returns a receipt for each.
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class KitchenChefs {

    public static void main(String[] args) throws Exception {
        ExecutorService kitchen = Executors.newFixedThreadPool(4); // 4 chefs
        List<Future<String>> receipts = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            int orderNumber = i;
            // submit() hands the order to a free chef; returns a Future (ticket).
            Future<String> receipt = kitchen.submit(() -> {
                String chef = Thread.currentThread().getName();
                System.out.println("🍳 " + chef + " is cooking order #" + orderNumber);
                Thread.sleep(800); // cooking takes time
                return "Receipt: order #" + orderNumber + " cooked by " + chef;
            });
            receipts.add(receipt);
        }

        // Collect every receipt; get() waits until that order is done.
        for (Future<String> receipt : receipts) {
            System.out.println("🧾 " + receipt.get());
        }

        kitchen.shutdown(); // close the kitchen
        System.out.println("🏁 Kitchen closed. All orders cooked.");
    }
}
```

### How to test
```bash
java src/KitchenChefs.java
```
**Expect:** Only 4 chef names (`pool-1-thread-1..4`), reused. Orders cook in waves of 4.
All 10 receipts print, then "Kitchen closed".

### 🎤 Interview Summary
> "I used an `ExecutorService` with a fixed pool of 4 threads to reuse workers instead of
> creating a thread per task, which saves resources. Each `submit()` returns a `Future`,
> I call `get()` to collect each result, then `shutdown()` to close the pool cleanly."

---

# STEP 4 — The Manager Daemon 👔

### Concept (simple)
The manager just **watches and reports** — he never sells or cooks. So the program should
not stay open just because he is still talking. A **daemon thread** is exactly this: a
background helper Java does **not** wait for. When all the real workers finish, the program
ends and the daemon stops on its own, even mid-loop.

- normal `Thread` = real worker; Java waits for it.
- `setDaemon(true)` = background helper; Java does not wait for it.
- **Rule:** call `setDaemon(true)` **before** `start()`, or you get an exception.

### Code — `src/ManagerDaemon.java`  **(NEW FILE)**

```java
// STEP 4: THE MANAGER DAEMON 👔
// A background thread that reports every second and dies when the app ends.
public class ManagerDaemon {

    public static void main(String[] args) throws InterruptedException {

        Thread manager = new Thread(() -> {
            while (true) { // loops forever; daemon is killed when app ends
                System.out.println("👔 Manager: staff are still working...");
                try {
                    Thread.sleep(1000); // report once per second
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });

        manager.setDaemon(true); // MUST be before start()
        manager.start();

        System.out.println("🏪 Shop is open. Real staff are working...");
        Thread.sleep(5000); // real work runs for 5 seconds

        System.out.println("🏁 Shop closed. Manager goes home too (daemon stops).");
    }
}
```

### How to test
```bash
java src/ManagerDaemon.java
```
**Expect:** Manager prints about 5 times (once per second), then "Shop closed" and the
program ends right away — its `while(true)` never blocks shutdown.

### 🎤 Interview Summary
> "I used a daemon thread for a background helper that shouldn't keep the program alive —
> the JVM exits when only daemon threads remain. The key rule is calling `setDaemon(true)`
> before `start()`, otherwise it throws an exception."

---

# STEP 5 — The Grand Opening 🎉 (all four together)

### Concept (simple)
No new idea here — this glues the four blocks into one shop. Each customer's journey:

1. **Rope** 🪢 — get past the door (wait if 5 are inside).
2. **Cashier** 🔑 — try to buy a bucket (lock stops double-grabbing).
3. **Kitchen** 👨‍🍳 — if they paid, 4 chefs cook it and return a receipt.
4. **Leave** 🚪 — step out so the next person can enter.

Meanwhile the **Manager** 👔 reports in the background.

Two extra small tools appear:
- `AtomicInteger` — a counter that's safe when many threads add to it at once.
- `Thread.join()` — "wait here until this thread finishes"; used so `main` waits for all 50.

> There are **two versions** of Step 5:
> - `ChickenShopSimulator.java` — clean **split** version. It uses the `EntryRope` and
>   `CashierKey` files from Steps 1–2, so it needs a real compiler (`javac`).
> - `ChickenShopSimulatorRun.java` — same logic but `EntryRope`/`CashierKey` are tucked
>   inside as nested classes, so it runs with just `java` (no compiler).

### Code — `src/ChickenShopSimulator.java`  **(NEW FILE — clean split version)**

```java
// STEP 5: THE GRAND OPENING 🎉  (split version — needs javac)
// Reuses EntryRope (Step 1) and CashierKey (Step 2) from their own files.
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class ChickenShopSimulator {

    public static void main(String[] args) throws Exception {

        EntryRope rope = new EntryRope();              // Step 1: door rope (max 5)
        CashierKey cashier = new CashierKey();          // Step 2: stock + lock (10)
        ExecutorService kitchen = Executors.newFixedThreadPool(4); // Step 3: 4 chefs

        AtomicInteger ordersCooked = new AtomicInteger(0);  // safe shared counter
        List<Future<String>> receipts = Collections.synchronizedList(new ArrayList<>());

        // Step 4: manager daemon
        Thread manager = new Thread(() -> {
            while (true) {
                System.out.println("   👔 Manager: " + ordersCooked.get() + " orders cooked so far...");
                try { Thread.sleep(1000); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        });
        manager.setDaemon(true);
        manager.start();

        // 50 customers
        List<Thread> customers = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> {
                try {
                    rope.enter(name);                          // 1) past the rope
                    boolean gotChicken = cashier.buyBucket(name); // 2) buy a bucket
                    if (gotChicken) {                          // 3) kitchen cooks it
                        Future<String> receipt = kitchen.submit(() -> {
                            String chef = Thread.currentThread().getName();
                            Thread.sleep(500);
                            ordersCooked.incrementAndGet();
                            return name + "'s order cooked by " + chef;
                        });
                        receipts.add(receipt);
                    }
                    rope.leave(name);                          // 4) leave the shop
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            customers.add(customer);
            customer.start();
        }

        for (Thread customer : customers) customer.join();     // wait for all 50

        System.out.println("\n----- 🧾 RECEIPTS -----");
        for (Future<String> receipt : receipts) {
            System.out.println("🧾 " + receipt.get());
        }

        kitchen.shutdown();
        System.out.println("\n🏁 Shop closed. Total chicken sold: " + receipts.size() + " buckets.");
    }
}
```

### Code — `src/ChickenShopSimulatorRun.java`  **(NEW FILE — single-file run version)**

> **What changed vs the split version:** `EntryRope` and `CashierKey` are copied in as
> `static` nested classes (marked below). Everything else is the same. This is so you can
> run it without a compiler.

```java
// STEP 5 (single-file run version) 🎉  — runs with: java src/ChickenShopSimulatorRun.java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class ChickenShopSimulatorRun {

    // ===== CHANGED: Step 1 EntryRope copied in as a nested class =====
    static class EntryRope {
        private int customersInside = 0;
        private final int MAX_INSIDE = 5;
        synchronized void enter(String name) throws InterruptedException {
            while (customersInside >= MAX_INSIDE) {
                System.out.println("⛔ " + name + " waits outside (shop is full).");
                wait();
            }
            customersInside++;
            System.out.println("✅ " + name + " stepped inside. Inside now: " + customersInside);
        }
        synchronized void leave(String name) { customersInside--; notifyAll(); }
    }

    // ===== CHANGED: Step 2 CashierKey copied in as a nested class =====
    static class CashierKey {
        private int buckets = 10;
        private final ReentrantLock key = new ReentrantLock();
        boolean buyBucket(String name) {
            key.lock();
            try {
                if (buckets > 0) {
                    buckets--;
                    System.out.println("🍗 " + name + " bought a bucket. Left: " + buckets);
                    return true;
                }
                System.out.println("❌ " + name + " — SOLD OUT, no chicken left.");
                return false;
            } finally { key.unlock(); }
        }
    }

    // ===== SAME as the split version below this line =====
    public static void main(String[] args) throws Exception {
        EntryRope rope = new EntryRope();
        CashierKey cashier = new CashierKey();
        ExecutorService kitchen = Executors.newFixedThreadPool(4);

        AtomicInteger ordersCooked = new AtomicInteger(0);
        List<Future<String>> receipts = Collections.synchronizedList(new ArrayList<>());

        Thread manager = new Thread(() -> {
            while (true) {
                System.out.println("   👔 Manager: " + ordersCooked.get() + " orders cooked so far...");
                try { Thread.sleep(1000); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        });
        manager.setDaemon(true);
        manager.start();

        List<Thread> customers = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> {
                try {
                    rope.enter(name);
                    boolean gotChicken = cashier.buyBucket(name);
                    if (gotChicken) {
                        Future<String> receipt = kitchen.submit(() -> {
                            String chef = Thread.currentThread().getName();
                            Thread.sleep(500);
                            ordersCooked.incrementAndGet();
                            return name + "'s order cooked by " + chef;
                        });
                        receipts.add(receipt);
                    }
                    rope.leave(name);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            customers.add(customer);
            customer.start();
        }

        for (Thread customer : customers) customer.join();

        System.out.println("\n----- 🧾 RECEIPTS -----");
        for (Future<String> receipt : receipts) {
            System.out.println("🧾 " + receipt.get());
        }

        kitchen.shutdown();
        System.out.println("\n🏁 Shop closed. Total chicken sold: " + receipts.size() + " buckets.");
    }
}
```

### How to test
```bash
# No compiler needed:
java src/ChickenShopSimulatorRun.java
```
**Expect:** "Inside now:" never above 5; exactly 10 buckets sold; only 4 chef names; the
manager line appears in the background; final line: `Total chicken sold: 10 buckets.`
Customer numbers come out scrambled — that's normal. Threads run in any order, but the
locks keep the **data** correct.

### 🎤 Interview Summary
> "I combined four concurrency tools in one app: a `synchronized` gate limits active
> threads, a `ReentrantLock` protects shared stock, a thread pool with `Future`s processes
> work, and a daemon thread reports in the background. I used `join()` to wait for all
> worker threads and `AtomicInteger` for a safe shared counter."

---

## 5. How to run everything

This machine has the Java **runtime** (`java`) but not the **compiler** (`javac`).
Java 11+ can run a single `.java` file directly, so use that for the self-contained files:

```bash
cd ChickenShop

java src/EntryRope.java                # Step 1
java src/CashierKey.java               # Step 2
java src/KitchenChefs.java             # Step 3
java src/ManagerDaemon.java            # Step 4
java src/ChickenShopSimulatorRun.java  # Step 5 (single-file, no compiler)
```

To compile the normal way and run the clean split version, install a full JDK first:

```bash
sudo apt install default-jdk          # gives you javac
cd ChickenShop
javac src/*.java && java -cp src ChickenShopSimulator
```

---

## 6. Cheat sheet (one-line each)

| Tool | One-line meaning |
|---|---|
| `Thread` | A worker that runs on its own. |
| `synchronized` | Only one thread in this code at a time. |
| `wait()` | Sleep until another thread wakes you. |
| `notifyAll()` | Wake up all waiting threads. |
| `ReentrantLock` | A lock you grab and release by hand. |
| `lock()` / `unlock()` | Take the lock / give it back (use `try/finally`). |
| `ExecutorService` | A manager for a pool of worker threads. |
| `newFixedThreadPool(n)` | A fixed team of `n` reusable workers. |
| `submit()` | Hand a task to the pool; returns a `Future`. |
| `Future` | A ticket to collect a result later. |
| `get()` | Wait for and read the result. |
| `shutdown()` | Stop accepting tasks and close the pool. |
| `setDaemon(true)` | Make a background thread that won't block exit (set before `start()`). |
| `join()` | Wait for a thread to finish. |
| `AtomicInteger` | A counter that's safe to share between threads. |

---

## 7. Where to go next

When you're ready to level up, these build on what you learned here:

- **`Semaphore`** — a cleaner version of your entry rope (built-in "N permits").
- **`BlockingQueue`** — a self-managing order line (workers wait for work safely).
- **`CompletableFuture`** — chain cooking steps together (do A, then B, then C).

🍗 Great job finishing the Chicken Shop Simulator!
```
