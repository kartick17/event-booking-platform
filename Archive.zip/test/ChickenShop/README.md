# 🍗 The Chicken Shop Simulator — Start Here

A tiny, beginner-friendly Java project to learn **multithreading**.
You can read it, run it, and practice it on any computer that has Java. No Claude Code needed.

---

## What you need on the other system

1. **Java** (version 11 or newer). Check with:
   ```bash
   java -version
   ```
   - If you see a version number, you're ready.
   - If not, install a JDK:
     - **Ubuntu/Debian:** `sudo apt install default-jdk`
     - **Mac:** `brew install openjdk`
     - **Windows:** download "OpenJDK" or "Temurin" from https://adoptium.net
2. **Any text editor** (VS Code, Notepad++, even plain Notepad).

That's it. No special tools.

---

## What's in this folder

```
ChickenShop/
├── README.md      <- you are here (quick start)
├── GUIDE.md       <- the FULL lesson: concepts, all code, interview summaries, cheat sheet
├── src/           <- the finished, working code (your "answer key")
│   ├── EntryRope.java                Step 1
│   ├── CashierKey.java               Step 2
│   ├── KitchenChefs.java             Step 3
│   ├── ManagerDaemon.java            Step 4
│   ├── ChickenShopSimulator.java     Step 5 (split version, needs javac)
│   └── ChickenShopSimulatorRun.java  Step 5 (single-file, runs with just java)
└── practice/      <- DO IT YOURSELF: same files with blanks to fill in
    ├── PRACTICE.md                   how to practice + the topics to read
    ├── EntryRope.java
    ├── CashierKey.java
    ├── KitchenChefs.java
    └── ManagerDaemon.java
```

---

## How to learn (suggested order)

1. **Read** `GUIDE.md` top to bottom. It explains every concept in plain English.
2. **Run** the finished files in `src/` to see them work (commands below).
3. **Practice**: open `practice/PRACTICE.md` and fill in the blanks in the practice files.
   When stuck, peek at the matching file in `src/`.

---

## How to run the finished code

Open a terminal in this folder, then:

```bash
# Run a single file directly (works on Java 11+, no compiler needed):
java src/EntryRope.java                # Step 1
java src/CashierKey.java               # Step 2
java src/KitchenChefs.java             # Step 3
java src/ManagerDaemon.java            # Step 4
java src/ChickenShopSimulatorRun.java  # Step 5 (all together)
```

If you have the full JDK (with `javac`), you can also compile the clean split version:

```bash
javac src/*.java && java -cp src ChickenShopSimulator
```

---

## How to run YOUR practice code

Same way, just point at the practice folder:

```bash
java practice/EntryRope.java
```

Fill in the blanks first, or it won't compile — that's the point. 🙂

---

Happy practicing! Full details and the "explain it to an interviewer" lines are in `GUIDE.md`.
