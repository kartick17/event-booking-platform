// PRACTICE — STEP 2: THE CASHIER KEY 🔑
// Topic: ReentrantLock, lock(), unlock(), try/finally
// Goal: protect 10 buckets so two customers never grab the same one.
// Fill in every // TODO. Answer key: ../src/CashierKey.java

// TODO: import the ReentrantLock class.
//       hint: java.util.concurrent.locks.ReentrantLock
// YOUR IMPORT HERE

public class CashierKey {

    private int buckets = 10;

    // TODO: create one ReentrantLock called "key".
    // YOUR CODE HERE

    public boolean buyBucket(String customerName) {

        // TODO: grab the key (lock it) BEFORE the try block.
        // YOUR CODE HERE

        try {
            if (buckets > 0) {
                buckets--;
                System.out.println("🍗 " + customerName + " bought a bucket. Left: " + buckets);
                return true;
            } else {
                System.out.println("❌ " + customerName + " — SOLD OUT, no chicken left.");
                return false;
            }
        } finally {
            // TODO: ALWAYS release the key here (unlock it).
            // YOUR CODE HERE
        }
    }

    // ---- Test (already written for you) ----
    public static void main(String[] args) {
        CashierKey shop = new CashierKey();
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> shop.buyBucket(name));
            customer.start();
        }
    }
}
