// PRACTICE — STEP 1: THE ENTRY ROPE 🪢
// Topic: synchronized, wait(), notifyAll()
// Goal: only 5 customers inside the shop at once; the rest wait outside.
// Fill in every // TODO. Answer key: ../src/EntryRope.java

public class EntryRope {

    private int customersInside = 0;
    private final int MAX_INSIDE = 5;

    // TODO: make this method "synchronized" so only one thread runs it at a time.
    public void enter(String customerName) throws InterruptedException {

        // TODO: use a WHILE loop (not if) to check if the shop is full.
        //       while the shop is full:
        //         - print that this customer waits outside
        //         - call wait();   <- this makes the thread sleep
        // YOUR CODE HERE


        customersInside++;
        System.out.println("✅ " + customerName + " stepped inside. Inside now: " + customersInside);
    }

    // TODO: make this method "synchronized" too.
    public void leave(String customerName) {
        customersInside--;
        System.out.println("🚪 " + customerName + " left. Inside now: " + customersInside);

        // TODO: wake up all waiting customers (one method call).
        // YOUR CODE HERE

    }

    // ---- Test (already written for you) ----
    public static void main(String[] args) throws InterruptedException {
        EntryRope rope = new EntryRope();
        for (int i = 1; i <= 10; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> {
                try {
                    rope.enter(name);
                    Thread.sleep(500);
                    rope.leave(name);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            customer.start();
        }
    }
}
