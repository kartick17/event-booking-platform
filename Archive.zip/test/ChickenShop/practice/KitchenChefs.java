// PRACTICE — STEP 3: THE KITCHEN CHEFS 👨‍🍳
// Topic: ExecutorService, newFixedThreadPool, Future, get(), shutdown()
// Goal: reuse 4 worker threads to cook 10 orders and collect a receipt for each.
// Fill in every // TODO. Answer key: ../src/KitchenChefs.java

import java.util.ArrayList;
import java.util.List;
// TODO: import ExecutorService, Executors, and Future.
//       hint: all live in java.util.concurrent
// YOUR IMPORTS HERE

public class KitchenChefs {

    public static void main(String[] args) throws Exception {

        // TODO: create a kitchen with a fixed pool of 4 threads (chefs).
        //       hint: Executors.newFixedThreadPool(4)
        // YOUR CODE HERE  (call the variable "kitchen")

        List<Future<String>> receipts = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            int orderNumber = i;

            // TODO: submit a task to the kitchen. The task should:
            //       - get the chef name: Thread.currentThread().getName()
            //       - print that the chef is cooking this order
            //       - Thread.sleep(800)
            //       - return a receipt String
            //       submit(...) returns a Future<String> — add it to "receipts".
            // YOUR CODE HERE

        }

        // TODO: loop over "receipts" and print each one.
        //       hint: call receipt.get() to wait for and read the result.
        // YOUR CODE HERE

        // TODO: close the kitchen so the program can end.
        //       hint: kitchen.shutdown()
        // YOUR CODE HERE

        System.out.println("🏁 Kitchen closed. All orders cooked.");
    }
}
