// PRACTICE — STEP 4: THE MANAGER DAEMON 👔
// Topic: daemon thread, setDaemon(true) (must be BEFORE start())
// Goal: a background thread that reports every second but does NOT keep the program alive.
// Fill in every // TODO. Answer key: ../src/ManagerDaemon.java

public class ManagerDaemon {

    public static void main(String[] args) throws InterruptedException {

        Thread manager = new Thread(() -> {
            while (true) {
                System.out.println("👔 Manager: staff are still working...");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });

        // TODO: mark "manager" as a daemon thread.
        //       IMPORTANT: this must come BEFORE start(), or you get an exception.
        // YOUR CODE HERE

        // TODO: start the manager thread.
        // YOUR CODE HERE

        System.out.println("🏪 Shop is open. Real staff are working...");
        Thread.sleep(5000);

        System.out.println("🏁 Shop closed. Manager goes home too (daemon stops).");
    }
}
