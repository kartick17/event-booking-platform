# 🏋️ Practice — Fill in the Blanks

Each file here is the real lesson code with the **important lines removed** and replaced
with `// TODO:` notes. Your job: write the missing lines yourself.

This is the best way to learn — you find out exactly **where to write what**.

---

## How to practice

1. Read the matching topic in `../GUIDE.md` first.
2. Open a practice file (for example `EntryRope.java`).
3. Find every `// TODO:` and write the missing code.
4. Run it:
   ```bash
   java practice/EntryRope.java
   ```
5. Stuck or it won't run? Compare with the finished file in `../src/EntryRope.java`.

> The files in `../src/` are your **answer key**. Try hard first, then peek.

---

## The topics to read (in order)

Do them one at a time. Don't rush.

1. **Step 1 — EntryRope** → topic: `synchronized`, `wait()`, `notifyAll()`
   - Goal: let only 5 threads be "inside" at once; the rest wait.
2. **Step 2 — CashierKey** → topic: `ReentrantLock`, `lock()`, `unlock()`, `try/finally`
   - Goal: protect 10 buckets so two threads never grab the same one.
3. **Step 3 — KitchenChefs** → topic: `ExecutorService`, `newFixedThreadPool`, `Future`, `get()`, `shutdown()`
   - Goal: reuse 4 worker threads to cook 10 orders and collect receipts.
4. **Step 4 — ManagerDaemon** → topic: daemon thread, `setDaemon(true)` (before `start()`)
   - Goal: a background thread that doesn't stop the program from ending.
5. **Step 5 — Put it together** (no practice file; build it yourself!)
   - Copy your 4 working pieces into one `main`. Add `Thread.join()` to wait for all
     customers and `AtomicInteger` for a safe counter.
   - Check your work against `../src/ChickenShopSimulatorRun.java`.

---

## Self-check: did it work?

| Step | What correct output looks like |
|---|---|
| 1 | "Inside now:" never goes above 5 |
| 2 | Exactly 10 "bought a bucket", rest "SOLD OUT", never negative |
| 3 | Only 4 chef names (pool-1-thread-1..4), all 10 receipts printed |
| 4 | Manager prints ~5 times, then program ends right away |
| 5 | Inside ≤ 5, exactly 10 sold, "Total chicken sold: 10 buckets." |

Good luck! 🍗
