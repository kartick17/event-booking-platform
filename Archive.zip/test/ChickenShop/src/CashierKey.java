// ============================================================
// STEP 2: THE CASHIER KEY 🔑
// ============================================================
// Real-life picture:
// There are only 10 buckets of chicken left on the shelf.
// 50 hungry customers all reach for them at once!
// To stop two people grabbing the SAME bucket, the shop has
// ONE cashier with ONE key. You must hold the key to take a
// bucket. When you are done, you hand the key back.
//
// In Java words:
//   - ReentrantLock = the single cashier key.
//   - lock()        = grab the key (others must wait for it).
//   - unlock()      = hand the key back so the next person can use it.
//   - try/finally   = ALWAYS hand the key back, even if something breaks.
// ============================================================

import java.util.concurrent.locks.ReentrantLock;

public class CashierKey {

    // 10 buckets of chicken on the shelf to start.
    private int buckets = 10;

    // The one and only cashier key.
    private final ReentrantLock key = new ReentrantLock();

    // A customer tries to buy one bucket.
    // Returns true if they got chicken, false if it sold out.
    public boolean buyBucket(String customerName) {

        // Grab the key. If someone else holds it, wait your turn here.
        key.lock();
        try {
            if (buckets > 0) {
                buckets--; // take one bucket off the shelf
                System.out.println("🍗 " + customerName + " bought a bucket. Left: " + buckets);
                return true;
            } else {
                System.out.println("❌ " + customerName + " — SOLD OUT, no chicken left.");
                return false;
            }
        } finally {
            // ALWAYS hand the key back, no matter what happened above.
            key.unlock();
        }
    }


    // ---- A tiny test so we can SEE the key working ----
    public static void main(String[] args) {

        CashierKey shop = new CashierKey();

        // 50 customers all rush the shelf at the same time.
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> shop.buyBucket(name));
            customer.start();
        }
    }
}
