// ============================================================
// STEP 5: THE GRAND OPENING 🎉
// ============================================================
// This is the whole shop running at once. It glues together the
// four ideas you already learned:
//
//   Step 1 🪢 EntryRope     -> only 5 customers inside at a time
//   Step 2 🔑 CashierKey    -> only 10 buckets, no double-grabbing
//   Step 3 👨‍🍳 Kitchen Chefs -> 4 chefs cook the paid orders
//   Step 4 👔 Manager Daemon -> background helper reports every second
//
// The story for ONE customer:
//   1. Squeeze in past the rope (wait if the shop is full).
//   2. Try to buy a bucket at the cashier (lock protects the stock).
//   3. If they got chicken, the kitchen cooks it and gives a receipt.
//   4. Leave the shop so the next person can come in.
// ============================================================

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class ChickenShopSimulator {

    public static void main(String[] args) throws Exception {

        // --- Set up the shop using our earlier building blocks ---
        EntryRope rope = new EntryRope();   // Step 1: the door rope (max 5)
        CashierKey cashier = new CashierKey(); // Step 2: the stock + lock (10 buckets)
        ExecutorService kitchen = Executors.newFixedThreadPool(4); // Step 3: 4 chefs

        // A simple shared counter so the manager has something to report.
        AtomicInteger ordersCooked = new AtomicInteger(0);

        // Receipts come back from the kitchen. Many threads add to this
        // list at once, so we wrap it to make adding safe.
        List<Future<String>> receipts = Collections.synchronizedList(new ArrayList<>());

        // --- Step 4: the manager daemon, watching in the background ---
        Thread manager = new Thread(() -> {
            while (true) {
                System.out.println("   👔 Manager: " + ordersCooked.get() + " orders cooked so far...");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        manager.setDaemon(true); // must be set BEFORE start()
        manager.start();

        // --- 50 hungry customers all show up at once ---
        List<Thread> customers = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;

            Thread customer = new Thread(() -> {
                try {
                    // 1) Get past the rope (only 5 allowed inside).
                    rope.enter(name);

                    // 2) Try to buy a bucket at the cashier.
                    boolean gotChicken = cashier.buyBucket(name);

                    // 3) If they paid, send the order to the kitchen.
                    if (gotChicken) {
                        Future<String> receipt = kitchen.submit(() -> {
                            String chef = Thread.currentThread().getName();
                            Thread.sleep(500); // cooking takes a moment
                            ordersCooked.incrementAndGet();
                            return name + "'s order cooked by " + chef;
                        });
                        receipts.add(receipt);
                    }

                    // 4) Leave so the next customer can come in.
                    rope.leave(name);

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });

            customers.add(customer);
            customer.start();
        }

        // Wait for all 50 customers to finish their visit.
        for (Thread customer : customers) {
            customer.join();
        }

        // Collect every receipt from the kitchen.
        System.out.println("\n----- 🧾 RECEIPTS -----");
        for (Future<String> receipt : receipts) {
            System.out.println("🧾 " + receipt.get());
        }

        // Close the kitchen. The manager daemon stops on its own.
        kitchen.shutdown();
        System.out.println("\n🏁 Shop closed. Total chicken sold: " + receipts.size() + " buckets.");
    }
}
