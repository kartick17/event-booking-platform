// ============================================================
// STEP 5 (single-file run version) 🎉
// ============================================================
// Same shop as ChickenShopSimulator.java, but EntryRope and
// CashierKey are tucked inside as nested classes so we can run
// it with NO compiler:   java src/ChickenShopSimulatorRun.java
// (The split version is the "real" one; this is just runnable now.)
// ============================================================

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class ChickenShopSimulatorRun {

    // ---- Step 1: the door rope (max 5 inside) ----
    static class EntryRope {
        private int customersInside = 0;
        private final int MAX_INSIDE = 5;

        synchronized void enter(String name) throws InterruptedException {
            while (customersInside >= MAX_INSIDE) {
                System.out.println("⛔ " + name + " waits outside (shop is full).");
                wait();
            }
            customersInside++;
            System.out.println("✅ " + name + " stepped inside. Inside now: " + customersInside);
        }

        synchronized void leave(String name) {
            customersInside--;
            notifyAll();
        }
    }

    // ---- Step 2: the cashier key (10 buckets, no double-grab) ----
    static class CashierKey {
        private int buckets = 10;
        private final ReentrantLock key = new ReentrantLock();

        boolean buyBucket(String name) {
            key.lock();
            try {
                if (buckets > 0) {
                    buckets--;
                    System.out.println("🍗 " + name + " bought a bucket. Left: " + buckets);
                    return true;
                }
                System.out.println("❌ " + name + " — SOLD OUT, no chicken left.");
                return false;
            } finally {
                key.unlock();
            }
        }
    }

    public static void main(String[] args) throws Exception {

        EntryRope rope = new EntryRope();
        CashierKey cashier = new CashierKey();
        ExecutorService kitchen = Executors.newFixedThreadPool(4); // Step 3: 4 chefs

        AtomicInteger ordersCooked = new AtomicInteger(0);
        List<Future<String>> receipts = Collections.synchronizedList(new ArrayList<>());

        // Step 4: the manager daemon
        Thread manager = new Thread(() -> {
            while (true) {
                System.out.println("   👔 Manager: " + ordersCooked.get() + " orders cooked so far...");
                try { Thread.sleep(1000); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        });
        manager.setDaemon(true);
        manager.start();

        // 50 hungry customers
        List<Thread> customers = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            String name = "Customer-" + i;
            Thread customer = new Thread(() -> {
                try {
                    rope.enter(name);                       // 1) past the rope
                    boolean gotChicken = cashier.buyBucket(name); // 2) buy a bucket
                    if (gotChicken) {                       // 3) kitchen cooks it
                        Future<String> receipt = kitchen.submit(() -> {
                            String chef = Thread.currentThread().getName();
                            Thread.sleep(500);
                            ordersCooked.incrementAndGet();
                            return name + "'s order cooked by " + chef;
                        });
                        receipts.add(receipt);
                    }
                    rope.leave(name);                       // 4) leave the shop
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            customers.add(customer);
            customer.start();
        }

        for (Thread customer : customers) customer.join();

        System.out.println("\n----- 🧾 RECEIPTS -----");
        for (Future<String> receipt : receipts) {
            System.out.println("🧾 " + receipt.get());
        }

        kitchen.shutdown();
        System.out.println("\n🏁 Shop closed. Total chicken sold: " + receipts.size() + " buckets.");
    }
}
