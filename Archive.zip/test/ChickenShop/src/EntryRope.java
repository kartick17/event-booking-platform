// ============================================================
// STEP 1: THE ENTRY ROPE 🪢
// ============================================================
// Real-life picture:
// Our little fried chicken shop is tiny. The owner puts a rope
// at the door. Only 5 customers are allowed inside the shop at
// the same time. If the shop is full, the next customer must
// WAIT outside until someone leaves.
//
// In Java words:
//   - "synchronized" = only one person can touch the rope at a time.
//   - "wait()"       = stand outside and sleep until called.
//   - "notifyAll()"  = shout "spot free!" so waiting people wake up.
// ============================================================

public class EntryRope {

    // How many customers are inside the shop right now.
    private int customersInside = 0;

    // The shop can hold at most 5 customers at once.
    private final int MAX_INSIDE = 5;

    // A customer tries to come in through the door.
    // "synchronized" means: only one customer can run this code
    // at a time, so the count never gets messed up.
    public synchronized void enter(String customerName) throws InterruptedException {

        // If the shop is already full, wait outside.
        // "while" (not "if") because we must re-check after waking up.
        while (customersInside >= MAX_INSIDE) {
            System.out.println("⛔ " + customerName + " waits outside (shop is full).");
            wait(); // sleep here until someone calls notifyAll()
        }

        // A spot is free, so step inside.
        customersInside++;
        System.out.println("✅ " + customerName + " stepped inside. Inside now: " + customersInside);
    }

    // A customer finishes and leaves the shop.
    public synchronized void leave(String customerName) {
        customersInside--;
        System.out.println("🚪 " + customerName + " left. Inside now: " + customersInside);

        // Tell everyone waiting outside that a spot just opened.
        notifyAll();
    }


    // ---- A tiny test so we can SEE the rope working ----
    public static void main(String[] args) throws InterruptedException {

        EntryRope rope = new EntryRope();

        // Make 10 customers. Only 5 should be inside at any moment.
        for (int i = 1; i <= 10; i++) {
            String name = "Customer-" + i;

            // Each customer is its own thread (its own person).
            Thread customer = new Thread(() -> {
                try {
                    rope.enter(name);
                    Thread.sleep(500); // pretend they are eating chicken
                    rope.leave(name);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });

            customer.start();
        }
    }
}
