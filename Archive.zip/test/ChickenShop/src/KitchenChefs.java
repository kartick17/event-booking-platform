// ============================================================
// STEP 3: THE KITCHEN CHEFS 👨‍🍳
// ============================================================
// Real-life picture:
// A customer paid for chicken. Now the order goes to the kitchen.
// The kitchen has exactly 4 chefs. They take orders one by one
// and cook them. You DON'T hire a brand-new chef for every order
// (that would be slow and silly) — you reuse the same 4 chefs.
// When a chef finishes, they hand back a RECEIPT.
//
// In Java words:
//   - ExecutorService          = the kitchen that manages the chefs.
//   - FixedThreadPool(4)       = exactly 4 chefs, reused for all orders.
//   - submit(...)              = drop an order into the kitchen.
//   - Future                   = the receipt you collect later.
//   - future.get()             = wait at the counter for that receipt.
//   - shutdown()               = close the kitchen after the last order.
// ============================================================

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class KitchenChefs {

    public static void main(String[] args) throws Exception {

        // Open the kitchen with exactly 4 chefs.
        ExecutorService kitchen = Executors.newFixedThreadPool(4);

        // We will keep all the receipts (Futures) in this list.
        List<Future<String>> receipts = new ArrayList<>();

        // 10 paid orders come into the kitchen.
        for (int i = 1; i <= 10; i++) {
            int orderNumber = i;

            // submit() hands the order to a free chef.
            // The chef returns a String (the receipt text).
            Future<String> receipt = kitchen.submit(() -> {
                String chef = Thread.currentThread().getName();
                System.out.println("🍳 " + chef + " is cooking order #" + orderNumber);
                Thread.sleep(800); // cooking takes a little time
                return "Receipt: order #" + orderNumber + " cooked by " + chef;
            });

            receipts.add(receipt);
        }

        // Go to the counter and collect every receipt.
        // future.get() waits until that order is actually done.
        for (Future<String> receipt : receipts) {
            System.out.println("🧾 " + receipt.get());
        }

        // Last order is done — close the kitchen so the program can end.
        kitchen.shutdown();
        System.out.println("🏁 Kitchen closed. All orders cooked.");
    }
}
