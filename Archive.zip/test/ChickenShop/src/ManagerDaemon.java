// ============================================================
// STEP 4: THE MANAGER DAEMON 👔
// ============================================================
// Real-life picture:
// The shop has a manager who walks around every second saying
// "How's it going? Keep cooking!" He never does real work and
// he never blocks the shop from closing. The moment the real
// staff go home (all normal threads finish), the manager goes
// home too — even mid-sentence.
//
// In Java words:
//   - A normal Thread       = a worker. Java waits for it to finish.
//   - setDaemon(true)       = a background helper. Java does NOT
//                             wait for it; it dies when the app ends.
//   - A daemon must be set BEFORE start(), or you get an error.
// ============================================================

public class ManagerDaemon {

    public static void main(String[] args) throws InterruptedException {

        // The manager: a background thread that reports every second.
        Thread manager = new Thread(() -> {
            // Loop forever — the daemon will be killed when the app ends.
            while (true) {
                System.out.println("👔 Manager: staff are still working...");
                try {
                    Thread.sleep(1000); // report once per second
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });

        // IMPORTANT: mark as daemon BEFORE starting it.
        // This makes Java NOT wait for the manager to finish.
        manager.setDaemon(true);
        manager.start();

        // The real work: pretend the shop is open for 5 seconds.
        System.out.println("🏪 Shop is open. Real staff are working...");
        Thread.sleep(5000);

        // Real work is done. The program ends here.
        // The manager daemon is killed automatically — we never
        // had to stop it by hand.
        System.out.println("🏁 Shop closed. Manager goes home too (daemon stops).");
    }
}
