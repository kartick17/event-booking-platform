// =====================================================================
// FLASH-SALE ORDER PROCESSING ENGINE — single-file run version
// =====================================================================
// Same logic as the packaged src/com/flashsale/* code, but every module
// is a nested static class so it runs with NO compiler:
//     java FlashSaleEngineRun.java
// The packaged version under src/ is the "real" enterprise layout.
// =====================================================================

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public final class FlashSaleEngineRun {

    // ---- MODEL: immutable order message ----
    record Order(String orderId, String buyerName, int quantity) {
        Order {
            if (orderId == null || orderId.isBlank()) throw new IllegalArgumentException("orderId blank");
            if (buyerName == null || buyerName.isBlank()) throw new IllegalArgumentException("buyerName blank");
            if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive");
        }
    }

    // ---- MODULE 1: bounded blocking queue (synchronized + wait/notifyAll) ----
    static final class OrderIngestionBuffer {
        private final Deque<Order> pending = new ArrayDeque<>();
        private final int capacity;

        OrderIngestionBuffer(int capacity) {
            if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive");
            this.capacity = capacity;
        }

        synchronized void enqueue(Order order) throws InterruptedException {
            while (pending.size() == capacity) wait();   // backpressure
            pending.addLast(order);
            notifyAll();
        }

        synchronized Order dequeue() throws InterruptedException {
            while (pending.isEmpty()) wait();
            Order next = pending.removeFirst();
            notifyAll();
            return next;
        }

        synchronized int size() { return pending.size(); }
    }

    // ---- MODULE 2: inventory guarded by a ReentrantLock ----
    static final class FlashInventoryManager {
        private final ReentrantLock stockLock = new ReentrantLock();
        private int availableUnits;
        private int reservedUnits = 0;

        FlashInventoryManager(int initialUnits) {
            if (initialUnits < 0) throw new IllegalArgumentException("initialUnits negative");
            this.availableUnits = initialUnits;
        }

        boolean tryReserve(int quantity) {
            if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive");
            stockLock.lock();
            try {
                if (availableUnits >= quantity) {
                    availableUnits -= quantity;
                    reservedUnits += quantity;
                    return true;
                }
                return false;
            } finally {
                stockLock.unlock();
            }
        }

        int availableUnits() { stockLock.lock(); try { return availableUnits; } finally { stockLock.unlock(); } }
        int reservedUnits()  { stockLock.lock(); try { return reservedUnits; }  finally { stockLock.unlock(); } }
    }

    // ---- MODULE 3: payment dispatcher (ExecutorService + Callable + Future) ----
    record PaymentResult(String orderId, boolean approved, String transactionId, String detail) { }

    static final class PaymentDispatcher implements AutoCloseable {
        private final ExecutorService paymentPool;

        PaymentDispatcher(int workerThreads) {
            if (workerThreads <= 0) throw new IllegalArgumentException("workerThreads must be positive");
            this.paymentPool = Executors.newFixedThreadPool(workerThreads, namedThreadFactory("payment-worker"));
        }

        Future<PaymentResult> submitPayment(Order order) {
            Callable<PaymentResult> task = () -> processPayment(order);
            return paymentPool.submit(task);
        }

        private PaymentResult processPayment(Order order) throws InterruptedException {
            Thread.sleep(200); // pretend gateway latency
            return new PaymentResult(order.orderId(), true, "TXN-" + order.orderId(),
                    "charged " + order.buyerName() + " for " + order.quantity() + " unit(s)");
        }

        @Override
        public void close() {
            paymentPool.shutdown();
            try {
                if (!paymentPool.awaitTermination(10, TimeUnit.SECONDS)) paymentPool.shutdownNow();
            } catch (InterruptedException e) {
                paymentPool.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        private static ThreadFactory namedThreadFactory(String prefix) {
            AtomicInteger seq = new AtomicInteger(1);
            return runnable -> new Thread(runnable, prefix + "-" + seq.getAndIncrement());
        }
    }

    // ---- MODULE 4: telemetry daemon (raw background Thread) ----
    static final class TelemetryDaemon {
        private final Thread daemonThread;
        private volatile boolean running = true;

        TelemetryDaemon(OrderIngestionBuffer buffer, FlashInventoryManager inventory,
                        List<Thread> workers, long intervalMillis) {
            if (intervalMillis <= 0) throw new IllegalArgumentException("intervalMillis must be positive");
            this.daemonThread = new Thread(() -> pollLoop(buffer, inventory, workers, intervalMillis), "telemetry-daemon");
            this.daemonThread.setDaemon(true); // before start()
        }

        void start() { daemonThread.start(); }

        void stop() { running = false; daemonThread.interrupt(); }

        private void pollLoop(OrderIngestionBuffer buffer, FlashInventoryManager inventory,
                              List<Thread> workers, long intervalMillis) {
            while (running) {
                try {
                    logSnapshot(buffer, inventory, workers);
                    Thread.sleep(intervalMillis);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        private void logSnapshot(OrderIngestionBuffer buffer, FlashInventoryManager inventory, List<Thread> workers) {
            StringBuilder s = new StringBuilder("[TELEMETRY] buffer=").append(buffer.size())
                    .append(" | available=").append(inventory.availableUnits())
                    .append(" | reserved=").append(inventory.reservedUnits())
                    .append(" | workers=[");
            for (int i = 0; i < workers.size(); i++) {
                Thread w = workers.get(i);
                s.append(w.getName()).append(':').append(w.getState());
                if (i < workers.size() - 1) s.append(", ");
            }
            s.append(']');
            System.out.println(s);
        }
    }

    // ---- ORCHESTRATION ----
    private static final int TOTAL_BUYERS = 50;
    private static final int TOTAL_STOCK = 10;
    private static final int BUFFER_CAPACITY = 20;
    private static final int WORKER_THREADS = 5;
    private static final int PAYMENT_THREADS = 4;
    private static final Order POISON_PILL = new Order("POISON", "system", 1);

    public static void main(String[] args) throws InterruptedException {
        OrderIngestionBuffer buffer = new OrderIngestionBuffer(BUFFER_CAPACITY);
        FlashInventoryManager inventory = new FlashInventoryManager(TOTAL_STOCK);
        List<Future<PaymentResult>> receipts = Collections.synchronizedList(new ArrayList<>());

        try (PaymentDispatcher dispatcher = new PaymentDispatcher(PAYMENT_THREADS)) {

            List<Thread> workers = new ArrayList<>();
            for (int i = 1; i <= WORKER_THREADS; i++) {
                Thread worker = new Thread(() -> runWorker(buffer, inventory, dispatcher, receipts), "order-worker-" + i);
                workers.add(worker);
                worker.start();
            }

            TelemetryDaemon telemetry = new TelemetryDaemon(buffer, inventory, workers, 500);
            telemetry.start();

            List<Thread> buyers = new ArrayList<>();
            for (int i = 1; i <= TOTAL_BUYERS; i++) {
                Order order = new Order("ORD-" + i, "Buyer-" + i, 1);
                Thread buyer = new Thread(() -> enqueueOrder(buffer, order), "buyer-" + i);
                buyers.add(buyer);
                buyer.start();
            }
            for (Thread buyer : buyers) buyer.join();

            for (int i = 0; i < WORKER_THREADS; i++) enqueueOrder(buffer, POISON_PILL);
            for (Thread worker : workers) worker.join();

            telemetry.stop();

            int approved = collectApprovedPayments(receipts);

            System.out.println("\n================ FLASH SALE SUMMARY ================");
            System.out.println("Buyers:            " + TOTAL_BUYERS);
            System.out.println("Stock at start:    " + TOTAL_STOCK);
            System.out.println("Units reserved:    " + inventory.reservedUnits());
            System.out.println("Payments approved: " + approved);
            System.out.println("Sold out (missed): " + (TOTAL_BUYERS - inventory.reservedUnits()));
            System.out.println("Stock remaining:   " + inventory.availableUnits());
            System.out.println("===================================================");
        }
    }

    private static void runWorker(OrderIngestionBuffer buffer, FlashInventoryManager inventory,
                                  PaymentDispatcher dispatcher, List<Future<PaymentResult>> receipts) {
        while (true) {
            try {
                Order order = buffer.dequeue();
                if (order == POISON_PILL) return;
                if (inventory.tryReserve(order.quantity())) {
                    System.out.println("[RESERVED] " + order.orderId() + " by " + order.buyerName());
                    receipts.add(dispatcher.submitPayment(order));
                } else {
                    System.out.println("[SOLD OUT] " + order.orderId() + " — no stock for " + order.buyerName());
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    private static void enqueueOrder(OrderIngestionBuffer buffer, Order order) {
        try {
            buffer.enqueue(order);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static int collectApprovedPayments(List<Future<PaymentResult>> receipts) {
        int approved = 0;
        for (Future<PaymentResult> receipt : receipts) {
            try {
                PaymentResult result = receipt.get();
                if (result.approved()) {
                    approved++;
                    System.out.println("[PAID] " + result.transactionId() + " — " + result.detail());
                }
            } catch (ExecutionException e) {
                System.out.println("[PAYMENT FAILED] " + e.getCause());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return approved;
    }
}
