# ⚡ Flash-Sale Order Processing Engine — Full Learning Guide

A lightweight, enterprise-style Java SE project to practice **core concurrency** hands-on.
No Spring Boot — just raw threads, so you see the mechanics. But the code is written the
way an enterprise team would write it: small classes, descriptive names, specific
exceptions, no thread leaks.

---

## 1. What is this project?

A flash sale: a product drops, traffic spikes, and far more buyers arrive than there is
stock. We simulate **50 buyers** fighting over **10 items**. The engine must:

- survive the spike without running out of memory,
- never sell the same item twice,
- charge cards without blocking the order line,
- and report what every thread is doing, live.

Each of those needs maps to one module and one concurrency tool.

> **Concurrency (plain English):** many things happening at the same time. Fast, but you
> must control shared data carefully or it gets corrupted.

---

## 2. What you will learn

| Need | Plain-English meaning | Java tool | Module |
|---|---|---|---|
| Absorb traffic spikes safely | Hold a fixed number of orders; make producers wait | `synchronized`, `wait()`, `notifyAll()` | 1 |
| Never oversell | One lock around "check then take" | `ReentrantLock`, `lock()`/`unlock()`, `try/finally` | 2 |
| Charge cards off the hot path | Reuse a pool of worker threads; collect results later | `ExecutorService`, `Callable`, `Future` | 3 |
| Live monitoring that never blocks shutdown | A background helper thread | daemon `Thread`, `setDaemon(true)`, `Thread.State` | 4 |
| Stop consumers cleanly | Send a "stop" marker through the queue | poison-pill pattern, `join()` | Main |

> **Race condition:** two threads read-then-write the same value at the same moment and
> the result is wrong (e.g. selling 11 items from a shelf of 10). Locks stop this.
> **Backpressure:** when you can't keep up, you make the sender wait instead of piling up
> work in memory.

---

## 3. The architecture (big picture)

```
50 buyers ──▶ [Module 1: Ingestion Buffer] ──▶ worker threads
                  (bounded, backpressure)            │
                                                      ▼
                                          [Module 2: Inventory Manager]
                                              (reserve 1 unit, locked)
                                                      │ reserved?
                                                      ▼
                                          [Module 3: Payment Dispatcher]
                                              (Callable → Future result)

   [Module 4: Telemetry Daemon] polls all of the above every 0.5s in the background
```

---

## 4. Project files

```
FlashSaleEngine/
├── README.md                 start here (install + run)
├── GUIDE.md                  this file (full lesson)
├── FlashSaleEngineRun.java   single-file version — runs with just `java` (no compiler)
├── src/com/flashsale/        the enterprise, packaged version (needs javac)
│   ├── model/Order.java
│   ├── ingestion/OrderIngestionBuffer.java        ── Module 1 ──
│   ├── ingestion/OrderIngestionBufferDemo.java     (manual test for Module 1)
│   ├── inventory/FlashInventoryManager.java       ── Module 2 ──
│   ├── dispatch/PaymentResult.java                ── Module 3 ──
│   ├── dispatch/PaymentDispatcher.java
│   ├── telemetry/TelemetryDaemon.java             ── Module 4 ──
│   └── Main.java                                   (orchestration: 50 buyers vs 10 stock)
└── practice/                 fill-in-the-blank versions + PRACTICE.md
```

---

# MODULE 1 — Order Ingestion Buffer 🛒

### Concept (simple)
A **bounded blocking queue** you build by hand. Buyers add orders; workers take them. It
holds a fixed maximum. When full, adders **wait** (backpressure) instead of letting memory
grow forever.

### Why `synchronized` + `wait()` / `notifyAll()` (not the alternatives)
- **Busy-wait** (`while(full){}`) burns 100% CPU. `wait()` releases the lock and sleeps —
  zero CPU while blocked.
- **`ReentrantLock` + `Condition`** also works and is more flexible (separate not-full /
  not-empty queues), but it's heavier than we need for one lock with two states.
- **`ArrayBlockingQueue`** is what you'd ship in production — but it hides the mechanics
  we're here to learn.
- **`synchronized` alone** gives mutual exclusion but no way to *sleep until a condition
  changes*. We need both.

Two things a senior will check:
- **`while`, not `if`** around `wait()` — handles spurious wakeups and lost-wakeup races.
- **`notifyAll()`, not `notify()`** — producers and consumers share one monitor; `notify()`
  could wake the wrong kind and stall.

### Code — `src/com/flashsale/ingestion/OrderIngestionBuffer.java` **(NEW FILE)**
```java
public final class OrderIngestionBuffer {
    private final Deque<Order> pending = new ArrayDeque<>(); // guarded by 'this'
    private final int capacity;

    public OrderIngestionBuffer(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive, was " + capacity);
        this.capacity = capacity;
    }

    public synchronized void enqueue(Order order) throws InterruptedException {
        while (pending.size() == capacity) wait();   // backpressure
        pending.addLast(order);
        notifyAll();
    }

    public synchronized Order dequeue() throws InterruptedException {
        while (pending.isEmpty()) wait();
        Order next = pending.removeFirst();
        notifyAll();
        return next;
    }

    public synchronized int size() { return pending.size(); }
}
```
Supporting file — `src/com/flashsale/model/Order.java` **(NEW FILE)**: an immutable
`record Order(String orderId, String buyerName, int quantity)` that validates its fields in
a compact constructor.

### How to test
```bash
# packaged version (needs javac):
javac -d out src/com/flashsale/model/Order.java src/com/flashsale/ingestion/*.java
java -cp out com.flashsale.ingestion.OrderIngestionBufferDemo
```
**Expect:** first 3 orders accepted fast, then ingestion pauses (buffer full) and accepts
one new order each time a worker drains one. That pause is backpressure.

### 🎤 Interview Defense
> "I built a bounded blocking queue on the intrinsic monitor for backpressure, so spikes
> block producers instead of exhausting memory. I wait in a `while` loop to survive
> spurious wakeups and lost-wakeup races, and use `notifyAll()` because producers and
> consumers share one monitor. I propagate `InterruptedException` so shutdown stays the
> caller's decision."

---

# MODULE 2 — Flash Inventory Manager 📦

### Concept (simple)
Holds the stock. The dangerous part is "check if a unit is free, then take it" — two steps
that must act as **one** atomic step, or two threads both see "1 left" and both take it.
A lock makes the check-and-take indivisible.

### Why `ReentrantLock` (not `synchronized`)
Both would work for the basic case. `ReentrantLock` is chosen because production code often
needs what it adds:
- **`tryLock(timeout)`** — give up after a wait instead of blocking forever (vital under a
  flash-sale spike).
- **`lockInterruptibly()`** — a waiting thread can be cancelled.
- **Fairness option** — `new ReentrantLock(true)` serves threads in arrival order.
- **Flexible scope** — you can lock across helper methods, not just one block.
`synchronized` is simpler but offers none of these. Same correctness, less control.

The non-negotiable habit: **`lock()` before `try`, `unlock()` in `finally`.** If you put
`lock()` inside the `try` and acquisition throws, `finally` would call `unlock()` on a lock
you never held. And without `finally`, a thrown exception leaks the lock forever →
**deadlock**.

### Code — `src/com/flashsale/inventory/FlashInventoryManager.java` **(NEW FILE)**
```java
public final class FlashInventoryManager {
    private final ReentrantLock stockLock = new ReentrantLock();
    private int availableUnits;     // guarded by stockLock
    private int reservedUnits = 0;  // guarded by stockLock

    public FlashInventoryManager(int initialUnits) {
        if (initialUnits < 0) throw new IllegalArgumentException("initialUnits must not be negative, was " + initialUnits);
        this.availableUnits = initialUnits;
    }

    public boolean tryReserve(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive, was " + quantity);
        stockLock.lock();                  // acquire OUTSIDE the try
        try {
            if (availableUnits >= quantity) {
                availableUnits -= quantity;
                reservedUnits  += quantity;
                return true;
            }
            return false;                  // clean "sold out", not an exception
        } finally {
            stockLock.unlock();            // ALWAYS release
        }
    }

    public int availableUnits() { stockLock.lock(); try { return availableUnits; } finally { stockLock.unlock(); } }
    public int reservedUnits()  { stockLock.lock(); try { return reservedUnits; }  finally { stockLock.unlock(); } }
}
```

### How to test
Easiest seen via the full run (Module Main) — final summary shows `Units reserved: 10`,
never 11, with 50 buyers.

### 🎤 Interview Defense
> "Reserving stock is a check-then-act, so I made it atomic with a `ReentrantLock`,
> acquiring before the `try` and releasing in `finally` so the lock can't leak on an
> exception. I chose `ReentrantLock` over `synchronized` for the production options it
> gives — `tryLock` with a timeout, interruptible acquisition, and fairness. 'Sold out' is
> a normal `false` return, not an exception, so the hot path stays cheap."

---

# MODULE 3 — Payment & Notification Dispatcher 💳

### Concept (simple)
Charging a card is slow (it calls an external gateway). We must not block the order workers
on it, and we must not spawn a new thread per payment. So payments run on a **fixed pool**
of reusable threads. Each payment is a **`Callable`** (returns a value, may throw a checked
exception). `submit` returns a **`Future`** you read later.

### Why `ExecutorService` + `Callable` + `Future` (not raw `Thread`)
- **Thread reuse:** a pool reuses a few threads; `new Thread()` per task is expensive and
  unbounded (50 buyers → 50 threads → resource blow-up).
- **`Callable` over `Runnable`:** `Callable` returns a result *and* can throw checked
  exceptions; `Runnable` can do neither.
- **`Future`:** carries the result back, and re-throws any task exception wrapped in
  `ExecutionException` — so failures aren't silently lost.
- **Bounded parallelism:** the pool size caps how many gateways calls run at once.

The enterprise detail: **graceful shutdown.** `shutdown()` stops new tasks and lets
in-flight ones finish; `awaitTermination(...)` waits a grace period; `shutdownNow()`
force-interrupts stragglers. We implement `AutoCloseable` so `try-with-resources` can't
forget to do it — that's how you prevent **thread leaks**.

### Code — `src/com/flashsale/dispatch/PaymentDispatcher.java` **(NEW FILE)**
```java
public final class PaymentDispatcher implements AutoCloseable {
    private final ExecutorService paymentPool;

    public PaymentDispatcher(int workerThreads) {
        if (workerThreads <= 0) throw new IllegalArgumentException("workerThreads must be positive, was " + workerThreads);
        this.paymentPool = Executors.newFixedThreadPool(workerThreads, namedThreadFactory("payment-worker"));
    }

    public Future<PaymentResult> submitPayment(Order order) {
        Callable<PaymentResult> paymentTask = () -> processPayment(order);
        return paymentPool.submit(paymentTask);
    }

    private PaymentResult processPayment(Order order) throws InterruptedException {
        Thread.sleep(200); // gateway latency
        return new PaymentResult(order.orderId(), true, "TXN-" + order.orderId(),
                "charged " + order.buyerName() + " for " + order.quantity() + " unit(s)");
    }

    @Override
    public void close() {
        paymentPool.shutdown();
        try {
            if (!paymentPool.awaitTermination(10, TimeUnit.SECONDS)) paymentPool.shutdownNow();
        } catch (InterruptedException e) {
            paymentPool.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private static ThreadFactory namedThreadFactory(String prefix) {
        AtomicInteger sequence = new AtomicInteger(1);
        return runnable -> new Thread(runnable, prefix + "-" + sequence.getAndIncrement());
    }
}
```
Supporting file — `src/com/flashsale/dispatch/PaymentResult.java` **(NEW FILE)**: an
immutable `record PaymentResult(String orderId, boolean approved, String transactionId,
String detail)`.

### 🎤 Interview Defense
> "Payments are slow I/O, so I run them on a fixed thread pool to reuse threads and bound
> parallelism, with `Callable` tasks that return a `Future`. I read results via `Future.get`
> and handle `ExecutionException` to surface task failures instead of hiding them. The
> dispatcher is `AutoCloseable` and shuts down in two phases — `shutdown` then
> `awaitTermination` then `shutdownNow` — so no threads leak."

---

# MODULE 4 — Live Telemetry Metrics Daemon 📊

### Concept (simple)
A single background thread that wakes every half-second and logs a snapshot: buffer depth,
stock left, and the **lifecycle state** of each worker thread. It is a **daemon**, so it
never keeps the program alive.

### Why a raw daemon `Thread` (not a pool)
- It's **one** long-lived housekeeping task, not a stream of short tasks — a dedicated
  thread fits better than a pool.
- **`setDaemon(true)`** means the JVM exits when only daemon threads remain. Monitoring
  must never block shutdown. (Rule: set daemon **before** `start()`, or you get
  `IllegalThreadStateException`.)
- A `ScheduledExecutorService.scheduleAtFixedRate` is a fine alternative, but you'd have to
  remember to shut it down; the daemon flag makes "don't block exit" automatic.

Interview gold — the **`Thread.State`** values you'll see in the output:
`NEW`, `RUNNABLE`, `BLOCKED` (waiting for a lock), `WAITING` / `TIMED_WAITING`
(in `wait()` / `sleep()`), `TERMINATED`.

### Code — `src/com/flashsale/telemetry/TelemetryDaemon.java` **(NEW FILE)**
```java
public final class TelemetryDaemon {
    private final Thread daemonThread;
    private volatile boolean running = true; // volatile: seen across threads

    public TelemetryDaemon(OrderIngestionBuffer buffer, FlashInventoryManager inventory,
                           List<Thread> workers, long intervalMillis) {
        if (intervalMillis <= 0) throw new IllegalArgumentException("intervalMillis must be positive, was " + intervalMillis);
        this.daemonThread = new Thread(() -> pollLoop(buffer, inventory, workers, intervalMillis), "telemetry-daemon");
        this.daemonThread.setDaemon(true); // BEFORE start()
    }

    public void start() { daemonThread.start(); }

    public void stop() { running = false; daemonThread.interrupt(); }

    private void pollLoop(OrderIngestionBuffer buffer, FlashInventoryManager inventory,
                          List<Thread> workers, long intervalMillis) {
        while (running) {
            try {
                logSnapshot(buffer, inventory, workers);
                Thread.sleep(intervalMillis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    // logSnapshot(...) prints buffer size, stock, and each worker's getName()/getState()
}
```

### 🎤 Interview Defense
> "Telemetry is one long-lived background job, so I use a dedicated daemon thread — the JVM
> won't wait for it on shutdown, set daemon before `start()`. The loop checks a `volatile`
> flag and honors interruption so it stops cleanly. I poll each worker's `Thread.State`
> (RUNNABLE, BLOCKED, WAITING, TIMED_WAITING) to show live lifecycle without touching the
> workers."

---

# MAIN — Orchestration 🎬

### What it does
Wires all four modules together and runs the simulation: 50 buyers, 10 items, 5 worker
threads, a 4-thread payment pool, and the telemetry daemon.

### Two patterns worth knowing
- **Poison pill:** to stop the worker threads cleanly, after all buyers finish we push one
  special sentinel `Order` per worker. A worker that dequeues it returns. We compare by
  reference (`order == POISON_PILL`). No flags, no `stop()`, no thread leak.
- **`join()`:** main waits for all buyers, then all workers, before reading results — so the
  summary reflects finished work.

### Code shape — `src/com/flashsale/Main.java` **(NEW FILE)**
```java
try (PaymentDispatcher dispatcher = new PaymentDispatcher(PAYMENT_THREADS)) {
    // start WORKER_THREADS workers: each loops dequeue() -> tryReserve() -> submitPayment()
    // start TelemetryDaemon over those workers
    // start 50 buyer threads that enqueue an order each; join them
    // enqueue one POISON_PILL per worker; join workers
    // telemetry.stop()
    // collect futures, count approvals, print summary
} // dispatcher.close() -> graceful pool shutdown
```

### How to run (packaged version)
```bash
cd FlashSaleEngine
javac -d out $(find src -name "*.java")
java -cp out com.flashsale.Main
```

**Expect:** lots of `[RESERVED]` / `[SOLD OUT]` / `[TELEMETRY]` / `[PAID]` lines, then:
```
Units reserved:    10
Payments approved: 10
Sold out (missed): 40
Stock remaining:   0
```
Exactly 10 sold — never 11 — no matter how many times you run it.

---

## 5. How to run everything

This machine has the Java runtime but not the compiler (`javac`). Use the single-file
version, which needs no compiler:
```bash
cd FlashSaleEngine
java FlashSaleEngineRun.java
```
To run the packaged enterprise version, install a JDK first:
```bash
sudo apt install default-jdk     # gives you javac
cd FlashSaleEngine
javac -d out $(find src -name "*.java")
java -cp out com.flashsale.Main
```

---

## 6. Cheat sheet (one line each)

| Tool | One-line meaning |
|---|---|
| `synchronized` | Only one thread in this code/object at a time. |
| `wait()` | Release the lock and sleep until notified. |
| `notifyAll()` | Wake all threads waiting on this monitor. |
| `ReentrantLock` | A manual lock with more control than `synchronized`. |
| `lock()` / `unlock()` | Take / release it (lock before `try`, unlock in `finally`). |
| `tryLock(timeout)` | Try to take the lock, give up after a wait. |
| `ExecutorService` | Manages a pool of worker threads. |
| `newFixedThreadPool(n)` | A reusable team of `n` threads. |
| `Callable<T>` | A task that returns `T` and may throw a checked exception. |
| `Future<T>` | A handle to a result that's still being computed. |
| `future.get()` | Wait for and read the result (or its `ExecutionException`). |
| `shutdown()` / `awaitTermination` / `shutdownNow` | Graceful two-phase pool shutdown. |
| `AutoCloseable` | Lets `try-with-resources` close it automatically. |
| `setDaemon(true)` | Background thread that won't block JVM exit (set before `start()`). |
| `Thread.State` | NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING, TERMINATED. |
| `volatile` | Make a field's latest value visible across threads. |
| `Thread.join()` | Wait for a thread to finish. |
| poison pill | A sentinel message that tells a consumer to stop. |
| `Thread.currentThread().interrupt()` | Restore the interrupt flag after catching `InterruptedException`. |

---

## 7. Where to go next

- **`ArrayBlockingQueue` / `LinkedBlockingQueue`** — the built-in version of Module 1.
- **`Semaphore`** — limit concurrent access to N permits.
- **`CompletableFuture`** — chain async steps (reserve → pay → notify) without blocking.
- **`ReadWriteLock` / `StampedLock`** — many readers, few writers.
- **`ThreadPoolExecutor`** (direct) — tune queue, rejection policy, keep-alive.

⚡ Great work building the Flash-Sale Engine!
