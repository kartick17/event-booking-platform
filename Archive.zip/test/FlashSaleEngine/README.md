# ⚡ Flash-Sale Order Processing Engine — Start Here

A lightweight, enterprise-style Java SE project to practice **core concurrency** hands-on.
Read it, run it, and practice it on any computer with Java. No Spring Boot, no Claude Code.

---

## What you need on the other system

1. **Java 17 or newer** (the code uses `record`). Check with:
   ```bash
   java -version
   ```
   - See a version number? You're ready to run the single-file version.
   - To compile the packaged version you also need `javac` (the full JDK):
     - **Ubuntu/Debian:** `sudo apt install default-jdk`
     - **Mac:** `brew install openjdk`
     - **Windows:** install OpenJDK / Temurin from https://adoptium.net
2. **Any text editor** (VS Code, Notepad++, etc.).

---

## What's in this folder

```
FlashSaleEngine/
├── README.md                 you are here
├── GUIDE.md                  full lesson: concepts, why each tool, all code, interview defenses
├── FlashSaleEngineRun.java   ONE file, runs with just `java` (no compiler needed)
├── src/com/flashsale/        enterprise packaged version (needs javac)
│   ├── model/Order.java
│   ├── ingestion/OrderIngestionBuffer.java        Module 1
│   ├── ingestion/OrderIngestionBufferDemo.java     (test for Module 1)
│   ├── inventory/FlashInventoryManager.java       Module 2
│   ├── dispatch/PaymentResult.java                Module 3
│   ├── dispatch/PaymentDispatcher.java
│   ├── telemetry/TelemetryDaemon.java             Module 4
│   └── Main.java                                   orchestration
└── practice/                 fill-in-the-blank versions + PRACTICE.md
```

---

## How to learn (suggested order)

1. **Read** `GUIDE.md` top to bottom — every module is explained in plain English, plus
   *why* each concurrency tool was chosen over the others.
2. **Run** the engine to see it work (commands below).
3. **Practice**: open `practice/PRACTICE.md` and fill in the blanks. Peek at `src/` if stuck.

---

## How to run the finished engine

**Easiest — single file, no compiler:**
```bash
cd FlashSaleEngine
java FlashSaleEngineRun.java
```

**Enterprise packaged version (needs `javac`):**
```bash
cd FlashSaleEngine
javac -d out $(find src -name "*.java")
java -cp out com.flashsale.Main
```

**Expect this summary every time (10 sold, never 11):**
```
Units reserved:    10
Payments approved: 10
Sold out (missed): 40
Stock remaining:   0
```

---

## Quick map: module → concept

| Module | Concept | Tool |
|---|---|---|
| 1 Order Ingestion Buffer | backpressure, bounded queue | `synchronized`, `wait`, `notifyAll` |
| 2 Flash Inventory Manager | atomic check-and-take, no oversell | `ReentrantLock` + try/finally |
| 3 Payment Dispatcher | thread reuse, async results | `ExecutorService`, `Callable`, `Future` |
| 4 Telemetry Daemon | non-blocking background monitor | daemon `Thread`, `Thread.State` |
| Main | clean shutdown of consumers | poison pill, `join()` |

Full details and the "explain it to an interviewer" lines are in `GUIDE.md`.
