// PRACTICE — MODULE 2: FLASH INVENTORY MANAGER 📦
// Topic: ReentrantLock, lock()/unlock(), try/finally
// Goal: reserve stock atomically so 50 buyers can never oversell 10 items.
// Fill in every // TODO. Answer key: ../src/com/flashsale/inventory/FlashInventoryManager.java
//
// Run when done:  java practice/FlashInventoryManager.java

// TODO: import the ReentrantLock class.
//       hint: java.util.concurrent.locks.ReentrantLock
// YOUR IMPORT HERE

public final class FlashInventoryManager {

    // TODO: create one ReentrantLock called "stockLock".
    // YOUR CODE HERE

    private int availableUnits;
    private int reservedUnits = 0;

    public FlashInventoryManager(int initialUnits) {
        if (initialUnits < 0) throw new IllegalArgumentException("initialUnits negative");
        this.availableUnits = initialUnits;
    }

    public boolean tryReserve(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("quantity must be positive");

        // TODO: lock the stockLock here, BEFORE the try block.
        // YOUR CODE HERE

        try {
            if (availableUnits >= quantity) {
                availableUnits -= quantity;
                reservedUnits  += quantity;
                return true;
            }
            return false;
        } finally {
            // TODO: ALWAYS unlock the stockLock here.
            // YOUR CODE HERE
        }
    }

    public int availableUnits() {
        // TODO: lock, return availableUnits in try, unlock in finally.
        // YOUR CODE HERE
        return availableUnits; // <- replace with the locked version
    }

    public int reservedUnits() {
        // TODO: lock, return reservedUnits in try, unlock in finally.
        // YOUR CODE HERE
        return reservedUnits;  // <- replace with the locked version
    }

    // ---- Test: 50 buyers rush 10 units; exactly 10 should win ----
    public static void main(String[] args) throws InterruptedException {
        FlashInventoryManager inventory = new FlashInventoryManager(10);
        Thread[] buyers = new Thread[50];
        for (int i = 0; i < 50; i++) {
            final int id = i + 1;
            buyers[i] = new Thread(() -> {
                if (inventory.tryReserve(1)) System.out.println("[WON]  Buyer-" + id);
                else System.out.println("[MISS] Buyer-" + id + " (sold out)");
            });
        }
        for (Thread b : buyers) b.start();
        for (Thread b : buyers) b.join();
        System.out.println("Reserved: " + inventory.reservedUnits() + " | Available: " + inventory.availableUnits());
        System.out.println("Expected -> Reserved: 10 | Available: 0");
    }
}
