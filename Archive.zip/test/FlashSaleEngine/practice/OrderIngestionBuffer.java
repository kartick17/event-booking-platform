// PRACTICE — MODULE 1: ORDER INGESTION BUFFER 🛒
// Topic: synchronized, wait(), notifyAll()  (a bounded blocking queue)
// Goal: producers wait when the buffer is full (backpressure); consumers wait when empty.
// Fill in every // TODO. Answer key: ../src/com/flashsale/ingestion/OrderIngestionBuffer.java
//
// Run when done:  java practice/OrderIngestionBuffer.java

import java.util.ArrayDeque;
import java.util.Deque;

public final class OrderIngestionBuffer {

    // A tiny inline order so this practice file runs on its own.
    record Order(String orderId) { }

    private final Deque<Order> pending = new ArrayDeque<>();
    private final int capacity;

    public OrderIngestionBuffer(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be positive");
        this.capacity = capacity;
    }

    // TODO: make this method synchronized.
    public void enqueue(Order order) throws InterruptedException {
        // TODO: use a WHILE loop: while the buffer is full (size == capacity), call wait();
        // YOUR CODE HERE

        pending.addLast(order);
        // TODO: wake any waiting consumer (one call).
        // YOUR CODE HERE
    }

    // TODO: make this method synchronized.
    public Order dequeue() throws InterruptedException {
        // TODO: while the buffer is empty, call wait();
        // YOUR CODE HERE

        Order next = pending.removeFirst();
        // TODO: wake any waiting producer (one call).
        // YOUR CODE HERE
        return next;
    }

    // TODO: make this method synchronized too (consistent locking for reads).
    public int size() { return pending.size(); }

    // ---- Test: capacity 3, fast producer, slow consumer ----
    public static void main(String[] args) throws InterruptedException {
        OrderIngestionBuffer buffer = new OrderIngestionBuffer(3);

        Thread producer = new Thread(() -> {
            for (int i = 1; i <= 6; i++) {
                try {
                    buffer.enqueue(new Order("ORD-" + i));
                    System.out.println("[INGEST] accepted ORD-" + i + " (size now " + buffer.size() + ")");
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        }, "ingest-thread");

        Thread consumer = new Thread(() -> {
            for (int i = 1; i <= 6; i++) {
                try {
                    Thread.sleep(300);
                    System.out.println("    [WORKER] processing " + buffer.dequeue().orderId());
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        }, "worker-thread");

        producer.start();
        consumer.start();
        producer.join();
        consumer.join();
        System.out.println("Done. Final size: " + buffer.size());
    }
}
