# 🏋️ Practice — Fill in the Blanks

Each file here is a module with the **key concurrency lines removed** and replaced with
`// TODO:` notes. Your job is to write the missing code. This is the fastest way to learn
*where* to write *what*.

These practice files are **self-contained** (default package, with a small `main`) so you
can run each one on its own with no compiler:

```bash
cd FlashSaleEngine
java practice/OrderIngestionBuffer.java
```

> Answer key: the matching files under `../src/com/flashsale/`. Try hard first, then peek.

---

## The topics to read (in order)

1. **Module 1 — OrderIngestionBuffer** → `synchronized`, `wait()`, `notifyAll()`
   - Goal: a bounded queue that makes producers wait when full (backpressure).
2. **Module 2 — FlashInventoryManager** → `ReentrantLock`, `lock()`/`unlock()`, `try/finally`
   - Goal: reserve stock atomically so 50 buyers can never oversell 10 items.
3. **Module 3 — PaymentDispatcher** → `ExecutorService`, `Callable`, `Future`, graceful shutdown
   - Goal: run slow payments on a fixed pool and return a `Future` result.
4. **Module 4 — TelemetryDaemon** → daemon `Thread`, `setDaemon(true)`, `Thread.State`
   - Goal: a background thread that logs worker states and never blocks shutdown.
5. **Orchestration (no practice file)** — build it yourself in a `Main`:
   - 5 workers loop `dequeue → tryReserve → submitPayment`; stop them with a poison pill;
     `join()` everything; collect `Future`s. Check against `../src/com/flashsale/Main.java`
     or `../FlashSaleEngineRun.java`.

---

## Self-check: did it work?

| Module | Correct behavior |
|---|---|
| 1 | Producer pauses when the buffer is full, resumes as the consumer drains it |
| 2 | Exactly 10 reservations succeed out of 50, never 11, never negative |
| 3 | Payments run on a few reused pool threads; every `Future` returns a result |
| 4 | Daemon prints worker states each interval, then the program exits on its own |

Good luck! ⚡
