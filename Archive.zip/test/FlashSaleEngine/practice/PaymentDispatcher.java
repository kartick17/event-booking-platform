// PRACTICE — MODULE 3: PAYMENT DISPATCHER 💳
// Topic: ExecutorService, Callable, Future, graceful shutdown
// Goal: run slow payments on a fixed pool of reusable threads and return a Future result.
// Fill in every // TODO. Answer key: ../src/com/flashsale/dispatch/PaymentDispatcher.java
//
// Run when done:  java practice/PaymentDispatcher.java

// TODO: import Callable, ExecutorService, Executors, Future, TimeUnit.
//       hint: all live in java.util.concurrent
// YOUR IMPORTS HERE

public final class PaymentDispatcher implements AutoCloseable {

    // tiny inline types so this file runs on its own
    record Order(String orderId, String buyerName, int quantity) { }
    record PaymentResult(String orderId, boolean approved, String transactionId, String detail) { }

    // TODO: declare the pool field, type ExecutorService, name it "paymentPool".
    // YOUR CODE HERE

    public PaymentDispatcher(int workerThreads) {
        if (workerThreads <= 0) throw new IllegalArgumentException("workerThreads must be positive");
        // TODO: create a fixed thread pool of "workerThreads" threads.
        //       hint: Executors.newFixedThreadPool(workerThreads)
        // YOUR CODE HERE
    }

    public Future<PaymentResult> submitPayment(Order order) {
        // TODO: build a Callable<PaymentResult> that calls processPayment(order),
        //       submit it to the pool, and return the Future.
        // YOUR CODE HERE
        return null; // <- replace
    }

    private PaymentResult processPayment(Order order) throws InterruptedException {
        Thread.sleep(200); // pretend gateway latency
        return new PaymentResult(order.orderId(), true, "TXN-" + order.orderId(),
                "charged " + order.buyerName() + " for " + order.quantity() + " unit(s)");
    }

    @Override
    public void close() {
        // TODO: graceful shutdown ->
        //   1) paymentPool.shutdown();
        //   2) if (!paymentPool.awaitTermination(10, TimeUnit.SECONDS)) paymentPool.shutdownNow();
        //   3) on InterruptedException: shutdownNow() and restore the interrupt flag.
        // YOUR CODE HERE
    }

    // ---- Test: submit 6 payments on a pool of 3 threads ----
    public static void main(String[] args) throws Exception {
        try (PaymentDispatcher dispatcher = new PaymentDispatcher(3)) {
            java.util.List<Future<PaymentResult>> futures = new java.util.ArrayList<>();
            for (int i = 1; i <= 6; i++) {
                futures.add(dispatcher.submitPayment(new Order("ORD-" + i, "Buyer-" + i, 1)));
            }
            for (Future<PaymentResult> f : futures) {
                PaymentResult r = f.get();
                System.out.println("[PAID] " + r.transactionId() + " — " + r.detail());
            }
        }
        System.out.println("All payments done; pool shut down cleanly.");
    }
}
