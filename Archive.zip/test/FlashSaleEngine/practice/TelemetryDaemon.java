// PRACTICE — MODULE 4: TELEMETRY DAEMON 📊
// Topic: daemon Thread, setDaemon(true) (before start()), volatile, Thread.State
// Goal: a background thread that logs worker states and never blocks shutdown.
// Fill in every // TODO. Answer key: ../src/com/flashsale/telemetry/TelemetryDaemon.java
//
// Run when done:  java practice/TelemetryDaemon.java

import java.util.List;

public final class TelemetryDaemon {

    private final Thread daemonThread;

    // TODO: declare a boolean field "running" that starts true.
    //       hint: it is read/written by two threads -> make it volatile.
    // YOUR CODE HERE

    public TelemetryDaemon(List<Thread> workers, long intervalMillis) {
        if (intervalMillis <= 0) throw new IllegalArgumentException("intervalMillis must be positive");
        this.daemonThread = new Thread(() -> pollLoop(workers, intervalMillis), "telemetry-daemon");

        // TODO: mark daemonThread as a daemon. IMPORTANT: must be BEFORE start().
        // YOUR CODE HERE
    }

    public void start() { daemonThread.start(); }

    public void stop() {
        // TODO: set running = false, then interrupt the daemon thread to wake it.
        // YOUR CODE HERE
    }

    private void pollLoop(List<Thread> workers, long intervalMillis) {
        // TODO: loop while running:
        //   - call logSnapshot(workers)
        //   - Thread.sleep(intervalMillis)
        //   - on InterruptedException: restore the interrupt flag and break out of the loop.
        // YOUR CODE HERE
    }

    private void logSnapshot(List<Thread> workers) {
        StringBuilder s = new StringBuilder("[TELEMETRY] workers=[");
        for (int i = 0; i < workers.size(); i++) {
            Thread w = workers.get(i);
            // Thread.getState() returns NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING, TERMINATED
            s.append(w.getName()).append(':').append(w.getState());
            if (i < workers.size() - 1) s.append(", ");
        }
        s.append(']');
        System.out.println(s);
    }

    // ---- Test: watch two sleeping workers, then stop ----
    public static void main(String[] args) throws InterruptedException {
        Thread w1 = new Thread(() -> sleepQuietly(3000), "order-worker-1");
        Thread w2 = new Thread(() -> sleepQuietly(3000), "order-worker-2");
        w1.start();
        w2.start();

        TelemetryDaemon telemetry = new TelemetryDaemon(List.of(w1, w2), 500);
        telemetry.start();

        w1.join();
        w2.join();
        telemetry.stop();
        System.out.println("Workers finished; daemon stopped.");
    }

    private static void sleepQuietly(long millis) {
        try { Thread.sleep(millis); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
