package com.flashsale;

import com.flashsale.dispatch.PaymentDispatcher;
import com.flashsale.dispatch.PaymentResult;
import com.flashsale.ingestion.OrderIngestionBuffer;
import com.flashsale.inventory.FlashInventoryManager;
import com.flashsale.model.Order;
import com.flashsale.telemetry.TelemetryDaemon;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * Orchestration entry point.
 *
 * <p>Simulates a flash sale: 50 concurrent buyers fight over 10 items.
 * It wires the four modules into one pipeline:</p>
 *
 * <pre>
 *   buyers -> Module 1 buffer -> worker threads -> Module 2 inventory
 *                                                -> Module 3 payments (Future)
 *   Module 4 telemetry watches everything in the background
 * </pre>
 */
public final class Main {

    private static final int TOTAL_BUYERS = 50;
    private static final int TOTAL_STOCK = 10;
    private static final int BUFFER_CAPACITY = 20;
    private static final int WORKER_THREADS = 5;
    private static final int PAYMENT_THREADS = 4;

    /**
     * Sentinel order. We compare it by reference (==) to tell a worker to stop.
     * This is the "poison pill" pattern for shutting down consumers cleanly.
     */
    private static final Order POISON_PILL = new Order("POISON", "system", 1);

    public static void main(String[] args) throws InterruptedException {

        OrderIngestionBuffer buffer = new OrderIngestionBuffer(BUFFER_CAPACITY);
        FlashInventoryManager inventory = new FlashInventoryManager(TOTAL_STOCK);

        // Results from every approved payment, collected across threads.
        List<Future<PaymentResult>> paymentReceipts = Collections.synchronizedList(new ArrayList<>());

        // try-with-resources guarantees the payment pool is shut down (no leaks).
        try (PaymentDispatcher dispatcher = new PaymentDispatcher(PAYMENT_THREADS)) {

            // --- Start the worker threads (consumers of the buffer) ---
            List<Thread> workers = new ArrayList<>();
            for (int i = 1; i <= WORKER_THREADS; i++) {
                Thread worker = new Thread(
                        () -> runWorker(buffer, inventory, dispatcher, paymentReceipts),
                        "order-worker-" + i);
                workers.add(worker);
                worker.start();
            }

            // --- Module 4: start telemetry watching those workers ---
            TelemetryDaemon telemetry = new TelemetryDaemon(buffer, inventory, workers, 500);
            telemetry.start();

            // --- Fire 50 concurrent buyers at the buffer ---
            List<Thread> buyers = new ArrayList<>();
            for (int i = 1; i <= TOTAL_BUYERS; i++) {
                Order order = new Order("ORD-" + i, "Buyer-" + i, 1);
                Thread buyer = new Thread(() -> enqueueOrder(buffer, order), "buyer-" + i);
                buyers.add(buyer);
                buyer.start();
            }
            for (Thread buyer : buyers) {
                buyer.join(); // wait until every buyer has handed in their order
            }

            // --- Tell each worker to stop, one poison pill per worker ---
            for (int i = 0; i < WORKER_THREADS; i++) {
                enqueueOrder(buffer, POISON_PILL);
            }
            for (Thread worker : workers) {
                worker.join();
            }

            telemetry.stop();

            // --- Collect the payment receipts ---
            int approved = collectApprovedPayments(paymentReceipts);

            System.out.println("\n================ FLASH SALE SUMMARY ================");
            System.out.println("Buyers:            " + TOTAL_BUYERS);
            System.out.println("Stock at start:    " + TOTAL_STOCK);
            System.out.println("Units reserved:    " + inventory.reservedUnits());
            System.out.println("Payments approved: " + approved);
            System.out.println("Sold out (missed): " + (TOTAL_BUYERS - inventory.reservedUnits()));
            System.out.println("Stock remaining:   " + inventory.availableUnits());
            System.out.println("===================================================");
        } // dispatcher.close() runs here -> pool shut down gracefully
    }

    /** One worker: pull orders, reserve stock, and dispatch payment for winners. */
    private static void runWorker(OrderIngestionBuffer buffer,
                                  FlashInventoryManager inventory,
                                  PaymentDispatcher dispatcher,
                                  List<Future<PaymentResult>> receipts) {
        while (true) {
            try {
                Order order = buffer.dequeue();
                if (order == POISON_PILL) {
                    return; // shutdown signal — leave the loop, no thread leak
                }
                if (inventory.tryReserve(order.quantity())) {
                    System.out.println("[RESERVED] " + order.orderId() + " by " + order.buyerName());
                    receipts.add(dispatcher.submitPayment(order));
                } else {
                    System.out.println("[SOLD OUT] " + order.orderId() + " — no stock for " + order.buyerName());
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    private static void enqueueOrder(OrderIngestionBuffer buffer, Order order) {
        try {
            buffer.enqueue(order);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Read every Future, counting approvals. Handles each failure mode specifically. */
    private static int collectApprovedPayments(List<Future<PaymentResult>> receipts) {
        int approved = 0;
        for (Future<PaymentResult> receipt : receipts) {
            try {
                PaymentResult result = receipt.get(); // waits for this payment to finish
                if (result.approved()) {
                    approved++;
                    System.out.println("[PAID] " + result.transactionId() + " — " + result.detail());
                }
            } catch (ExecutionException e) {
                // The payment task threw — inspect the real cause, don't hide it.
                System.out.println("[PAYMENT FAILED] " + e.getCause());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return approved;
    }
}
