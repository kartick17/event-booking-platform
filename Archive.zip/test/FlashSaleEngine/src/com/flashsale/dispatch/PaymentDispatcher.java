package com.flashsale.dispatch;

import com.flashsale.model.Order;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MODULE 3 — Payment & Notification Dispatcher.
 *
 * <p>Reserving stock is fast and local. Charging a card is slow and talks to an
 * external gateway. We must not block our order workers on that latency, and we
 * must not spawn a fresh thread per payment (50 buyers = 50 threads = trouble).</p>
 *
 * <p>So payments run on a fixed pool of reusable threads. Each payment is a
 * {@link Callable} (it returns a value and may throw a checked exception), and
 * {@code submit} hands back a {@link Future} the caller collects later.</p>
 *
 * <p>Implements {@link AutoCloseable} so it can be used in try-with-resources
 * and shut down cleanly — no leaked threads.</p>
 */
public final class PaymentDispatcher implements AutoCloseable {

    private final ExecutorService paymentPool;

    public PaymentDispatcher(int workerThreads) {
        if (workerThreads <= 0) {
            throw new IllegalArgumentException("workerThreads must be positive, was " + workerThreads);
        }
        this.paymentPool = Executors.newFixedThreadPool(workerThreads, namedThreadFactory("payment-worker"));
    }

    /**
     * Queue a payment to run on the pool.
     *
     * @return a {@link Future} that will hold the {@link PaymentResult}. Calling
     *         {@code get()} on it blocks only the caller, not the pool.
     */
    public Future<PaymentResult> submitPayment(Order order) {
        Callable<PaymentResult> paymentTask = () -> processPayment(order);
        return paymentPool.submit(paymentTask);
    }

    /** Pretend to call an external payment gateway. */
    private PaymentResult processPayment(Order order) throws InterruptedException {
        Thread.sleep(200); // network latency to the gateway
        String transactionId = "TXN-" + order.orderId();
        return new PaymentResult(order.orderId(), true, transactionId,
                "charged " + order.buyerName() + " for " + order.quantity() + " unit(s)");
    }

    /**
     * Graceful two-phase shutdown: stop accepting work, let in-flight payments
     * finish, then force-stop if they overrun. This is how you avoid thread leaks.
     */
    @Override
    public void close() {
        paymentPool.shutdown(); // stop accepting new tasks; let running ones finish
        try {
            if (!paymentPool.awaitTermination(10, TimeUnit.SECONDS)) {
                paymentPool.shutdownNow(); // overran the grace period -> interrupt them
            }
        } catch (InterruptedException e) {
            paymentPool.shutdownNow();
            Thread.currentThread().interrupt(); // restore the flag for callers up the stack
        }
    }

    /** Names threads so the telemetry module can report them clearly. */
    private static ThreadFactory namedThreadFactory(String prefix) {
        AtomicInteger sequence = new AtomicInteger(1);
        return runnable -> new Thread(runnable, prefix + "-" + sequence.getAndIncrement());
    }
}
