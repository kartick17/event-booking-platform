package com.flashsale.dispatch;

/**
 * Immutable result of trying to charge a buyer.
 *
 * @param orderId       which order this result belongs to
 * @param approved      true if the payment gateway approved the charge
 * @param transactionId gateway transaction id (null if declined)
 * @param detail        human-readable note for logs
 */
public record PaymentResult(String orderId, boolean approved, String transactionId, String detail) {
}
