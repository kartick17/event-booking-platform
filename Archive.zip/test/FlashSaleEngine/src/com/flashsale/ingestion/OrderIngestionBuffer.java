package com.flashsale.ingestion;

import com.flashsale.model.Order;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * MODULE 1 — Order Ingestion Buffer.
 *
 * <p>A custom <b>bounded</b> blocking queue. It sits between the buyers
 * (producers) and the order workers (consumers). Its one job is
 * <b>backpressure</b>: when traffic spikes, it holds a fixed number of
 * orders and makes producers wait instead of letting memory grow without
 * limit.</p>
 *
 * <p>Built from the ground up with the intrinsic monitor ({@code synchronized}
 * + {@code wait()} / {@code notifyAll()}) so the thread mechanics are visible,
 * rather than delegating to {@code java.util.concurrent.ArrayBlockingQueue}.</p>
 *
 * <p>Thread-safety: every method that touches {@code pending} is
 * {@code synchronized} on {@code this}, so all reads and writes happen under
 * the same lock.</p>
 */
public final class OrderIngestionBuffer {

    /** Orders waiting to be processed. Guarded by {@code this}. */
    private final Deque<Order> pending = new ArrayDeque<>();

    /** Hard cap on buffered orders — the memory safety limit. */
    private final int capacity;

    public OrderIngestionBuffer(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("capacity must be positive, was " + capacity);
        }
        this.capacity = capacity;
    }

    /**
     * Add an order, waiting if the buffer is full (this is the backpressure).
     *
     * @throws InterruptedException if the thread is interrupted while waiting.
     *         We let it propagate instead of swallowing it — the caller decides
     *         how to stop cleanly.
     */
    public synchronized void enqueue(Order order) throws InterruptedException {
        // WHILE, not IF: after waking we must re-check, because another
        // producer may have refilled the buffer before we got the lock back.
        while (pending.size() == capacity) {
            wait(); // release the lock and sleep until a consumer makes room
        }
        pending.addLast(order);
        notifyAll(); // a consumer waiting on an empty buffer can now proceed
    }

    /**
     * Take the next order, waiting if the buffer is empty.
     *
     * @throws InterruptedException if interrupted while waiting (propagated).
     */
    public synchronized Order dequeue() throws InterruptedException {
        while (pending.isEmpty()) {
            wait(); // nothing to do yet — sleep until a producer adds work
        }
        Order next = pending.removeFirst();
        notifyAll(); // a producer waiting on a full buffer can now proceed
        return next;
    }

    /** Current number of buffered orders. Useful for telemetry (Module 4). */
    public synchronized int size() {
        return pending.size();
    }
}
