package com.flashsale.ingestion;

import com.flashsale.model.Order;

/**
 * Manual test harness for MODULE 1 only.
 *
 * <p>One fast producer pushes 6 orders into a buffer of capacity 3, while a
 * slow consumer drains them. You should see the producer pause (backpressure)
 * once the buffer is full, then resume as the consumer frees space.</p>
 */
public final class OrderIngestionBufferDemo {

    public static void main(String[] args) throws InterruptedException {
        OrderIngestionBuffer buffer = new OrderIngestionBuffer(3);

        Thread ingest = new Thread(() -> {
            for (int i = 1; i <= 6; i++) {
                try {
                    Order order = new Order("ORD-" + i, "Buyer-" + i, 1);
                    buffer.enqueue(order); // blocks here when the buffer is full
                    System.out.println("[INGEST] accepted " + order.orderId()
                            + " (buffer size now " + buffer.size() + ")");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); // restore the flag, then stop
                    return;
                }
            }
        }, "ingest-thread");

        Thread worker = new Thread(() -> {
            for (int i = 1; i <= 6; i++) {
                try {
                    Thread.sleep(300); // a slow worker, so the buffer fills up
                    Order order = buffer.dequeue();
                    System.out.println("    [WORKER] processing " + order.orderId());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }, "worker-thread");

        ingest.start();
        worker.start();
        ingest.join();   // no thread leaks: wait for both to finish
        worker.join();
        System.out.println("Done. Final buffer size: " + buffer.size());
    }
}
