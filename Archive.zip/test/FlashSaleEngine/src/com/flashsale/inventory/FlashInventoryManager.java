package com.flashsale.inventory;

import java.util.concurrent.locks.ReentrantLock;

/**
 * MODULE 2 — Flash Inventory Manager.
 *
 * <p>Holds the limited stock for the flash sale and hands out units to buyers.
 * Its single guarantee: <b>never oversell</b>. With 10 units and 50 buyers,
 * exactly 10 reservations succeed — no more, even though every buyer checks and
 * decrements at the same time.</p>
 *
 * <p>The check ("is there stock?") and the act ("take a unit") must happen as
 * one indivisible step. That read-modify-write is the classic race condition;
 * a lock makes it atomic.</p>
 */
public final class FlashInventoryManager {

    /** Explicit lock guarding all stock fields. */
    private final ReentrantLock stockLock = new ReentrantLock();

    private int availableUnits;     // guarded by stockLock
    private int reservedUnits = 0;  // guarded by stockLock

    public FlashInventoryManager(int initialUnits) {
        if (initialUnits < 0) {
            throw new IllegalArgumentException("initialUnits must not be negative, was " + initialUnits);
        }
        this.availableUnits = initialUnits;
    }

    /**
     * Atomically reserve {@code quantity} units if enough are in stock.
     *
     * @return {@code true} if reserved, {@code false} if there was not enough
     *         stock (a clean "sold out" — not an exception).
     */
    public boolean tryReserve(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("quantity must be positive, was " + quantity);
        }
        stockLock.lock();   // acquire the lock OUTSIDE the try (see Interview Defense)
        try {
            if (availableUnits >= quantity) {
                availableUnits -= quantity;
                reservedUnits += quantity;
                return true;
            }
            return false;
        } finally {
            stockLock.unlock(); // ALWAYS release, even if something above throws
        }
    }

    public int availableUnits() {
        stockLock.lock();
        try {
            return availableUnits;
        } finally {
            stockLock.unlock();
        }
    }

    public int reservedUnits() {
        stockLock.lock();
        try {
            return reservedUnits;
        } finally {
            stockLock.unlock();
        }
    }
}
