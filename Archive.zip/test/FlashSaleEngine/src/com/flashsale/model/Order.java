package com.flashsale.model;

/**
 * An immutable order placed by a buyer during the flash sale.
 *
 * <p>Real-world note: orders flow through the system as small, read-only
 * messages. Making them immutable (a {@code record}) means many threads can
 * read the same order safely without locking — there is no shared state to
 * corrupt.</p>
 *
 * @param orderId   unique id for this order (e.g. "ORD-42")
 * @param buyerName who placed it
 * @param quantity  how many items they want (must be positive)
 */
public record Order(String orderId, String buyerName, int quantity) {

    // Compact constructor: validate at the edge so a bad order can never
    // enter the pipeline. Fail fast with a clear, specific exception.
    public Order {
        if (orderId == null || orderId.isBlank()) {
            throw new IllegalArgumentException("orderId must not be blank");
        }
        if (buyerName == null || buyerName.isBlank()) {
            throw new IllegalArgumentException("buyerName must not be blank");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("quantity must be positive, was " + quantity);
        }
    }
}
