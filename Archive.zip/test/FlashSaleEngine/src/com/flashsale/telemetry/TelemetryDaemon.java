package com.flashsale.telemetry;

import com.flashsale.ingestion.OrderIngestionBuffer;
import com.flashsale.inventory.FlashInventoryManager;

import java.util.List;

/**
 * MODULE 4 — Live Telemetry Metrics Daemon.
 *
 * <p>A single, long-lived background thread that polls the system once per
 * interval and logs a snapshot: buffer depth, stock left, and the lifecycle
 * {@link Thread.State} of each worker thread.</p>
 *
 * <p>It is a <b>daemon</b> thread: the JVM does not wait for it on shutdown.
 * Monitoring must never keep the application alive — when the real work ends,
 * the daemon disappears on its own.</p>
 */
public final class TelemetryDaemon {

    private final Thread daemonThread;

    /** Visible to the polling loop and the stopper; volatile for cross-thread reads. */
    private volatile boolean running = true;

    public TelemetryDaemon(OrderIngestionBuffer buffer,
                           FlashInventoryManager inventory,
                           List<Thread> workers,
                           long intervalMillis) {
        if (intervalMillis <= 0) {
            throw new IllegalArgumentException("intervalMillis must be positive, was " + intervalMillis);
        }
        this.daemonThread = new Thread(
                () -> pollLoop(buffer, inventory, workers, intervalMillis),
                "telemetry-daemon");
        this.daemonThread.setDaemon(true); // MUST be set before start()
    }

    public void start() {
        daemonThread.start();
    }

    /** Ask the daemon to stop and wake it if it is sleeping. */
    public void stop() {
        running = false;
        daemonThread.interrupt();
    }

    private void pollLoop(OrderIngestionBuffer buffer,
                          FlashInventoryManager inventory,
                          List<Thread> workers,
                          long intervalMillis) {
        while (running) {
            try {
                logSnapshot(buffer, inventory, workers);
                Thread.sleep(intervalMillis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // honor interruption...
                break;                              // ...and leave the loop cleanly
            }
        }
    }

    private void logSnapshot(OrderIngestionBuffer buffer,
                             FlashInventoryManager inventory,
                             List<Thread> workers) {
        StringBuilder snapshot = new StringBuilder("[TELEMETRY] ")
                .append("buffer=").append(buffer.size())
                .append(" | available=").append(inventory.availableUnits())
                .append(" | reserved=").append(inventory.reservedUnits())
                .append(" | workers=[");

        for (int i = 0; i < workers.size(); i++) {
            Thread worker = workers.get(i);
            snapshot.append(worker.getName()).append(':').append(worker.getState());
            if (i < workers.size() - 1) {
                snapshot.append(", ");
            }
        }
        snapshot.append(']');
        System.out.println(snapshot);
    }
}
