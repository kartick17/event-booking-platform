# 🔌 Home Appliances — Full Learning Guide (Basic)

## 1. What is this project?
A set of **home appliances**. This one picture explains abstraction:

- **Abstraction** = show **what**, hide **how**. You press "run"; you don't see
  the wiring.
- An **abstract class** is a shared **chassis** — a half-built blueprint that can
  hold common parts (a name, a power switch) and leave the real job unfinished.
- An **interface** is a **plug/switch standard** — a list of buttons (abilities)
  that any device can support, related or not.

## 2. What you will learn
| Need | Plain-English meaning | Tool | Step |
|------|----------------------|------|------|
| Name a job without doing it | unfinished blueprint | `abstract class` + abstract method | 1 |
| Share parts across types | common fields + finished code | abstract class state/constructor | 2 |
| Give many types one ability | a contract to fulfil | `interface` + `implements` | 3 |
| Add code to a contract | shared/util/helper methods | `default` / `static` / `private` | 4 |
| Choose between the two | is-a-kind vs can-do | abstract class vs interface | 5 |

## 3. The big picture
```
   abstract class Appliance          interface Openable
   - name, power (STATE)             - open()   (just the ability)
   - plugIn()  (shared CODE)               ^
   - run()     (abstract)                  | implements (any type)
        ^                                   |
        | extends (ONE only)        +-------+--------+
   Dishwasher  -------------------- implements ---- Door
   (is an Appliance AND Openable)              (only Openable)

   Rule: extend ONE class, implement MANY interfaces.
```

## 4. Project files
```
Step1_AbstractClass.java          (NEW FILE)
Step2_AbstractClassShared.java    (NEW FILE)
Step3_Interface.java              (NEW FILE)
Step4_DefaultStaticMethods.java   (NEW FILE)
Step5_WhenToUseWhich.java         (NEW FILE)
```

---

# STEP 1 — What abstraction is (abstract class)

### Concept (simple)
Abstraction shows what a thing does and hides how. An `abstract` class is a
half-built blueprint: it can declare a job (`abstract void run()`) with no body.
You can't do `new Appliance()` — only a real subclass. You code to `Appliance`
and never care how each works.

### Code — `Step1_AbstractClass.java` (NEW FILE)
```java
abstract static class Appliance {
    abstract void run();             // WHAT, no HOW
}
class WashingMachine extends Appliance { void run() { ... wash ... } }
Appliance a = new WashingMachine();  // hold the abstract type
a.run();                             // child decides the behaviour
```

### How to test
`java Step1_AbstractClass.java` → `washing clothes...`, `heating food...`.

### Interview summary
"An abstract class can't be instantiated and can declare abstract methods that
subclasses must implement. It models a base type that's incomplete on its own."

---

# STEP 2 — Abstract class with shared state + code

### Concept (simple)
The strength of an abstract class: it holds shared state (a name, a power flag),
a constructor, and finished methods (`plugIn()`), while leaving `run()` abstract.
It mixes done and to-be-done code in one place.

### Code — `Step2_AbstractClassShared.java` (NEW FILE)
```java
abstract static class Appliance {
    private final String name;
    Appliance(String name) { this.name = name; }   // abstract classes CAN have constructors
    void plugIn() { System.out.println(name + " is now powered on"); }  // shared, finished
    abstract void run();                            // unfinished
}
class Kettle extends Appliance { Kettle() { super("Kettle"); } void run() { ... } }
```

### How to test
`java Step2_AbstractClassShared.java` → each device powers on, then runs its own way.

### Interview summary
"Abstract classes can have fields, constructors, and concrete methods. I use one
when subtypes share state and an implementation, not just a contract."

---

# STEP 3 — Interface: a pure contract

### Concept (simple)
An interface lists abilities with no state (classic form). A class fulfils it
with `implements`, and a class can implement many interfaces — Java's safe form
of multiple inheritance. Code to the interface; treat every implementer the same.

### Code — `Step3_Interface.java` (NEW FILE)
```java
interface Switchable { void on(); void off(); }
interface Timer      { void schedule(int minutes); }
class Fan implements Switchable, Timer { ... }     // many interfaces at once
static void pressButton(Switchable d) { d.on(); d.off(); }   // works for any implementer
```

### How to test
`java Step3_Interface.java` → fan and lamp both on/off; `fan is Timer? true`, `lamp is Timer? false`.

### Interview summary
"An interface is a capability contract. A class can implement many, so I use
interfaces to give unrelated types a shared ability with no shared base."

---

# STEP 4 — Interfaces with code: default, static, private

### Concept (simple)
Since Java 8, interfaces can carry code. A `default` method is shared behaviour
implementers get free and may override. A `static` method is a helper on the
interface itself. A `private` method (Java 9) is a helper used only by the
interface's own default methods.

### Code — `Step4_DefaultStaticMethods.java` (NEW FILE)
```java
interface Switchable {
    void on(); void off();
    default void toggle(boolean turnOn) { log("toggle"); if (turnOn) on(); else off(); }
    private void log(String m) { System.out.println("[switchable] " + m); }
    static Switchable dummy() { return new Switchable() { ... }; }
}
```

### How to test
`java Step4_DefaultStaticMethods.java` → `Lamp` gets `toggle()` free; `Switchable.dummy()` runs.

### Interview summary
"Default methods add behaviour to an interface without breaking existing
implementers. Static methods hold factory/util helpers; private methods share
code between defaults."

---

# STEP 5 — Abstract class vs interface (which to use)

### Concept (simple)
Abstract class = a shared kind of thing with state + code ("is a kind of").
Interface = an ability unrelated types can have ("can do"). A class extends one
class but implements many interfaces, so a `Dishwasher` extends `Appliance` and
implements `Openable`, while a `Door` is just `Openable`.

### Side-by-side
| | Abstract class | Interface |
|--|---------------|-----------|
| Models | "is a kind of" | "can do" |
| State (fields) | yes | no (only constants) |
| Constructor | yes | no |
| How many per class | ONE (`extends`) | MANY (`implements`) |
| Code allowed | yes | `default`/`static`/`private` only |
| Use when | subtypes share state + base code | spread an ability across unrelated types |

### Code — `Step5_WhenToUseWhich.java` (NEW FILE)
```java
abstract static class Appliance { ... }       // shared kind
interface Openable { void open(); }           // ability
class Dishwasher extends Appliance implements Openable { ... }
class Door implements Openable { ... }        // not an appliance, still Openable
```

### How to test
`java Step5_WhenToUseWhich.java` → dishwasher runs + opens; door just opens.

### Interview summary
"Abstract class for shared state and a base implementation; interface for a
capability across unrelated types. When in doubt prefer interfaces — a class gets
only one parent, so spend it carefully."

---

## How to run everything
```bash
java Step1_AbstractClass.java
java Step2_AbstractClassShared.java
java Step3_Interface.java
java Step4_DefaultStaticMethods.java
java Step5_WhenToUseWhich.java
```

## Cheat sheet (one line per tool)
| Tool | What it does |
|------|--------------|
| abstraction | show what, hide how |
| `abstract class` | half-built blueprint; can't be instantiated |
| abstract method | a named job with no body; subclasses must fill it |
| abstract class state/constructor | share fields + setup across subtypes |
| concrete method (in abstract class) | finished shared code subtypes inherit |
| `interface` | a pure contract of abilities |
| `implements` | a class promises to fulfil an interface (many allowed) |
| `default` method | shared code inside an interface; overridable |
| `static` method (interface) | helper/factory called on the interface itself |
| `private` method (interface) | helper used only by the interface's defaults |
| `extends` one / `implements` many | the core "which to use" rule |

## Where to go next
1. **The diamond problem** — two interfaces with the same default method (interview pack).
2. **Functional interfaces + lambdas** — one-method interfaces written as `() -> ...`.
3. **Template method pattern** — an abstract class that fixes the steps of an algorithm.
4. **`sealed` interfaces/classes** — limit who can implement/extend.
5. The **interview pack** of this topic — a pluggable notification system.
