# 🔌 Home Appliances — Abstraction, Abstract Class & Interface (Basic) — Start Here

Learn **abstraction** and the two tools that provide it — **abstract classes**
and **interfaces** — with one picture: **home appliances**. You press "run"
without knowing the wiring. A shared appliance chassis (abstract class) vs a
plug/switch standard (interface).

Abstraction = show **what** a thing does, hide **how** it does it.

## What you need on the other system
1. **Java 9+** (tested on Java 17; uses private interface methods from Java 9).
   Check with: `java -version`
   - **No compiler needed.** Every file runs with `java File.java`.
   - Full JDK (`javac`) only if you want to compile: Ubuntu/Debian
     `sudo apt install default-jdk`, Mac `brew install openjdk`,
     Windows: Temurin from https://adoptium.net
2. Any text editor.

## What's in this folder
```
abstraction-basic/
├── README.md                          you are here
├── GUIDE.md                           full lesson + cheat sheet
├── Step1_AbstractClass.java           the idea + a bare abstract class
├── Step2_AbstractClassShared.java     abstract class with state + shared code
├── Step3_Interface.java               interface: a pure contract, implement many
├── Step4_DefaultStaticMethods.java    default / static / private interface methods
├── Step5_WhenToUseWhich.java          abstract class vs interface — the decision
└── practice/
    ├── PRACTICE.md
    └── Step*_Practice.java            fill-in-the-blank versions
```

## How to learn (suggested order)
1. Read **GUIDE.md** top to bottom.
2. Run each finished file and match the output.
3. Practice: fill in the `practice/` blanks; peek at the finished file when stuck.

## How to run
```bash
java Step1_AbstractClass.java
java Step2_AbstractClassShared.java
java Step3_Interface.java
java Step4_DefaultStaticMethods.java
java Step5_WhenToUseWhich.java
```

## Quick map: step → concept → tool
| Step | Concept | Tool |
|------|---------|------|
| 1 | Show what, hide how | `abstract class`, `abstract` method |
| 2 | Share state + finished code | abstract class fields, constructor, concrete methods |
| 3 | A contract many types can fulfil | `interface`, `implements` (many) |
| 4 | Put code in an interface | `default`, `static`, `private` methods |
| 5 | Choose the right tool | abstract class vs interface |
