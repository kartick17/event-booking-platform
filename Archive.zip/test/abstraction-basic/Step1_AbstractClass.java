// STEP 1 — What is abstraction? Start with an ABSTRACT CLASS
// Analogy: HOME APPLIANCES.
//   Abstraction = show WHAT a thing does, hide HOW it does it.
//   You press "run" on an appliance. A washing machine washes, a microwave
//   heats — you don't care about the wiring inside. The word "Appliance" is the
//   idea; each real appliance fills in the "how".
//
//   An ABSTRACT CLASS is a half-built blueprint. It can name a job (run) without
//   doing it. You can't build a bare Appliance — only a real one.
//
// Run with:  java Step1_AbstractClass.java

public class Step1_AbstractClass {

    // abstract = unfinished. You cannot do `new Appliance()`.
    abstract static class Appliance {
        // An abstract method: the WHAT, with no HOW. Children must fill it in.
        abstract void run();
    }

    static class WashingMachine extends Appliance {
        @Override
        void run() {
            System.out.println("washing clothes...");
        }
    }

    static class Microwave extends Appliance {
        @Override
        void run() {
            System.out.println("heating food...");
        }
    }

    public static void main(String[] args) {
        // We hold them as the ABSTRACT type, but each runs its own way.
        Appliance a = new WashingMachine();
        Appliance b = new Microwave();

        a.run();    // washing clothes...
        b.run();    // heating food...

        // Appliance bare = new Appliance();  // <-- would NOT compile: it's abstract
        System.out.println("We coded to 'Appliance' and never cared HOW each works.");
    }
}
