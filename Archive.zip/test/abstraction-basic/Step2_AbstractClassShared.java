// STEP 2 — Abstract class with SHARED parts (state + finished code)
// Analogy: every appliance shares a chassis: a name and a power switch.
//   The abstract class builds those common parts ONCE (a constructor, fields,
//   and a finished plugIn() method). It still leaves run() unfinished for each
//   child. So an abstract class can mix FINISHED and UNFINISHED methods.
//
// This is the key strength of an abstract class: shared state + shared code.
//
// Run with:  java Step2_AbstractClassShared.java

public class Step2_AbstractClassShared {

    abstract static class Appliance {
        private final String name;     // shared STATE
        private boolean on;

        // An abstract class CAN have a constructor (run by its children via super).
        Appliance(String name) {
            this.name = name;
        }

        // FINISHED, shared method — every appliance gets this for free.
        void plugIn() {
            on = true;
            System.out.println(name + " is now powered on");
        }

        String name() {
            return name;
        }

        // UNFINISHED — each appliance does its own job.
        abstract void run();
    }

    static class Kettle extends Appliance {
        Kettle() {
            super("Kettle");           // call the shared constructor
        }
        @Override
        void run() {
            System.out.println(name() + " is boiling water");
        }
    }

    static class Fan extends Appliance {
        Fan() {
            super("Fan");
        }
        @Override
        void run() {
            System.out.println(name() + " is spinning");
        }
    }

    public static void main(String[] args) {
        Appliance[] devices = { new Kettle(), new Fan() };
        for (Appliance d : devices) {
            d.plugIn();    // shared code from the abstract class
            d.run();       // each child's own code
        }
    }
}
