// STEP 3 — Interface: a pure CONTRACT of abilities
// Analogy: a plug/switch STANDARD. Anything that fits the standard works with
//   your sockets and remotes — a fan, a lamp, a TV. The standard says what
//   buttons exist (on, off), not how any device builds them.
//
//   An INTERFACE lists abilities with no state and no built code (the classic
//   form). A class promises to provide them with `implements`. A class can
//   implement MANY interfaces — that's how Java does "multiple inheritance" of
//   type safely.
//
// Run with:  java Step3_Interface.java

public class Step3_Interface {

    // A contract: "anything Switchable can be turned on and off".
    interface Switchable {
        void on();
        void off();
    }

    // A second, separate contract.
    interface Timer {
        void schedule(int minutes);
    }

    // A class can implement MANY interfaces at once.
    static class Fan implements Switchable, Timer {
        @Override public void on()  { System.out.println("fan: spinning"); }
        @Override public void off() { System.out.println("fan: stopped"); }
        @Override public void schedule(int minutes) {
            System.out.println("fan: will stop in " + minutes + " min");
        }
    }

    static class Lamp implements Switchable {
        @Override public void on()  { System.out.println("lamp: light on"); }
        @Override public void off() { System.out.println("lamp: light off"); }
    }

    // We can treat ANY Switchable the same way, fan or lamp.
    static void pressButton(Switchable device) {
        device.on();
        device.off();
    }

    public static void main(String[] args) {
        Fan fan = new Fan();
        Lamp lamp = new Lamp();

        pressButton(fan);
        pressButton(lamp);

        fan.schedule(30);    // only the Fan has the Timer ability

        // A Fan IS both a Switchable and a Timer:
        System.out.println("fan is Switchable? " + (fan instanceof Switchable));
        System.out.println("fan is Timer?      " + (fan instanceof Timer));
        System.out.println("lamp is Timer?     " + (lamp instanceof Timer));
    }
}
