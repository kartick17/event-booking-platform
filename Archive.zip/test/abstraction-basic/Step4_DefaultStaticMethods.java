// STEP 4 — Interfaces can carry CODE too: default & static methods
// Analogy: the plug standard ships with a few built-in extras. Every switchable
//   device gets a free "toggle" button (a DEFAULT method) without each maker
//   building it. And the standard itself can offer a handy tool (a STATIC
//   method) you call on the standard, not on a device.
//
//   - default method: shared code inside an interface. Implementers get it free,
//     and can override it if they want. (Added in Java 8.)
//   - static method: a helper that belongs to the interface itself.
//   - private method: a helper used only by the interface's own default methods.
//
// Run with:  java Step4_DefaultStaticMethods.java

public class Step4_DefaultStaticMethods {

    interface Switchable {
        void on();
        void off();

        // DEFAULT method: built-in shared behaviour. No need to repeat it per class.
        default void toggle(boolean turnOn) {
            log("toggle " + (turnOn ? "ON" : "OFF"));
            if (turnOn) on(); else off();
        }

        // PRIVATE method: a helper only the default methods above can use.
        private void log(String msg) {
            System.out.println("[switchable] " + msg);
        }

        // STATIC method: a factory/helper called on the interface itself.
        static Switchable dummy() {
            return new Switchable() {
                @Override public void on()  { System.out.println("dummy on"); }
                @Override public void off() { System.out.println("dummy off"); }
            };
        }
    }

    static class Lamp implements Switchable {
        @Override public void on()  { System.out.println("lamp on"); }
        @Override public void off() { System.out.println("lamp off"); }
        // note: no toggle() here — we get it free from the interface
    }

    public static void main(String[] args) {
        Lamp lamp = new Lamp();
        lamp.toggle(true);    // uses the DEFAULT method (+ its private helper)
        lamp.toggle(false);

        // STATIC method called on the interface, not an object:
        Switchable d = Switchable.dummy();
        d.toggle(true);
    }
}
