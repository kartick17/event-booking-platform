// STEP 5 — Abstract class vs Interface: when to use which
// Analogy:
//   - Abstract class = a shared CHASSIS. Use it when devices are the same KIND
//     of thing and share state + code (every Appliance has a name and power).
//   - Interface = a PLUG STANDARD. Use it for an ability that unrelated things
//     can have (a Fan, a Door, and a Car can all be "Openable").
//
//   Rule of thumb:
//     * "is a kind of"  + shared fields/code  -> abstract class
//     * "can do"        + many unrelated types -> interface
//     * a class can extend ONE class but implement MANY interfaces
//
// Run with:  java Step5_WhenToUseWhich.java

public class Step5_WhenToUseWhich {

    // Shared KIND of thing, with state + code -> abstract class.
    abstract static class Appliance {
        private final String name;
        Appliance(String name) { this.name = name; }
        String name() { return name; }
        abstract void run();
    }

    // A pure ABILITY that unrelated things can have -> interface.
    interface Openable {
        void open();
    }

    // A Dishwasher IS an Appliance (extends) and CAN be opened (implements).
    static class Dishwasher extends Appliance implements Openable {
        Dishwasher() { super("Dishwasher"); }
        @Override void run()  { System.out.println(name() + " washes dishes"); }
        @Override public void open() { System.out.println(name() + " door opens"); }
    }

    // A Door is NOT an appliance, but it is still Openable. Same ability, no shared base.
    static class Door implements Openable {
        @Override public void open() { System.out.println("Door swings open"); }
    }

    public static void main(String[] args) {
        Dishwasher dw = new Dishwasher();
        dw.run();      // from the abstract base
        dw.open();     // from the interface

        // One method, any Openable — appliance or not.
        Openable[] things = { dw, new Door() };
        for (Openable o : things) {
            o.open();
        }

        System.out.println();
        System.out.println("Pick abstract class for a shared KIND (state + code).");
        System.out.println("Pick interface for an ABILITY many unrelated types share.");
        System.out.println("Extend ONE class; implement MANY interfaces.");
    }
}
