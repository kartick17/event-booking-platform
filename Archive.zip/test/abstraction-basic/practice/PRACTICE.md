# 🔌 Practice — Fill in the Blanks (Basic Abstraction)

Each file is a step with the key lines removed and marked `// TODO:`. Fill them
in, then run. Answer key: the matching finished file in the folder above
(`../Step*.java`).

## How to practice
1. Read the matching step in `../GUIDE.md`.
2. Open a practice file, fill every `// TODO`.
3. Run it (no compiler needed):
   ```bash
   java Step1_AbstractClass_Practice.java
   java Step2_AbstractClassShared_Practice.java
   java Step3_Interface_Practice.java
   java Step4_DefaultStaticMethods_Practice.java
   java Step5_WhenToUseWhich_Practice.java
   ```
4. Stuck? Compare with `../Step*.java`.

## The topics to read (in order)
1. **Step 1** → abstract class + abstract method → name a job, hide how.
2. **Step 2** → abstract class state + constructor → share parts.
3. **Step 3** → interface + implements → a contract many types fulfil.
4. **Step 4** → default / static / private → code inside an interface.
5. **Step 5** → abstract class vs interface → pick the right one.

## Self-check: did it work?
| Step | What correct output looks like |
|------|--------------------------------|
| 1 | `washing clothes...`, `heating food...` |
| 2 | each device "is now powered on" then runs its own way |
| 3 | fan + lamp on/off; `fan is Timer? true`, `lamp is Timer? false` |
| 4 | `[switchable] toggle ON`, `lamp on`, then `dummy on` |
| 5 | dishwasher runs + opens; door opens |
