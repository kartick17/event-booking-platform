// PRACTICE — STEP 1: Abstract class + abstract method
// Topic: abstraction, abstract class, abstract method
// Goal: name a job (run) and let each appliance fill it in.
// Fill in every // TODO. Answer key: ../Step1_AbstractClass.java
//
// Run when done:  java Step1_AbstractClass_Practice.java
//
// NOTE: this file will NOT compile until you declare the abstract method and
// override it in the children — that IS the exercise.

public class Step1_AbstractClass_Practice {

    abstract static class Appliance {
        // TODO: declare an abstract method:  abstract void run();
        // YOUR CODE HERE
    }

    static class WashingMachine extends Appliance {
        // TODO: override run() to print "washing clothes..."
        // YOUR CODE HERE
    }

    static class Microwave extends Appliance {
        // TODO: override run() to print "heating food..."
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        Appliance a = new WashingMachine();
        Appliance b = new Microwave();
        a.run();    // expect: washing clothes...
        b.run();    // expect: heating food...
    }
}
