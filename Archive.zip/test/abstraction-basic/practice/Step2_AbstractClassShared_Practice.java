// PRACTICE — STEP 2: Abstract class with shared state + code
// Topic: abstract class fields, constructor, concrete + abstract methods
// Goal: share a name and a finished plugIn(); leave run() to each child.
// Fill in every // TODO. Answer key: ../Step2_AbstractClassShared.java
//
// Run when done:  java Step2_AbstractClassShared_Practice.java
//
// NOTE: this file will NOT compile until you call super(...) and override
// run() — that IS the exercise.

public class Step2_AbstractClassShared_Practice {

    abstract static class Appliance {
        private final String name;

        // An abstract class CAN have a constructor.
        Appliance(String name) {
            this.name = name;
        }

        void plugIn() {
            System.out.println(name + " is now powered on");
        }

        String name() { return name; }

        // TODO: declare the abstract method:  abstract void run();
        // YOUR CODE HERE
    }

    static class Kettle extends Appliance {
        Kettle() {
            // TODO: call super("Kettle");
            // YOUR CODE HERE
        }
        // TODO: override run() to print  name() + " is boiling water"
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        Appliance k = new Kettle();
        k.plugIn();    // expect: Kettle is now powered on
        k.run();       // expect: Kettle is boiling water
    }
}
