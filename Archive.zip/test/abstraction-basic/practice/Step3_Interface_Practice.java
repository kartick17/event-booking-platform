// PRACTICE — STEP 3: Interface = a pure contract
// Topic: interface, implements (many), program to the interface
// Goal: make Fan fulfil two contracts; treat any Switchable the same.
// Fill in every // TODO. Answer key: ../Step3_Interface.java
//
// Run when done:  java Step3_Interface_Practice.java
//
// NOTE: this file will NOT compile until Fan implements the interfaces and
// their methods — that IS the exercise.

public class Step3_Interface_Practice {

    interface Switchable {
        void on();
        void off();
    }

    interface Timer {
        void schedule(int minutes);
    }

    // TODO: make Fan implement BOTH Switchable and Timer.
    static class Fan /* TODO: implements Switchable, Timer */ {
        // TODO: implement on()  -> print "fan: spinning"
        // TODO: implement off() -> print "fan: stopped"
        // TODO: implement schedule(min) -> print "fan: will stop in " + min + " min"
        // YOUR CODE HERE
    }

    // Works for ANY Switchable.
    static void pressButton(Switchable device) {
        device.on();
        device.off();
    }

    public static void main(String[] args) {
        Fan fan = new Fan();
        pressButton(fan);          // expect: fan: spinning / fan: stopped
        fan.schedule(30);          // expect: fan: will stop in 30 min
        System.out.println("fan is Timer? " + (fan instanceof Timer));  // expect true
    }
}
