// PRACTICE — STEP 4: default / static / private interface methods
// Topic: code inside an interface
// Goal: give every Switchable a free toggle(); add a static factory.
// Fill in every // TODO. Answer key: ../Step4_DefaultStaticMethods.java
//
// Run when done:  java Step4_DefaultStaticMethods_Practice.java

public class Step4_DefaultStaticMethods_Practice {

    interface Switchable {
        void on();
        void off();

        // TODO: make this a DEFAULT method (add the `default` keyword) so every
        //       implementer gets it free.
        /* TODO: default */ void toggle(boolean turnOn);   // <- remove the ; and add a body below

        // Hint, the finished default method looks like:
        //   default void toggle(boolean turnOn) {
        //       if (turnOn) on(); else off();
        //   }

        // TODO: add a STATIC factory method `dummy()` that returns a Switchable
        //       whose on()/off() print "dummy on" / "dummy off".
        // YOUR CODE HERE
    }

    static class Lamp implements Switchable {
        @Override public void on()  { System.out.println("lamp on"); }
        @Override public void off() { System.out.println("lamp off"); }
        // no toggle() here — it should come free from the interface
    }

    public static void main(String[] args) {
        Lamp lamp = new Lamp();
        lamp.toggle(true);    // expect: lamp on
        lamp.toggle(false);   // expect: lamp off
        // Switchable d = Switchable.dummy();   // uncomment once you add dummy()
        // d.toggle(true);                       // expect: dummy on
    }
}
