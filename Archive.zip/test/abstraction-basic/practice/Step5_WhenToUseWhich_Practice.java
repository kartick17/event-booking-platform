// PRACTICE — STEP 5: abstract class vs interface
// Topic: extend ONE class, implement MANY interfaces
// Goal: Dishwasher IS an Appliance and CAN be opened; Door is only Openable.
// Fill in every // TODO. Answer key: ../Step5_WhenToUseWhich.java
//
// Run when done:  java Step5_WhenToUseWhich_Practice.java
//
// NOTE: this file will NOT compile until you wire up extends/implements and the
// methods — that IS the exercise.

public class Step5_WhenToUseWhich_Practice {

    abstract static class Appliance {
        private final String name;
        Appliance(String name) { this.name = name; }
        String name() { return name; }
        abstract void run();
    }

    interface Openable {
        void open();
    }

    // TODO: Dishwasher should EXTEND Appliance and IMPLEMENT Openable.
    static class Dishwasher /* TODO: extends Appliance implements Openable */ {
        Dishwasher() {
            // TODO: super("Dishwasher");
            // YOUR CODE HERE
        }
        // TODO: implement run()  -> print name() + " washes dishes"
        // TODO: implement open() -> print name() + " door opens"
        // YOUR CODE HERE
    }

    // TODO: Door is NOT an appliance, but it IS Openable.
    static class Door /* TODO: implements Openable */ {
        // TODO: implement open() -> print "Door swings open"
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        Dishwasher dw = new Dishwasher();
        dw.run();      // expect: Dishwasher washes dishes
        dw.open();     // expect: Dishwasher door opens

        Openable[] things = { dw, new Door() };
        for (Openable o : things) o.open();   // dishwasher door opens / Door swings open
    }
}
