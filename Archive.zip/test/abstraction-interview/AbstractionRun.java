// ============================================================================
// AbstractionRun.java — SELF-CONTAINED single-file version (no compiler needed)
// Run with:  java AbstractionRun.java
//
// Real scenario: a pluggable NOTIFICATION SYSTEM. It delivers messages over
// different channels (email, SMS, push). The same domain shows every angle of
// abstraction an interviewer asks about:
//
//   1) Abstract class as a TEMPLATE METHOD  -> fix the algorithm, vary the steps
//   2) Interface as a capability + FUNCTIONAL interface + lambda
//   3) default / static / private methods in an interface
//   4) The DIAMOND problem (two default methods) and how to resolve it
//   5) Abstract class vs interface — and combining both
//
// The packaged version under src/com/notify/ is the production shape; this is
// the runnable mirror for a machine that only has `java`.
// ============================================================================

public final class AbstractionRun {

    // The immutable result of one delivery attempt.
    record Receipt(String channel, String user, boolean delivered, int attempts) {
        @Override
        public String toString() {
            return (delivered ? "OK  " : "FAIL") + " -> " + user
                    + " via " + channel + " (attempts=" + attempts + ")";
        }
    }

    // ------------------------------------------------------------------ //
    // 2) FUNCTIONAL INTERFACE — exactly one abstract method, so a lambda fits.
    //    It also carries a static factory and a default helper.
    // ------------------------------------------------------------------ //
    @FunctionalInterface
    interface RetryPolicy {
        int maxAttempts();                              // the single abstract method

        static RetryPolicy of(int attempts) {           // static factory
            return () -> attempts;                      // built from a lambda
        }

        default boolean allows(int attemptsSoFar) {     // default helper
            return attemptsSoFar < maxAttempts();
        }
    }

    // ------------------------------------------------------------------ //
    // 3) CAPABILITY INTERFACE with default / static / private methods.
    // ------------------------------------------------------------------ //
    interface Channel {
        String name();                                  // contract

        default String describe() {                     // default: shared behaviour
            return banner() + name();
        }

        private String banner() {                       // private: helper for defaults (Java 9+)
            return "channel: ";
        }

        static Channel named(String n) {                // static: factory on the interface
            return () -> n;
        }
    }

    // ------------------------------------------------------------------ //
    // 1) ABSTRACT CLASS as a TEMPLATE METHOD.
    //    send() fixes the algorithm (validate -> format -> deliver+retry) and is
    //    `final` so no subclass can break the skeleton. Subclasses only fill the
    //    varying steps: the abstract deliver(), and the optional format() hook.
    //    This is the thing an interface alone cannot do — it owns shared state
    //    (the retry policy) and a shared, locked algorithm.
    // ------------------------------------------------------------------ //
    abstract static class Notifier implements Channel {
        private final RetryPolicy retry;                // shared STATE

        protected Notifier(RetryPolicy retry) {
            this.retry = retry;
        }

        public final Receipt send(String user, String message) {
            if (user == null || user.isBlank()) {
                throw new IllegalArgumentException("user required");
            }
            String body = format(message);              // overridable hook
            int attempt = 0;
            boolean ok = false;
            do {
                attempt++;
                ok = deliver(user, body);               // abstract step
            } while (!ok && retry.allows(attempt));
            return new Receipt(name(), user, ok, attempt);
        }

        // HOOK: a default that subclasses MAY override.
        protected String format(String message) {
            return message;
        }

        // STEP: each channel MUST implement how it actually delivers.
        protected abstract boolean deliver(String user, String message);
    }

    static final class EmailNotifier extends Notifier {
        EmailNotifier(RetryPolicy retry) { super(retry); }

        @Override public String name() { return "email"; }

        @Override
        protected String format(String message) {       // override the hook
            return "<html>" + message + "</html>";
        }

        @Override
        protected boolean deliver(String user, String body) {
            System.out.println("    SMTP to " + user + ": " + body);
            return true;
        }
    }

    // Fails the first try, succeeds on the second — to show the retry loop.
    static final class FlakySms extends Notifier {
        private int calls = 0;
        FlakySms(RetryPolicy retry) { super(retry); }

        @Override public String name() { return "sms"; }

        @Override
        protected boolean deliver(String user, String body) {
            calls++;
            boolean ok = calls >= 2;
            System.out.println("    SMS attempt " + calls + " to " + user
                    + " -> " + (ok ? "sent" : "failed"));
            return ok;
        }
    }

    // ------------------------------------------------------------------ //
    // 4) THE DIAMOND PROBLEM.
    //    Two interfaces give the SAME default method tag(). A class that
    //    implements both MUST override tag() to resolve the clash. It can reach
    //    each parent's version with Interface.super.method().
    // ------------------------------------------------------------------ //
    interface Audited { default String tag() { return "[audit]"; } }
    interface Secured { default String tag() { return "[secure]"; } }

    static final class SecureChannel implements Audited, Secured {
        @Override
        public String tag() {
            // resolve the clash explicitly:
            return Audited.super.tag() + Secured.super.tag();
        }
    }

    // ------------------------------------------------------------------ //
    // MAIN
    // ------------------------------------------------------------------ //
    public static void main(String[] args) {
        System.out.println("== 1) Abstract class as a template method ==");
        Notifier email = new EmailNotifier(RetryPolicy.of(1));
        System.out.println("  " + email.send("alice@x.com", "Hello"));   // formatted to <html>

        System.out.println("\n== 2) Functional interface + retry (lambda) ==");
        Notifier sms = new FlakySms(RetryPolicy.of(3));                  // RetryPolicy is a lambda
        System.out.println("  " + sms.send("+15550000", "Code 1234"));  // succeeds on attempt 2

        System.out.println("\n== 3) Interface default / static / private ==");
        Channel push = Channel.named("push");        // static factory returns a lambda Channel
        System.out.println("  " + push.describe());  // default method + private helper -> "channel: push"
        System.out.println("  email.describe(): " + email.describe());

        System.out.println("\n== 4) Diamond problem resolved ==");
        SecureChannel sc = new SecureChannel();
        System.out.println("  tag() = " + sc.tag());  // [audit][secure]

        System.out.println("\n== 5) Abstract class vs interface ==");
        System.out.println("  Abstract class: owns state + a locked algorithm (Notifier.send).");
        System.out.println("  Interface:      a capability many types share (Channel, RetryPolicy).");
        System.out.println("  A class extends ONE class, implements MANY interfaces.");
    }
}
