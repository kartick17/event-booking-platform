# 📣 Notification System — Full Learning Guide (Interview)

## 1. What is this project?
A pluggable **notification system**. It delivers a message over a channel (email,
SMS, push) with retries. One realistic domain shows every angle of abstraction an
interviewer probes, and each step says *why this tool over the other*.

## 2. What you will learn
| Need | Plain-English meaning | Tool | Step |
|------|----------------------|------|------|
| Fix steps of an algorithm, vary the details | locked skeleton + holes | abstract class + template method | 1 |
| A one-method contract written inline | a lambda is the implementation | `@FunctionalInterface` | 2 |
| Ship code with a contract | shared/util/helper methods | `default`/`static`/`private` | 3 |
| Resolve two equal defaults | pick which wins | diamond + `Iface.super.m()` | 4 |
| Choose abstract class or interface | state+algorithm vs capability | the decision | 5 |

## 3. The big picture
```
   Channel (interface)            RetryPolicy (@FunctionalInterface)
   - name()                       - maxAttempts()       <- a lambda
   - describe() default           - of(n) static
   - banner() private             - allows() default
        ^
        | implements
   Notifier (abstract)  ── template method ──> send() is FINAL:
   - retry (state)                 validate -> format(hook) -> deliver(abstract)+retry
        ^
        | extends (ONE)
   EmailNotifier      FlakySmsNotifier

   Audited.tag() + Secured.tag()  --(clash)-->  SecureChannel overrides tag()
```

## 4. Project files
```
AbstractionRun.java                  (NEW FILE)  single-file runnable mirror
src/com/notify/Receipt.java          (NEW FILE)
src/com/notify/RetryPolicy.java      (NEW FILE)  functional interface
src/com/notify/Channel.java          (NEW FILE)  default/static/private
src/com/notify/Notifier.java         (NEW FILE)  abstract template method
src/com/notify/EmailNotifier.java    (NEW FILE)
src/com/notify/FlakySmsNotifier.java (NEW FILE)
src/com/notify/Audited.java          (NEW FILE)  diamond half
src/com/notify/Secured.java          (NEW FILE)  diamond half
src/com/notify/SecureChannel.java    (NEW FILE)  diamond resolver
src/com/notify/Main.java             (NEW FILE)
```

---

# STEP 1 — Abstract class as a template method

### Concept
`Notifier.send()` fixes the algorithm — validate, then `format`, then
`deliver` with retries — and is `final` so no subclass can break the skeleton. It
owns shared state (the retry policy). Subclasses fill only the holes: the
abstract `deliver()`, and the optional `format()` hook. This is what a plain
interface can't do: hold state plus a locked algorithm.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why abstract class wins |
|-------------|---------|--------------------------|
| interface with the algorithm in each class | every channel re-writes validate/retry | base writes it once, `final` locks it |
| copy-paste the send loop | drift, bugs per channel | one shared, tested skeleton |
| put state in an interface | interfaces hold no instance state | abstract class holds the `RetryPolicy` |

### Code — `Notifier.java`
```java
public abstract class Notifier implements Channel {
    private final RetryPolicy retry;
    public final Receipt send(String user, String message) {
        if (user == null || user.isBlank()) throw new IllegalArgumentException("user required");
        String body = format(message);           // hook
        int attempt = 0; boolean ok = false;
        do { attempt++; ok = deliver(user, body); } while (!ok && retry.allows(attempt));
        return new Receipt(name(), user, ok, attempt);
    }
    protected String format(String m) { return m; }            // overridable
    protected abstract boolean deliver(String user, String message);  // required
}
```

### How to test
`java AbstractionRun.java` → email sends `<html>Hello</html>` on attempt 1.

### Interview defense
"The template method pattern lives in an abstract class: a `final` algorithm with
abstract steps and optional hooks. I use an abstract class here because I need
shared state and a locked control flow — neither of which an interface gives me."

---

# STEP 2 — Functional interface + lambda

### Concept
`RetryPolicy` has exactly one abstract method, so `@FunctionalInterface` lets a
lambda BE the implementation: `RetryPolicy.of(3)` returns `() -> 3`. The interface
still carries a `default allows(...)` helper and a `static of(...)` factory.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why functional interface wins |
|-------------|---------|-------------------------------|
| a full class per policy | boilerplate for one number | a lambda is one line |
| an `int` parameter everywhere | no behaviour, no `allows()` | the interface bundles data + helper |

### Code — `RetryPolicy.java`
```java
@FunctionalInterface
public interface RetryPolicy {
    int maxAttempts();
    static RetryPolicy of(int n) { return () -> n; }
    default boolean allows(int soFar) { return soFar < maxAttempts(); }
}
```

### How to test
`java AbstractionRun.java` → flaky SMS retries and succeeds on attempt 2.

### Interview defense
"A functional interface is any interface with a single abstract method, so it can
be supplied as a lambda. `@FunctionalInterface` makes that intent explicit and
fails the build if someone adds a second abstract method."

---

# STEP 3 — default / static / private interface methods

### Concept
`Channel` carries code: `describe()` is a `default` (shared behaviour), `banner()`
is a `private` helper used only by defaults (Java 9+), and `named(...)` is a
`static` factory on the interface itself.

### Why this tool (vs the alternatives)
| Method kind | Use it for | Why |
|-------------|-----------|-----|
| `default` | add behaviour without breaking implementers | old classes still compile |
| `static` | factory/util tied to the type | no separate `Utils` class |
| `private` | share code between defaults | keeps the API clean |

### Code — `Channel.java`
```java
public interface Channel {
    String name();
    default String describe() { return banner() + name(); }
    private String banner() { return "channel: "; }
    static Channel named(String n) { return () -> n; }
}
```

### How to test
`java AbstractionRun.java` → `channel: push`, `channel: email`.

### Interview defense
"Default methods let an interface evolve without breaking existing implementers —
that's why they were added in Java 8. Static methods hold factories; private
methods (Java 9) share logic between defaults without leaking into the API."

---

# STEP 4 — The diamond problem

### Concept
`Audited` and `Secured` both provide a `default tag()`. A class implementing both
inherits two equal methods — ambiguous — so Java forces it to override `tag()`.
It can call each parent explicitly with `Audited.super.tag()`.

### Why this matters
It's the safe version of multiple inheritance: Java allows multiple interfaces
but makes you resolve any default-method clash by hand, so there's never a hidden
"which one ran?".

### Code — `Audited.java`, `Secured.java`, `SecureChannel.java`
```java
interface Audited { default String tag() { return "[audit]"; } }
interface Secured { default String tag() { return "[secure]"; } }
class SecureChannel implements Audited, Secured {
    public String tag() { return Audited.super.tag() + Secured.super.tag(); }
}
```

### How to test
`java AbstractionRun.java` → `tag() = [audit][secure]`.

### Interview defense
"When two interfaces give the same default method, the implementing class must
override it; I reach a specific parent with `Interface.super.method()`. This is
how Java keeps multiple inheritance of behaviour unambiguous."

---

# STEP 5 — Abstract class vs interface (the decision)

### Concept
Use an **abstract class** when subtypes share state and a base algorithm
(`Notifier`). Use an **interface** for a capability many, possibly unrelated,
types can have (`Channel`, `RetryPolicy`). A class extends one class but
implements many interfaces — `Notifier` does both: it `implements Channel` and is
extended by the channels.

### Side-by-side
| | Abstract class | Interface |
|--|---------------|-----------|
| Instance state | yes (`retry` field) | no |
| Constructor | yes | no |
| How many per class | ONE | MANY |
| Code | full methods | `default`/`static`/`private` |
| Models | "is a kind of" + shared impl | "can do" capability |
| Picks | template method, shared base | strategy, mix-in capability, lambda target |

### Interview defense
"Abstract class for shared state plus a locked algorithm; interface for
capabilities and lambda targets. They compose: `Notifier` is an abstract class
that implements the `Channel` interface. Default to interfaces and add an
abstract class only when you truly need shared state or a fixed algorithm."

---

## How to run everything
**No compiler:**
```bash
java AbstractionRun.java
```
**Packaged (needs javac):**
```bash
javac -d out $(find src -name "*.java")
java -cp out com.notify.Main
```

## Cheat sheet (one line per tool)
| Tool | What it does |
|------|--------------|
| abstract class | base type with state + code; can't be instantiated |
| template method | a `final` algorithm with abstract steps + hooks |
| abstract method | a required step subclasses must implement |
| hook method | a `default`-bodied step subclasses MAY override |
| `interface` | a capability contract |
| `@FunctionalInterface` | single-abstract-method interface; lambda target |
| lambda `() -> ...` | inline implementation of a functional interface |
| `default` method | shared code in an interface; overridable |
| `static` method (interface) | factory/util on the interface |
| `private` method (interface) | helper shared by defaults (Java 9+) |
| diamond problem | two equal defaults → class must override |
| `Iface.super.m()` | call a specific interface's default |
| extend ONE / implement MANY | the abstract-class-vs-interface rule |

## Where to go next
1. **Strategy pattern** — swap behaviour via interfaces/lambdas instead of subclassing.
2. **`sealed` interfaces** — a fixed, exhaustive set of implementers (Java 17).
3. **`Comparator`/`Function`/`Supplier`** — the standard functional interfaces.
4. **SOLID: Interface Segregation & Dependency Inversion** — both shown here.
5. The **oop-interview** pack — abstraction alongside the other three pillars.
