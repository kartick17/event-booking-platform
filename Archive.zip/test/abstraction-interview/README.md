# 📣 Notification System — Abstraction (Interview) — Start Here

Abstraction at senior depth: a pluggable **notification system** (email, SMS,
push). It shows the template-method pattern (abstract class), functional
interfaces with lambdas, `default`/`static`/`private` interface methods, the
diamond problem, and a clear "abstract class vs interface" decision — each with a
"why this over that" note.

## What you need on the other system
1. **Java 9+** (tested on Java 17; uses private interface methods + records).
   Check with: `java -version`
   - **No compiler needed** for the single-file mirror `AbstractionRun.java`.
   - To compile the packaged `src/` you need `javac` (full JDK):
     Ubuntu/Debian `sudo apt install default-jdk`, Mac `brew install openjdk`,
     Windows: Temurin from https://adoptium.net
2. Any text editor.

## What's in this folder
```
abstraction-interview/
├── README.md                          you are here
├── GUIDE.md                           full lesson + "why this over that" tables
├── AbstractionRun.java                SELF-CONTAINED single-file version (no compiler)
├── src/com/notify/
│   ├── Receipt.java                   immutable result record
│   ├── RetryPolicy.java               functional interface (+ static + default)
│   ├── Channel.java                   capability interface (default/static/private)
│   ├── Notifier.java                  abstract base = template method
│   ├── EmailNotifier.java             overrides the format hook
│   ├── FlakySmsNotifier.java          exercises the retry loop
│   ├── Audited.java / Secured.java    the two halves of the diamond
│   ├── SecureChannel.java             resolves the diamond clash
│   └── Main.java                      packaged entry point
└── practice/
    ├── PRACTICE.md
    ├── Notifier_Practice.java          build the template method + a subclass
    └── Diamond_Practice.java           resolve a default-method clash
```

## How to learn (suggested order)
1. Read **GUIDE.md** top to bottom (each step has a "why this over that" table).
2. Run the single-file version and match the output.
3. Read the packaged `src/` for the production shape.
4. Practice: fill in the `practice/` blanks.

## How to run
**No compiler (works anywhere with `java`):**
```bash
java AbstractionRun.java
```
**Full packaged build (needs `javac`):**
```bash
javac -d out $(find src -name "*.java")
java -cp out com.notify.Main
```

## Quick map: step → concept → tool
| Step | Concept | Tool |
|------|---------|------|
| 1 | Fix the algorithm, vary the steps | abstract class + template method + `final` |
| 2 | One-method contract as a lambda | `@FunctionalInterface`, lambda |
| 3 | Code inside a contract | `default` / `static` / `private` methods |
| 4 | Two clashing defaults | diamond problem + `Interface.super.m()` |
| 5 | Pick the right tool | abstract class vs interface |
