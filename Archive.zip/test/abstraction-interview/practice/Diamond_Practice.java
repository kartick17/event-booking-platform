// PRACTICE — STEP 4: the diamond problem
// Topic: two interfaces with the same default method; resolve the clash
// Goal: make SecureChannel combine both parents' tag() values.
// Fill in every // TODO. Answer key: ../src/com/notify/SecureChannel.java
//
// Run when done:  java Diamond_Practice.java
//
// NOTE: this file will NOT compile until you override tag() — Java forces it
// because both interfaces give an equal default. That IS the exercise.

public class Diamond_Practice {

    interface Audited {
        default String tag() { return "[audit]"; }
    }

    interface Secured {
        default String tag() { return "[secure]"; }
    }

    // TODO: make SecureChannel implement BOTH Audited and Secured.
    static final class SecureChannel /* TODO: implements Audited, Secured */ {
        // TODO: override tag() and return Audited.super.tag() + Secured.super.tag()
        // Hint: you reach a specific parent's default with Interface.super.method()
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        SecureChannel sc = new SecureChannel();
        System.out.println("tag() = " + sc.tag());   // expect: [audit][secure]
    }
}
