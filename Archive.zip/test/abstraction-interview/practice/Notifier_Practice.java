// PRACTICE — STEPS 1-2: abstract class as a template method
// Topic: abstract class, final template method, abstract step, overridable hook
// Goal: build the send() skeleton once; let Email fill deliver() + format().
// Fill in every // TODO. Answer key: ../src/com/notify/Notifier.java + EmailNotifier.java
//
// Run when done:  java Notifier_Practice.java
//
// NOTE: this file will NOT compile until you declare the abstract method and
// implement it in Email — that IS the exercise.

public class Notifier_Practice {

    abstract static class Notifier {
        // TEMPLATE METHOD: fixed skeleton. `final` so subclasses can't change it.
        public final String send(String user, String message) {
            if (user == null || user.isBlank()) {
                throw new IllegalArgumentException("user required");
            }
            String body = format(message);     // overridable hook
            boolean ok = deliver(user, body);  // abstract step
            return (ok ? "OK  " : "FAIL") + " -> " + user + " via " + name() + " (attempts=1)";
        }

        // HOOK with a default body — subclasses MAY override.
        protected String format(String message) {
            return message;
        }

        // TODO: declare the two abstract methods every channel must provide:
        //   protected abstract boolean deliver(String user, String body);
        //   public abstract String name();
        // YOUR CODE HERE
    }

    static class Email extends Notifier {
        // TODO: override name() to return "email"
        // YOUR CODE HERE

        // TODO: override format(message) to return "<b>" + message + "</b>"
        // YOUR CODE HERE

        // TODO: override deliver(user, body) to print "SMTP to " + user + ": " + body
        //       and return true
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        Notifier email = new Email();
        System.out.println(email.send("bob", "Hi"));
        // expect:
        //   SMTP to bob: <b>Hi</b>
        //   OK  -> bob via email (attempts=1)
    }
}
