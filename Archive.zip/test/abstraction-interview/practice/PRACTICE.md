# 📣 Practice — Fill in the Blanks (Interview Abstraction)

Two drills on the parts interviewers push on: the template-method pattern in an
abstract class, and resolving a default-method clash (the diamond problem). Each
file is self-contained and runs with no compiler.

## How to practice
1. Read the matching steps in `../GUIDE.md`.
2. Open a practice file, fill every `// TODO`.
3. Run it (no compiler needed):
   ```bash
   java Notifier_Practice.java
   java Diamond_Practice.java
   ```
4. Stuck? Compare with `../AbstractionRun.java` and the `../src/` files.

## The topics to read (in order)
1. **Notifier_Practice** → Steps 1-2 → abstract template method + abstract step.
2. **Diamond_Practice** → Step 4 → two default methods, resolve the clash.

## Self-check: did it work?
| File | What correct output looks like |
|------|--------------------------------|
| Notifier_Practice | `SMTP to bob: <b>Hi</b>` then `OK -> bob via email (attempts=1)` |
| Diamond_Practice | `tag() = [audit][secure]` |
