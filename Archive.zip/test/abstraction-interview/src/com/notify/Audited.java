package com.notify;

/** One half of the diamond: a default tag(). */
public interface Audited {
    default String tag() {
        return "[audit]";
    }
}
