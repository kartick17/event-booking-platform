package com.notify;

/**
 * A capability contract that also carries code:
 * <ul>
 *   <li>{@code name()} — the abstract contract</li>
 *   <li>{@code describe()} — a {@code default} method, shared behaviour</li>
 *   <li>{@code banner()} — a {@code private} helper used only by defaults (Java 9+)</li>
 *   <li>{@code named(...)} — a {@code static} factory on the interface</li>
 * </ul>
 */
public interface Channel {

    String name();

    default String describe() {
        return banner() + name();
    }

    private String banner() {
        return "channel: ";
    }

    static Channel named(String n) {
        return () -> n;
    }
}
