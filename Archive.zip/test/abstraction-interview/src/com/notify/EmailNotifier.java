package com.notify;

/** Email channel: overrides the format hook to wrap the body in HTML. */
public final class EmailNotifier extends Notifier {

    public EmailNotifier(RetryPolicy retry) {
        super(retry);
    }

    @Override
    public String name() {
        return "email";
    }

    @Override
    protected String format(String message) {
        return "<html>" + message + "</html>";
    }

    @Override
    protected boolean deliver(String user, String body) {
        System.out.println("    SMTP to " + user + ": " + body);
        return true;
    }
}
