package com.notify;

/** SMS channel that fails the first attempt, to exercise the retry loop. */
public final class FlakySmsNotifier extends Notifier {

    private int calls = 0;

    public FlakySmsNotifier(RetryPolicy retry) {
        super(retry);
    }

    @Override
    public String name() {
        return "sms";
    }

    @Override
    protected boolean deliver(String user, String body) {
        calls++;
        boolean ok = calls >= 2;
        System.out.println("    SMS attempt " + calls + " to " + user
                + " -> " + (ok ? "sent" : "failed"));
        return ok;
    }
}
