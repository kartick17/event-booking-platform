package com.notify;

/**
 * Packaged entry point. Mirrors AbstractionRun.java.
 *
 * <p>Build + run (needs the full JDK with javac):
 * <pre>
 *   cd abstraction-interview
 *   javac -d out $(find src -name "*.java")
 *   java -cp out com.notify.Main
 * </pre>
 * No compiler? Run the single-file mirror: {@code java AbstractionRun.java}
 */
public final class Main {

    public static void main(String[] args) {
        System.out.println("== Abstract class as a template method ==");
        Notifier email = new EmailNotifier(RetryPolicy.of(1));
        System.out.println("  " + email.send("alice@x.com", "Hello"));

        System.out.println("\n== Functional interface + retry (lambda) ==");
        Notifier sms = new FlakySmsNotifier(RetryPolicy.of(3));
        System.out.println("  " + sms.send("+15550000", "Code 1234"));

        System.out.println("\n== Interface default / static / private ==");
        Channel push = Channel.named("push");
        System.out.println("  " + push.describe());
        System.out.println("  email.describe(): " + email.describe());

        System.out.println("\n== Diamond problem resolved ==");
        System.out.println("  tag() = " + new SecureChannel().tag());
    }
}
