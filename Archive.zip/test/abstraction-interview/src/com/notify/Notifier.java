package com.notify;

/**
 * Abstract base that implements the TEMPLATE METHOD pattern.
 *
 * <p>{@link #send} fixes the algorithm — validate, then format, then deliver with
 * retries — and is {@code final} so no subclass can break that skeleton. It owns
 * shared state (the {@link RetryPolicy}). Subclasses fill only the varying steps:
 * the abstract {@link #deliver} and the optional {@link #format} hook.
 *
 * <p>This is what an interface alone cannot give you: shared mutable/stateful
 * setup plus a locked algorithm. Compare with {@link Channel}, a pure capability.
 */
public abstract class Notifier implements Channel {

    private final RetryPolicy retry;        // shared state

    protected Notifier(RetryPolicy retry) {
        this.retry = retry;
    }

    public final Receipt send(String user, String message) {
        if (user == null || user.isBlank()) {
            throw new IllegalArgumentException("user required");
        }
        String body = format(message);      // overridable hook
        int attempt = 0;
        boolean ok = false;
        do {
            attempt++;
            ok = deliver(user, body);       // abstract step
        } while (!ok && retry.allows(attempt));
        return new Receipt(name(), user, ok, attempt);
    }

    /** Hook: subclasses MAY override how a message is formatted. */
    protected String format(String message) {
        return message;
    }

    /** Step: subclasses MUST implement how a message is delivered. */
    protected abstract boolean deliver(String user, String message);
}
