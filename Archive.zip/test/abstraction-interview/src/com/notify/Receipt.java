package com.notify;

/** Immutable result of one delivery attempt. */
public record Receipt(String channel, String user, boolean delivered, int attempts) {

    @Override
    public String toString() {
        return (delivered ? "OK  " : "FAIL") + " -> " + user
                + " via " + channel + " (attempts=" + attempts + ")";
    }
}
