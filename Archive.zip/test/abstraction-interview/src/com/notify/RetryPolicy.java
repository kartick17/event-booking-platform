package com.notify;

/**
 * A FUNCTIONAL interface: exactly one abstract method, so it can be written as a
 * lambda. It also shows that interfaces can carry a static factory and a default
 * helper alongside that single contract method.
 */
@FunctionalInterface
public interface RetryPolicy {

    int maxAttempts();                               // the single abstract method

    static RetryPolicy of(int attempts) {            // static factory
        return () -> attempts;                       // built from a lambda
    }

    default boolean allows(int attemptsSoFar) {      // default helper
        return attemptsSoFar < maxAttempts();
    }
}
