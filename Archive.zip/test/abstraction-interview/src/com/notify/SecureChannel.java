package com.notify;

/**
 * Implements two interfaces that both give a default {@code tag()}. Java forces
 * this class to override tag() to resolve the clash; it reaches each parent's
 * version with {@code Interface.super.method()}.
 */
public final class SecureChannel implements Audited, Secured {

    @Override
    public String tag() {
        return Audited.super.tag() + Secured.super.tag();
    }
}
