package com.notify;

/** The other half of the diamond: a clashing default tag(). */
public interface Secured {
    default String tag() {
        return "[secure]";
    }
}
