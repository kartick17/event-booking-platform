// STEP 1 — try / catch / finally : the kitchen safety net
//
// A cook TRIES to cook a dish.
// If something goes wrong, we CATCH the problem and deal with it.
// FINALLY, we always clean the station — success or failure.
//
// Run it:  java Step1_TryCatchFinally.java

public class Step1_TryCatchFinally {

    // Cook a dish using a given number of eggs.
    // If eggs is 0, dividing by it blows up (ArithmeticException).
    static void cook(int eggs) {
        System.out.println("\nCooking with " + eggs + " eggs...");
        try {
            // risky work: this line throws if eggs == 0
            int omelettesPerEgg = 12 / eggs;
            System.out.println("  Great! Each egg makes " + omelettesPerEgg + " mini-omelettes.");
        } catch (ArithmeticException e) {
            // our plan when the risky work fails
            System.out.println("  Problem caught: " + e.getMessage());
            System.out.println("  Plan B: order more eggs.");
        } finally {
            // cleanup that ALWAYS runs
            System.out.println("  Station cleaned. (finally always runs)");
        }
    }

    public static void main(String[] args) {
        cook(4);   // works fine
        cook(0);   // goes wrong, but we catch it and keep going
        System.out.println("\nShop is still open. The program did not crash.");
    }
}
