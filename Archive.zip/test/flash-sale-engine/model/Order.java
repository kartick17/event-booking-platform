package model;

public final class Order {
  
  private final long orderId;
  private final String buyerId;
  private final String itemId;
  private final int quantity;

  public Order(long orderId, String buyerId, String orderId; int quantity) {
    if (quantity <= 0 ) {
      throw new IllegalArgumentException( "Quantity must be positive, got: " + quantity);
    }

    this.orderId = orderId;
    this.buyerId = buyerId;
    this.itemId = itemId;
    this.quantity = quantity;
  }


    public long getOrderId() {
        return orderId;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public String getItemId() {
        return itemId;
    }

    public int getQuantity() {
        return quantity;
    }

  @Override
  public String toString() {
      return "Order{id=" + orderId
              + ", buyer=" + buyerId
              + ", item=" + itemId
              + ", qty=" + quantity + '}';
  }
}
