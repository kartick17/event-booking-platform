# 📦 Labeled Storage-Box Shop — Full Learning Guide (Basic)

## 1. What is this project?
A tiny shop full of **storage boxes**. This one picture explains both topics:

- A **primitive** (`int`, `double`, `boolean`) is a **loose item** — fast, but it
  can't sit on the shop's shelves, because the shelves only hold boxes.
- A **wrapper** (`Integer`, `Double`, `Boolean`) is that item **packed in a box**
  (an object). Now it can go on shelves (lists, maps, anything generic).
- A **generic** is the **label** on the box. `Box<String>` means "Strings only".
  The label stops the wrong thing going in and the wrong type coming out.

## 2. What you will learn
| Need | Plain-English meaning | Tool | Step |
|------|----------------------|------|------|
| Store a number where only objects fit | pack the value in a box | wrapper class `Integer` | 1 |
| Convert between loose and boxed | shop auto-packs / unpacks | autoboxing / unboxing | 1 |
| Stop wrong types getting in | put a label on the box | generic type `List<String>` | 2 |
| Build a reusable typed container | design your own labeled box | generic class `Box<T>` | 3 |
| One helper for every type | a worker who handles any box | generic method `<T>` | 4 |
| Do number math on a generic | a "numbers only" shelf | bound `<T extends Number>` | 5 |

## 3. The big picture
```
   loose item (int 42)
        |  autobox
        v
   +-----------+        label says <Integer>
   |  Integer  |  ----> goes on the shelf:  List<Integer>
   |    42     |
   +-----------+
        |  unbox
        v
   loose item (int 42)   <- needed for math

   Box<T>  = a box you design, label filled in by the caller
   <T extends Number> = a shelf that only accepts number-labeled boxes
```

## 4. Project files
```
Step1_Wrappers.java        (NEW FILE)
Step2_WhyGenerics.java     (NEW FILE)
Step3_GenericBox.java      (NEW FILE)
Step4_GenericMethod.java   (NEW FILE)
Step5_BoundedTypes.java    (NEW FILE)
```

---

# STEP 1 — Wrapper classes (the item in a box)

### Concept (simple)
Primitives are loose values; wrappers are object versions of them. Java packs
(`autoboxing`) and unpacks (`unboxing`) automatically. You need wrappers because
collections and generics hold **objects**, not loose primitives. The one trap: a
box can be **empty** (`null`), and unpacking an empty box throws a
`NullPointerException` (the "value is missing" crash).

### Code — `Step1_Wrappers.java` (NEW FILE)
Key lines:
```java
int looseCoin = 42;
Integer boxedCoin = looseCoin;        // autobox
int backToLoose = boxedCoin + 8;      // unbox
List<Integer> shelf = new ArrayList<>();
shelf.add(10);                        // autobox into the list
Integer.parseInt("123");              // wrapper helper method
Integer emptyBox = null;
int crash = emptyBox;                 // NullPointerException
```

### How to test
```bash
java Step1_Wrappers.java
```
Ends with: `empty box : null` then `unpacking an empty box throws: NullPointerException`.

### Interview summary
"Primitives are raw values, wrappers are their object form. Autoboxing/unboxing
convert automatically. We need wrappers because generics and collections store
objects — and a wrapper can be `null`, so unboxing it can throw an NPE."

---

# STEP 2 — Why generics exist (label the box)

### Concept (simple)
A raw `List` (no `<...>`) is an unlabeled box. It holds anything, so reading it
needs a hand-written cast and a guess. Guess wrong → `ClassCastException` at run
time. A labeled `List<String>` blocks the wrong type at compile time and needs
no cast. (The "unchecked" note Java prints for the raw list is the compiler
warning you about exactly this.)

### Code — `Step2_WhyGenerics.java` (NEW FILE)
```java
List unlabeled = new ArrayList();        // raw = no label
unlabeled.add("apple");
unlabeled.add(123);                      // a number sneaks in
String wrong = (String) unlabeled.get(1);// ClassCastException at run time

List<String> labeled = new ArrayList<>();
labeled.add("apple");
String safe = labeled.get(0);            // no cast, no guess
```

### How to test
```bash
java Step2_WhyGenerics.java
```
Shows `guessed wrong -> ClassCastException at RUN time`, then the labeled box reads safely.

### Interview summary
"Generics move type errors from run time to compile time and remove manual
casts. Raw types still compile but are unsafe — the compiler warns 'unchecked'."

---

# STEP 3 — Your own generic class `Box<T>`

### Concept (simple)
`T` is a type placeholder filled in when the box is created. `Box<String>` makes
every `T` a `String`; `Box<Integer>` makes it `Integer`. One class, any type,
no casts.

### Code — `Step3_GenericBox.java` (NEW FILE)
```java
static class Box<T> {
    private T item;
    public void put(T item) { this.item = item; }
    public T get()          { return item; }
    public boolean isEmpty(){ return item == null; }
}
Box<String> nameBox = new Box<>();
nameBox.put("Alice");
String name = nameBox.get();   // no cast
```

### How to test
```bash
java Step3_GenericBox.java
```
Shows `name box holds : Alice` and `age box holds : 30`.

### Interview summary
"A generic class declares a type parameter `T`, bound when the object is created.
It gives type-safe reuse — one class for any type, no `Object`, no casts."

---

# STEP 4 — Generic method `<T>`

### Concept (simple)
Put `<T>` before the return type and one method works for any type. Java infers
`T` from the arguments per call — `printAll(fruits)` → `T` is `String`,
`printAll(scores)` → `T` is `Integer`. No need for one method per type.

### Code — `Step4_GenericMethod.java` (NEW FILE)
```java
static <T> void printAll(T[] items) { for (T x : items) System.out.println(x); }
static <T> T    first(T[] items)    { return items[0]; }
static <T> void swap(T[] a, int i, int j) { T t = a[i]; a[i] = a[j]; a[j] = t; }
```

### How to test
```bash
java Step4_GenericMethod.java
```
Prints both arrays, the first element of each, and the swapped array.

### Interview summary
"A generic method has its own type parameter, separate from the class. The
compiler infers it from the arguments, so one method covers every type."

---

# STEP 5 — Bounded generics `<T extends Number>`

### Concept (simple)
A bound is a promise about `T`. `<T extends Number>` says "T is a Number or a
subtype", which unlocks number methods like `doubleValue()`. Without it, Java
only knows `T` is some object and won't let you add the items.

### Code — `Step5_BoundedTypes.java` (NEW FILE)
```java
static <T extends Number> double sum(List<T> nums) {
    double total = 0;
    for (T n : nums) total += n.doubleValue();   // allowed: T IS a Number
    return total;
}
```

### How to test
```bash
java Step5_BoundedTypes.java
```
Shows `sum of ints : 60.0` and `avg of doubles : 2.6666666666666665`.

### Interview summary
"An upper bound `<T extends Number>` restricts the type and grants access to that
type's methods. It's how you write generic numeric code that stays type-safe."

---

## How to run everything
```bash
java Step1_Wrappers.java
java Step2_WhyGenerics.java
java Step3_GenericBox.java
java Step4_GenericMethod.java
java Step5_BoundedTypes.java
```

## Cheat sheet (one line per tool)
| Tool | What it does |
|------|--------------|
| `Integer`, `Double`, `Boolean` | object "box" form of a primitive |
| autoboxing | `Integer x = 5;` auto-packs a primitive into a wrapper |
| unboxing | `int y = x;` auto-unpacks a wrapper (NPE if `x` is null) |
| `Integer.parseInt("5")` | turn text into a number |
| `Integer.MAX_VALUE` | biggest `int` (handy wrapper constant) |
| raw type `List` | unlabeled container — unsafe, needs casts, warns "unchecked" |
| `List<String>` | labeled container — type-safe, no casts |
| generic class `Box<T>` | your own typed container; `T` set when created |
| generic method `<T>` | one method for any type; `T` inferred per call |
| `<T extends Number>` | upper bound: restrict T, unlock that type's methods |

## Where to go next
1. **Wildcards** `<?>`, `<? extends T>`, `<? super T>` — flexible read/write rules (PECS).
2. **`Map<K, V>`** — two type parameters at once.
3. **Type erasure** — why generics vanish at run time, and what that limits.
4. **`Comparable<T>` / `Comparator<T>`** — generics in sorting.
5. The **interview pack** of this topic — the same tools in a real typed repository.
