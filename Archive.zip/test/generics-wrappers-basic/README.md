# 📦 Labeled Storage-Box Shop — Generics & Wrapper Classes (Basic) — Start Here

Learn Java **wrapper classes** and **generics** with one simple picture: a shop
full of **labeled storage boxes**. Loose items vs items packed in labeled boxes.

## What you need on the other system
1. **Java 11+** (this pack is tested on Java 17). Check with: `java -version`
   - You do **not** need the compiler. Every file runs as a single source file
     with `java File.java`.
   - If you ever want the full compiler (`javac`): Ubuntu/Debian
     `sudo apt install default-jdk`, Mac `brew install openjdk`,
     Windows: Temurin from https://adoptium.net
2. Any text editor.

## What's in this folder
```
generics-wrappers-basic/
├── README.md                 you are here
├── GUIDE.md                  full lesson: every step's concept, code, summary, cheat sheet
├── Step1_Wrappers.java       loose primitive vs boxed wrapper (autobox/unbox, null trap)
├── Step2_WhyGenerics.java    unlabeled box (raw type) vs labeled box (generic)
├── Step3_GenericBox.java     write your own generic class Box<T>
├── Step4_GenericMethod.java  a generic method <T> that works for any type
├── Step5_BoundedTypes.java   bounded generics <T extends Number>
└── practice/
    ├── PRACTICE.md           how to practice
    └── Step*_Practice.java   fill-in-the-blank versions (answer key = the files above)
```

## How to learn (suggested order)
1. Read **GUIDE.md** top to bottom.
2. Run the finished code (commands below) and match the output.
3. Practice: fill in the `practice/` blanks; peek at the finished file when stuck.

## How to run
No compiler needed — run each file straight from source:
```bash
java Step1_Wrappers.java
java Step2_WhyGenerics.java
java Step3_GenericBox.java
java Step4_GenericMethod.java
java Step5_BoundedTypes.java
```

## Quick map: step → concept → tool
| Step | Concept | Tool |
|------|---------|------|
| 1 | Loose value vs object value | `Integer`/`Double` wrappers, autoboxing, `parseInt` |
| 2 | Why label a container | raw type vs `List<String>` |
| 3 | Your own typed container | generic class `Box<T>` |
| 4 | One method, any type | generic method `<T>` |
| 5 | Restrict the type to unlock methods | bound `<T extends Number>` |
