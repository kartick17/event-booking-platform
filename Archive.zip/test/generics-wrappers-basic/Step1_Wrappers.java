// STEP 1 — Wrapper classes: the "loose item" vs the "item in a box"
// Analogy: a labeled storage-box shop.
//   - A primitive (int, double, boolean) is a LOOSE item. Fast, but it can't
//     sit on the shop's shelves, because the shelves only hold BOXES.
//   - A wrapper (Integer, Double, Boolean) is the same item PACKED IN A BOX.
//     A box is an object, so it can go on shelves (lists, maps, etc.).
//
// Run with:  java Step1_Wrappers.java

import java.util.ArrayList;
import java.util.List;

public class Step1_Wrappers {

    public static void main(String[] args) {
        // 1) Loose item (primitive) vs boxed item (wrapper object)
        int looseCoin = 42;                 // a loose item
        Integer boxedCoin = looseCoin;      // autoboxing: shop auto-packs it in a box

        System.out.println("loose primitive : " + looseCoin);
        System.out.println("boxed wrapper   : " + boxedCoin);

        // 2) Unboxing: take the item back out of the box to do math
        int backToLoose = boxedCoin + 8;    // autounboxing: shop unpacks it
        System.out.println("unboxed + 8     : " + backToLoose);

        // 3) Why boxes matter: a List can only hold OBJECTS, not loose primitives.
        //    So numbers must be boxed to live on this "shelf".
        List<Integer> shelf = new ArrayList<>();
        shelf.add(10);   // autoboxed int -> Integer
        shelf.add(20);
        shelf.add(30);
        System.out.println("shelf of boxes  : " + shelf);

        // 4) Wrappers come with handy tools the primitive does not have.
        System.out.println("biggest int     : " + Integer.MAX_VALUE);
        System.out.println("parse \"123\"+1  : " + (Integer.parseInt("123") + 1));
        System.out.println("123 in binary   : " + Integer.toBinaryString(123));

        // 5) The big gotcha: a box can be EMPTY (null). A loose item never can.
        Integer emptyBox = null;            // an empty box on the shelf
        System.out.println("empty box       : " + emptyBox);
        try {
            int crash = emptyBox;           // unpacking an empty box -> crash
            System.out.println(crash);      // never reached
        } catch (NullPointerException e) {
            System.out.println("unpacking an empty box throws: NullPointerException");
        }
    }
}
