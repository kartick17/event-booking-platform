// STEP 2 — Why generics exist: an UNLABELED box vs a LABELED box
// Analogy: in the storage-box shop, a box with no label can hold anything.
//   That sounds handy, but when you reach in you don't know what comes out,
//   so you have to GUESS the type. Guess wrong and you get a crash.
//   A LABELED box ("Apples only") stops the mistake before it happens.
//
// Run with:  java Step2_WhyGenerics.java

import java.util.ArrayList;
import java.util.List;

public class Step2_WhyGenerics {

    public static void main(String[] args) {
        // 1) The OLD way: an unlabeled box (a raw List that holds Object).
        //    It happily takes a String AND a number. No label, no safety.
        List unlabeled = new ArrayList();   // raw type = no label
        unlabeled.add("apple");
        unlabeled.add(123);                  // oops, a number sneaked in

        // Reaching in, we must GUESS it is a String and cast by hand.
        String first = (String) unlabeled.get(0);   // ok by luck
        System.out.println("got from unlabeled box: " + first);

        try {
            String wrong = (String) unlabeled.get(1); // 123 is NOT a String
            System.out.println(wrong);                // never reached
        } catch (ClassCastException e) {
            System.out.println("guessed wrong -> ClassCastException at RUN time");
        }

        // 2) The NEW way: a LABELED box. The <String> label means "Strings only".
        List<String> labeled = new ArrayList<>();
        labeled.add("apple");
        // labeled.add(123);   // <-- would NOT compile. The label blocks it early.

        // No cast needed when reading. We KNOW it is a String.
        String safe = labeled.get(0);
        System.out.println("got from labeled box  : " + safe + " (no cast, no guess)");

        System.out.println();
        System.out.println("Lesson: the label moves the error from RUN time to COMPILE time,");
        System.out.println("and removes the hand-written cast. That is what generics buy you.");
    }
}
