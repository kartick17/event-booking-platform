// STEP 3 — Write your OWN labeled box: a generic class Box<T>
// Analogy: you design the box itself. T is the label slot.
//   When a customer says Box<String>, T becomes String everywhere inside.
//   When another says Box<Integer>, T becomes Integer. One design, many labels.
//
// Run with:  java Step3_GenericBox.java

public class Step3_GenericBox {

    // T is a "type placeholder". It is filled in when someone makes a Box.
    static class Box<T> {
        private T item;                 // the thing inside, of the labeled type

        public void put(T item) {       // can only put the labeled type in
            this.item = item;
        }

        public T get() {                // get back exactly that type, no cast
            return item;
        }

        public boolean isEmpty() {
            return item == null;
        }
    }

    public static void main(String[] args) {
        // A box labeled for Strings
        Box<String> nameBox = new Box<>();
        nameBox.put("Alice");
        String name = nameBox.get();        // no cast needed
        System.out.println("name box holds   : " + name);

        // The SAME Box design, now labeled for Integers
        Box<Integer> ageBox = new Box<>();
        ageBox.put(30);
        int age = ageBox.get();             // unboxes Integer -> int
        System.out.println("age box holds    : " + age);

        // nameBox.put(123);  // <-- would NOT compile: wrong label

        // A fresh box is empty
        Box<Double> priceBox = new Box<>();
        System.out.println("price box empty? : " + priceBox.isEmpty());
        priceBox.put(9.99);
        System.out.println("price box empty? : " + priceBox.isEmpty() + " -> " + priceBox.get());
    }
}
