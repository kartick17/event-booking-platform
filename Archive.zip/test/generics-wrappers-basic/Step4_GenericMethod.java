// STEP 4 — A generic METHOD: one helper that works for any label
// Analogy: a shop worker who can handle a box of ANY label.
//   You don't write one worker for String boxes and another for Integer boxes.
//   You write ONE worker, and the <T> tells Java to figure out the type per call.
//
// Run with:  java Step4_GenericMethod.java

public class Step4_GenericMethod {

    // The <T> before the return type means: this method has its own type slot.
    // It works for an array of ANY type and prints each item.
    static <T> void printAll(T[] items) {
        for (T item : items) {
            System.out.println("  - " + item);
        }
    }

    // Another generic method: return the first item of any array.
    static <T> T first(T[] items) {
        return items[0];
    }

    // Swap two items in any array. Same method, any type.
    static <T> void swap(T[] items, int i, int j) {
        T temp = items[i];
        items[i] = items[j];
        items[j] = temp;
    }

    public static void main(String[] args) {
        String[] fruits = { "apple", "banana", "cherry" };
        Integer[] scores = { 90, 80, 70 };

        System.out.println("fruits:");
        printAll(fruits);                 // T becomes String here

        System.out.println("scores:");
        printAll(scores);                 // T becomes Integer here

        System.out.println("first fruit : " + first(fruits));
        System.out.println("first score : " + first(scores));

        swap(fruits, 0, 2);
        System.out.print("after swap  : ");
        printAll(fruits);
    }
}
