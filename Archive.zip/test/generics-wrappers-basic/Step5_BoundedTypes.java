// STEP 5 — Bounded generics: a shelf that only takes NUMBER boxes
// Analogy: a special shelf marked "numbers only". You can put a Box<Integer>
//   or Box<Double> on it, but not a Box<String>. Because the shop KNOWS every
//   item is a number, the worker is allowed to do number things (add them up).
//
// <T extends Number> means: T must be Number or a subtype (Integer, Double...).
// That promise lets us call number methods like doubleValue() safely.
//
// Run with:  java Step5_BoundedTypes.java

import java.util.List;

public class Step5_BoundedTypes {

    // Without the bound, we could not call .doubleValue() — Java wouldn't know
    // the items are numbers. The "extends Number" bound unlocks that.
    static <T extends Number> double sum(List<T> numbers) {
        double total = 0;
        for (T n : numbers) {
            total += n.doubleValue();     // allowed because T IS a Number
        }
        return total;
    }

    static <T extends Number> double average(List<T> numbers) {
        if (numbers.isEmpty()) return 0;
        return sum(numbers) / numbers.size();
    }

    public static void main(String[] args) {
        List<Integer> ints = List.of(10, 20, 30);
        List<Double> doubles = List.of(1.5, 2.5, 4.0);

        System.out.println("sum of ints     : " + sum(ints));
        System.out.println("sum of doubles  : " + sum(doubles));
        System.out.println("avg of ints     : " + average(ints));
        System.out.println("avg of doubles  : " + average(doubles));

        // sum(List.of("a", "b"));  // <-- would NOT compile: String is not a Number
        System.out.println();
        System.out.println("The 'extends Number' bound is a promise: every item is a");
        System.out.println("number, so calling doubleValue() is safe.");
    }
}
