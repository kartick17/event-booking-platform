# 📦 Practice — Fill in the Blanks (Basic)

Each file is a step with the key lines removed and marked `// TODO:`. Write the
missing code, then run it. Answer key: the matching finished file in the folder
above (`../Step*.java`).

## How to practice
1. Read the matching step in `../GUIDE.md`.
2. Open a practice file, fill every `// TODO`.
3. Run it (no compiler needed):
   ```bash
   java Step1_Wrappers_Practice.java
   java Step2_WhyGenerics_Practice.java
   java Step3_GenericBox_Practice.java
   java Step4_GenericMethod_Practice.java
   java Step5_BoundedTypes_Practice.java
   ```
4. Stuck? Compare with `../Step*.java`.

## The topics to read (in order)
1. **Step 1** → wrapper classes, autobox/unbox → store a primitive as an object.
2. **Step 2** → raw type vs `List<String>` → see why labels matter.
3. **Step 3** → generic class `Box<T>` → build your own typed container.
4. **Step 4** → generic method `<T>` → one helper for every type.
5. **Step 5** → bound `<T extends Number>` → numeric math on a generic.

## Self-check: did it work?
| Step | What correct output looks like |
|------|--------------------------------|
| 1 | ends with `unpacking an empty box throws: NullPointerException` |
| 2 | shows a `ClassCastException`, then a safe labeled read |
| 3 | `name box holds : Alice`, `age box holds : 30` |
| 4 | both arrays print; `first fruit : apple` |
| 5 | `sum of ints : 60.0`, `avg of ints : 20.0` |
