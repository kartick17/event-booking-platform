// PRACTICE — STEP 1: Wrapper classes
// Topic: primitives vs wrappers, autoboxing, unboxing, the null trap
// Goal: store a primitive as an object, then unpack it again.
// Fill in every // TODO. Answer key: ../Step1_Wrappers.java
//
// Run when done:  java Step1_Wrappers_Practice.java

import java.util.ArrayList;
import java.util.List;

public class Step1_Wrappers_Practice {

    public static void main(String[] args) {
        int looseCoin = 42;

        // TODO: autobox looseCoin into an Integer wrapper called boxedCoin.
        // YOUR CODE HERE
        Integer boxedCoin = /* TODO */ null;

        System.out.println("boxed wrapper   : " + boxedCoin);  // expect 42

        // TODO: unbox boxedCoin and add 8, store in int backToLoose.
        // YOUR CODE HERE
        int backToLoose = /* TODO */ 0;
        System.out.println("unboxed + 8     : " + backToLoose); // expect 50

        // TODO: make a List that holds Integer (a "shelf of boxes"), then add 10, 20, 30.
        // YOUR CODE HERE
        List<Integer> shelf = /* TODO */ new ArrayList<>();
        // TODO: add 10, 20, 30 to shelf

        System.out.println("shelf of boxes  : " + shelf);       // expect [10, 20, 30]

        // TODO: use a wrapper helper to parse "123" into an int and add 1.
        // YOUR CODE HERE
        int parsed = /* TODO */ 0;
        System.out.println("parse 123 + 1   : " + parsed);      // expect 124

        Integer emptyBox = null;
        try {
            int crash = emptyBox;   // unpacking an empty box
            System.out.println(crash);
        } catch (NullPointerException e) {
            System.out.println("empty box throws: NullPointerException");
        }
    }
}
