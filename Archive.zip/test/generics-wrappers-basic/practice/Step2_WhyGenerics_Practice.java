// PRACTICE — STEP 2: Why generics exist
// Topic: raw type (unlabeled box) vs List<String> (labeled box)
// Goal: feel the run-time crash from a raw list, then the safety of a label.
// Fill in every // TODO. Answer key: ../Step2_WhyGenerics.java
//
// Run when done:  java Step2_WhyGenerics_Practice.java

import java.util.ArrayList;
import java.util.List;

public class Step2_WhyGenerics_Practice {

    public static void main(String[] args) {
        // A raw (unlabeled) list — given to you on purpose.
        List unlabeled = new ArrayList();
        unlabeled.add("apple");
        unlabeled.add(123);

        try {
            // TODO: cast element 1 to String (it is really 123 -> will crash).
            // YOUR CODE HERE
            String wrong = /* TODO */ "";
            System.out.println(wrong);
        } catch (ClassCastException e) {
            System.out.println("guessed wrong -> ClassCastException at RUN time");
        }

        // TODO: make a LABELED list of String called labeled, then add "apple".
        // YOUR CODE HERE
        List<String> labeled = /* TODO */ new ArrayList<>();
        // TODO: add "apple" to labeled

        // TODO: read element 0 into a String WITHOUT a cast.
        // YOUR CODE HERE
        String safe = /* TODO */ "";
        System.out.println("labeled read    : " + safe + " (no cast)"); // expect apple
    }
}
