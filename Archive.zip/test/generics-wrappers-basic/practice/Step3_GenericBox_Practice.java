// PRACTICE — STEP 3: Your own generic class Box<T>
// Topic: generic class, type parameter T
// Goal: build a typed container that works for any type.
// Fill in every // TODO. Answer key: ../Step3_GenericBox.java
//
// Run when done:  java Step3_GenericBox_Practice.java

public class Step3_GenericBox_Practice {

    // TODO: make this class generic by adding the type parameter after the name.
    //       Then make 'item' of type T, 'put' take a T, and 'get' return a T.
    static class Box /* TODO: <T> */ {
        // TODO: declare the field of type T
        private Object item;          // TODO: change Object to T

        // TODO: change the parameter type to T
        public void put(Object item) {  // TODO
            this.item = item;
        }

        // TODO: change the return type to T
        public Object get() {           // TODO
            return item;
        }

        public boolean isEmpty() {
            return item == null;
        }
    }

    public static void main(String[] args) {
        // TODO: make a Box labeled for String, put "Alice", get it back into a String.
        // YOUR CODE HERE
        Box nameBox = new Box();         // TODO: Box<String>
        nameBox.put("Alice");
        Object name = nameBox.get();      // TODO: read into a String, no cast
        System.out.println("name box holds : " + name);   // expect Alice

        // TODO: make a Box labeled for Integer, put 30, read into an int.
        // YOUR CODE HERE
        Box ageBox = new Box();          // TODO: Box<Integer>
        ageBox.put(30);
        Object age = ageBox.get();        // TODO: read into an int
        System.out.println("age box holds  : " + age);    // expect 30
    }
}
