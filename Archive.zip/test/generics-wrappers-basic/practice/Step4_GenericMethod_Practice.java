// PRACTICE — STEP 4: Generic method <T>
// Topic: a single method that works for any type
// Goal: write printAll, first, and swap using a type parameter.
// Fill in every // TODO. Answer key: ../Step4_GenericMethod.java
//
// Run when done:  java Step4_GenericMethod_Practice.java

public class Step4_GenericMethod_Practice {

    // TODO: add the type parameter <T> before void, and make items a T[].
    static void printAll(Object[] items) {   // TODO: <T> void printAll(T[] items)
        for (Object item : items) {           // TODO: T item
            System.out.println("  - " + item);
        }
    }

    // TODO: add <T> and return T; the parameter is T[].
    static Object first(Object[] items) {     // TODO: <T> T first(T[] items)
        return items[0];
    }

    // TODO: add <T> and make this swap any T[] in place.
    static void swap(Object[] items, int i, int j) {  // TODO: <T> void swap(T[] items, int i, int j)
        Object temp = items[i];                // TODO: T temp
        items[i] = items[j];
        items[j] = temp;
    }

    public static void main(String[] args) {
        String[] fruits = { "apple", "banana", "cherry" };
        Integer[] scores = { 90, 80, 70 };

        System.out.println("fruits:");
        printAll(fruits);
        System.out.println("first fruit : " + first(fruits));   // expect apple

        swap(fruits, 0, 2);
        System.out.print("after swap  :");
        printAll(fruits);                                       // cherry, banana, apple
    }
}
