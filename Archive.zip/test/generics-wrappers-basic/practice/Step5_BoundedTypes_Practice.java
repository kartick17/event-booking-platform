// PRACTICE — STEP 5: Bounded generics <T extends Number>
// Topic: an upper bound that unlocks number methods
// Goal: sum and average any list of numbers.
// Fill in every // TODO. Answer key: ../Step5_BoundedTypes.java
//
// Run when done:  java Step5_BoundedTypes_Practice.java

import java.util.List;

public class Step5_BoundedTypes_Practice {

    // TODO: bound T so it must be a Number, so n.doubleValue() is allowed.
    static double sum(List<? /* TODO: T extends Number */> numbers) {
        double total = 0;
        for (Object n : numbers) {                 // TODO: T n
            // TODO: add n.doubleValue() to total
            // YOUR CODE HERE
        }
        return total;
    }

    // TODO: same bound here; reuse sum().
    static double average(List<? /* TODO: T extends Number */> numbers) {
        if (numbers.isEmpty()) return 0;
        // TODO: return sum(numbers) / numbers.size();
        return 0; // TODO
    }

    public static void main(String[] args) {
        List<Integer> ints = List.of(10, 20, 30);
        List<Double> doubles = List.of(1.5, 2.5, 4.0);

        System.out.println("sum of ints    : " + sum(ints));      // expect 60.0
        System.out.println("avg of ints    : " + average(ints));  // expect 20.0
        System.out.println("sum of doubles : " + sum(doubles));   // expect 8.0
    }
}
