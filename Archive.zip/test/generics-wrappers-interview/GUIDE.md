# 🏷️ Typed Inventory Repository — Full Learning Guide (Interview)

## 1. What is this project?
A small **inventory system**. Products are stored in a typed, in-memory
repository keyed by SKU. Around it sit the tools an interviewer probes: bounded
generics, generic methods, wildcards (PECS), Optional, safe wrapper parsing, and
the classic traps (Integer cache, type erasure). Same two topics as the basic
pack — generics and wrapper classes — but at production depth.

## 2. What you will learn
| Need | Plain-English meaning | Tool | Step |
|------|----------------------|------|------|
| Store any typed entity, no casts | one store, many entity types | generic class + bound | 1 |
| Make "missing" part of the type | can't forget the not-found case | `Optional<T>` | 2 |
| Accept any kind of number to read | read-only input is flexible | `? extends Number` | 3 |
| Copy between lists safely | producer vs consumer rules | PECS `? super` / `? extends` | 4 |
| Parse raw text without surprises | strict and lenient parsing | wrapper `parseInt` / `valueOf` | 5 |
| Compare wrapper values correctly | never `==` on objects | Integer cache + `.equals` | 6 |
| Know what generics can't do | types vanish at run time | type erasure | 7 |

## 3. The big picture
```
   Product (record, id = SKU) ── implements ──> Entity<String>
        |                                            ^
        | save / findById / findAll                  | bound: T extends Entity<ID>
        v                                            |
   Repository<String, Product>  <— InMemoryRepository (LinkedHashMap)
        |
        | findAll() -> List<Product>
        v
   NumberLists.sum( ? extends Number )    <- generic methods + wildcards (PECS)
   Config.requireQuantity( String )       <- wrapper parsing
```

## 4. Project files
```
RepositoryRun.java                          (NEW FILE)  single-file runnable mirror
src/com/inventory/model/Entity.java         (NEW FILE)  the bound
src/com/inventory/model/Product.java        (NEW FILE)  record entity
src/com/inventory/repo/Repository.java      (NEW FILE)  generic interface
src/com/inventory/repo/InMemoryRepository.java (NEW FILE) implementation
src/com/inventory/util/NumberLists.java      (NEW FILE)  generic methods + wildcards
src/com/inventory/config/Config.java         (NEW FILE)  wrapper parsing
src/com/inventory/Main.java                  (NEW FILE)  packaged entry point
```

---

# STEP 1 — Generic class with a bound: `Repository<ID, T extends Entity<ID>>`

### Concept
The repository takes **two** type parameters that are tied together: `ID` is the
key type, and `T extends Entity<ID>` means the stored type's id IS that key type.
The bound is what lets `save` call `entity.getId()` directly — no cast, no
reflection — while staying fully type-safe.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why the bound wins |
|-------------|---------|--------------------|
| `Repository` of `Object` | casts everywhere, run-time `ClassCastException` | bound keeps it compile-checked |
| One class per entity (`ProductRepo`, `OrderRepo`) | copy-paste, drift | one generic class serves all |
| `T` with no bound | can't call `getId()` — T is just Object | `T extends Entity<ID>` unlocks `getId()` |

### Code — `src/com/inventory/repo/Repository.java` + `InMemoryRepository.java` (NEW FILE)
```java
public interface Repository<ID, T extends Entity<ID>> {
    T save(T entity);
    Optional<T> findById(ID id);
    List<T> findAll();
    boolean deleteById(ID id);
    int count();
}
```

### How to test
```bash
java RepositoryRun.java
```
Shows `count : 3`, `findById SKU-2 : Notebook`, `after delete : 2`.

### Interview defense
"A generic class with the bound `T extends Entity<ID>` gives one type-safe store
for every entity type. The bound is not decoration — it's what lets the impl call
`getId()` without a cast. I tie `ID` and `T` together so the key type can't drift
from the entity's id type."

---

# STEP 2 — `Optional<T>` instead of null

### Concept
`findById` returns `Optional<T>`, not a raw `T` that might be null. "Not found"
becomes part of the return type, so the caller is forced to handle it
(`.orElseThrow()`, `.map(...)`), and there's no silent NPE later.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why Optional wins |
|-------------|---------|-------------------|
| return `null` | callers forget the null check → NPE | type makes "absent" explicit |
| throw when missing | "not found" is normal, not exceptional | Optional models it without control-flow by exception |

### Code — in `Repository` / `InMemoryRepository`
```java
public Optional<T> findById(ID id) {
    return Optional.ofNullable(store.get(id));
}
```

### How to test
`java RepositoryRun.java` → `findById missing : Optional.empty`.

### Interview defense
"Returning `Optional<T>` puts 'might be absent' into the type system. It's the
right tool when absence is a normal outcome; I'd still throw for truly
exceptional states. It removes a whole class of NPEs at the call site."

---

# STEP 3 — Wildcard `? extends Number` (Producer Extends)

### Concept
`sum(List<? extends Number>)` only **reads** from the list, so it accepts a list
of *any* subtype of Number — `List<Integer>`, `List<Double>`, etc. The wildcard
makes a read-only method flexible without losing safety.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why `? extends` wins |
|-------------|---------|----------------------|
| `List<Number>` | rejects `List<Integer>` (not the same type) | wildcard accepts all subtypes |
| `<T extends Number> sum(List<T>)` | needs a named T you never use | wildcard is simpler when T isn't referenced |
| raw `List` | unsafe, unchecked warning | wildcard keeps it checked |

### Code — `src/com/inventory/util/NumberLists.java`
```java
public static double sum(List<? extends Number> numbers) {
    double total = 0;
    for (Number n : numbers) total += n.doubleValue();
    return total;
}
```

### How to test
`java RepositoryRun.java` → `sum (Number) : 1898.0`, `sum (Double) : 4.0`.

### Interview defense
"`? extends Number` is the Producer-Extends half of PECS: the list only produces
values for me to read, so I accept any subtype. If I'd written `List<Number>` I
couldn't pass a `List<Integer>`. I use a named `<T>` only when I need to refer to
the element type."

---

# STEP 4 — Full PECS: `? super T` and `? extends T`

### Concept
`copyInto(List<? super T> dest, List<? extends T> src)` reads from `src` (a
producer → `extends`) and writes into `dest` (a consumer → `super`). That's the
whole PECS rule in one signature: **P**roducer **E**xtends, **C**onsumer
**S**uper.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why PECS wins |
|-------------|---------|---------------|
| `copyInto(List<T> dest, List<T> src)` | both must be the exact same type | wildcards allow `Number` dest, `Integer` src |
| swap the wildcards | can't write to `? extends`, can't read useful type from `? super` | PECS puts each on the correct side |

### Code — `src/com/inventory/util/NumberLists.java`
```java
public static <T> void copyInto(List<? super T> dest, List<? extends T> src) {
    for (T item : src) dest.add(item);
}
```

### How to test
`java RepositoryRun.java` → `copied into : [1299, 599, 3.14]` (Integers and a Double into a `List<Number>`).

### Interview defense
"PECS decides wildcard direction: a producer you read from is `? extends`, a
consumer you write to is `? super`. `copyInto` does both, so dest is `? super T`
and src is `? extends T`. Get it backwards and the compiler won't let you read or
write — which is the point."

---

# STEP 5 — Wrapper parsing done right

### Concept
Two parse styles. `requireQuantity` is strict: parse or throw an
`IllegalArgumentException` with context (it wraps the low-level
`NumberFormatException`). `tryParseInt` is lenient: returns `Optional<Integer>`,
empty on bad input, never throws. Pick by whether the value is required.

### Why this tool (vs the alternatives)
| Alternative | Problem | Why this wins |
|-------------|---------|---------------|
| let `NumberFormatException` escape | message lacks context | wrap it with the bad input + cause |
| return -1 / 0 on failure | magic value confused with real data | Optional has no magic value |

### Code — `src/com/inventory/config/Config.java`
```java
public static int requireQuantity(String raw) {
    try {
        int qty = Integer.parseInt(raw.trim());
        if (qty < 0) throw new IllegalArgumentException("quantity < 0: " + qty);
        return qty;
    } catch (NumberFormatException e) {
        throw new IllegalArgumentException("not a quantity: '" + raw + "'", e);
    }
}
```

### How to test
`java RepositoryRun.java` → `requireQuantity : 42`, `tryParseInt bad : Optional.empty`, `clear failure : not a quantity: 'ten'`.

### Interview defense
"`Integer.parseInt` returns a primitive and throws `NumberFormatException`; I wrap
that with context so the caller sees the bad input and the cause. For optional
config I return `Optional<Integer>` rather than a sentinel like -1, which can be
mistaken for real data."

---

# STEP 6 — The Integer-cache pitfall (`==` vs `.equals`)

### Concept
Java caches small `Integer` objects (-128..127). So `==` (same object) looks
correct for `127` but fails for `1000`, where the two boxes are different
objects. **Always** compare wrapper values with `.equals` (or unbox to
primitives).

### Why this matters
`==` on wrappers compares identity, not value. The cache hides the bug for small
numbers, so it passes your quick test and breaks in production with bigger ones.

### Code — in `RepositoryRun.java`
```java
Integer a = 127, b = 127;     // cached -> a == b is true (by luck)
Integer c = 1000, d = 1000;   // not cached -> c == d is false
c.equals(d);                  // true -> the correct way
```

### How to test
`java RepositoryRun.java` → `1000 == 1000 : false`, `1000.equals(1000): true`.

### Interview defense
"Autoboxing reuses cached Integer instances from -128 to 127, so `==` accidentally
works for small values and breaks above 127. `==` tests reference identity;
`.equals` tests value. I always use `.equals` or unbox first."

---

# STEP 7 — Type erasure (the limits)

### Concept
Generics are a compile-time feature. At run time the type argument is **erased** —
`List<String>` and `List<Integer>` are both just `ArrayList`. That's why you
can't do `new T[]`, `obj instanceof T`, or use a primitive as a type argument
(`List<int>` is illegal — use `List<Integer>`).

### Why this matters
It explains real limits you'll hit: no generic arrays, no reflection on `T`, and
why every instance of a generic class shares one runtime class.

### Code — in `RepositoryRun.java`
```java
List<String> ls = new ArrayList<>();
List<Integer> li = new ArrayList<>();
ls.getClass() == li.getClass();   // true -> same runtime class
```

### How to test
`java RepositoryRun.java` → `ls.getClass() == li.getClass() ? true`.

### Interview defense
"Generics use type erasure: the parameter is checked at compile time then removed,
so there's one runtime class for all instantiations. That's why `new T[]` and
`instanceof T` don't compile, and why I pass a `Class<T>` token when I truly need
the type at run time."

---

## How to run everything
**No compiler:**
```bash
java RepositoryRun.java
```
**Packaged (needs javac):**
```bash
javac -d out $(find src -name "*.java")
java -cp out com.inventory.Main
```

## Cheat sheet (one line per tool)
| Tool | What it does |
|------|--------------|
| `class Repo<ID, T extends Entity<ID>>` | generic class with a bound; tie key type to entity id |
| `T extends Entity<ID>` | upper bound — unlocks the bound type's methods (`getId()`) |
| `Optional<T>` | makes "absent" part of the return type; kills a class of NPEs |
| `? extends Number` | Producer Extends — read-only input, any subtype |
| `? super T` | Consumer Super — write-target, any supertype |
| PECS | Producer Extends, Consumer Super — picks wildcard direction |
| `<T extends Comparable<? super T>>` | bounded generic method for ordering |
| `Integer.parseInt` / `valueOf` | text → number; `parseInt` is primitive, `valueOf` is cached wrapper |
| Integer cache (-128..127) | why `==` on wrappers is a bug; use `.equals` |
| type erasure | `T` is gone at run time; no `new T[]`, no `instanceof T` |

## Where to go next
1. **`Class<T>` type tokens** — keep type info past erasure (`enum` of class, `cast`).
2. **Recursive generics** — `class Builder<T extends Builder<T>>` (self-typing).
3. **`Comparator<T>` chaining** — `comparing().thenComparing()` with generics.
4. **Generic functional interfaces** — `Function<T,R>`, `Supplier<T>`, streams.
5. **Bounded type tokens + reflection** — when erasure forces a `Class<T>` argument.
