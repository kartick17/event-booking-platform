# 🏷️ Typed Inventory Repository — Generics & Wrappers (Interview) — Start Here

The same two topics as the basic pack, written the way a strong engineer would
for a senior interview: a **typed in-memory repository**, bounded generics,
wildcards (PECS), Optional-based lookups, safe wrapper parsing, and the gotchas
(Integer cache, type erasure) you'll be asked about.

## What you need on the other system
1. **Java 11+** (tested on Java 17; uses `record`, so Java 16+ for the packaged form).
   Check with: `java -version`
   - **No compiler needed** for the single-file mirror `RepositoryRun.java`.
   - To compile the packaged `src/` you need `javac` (full JDK):
     Ubuntu/Debian `sudo apt install default-jdk`, Mac `brew install openjdk`,
     Windows: Temurin from https://adoptium.net
2. Any text editor.

## What's in this folder
```
generics-wrappers-interview/
├── README.md                    you are here
├── GUIDE.md                     full lesson with "why this tool over the alternatives"
├── RepositoryRun.java           SELF-CONTAINED single-file version (runs with no compiler)
├── src/com/inventory/           clean packaged version (needs javac)
│   ├── model/Entity.java        the bound: Entity<ID>
│   ├── model/Product.java       a record entity (id = SKU)
│   ├── repo/Repository.java     generic interface Repository<ID, T extends Entity<ID>>
│   ├── repo/InMemoryRepository.java   map-backed implementation
│   ├── util/NumberLists.java    generic methods + wildcards (PECS)
│   ├── config/Config.java       safe wrapper parsing (strict + Optional)
│   └── Main.java                packaged entry point
└── practice/
    ├── PRACTICE.md
    ├── Repository_Practice.java   build the generic class + bound
    └── Wildcards_Practice.java     fill in the PECS method signatures
```

## How to learn (suggested order)
1. Read **GUIDE.md** top to bottom (each step has a "why this tool" table).
2. Run the single-file version and match the output.
3. Read the packaged `src/` to see the production shape.
4. Practice: fill in the `practice/` blanks.

## How to run
**No compiler (works anywhere with `java`):**
```bash
java RepositoryRun.java
```

**Full packaged build (needs `javac`):**
```bash
javac -d out $(find src -name "*.java")
java -cp out com.inventory.Main
```

## Quick map: step → concept → tool
| Step | Concept | Tool |
|------|---------|------|
| 1 | Store any typed entity safely | generic class + bound `Repository<ID, T extends Entity<ID>>` |
| 2 | "Not found" without null | `Optional<T>` return |
| 3 | Read-only generic input | wildcard `? extends Number` (Producer Extends) |
| 4 | Copy between lists safely | full PECS `? super T` / `? extends T` |
| 5 | Parse raw text safely | wrapper `Integer.parseInt` / `valueOf` + Optional |
| 6 | Avoid `==` on wrappers | Integer cache pitfall, use `.equals` |
| 7 | Know the limits | type erasure |
