// ============================================================================
// RepositoryRun.java — SELF-CONTAINED single-file version (no compiler needed)
// Run with:  java RepositoryRun.java
//
// Real scenario: a small INVENTORY system. It shows the same generics and
// wrapper-class tools as the packaged src/ version, but all in one file so it
// runs on a runtime-only machine (no javac). The packaged version under
// src/com/inventory/ is the "production shape"; this is the runnable mirror.
//
// What it demonstrates:
//   1) Wrapper classes done right  -> safe parsing + the Integer cache pitfall
//   2) Generic class with bounds   -> Repository<ID, T extends Entity<ID>>
//   3) Generic methods + wildcards -> NumberStats (PECS: extends to read)
//   4) Type erasure                -> why you can't do `new T[]` or `x instanceof T`
// ============================================================================

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class RepositoryRun {

    // ------------------------------------------------------------------ //
    // 1) DOMAIN MODEL
    //    Entity<ID> is the bound: anything stored must expose a typed id.
    // ------------------------------------------------------------------ //
    interface Entity<ID> {
        ID getId();
    }

    // A record is an immutable data carrier. Product is identified by a String SKU.
    record Product(String getId, String name, int priceCents) implements Entity<String> {
        Product {
            Objects.requireNonNull(getId, "sku");
            Objects.requireNonNull(name, "name");
            if (priceCents < 0) throw new IllegalArgumentException("priceCents < 0");
        }
    }

    // ------------------------------------------------------------------ //
    // 2) GENERIC CLASS WITH A BOUND
    //    Repository<ID, T extends Entity<ID>>:
    //      - two type parameters, tied together (T's id type IS ID)
    //      - the bound lets us call entity.getId() safely
    //    findById returns Optional<T> instead of null (no NPE surprises).
    // ------------------------------------------------------------------ //
    interface Repository<ID, T extends Entity<ID>> {
        T save(T entity);
        Optional<T> findById(ID id);
        List<T> findAll();
        boolean deleteById(ID id);
        int count();
    }

    static final class InMemoryRepository<ID, T extends Entity<ID>>
            implements Repository<ID, T> {

        // LinkedHashMap keeps insertion order so findAll() is predictable.
        private final Map<ID, T> store = new LinkedHashMap<>();

        @Override
        public T save(T entity) {
            Objects.requireNonNull(entity, "entity");
            store.put(entity.getId(), entity);   // getId() works thanks to the bound
            return entity;
        }

        @Override
        public Optional<T> findById(ID id) {
            return Optional.ofNullable(store.get(id));
        }

        @Override
        public List<T> findAll() {
            // defensive copy: callers can't mutate our internal store
            return new ArrayList<>(store.values());
        }

        @Override
        public boolean deleteById(ID id) {
            return store.remove(id) != null;
        }

        @Override
        public int count() {
            return store.size();
        }
    }

    // ------------------------------------------------------------------ //
    // 3) GENERIC METHODS + WILDCARDS (PECS = Producer Extends, Consumer Super)
    //    - sum/max READ from the list (the list is a producer) -> ? extends Number
    //    - copyInto WRITES into dest (a consumer) and reads from src (producer)
    // ------------------------------------------------------------------ //
    static final class Collections2 {
        private Collections2() {}

        // Producer: we only read numbers out, so accept any subtype of Number.
        static double sum(List<? extends Number> numbers) {
            double total = 0;
            for (Number n : numbers) total += n.doubleValue();
            return total;
        }

        // Bounded generic method: T must be Comparable to itself, so we can order it.
        static <T extends Comparable<? super T>> T max(List<? extends T> items) {
            if (items.isEmpty()) throw new IllegalArgumentException("empty list");
            T best = items.get(0);
            for (T candidate : items) {
                if (candidate.compareTo(best) > 0) best = candidate;
            }
            return best;
        }

        // Full PECS: read from src (extends), write into dest (super).
        static <T> void copyInto(List<? super T> dest, List<? extends T> src) {
            for (T item : src) dest.add(item);
        }
    }

    // ------------------------------------------------------------------ //
    // 4) WRAPPER CLASSES DONE RIGHT
    //    Safe parsing with clear errors, plus the famous Integer-cache pitfall.
    // ------------------------------------------------------------------ //
    static final class Config {
        private Config() {}

        // Parse a quantity from raw text. Wrappers give us parseInt + a typed
        // failure we can wrap with context instead of a bare NumberFormatException.
        static int requireQuantity(String raw) {
            try {
                int qty = Integer.parseInt(raw.trim());
                if (qty < 0) throw new IllegalArgumentException("quantity < 0: " + qty);
                return qty;
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("not a quantity: '" + raw + "'", e);
            }
        }

        // Optional-based parse: missing/garbage -> empty, never an exception.
        static Optional<Integer> tryParseInt(String raw) {
            if (raw == null) return Optional.empty();
            try {
                return Optional.of(Integer.valueOf(raw.trim()));
            } catch (NumberFormatException e) {
                return Optional.empty();
            }
        }
    }

    // ------------------------------------------------------------------ //
    // MAIN — prove every piece works.
    // ------------------------------------------------------------------ //
    public static void main(String[] args) {
        System.out.println("== 1) Typed repository (generic class + bound) ==");
        Repository<String, Product> products = new InMemoryRepository<>();
        products.save(new Product("SKU-1", "Coffee Mug", 1299));
        products.save(new Product("SKU-2", "Notebook", 599));
        products.save(new Product("SKU-3", "Pen", 199));

        System.out.println("count            : " + products.count());
        System.out.println("findById SKU-2   : " + products.findById("SKU-2").orElseThrow().name());
        System.out.println("findById missing : " + products.findById("SKU-9")); // Optional.empty
        products.deleteById("SKU-3");
        System.out.println("after delete     : " + products.count());

        System.out.println();
        System.out.println("== 2) Generic methods + wildcards (PECS) ==");
        List<Integer> cents = new ArrayList<>();
        for (Product p : products.findAll()) cents.add(p.priceCents());
        System.out.println("prices (cents)   : " + cents);
        System.out.println("sum (Number)     : " + Collections2.sum(cents));      // reads Integers
        System.out.println("sum (Double)     : " + Collections2.sum(List.of(1.5, 2.5)));
        System.out.println("max price        : " + Collections2.max(cents));

        List<Number> mixed = new ArrayList<>();
        Collections2.copyInto(mixed, cents);          // dest is List<? super Integer>
        Collections2.copyInto(mixed, List.of(3.14));  // also accepts Doubles
        System.out.println("copied into      : " + mixed);

        System.out.println();
        System.out.println("== 3) Wrapper classes done right ==");
        System.out.println("requireQuantity  : " + Config.requireQuantity("  42 "));
        System.out.println("tryParseInt good : " + Config.tryParseInt("100"));
        System.out.println("tryParseInt bad  : " + Config.tryParseInt("oops"));
        try {
            Config.requireQuantity("ten");
        } catch (IllegalArgumentException e) {
            System.out.println("clear failure    : " + e.getMessage());
        }

        System.out.println();
        System.out.println("== 4) Integer-cache pitfall (== vs equals) ==");
        Integer a = 127, b = 127;       // cached range -128..127 -> same object
        Integer c = 1000, d = 1000;     // outside cache -> different objects
        System.out.println("127 == 127       : " + (a == b) + "   (cached, but luck!)");
        System.out.println("1000 == 1000     : " + (c == d) + "  (different objects!)");
        System.out.println("1000.equals(1000): " + c.equals(d) + "   (ALWAYS use equals)");

        System.out.println();
        System.out.println("== 5) Type erasure (what generics CANNOT do) ==");
        // At run time the type T is erased. These are compile errors, shown as notes:
        //   new T[10]            -> cannot create a generic array
        //   obj instanceof T     -> cannot test an erased type
        //   List<int>            -> primitives can't be type args; use List<Integer>
        List<String> ls = new ArrayList<>();
        List<Integer> li = new ArrayList<>();
        System.out.println("ls.getClass() == li.getClass() ? "
                + (ls.getClass() == li.getClass()) + "  (both are just ArrayList at run time)");
        // Bonus: unmodifiable view to show defensive returns are real lists.
        System.out.println("findAll is a copy: "
                + (products.findAll() != products.findAll()));
        System.out.println(Collections.emptyList().isEmpty() ? "" : "");
    }
}
