# 🏷️ Practice — Fill in the Blanks (Interview)

Two focused drills on the parts interviewers push on: building a generic class
with a bound, and getting wildcard direction (PECS) right. Each file is
self-contained and runs with no compiler.

## How to practice
1. Read the matching step in `../GUIDE.md`.
2. Open a practice file, fill every `// TODO`.
3. Run it (no compiler needed):
   ```bash
   java Repository_Practice.java
   java Wildcards_Practice.java
   ```
4. Stuck? Compare with `../RepositoryRun.java` and the `../src/` files.

## The topics to read (in order)
1. **Repository_Practice** → Steps 1–2 → generic class + bound + `Optional`.
2. **Wildcards_Practice** → Steps 3–4 → `? extends`, `? super`, full PECS.

## Self-check: did it work?
| File | What correct output looks like |
|------|--------------------------------|
| Repository_Practice | `count : 2`, `find A : Apple`, `missing : Optional.empty` |
| Wildcards_Practice | `sum : 60.0`, `copied : [1, 2, 3, 4]` |
