// PRACTICE — STEPS 1-2: Generic class with a bound + Optional
// Topic: Repository<ID, T extends Entity<ID>>, Optional<T> lookups
// Goal: build a typed in-memory store that calls getId() via the bound.
// Fill in every // TODO. Answer key: ../src/com/inventory/repo/*.java
//
// Run when done:  java Repository_Practice.java

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Repository_Practice {

    // Everything stored must expose a typed id.
    interface Entity<ID> {
        ID getId();
    }

    record Item(String id, String name) implements Entity<String> {
        public String getId() { return id; }
    }

    // TODO: add the bound so T must be an Entity<ID> (so getId() is callable).
    static final class Repo<ID, T /* TODO: extends Entity<ID> */> {
        private final Map<ID, T> store = new LinkedHashMap<>();

        public T save(T entity) {
            // TODO: use entity.getId() as the map key.
            // (This only compiles once the bound above is in place.)
            // YOUR CODE HERE
            store.put(/* TODO */ null, entity);
            return entity;
        }

        // TODO: return Optional<T>, empty when the id is missing.
        public Optional<T> findById(ID id) {
            // YOUR CODE HERE
            return /* TODO */ Optional.empty();
        }

        public List<T> findAll() { return new ArrayList<>(store.values()); }
        public int count() { return store.size(); }
    }

    public static void main(String[] args) {
        Repo<String, Item> repo = new Repo<>();
        repo.save(new Item("A", "Apple"));
        repo.save(new Item("B", "Banana"));

        System.out.println("count   : " + repo.count());                       // expect 2
        System.out.println("find A  : " + repo.findById("A").map(Item::name).orElse("?")); // Apple
        System.out.println("missing : " + repo.findById("Z"));                 // Optional.empty
    }
}
