// PRACTICE — STEPS 3-4: Wildcards and PECS
// Topic: ? extends Number (producer), ? super T / ? extends T (full PECS)
// Goal: write a read-only sum and a safe copy between lists.
// As-given this runs with RAW types (you'll see an "unchecked" warning) — your
// job is to replace the raw types with the correct, type-safe wildcards.
// Fill in every // TODO. Answer key: ../src/com/inventory/util/NumberLists.java
//
// Run when done:  java Wildcards_Practice.java

import java.util.ArrayList;
import java.util.List;

public class Wildcards_Practice {

    // TODO: change the raw `List` to a list of ANY subtype of Number (read only).
    //       Hint: Producer Extends  ->  List<? extends Number>
    //       Then change `Object o` back to `Number n` and drop the cast.
    @SuppressWarnings({"rawtypes", "unchecked"})
    static double sum(List numbers) {                 // TODO: List<? extends Number> numbers
        double total = 0;
        for (Object o : numbers) {                    // TODO: for (Number n : numbers)
            total += ((Number) o).doubleValue();      // TODO: n.doubleValue()
        }
        return total;
    }

    // TODO: make this a generic method <T> with full PECS:
    //       dest is written to (consumer -> List<? super T>),
    //       src is read from   (producer -> List<? extends T>).
    @SuppressWarnings({"rawtypes", "unchecked"})
    static void copyInto(List dest, List src) {       // TODO: <T> void copyInto(List<? super T> dest, List<? extends T> src)
        for (Object item : src) {                     // TODO: for (T item : src)
            dest.add(item);
        }
    }

    public static void main(String[] args) {
        List<Integer> ints = List.of(10, 20, 30);
        System.out.println("sum     : " + sum(ints));            // expect 60.0
        System.out.println("sum dbl : " + sum(List.of(1.5, 2.5)));// expect 4.0

        List<Number> dest = new ArrayList<>();
        copyInto(dest, List.of(1, 2, 3));   // Integers into a List<Number>
        copyInto(dest, List.of(4));
        System.out.println("copied  : " + dest);                 // expect [1, 2, 3, 4]
    }
}
