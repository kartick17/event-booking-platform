package com.inventory;

import com.inventory.config.Config;
import com.inventory.model.Product;
import com.inventory.repo.InMemoryRepository;
import com.inventory.repo.Repository;
import com.inventory.util.NumberLists;

import java.util.ArrayList;
import java.util.List;

/**
 * Entry point for the packaged version. Mirrors RepositoryRun.java.
 *
 * <p>Build + run (needs the full JDK with javac):
 * <pre>
 *   cd generics-wrappers-interview
 *   javac -d out $(find src -name "*.java")
 *   java -cp out com.inventory.Main
 * </pre>
 * No compiler? Run the single-file mirror instead: {@code java RepositoryRun.java}
 */
public final class Main {

    public static void main(String[] args) {
        System.out.println("== Typed repository (generic class + bound) ==");
        Repository<String, Product> products = new InMemoryRepository<>();
        products.save(new Product("SKU-1", "Coffee Mug", 1299));
        products.save(new Product("SKU-2", "Notebook", 599));
        products.save(new Product("SKU-3", "Pen", 199));

        System.out.println("count          : " + products.count());
        System.out.println("findById SKU-2 : " + products.findById("SKU-2").orElseThrow().name());
        System.out.println("missing        : " + products.findById("SKU-9"));
        products.deleteById("SKU-3");
        System.out.println("after delete   : " + products.count());

        System.out.println("\n== Generic methods + wildcards (PECS) ==");
        List<Integer> cents = new ArrayList<>();
        for (Product p : products.findAll()) {
            cents.add(p.priceCents());
        }
        System.out.println("sum            : " + NumberLists.sum(cents));
        System.out.println("max            : " + NumberLists.max(cents));
        List<Number> mixed = new ArrayList<>();
        NumberLists.copyInto(mixed, cents);
        NumberLists.copyInto(mixed, List.of(3.14));
        System.out.println("copied         : " + mixed);

        System.out.println("\n== Wrapper classes done right ==");
        System.out.println("requireQuantity: " + Config.requireQuantity("  42 "));
        System.out.println("tryParseInt bad: " + Config.tryParseInt("oops"));

        System.out.println("\n== Integer cache pitfall ==");
        Integer c = 1000, d = 1000;
        System.out.println("1000 == 1000   : " + (c == d) + " (use equals: " + c.equals(d) + ")");
    }
}
