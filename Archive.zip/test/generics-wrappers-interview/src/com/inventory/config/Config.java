package com.inventory.config;

import java.util.Optional;

/**
 * Wrapper classes used the right way for reading raw input.
 *
 * <p>Two styles:
 * <ul>
 *   <li>{@link #requireQuantity} — strict: parse or throw a clear, contextful error.</li>
 *   <li>{@link #tryParseInt} — lenient: parse or return {@link Optional#empty()},
 *       never an exception. Good for optional config.</li>
 * </ul>
 *
 * <p>Note: we never compare wrapper objects with {@code ==}. The Integer cache
 * (-128..127) makes {@code ==} look right for small values and wrong for large
 * ones; {@code equals} is always correct.
 */
public final class Config {

    private Config() {
    }

    public static int requireQuantity(String raw) {
        try {
            int qty = Integer.parseInt(raw.trim());
            if (qty < 0) {
                throw new IllegalArgumentException("quantity < 0: " + qty);
            }
            return qty;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("not a quantity: '" + raw + "'", e);
        }
    }

    public static Optional<Integer> tryParseInt(String raw) {
        if (raw == null) {
            return Optional.empty();
        }
        try {
            return Optional.of(Integer.valueOf(raw.trim()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }
}
