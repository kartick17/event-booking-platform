package com.inventory.model;

/**
 * Anything the repository can store must expose a typed identifier.
 *
 * <p>This is the upper bound used by the repository
 * ({@code T extends Entity<ID>}). It ties the entity type to its id type, so the
 * compiler can guarantee {@code repo.findById(id)} takes the right kind of key.
 *
 * @param <ID> the type of this entity's identifier (e.g. String SKU, Long id)
 */
public interface Entity<ID> {
    ID getId();
}
