package com.inventory.model;

import java.util.Objects;

/**
 * An inventory item, identified by a String SKU.
 *
 * <p>A {@code record} is an immutable data carrier — final fields, a canonical
 * constructor, and {@code equals}/{@code hashCode}/{@code toString} generated for
 * you. We validate in the compact constructor so a Product can never be built in
 * a broken state.
 */
public record Product(String sku, String name, int priceCents) implements Entity<String> {

    public Product {
        Objects.requireNonNull(sku, "sku");
        Objects.requireNonNull(name, "name");
        if (priceCents < 0) {
            throw new IllegalArgumentException("priceCents < 0: " + priceCents);
        }
    }

    /** The Entity contract: the SKU is this product's id. */
    @Override
    public String getId() {
        return sku;
    }
}
