package com.inventory.repo;

import com.inventory.model.Entity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Simple {@link Repository} backed by a map.
 *
 * <p>{@link LinkedHashMap} keeps insertion order, so {@link #findAll()} is
 * predictable. {@link #findAll()} returns a defensive copy so callers can't
 * mutate our internal state.
 */
public final class InMemoryRepository<ID, T extends Entity<ID>> implements Repository<ID, T> {

    private final Map<ID, T> store = new LinkedHashMap<>();

    @Override
    public T save(T entity) {
        Objects.requireNonNull(entity, "entity");
        store.put(entity.getId(), entity);   // getId() is available thanks to the bound
        return entity;
    }

    @Override
    public Optional<T> findById(ID id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<T> findAll() {
        return new ArrayList<>(store.values());
    }

    @Override
    public boolean deleteById(ID id) {
        return store.remove(id) != null;
    }

    @Override
    public int count() {
        return store.size();
    }
}
