package com.inventory.repo;

import com.inventory.model.Entity;

import java.util.List;
import java.util.Optional;

/**
 * A typed, in-memory store for entities.
 *
 * <p>Two type parameters, tied together:
 * <ul>
 *   <li>{@code ID} — the key type</li>
 *   <li>{@code T extends Entity<ID>} — the stored type, whose id IS that key type</li>
 * </ul>
 *
 * <p>The bound {@code T extends Entity<ID>} is what lets the implementation call
 * {@code entity.getId()} with no cast and no reflection. {@code findById} returns
 * {@link Optional} instead of {@code null}, so "not found" is part of the type and
 * can't be forgotten.
 */
public interface Repository<ID, T extends Entity<ID>> {

    T save(T entity);

    Optional<T> findById(ID id);

    List<T> findAll();

    boolean deleteById(ID id);

    int count();
}
