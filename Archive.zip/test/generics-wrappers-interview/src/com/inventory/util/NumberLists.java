package com.inventory.util;

import java.util.List;

/**
 * Generic methods over lists, showing wildcards and PECS
 * (Producer Extends, Consumer Super).
 *
 * <ul>
 *   <li>{@link #sum} only READS numbers (the list is a producer)
 *       → {@code ? extends Number}.</li>
 *   <li>{@link #max} needs items orderable against themselves
 *       → {@code T extends Comparable<? super T>}.</li>
 *   <li>{@link #copyInto} reads from src and writes to dest
 *       → full PECS: {@code dest} is {@code ? super T}, {@code src} is {@code ? extends T}.</li>
 * </ul>
 */
public final class NumberLists {

    private NumberLists() {
    }

    /** Producer: read-only, so accept any subtype of Number. */
    public static double sum(List<? extends Number> numbers) {
        double total = 0;
        for (Number n : numbers) {
            total += n.doubleValue();
        }
        return total;
    }

    /** Bounded generic method: T must be comparable to itself (or a supertype). */
    public static <T extends Comparable<? super T>> T max(List<? extends T> items) {
        if (items.isEmpty()) {
            throw new IllegalArgumentException("empty list");
        }
        T best = items.get(0);
        for (T candidate : items) {
            if (candidate.compareTo(best) > 0) {
                best = candidate;
            }
        }
        return best;
    }

    /** Full PECS: src produces (extends), dest consumes (super). */
    public static <T> void copyInto(List<? super T> dest, List<? extends T> src) {
        for (T item : src) {
            dest.add(item);
        }
    }
}
