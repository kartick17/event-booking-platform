# 🚗 Vehicle Factory — Full Learning Guide (Basic)

## 1. What is this project?
A **vehicle factory**. This one picture carries the whole of OOP:

- A **class** is the blueprint on paper. An **object** is a real vehicle built
  from it.
- A **constructor** is the build line — it sets up each new vehicle.
- **Encapsulation**: the fuel tank is sealed; you use the fuel cap, not your hand.
- **Inheritance**: a Car and a Truck are both Vehicles.
- **Polymorphism**: press "start" — each vehicle starts in its own way.
- **Abstraction**: you drive with pedals; the engine is hidden.

OOP just means organising code around **objects** — bundles of data + behaviour.

## 2. What you will learn
| Need | Plain-English meaning | Tool | Step |
|------|----------------------|------|------|
| Make real things from a design | blueprint → object, with setup | `class`, `new`, constructor | 1 |
| Stop bad data | lock the fields, guard with methods | `private` + getters/setters | 2 |
| Reuse a class | a child "is a" parent | `extends`, `super` | 3 |
| One call, many results | each object answers its own way | `@Override`, dynamic dispatch | 4 |
| Describe abilities, hide details | contract vs implementation | `abstract class`, `interface` | 5 |
| Share class-level things | one counter, constants, identity | `static`, `final`, `equals` | 6 |

## 3. The big picture
```
            Vehicle (blueprint / abstract)
            - name, fuel        <- encapsulated (private)
            - start()           <- overridden (polymorphism)
            - howItMoves()      <- abstract (abstraction)
                  ^
        extends   |   extends            <- inheritance
     +------------+------------+
   Car                       Truck
   (its own boot)            (its own load)

   build with `new` -> constructor sets up state
   static count / final constants belong to the whole factory
```

## 4. Project files
```
Step1_ClassObjectConstructor.java  (NEW FILE)
Step2_Encapsulation.java           (NEW FILE)
Step3_Inheritance.java             (NEW FILE)
Step4_Polymorphism.java            (NEW FILE)
Step5_Abstraction.java             (NEW FILE)
Step6_TheGlue.java                 (NEW FILE)
```

---

# STEP 1 — Class, Object, Constructor

### Concept (simple)
A class is a blueprint; an object is a real thing built from it with `new`. A
constructor runs once at build time to set the starting state. `this.x` means
"this object's x". Overloaded constructors give more than one way to build; chain
them with `this(...)` so setup logic lives in one place.

### Code — `Step1_ClassObjectConstructor.java` (NEW FILE)
```java
static class Vehicle {
    String name; int fuel;
    Vehicle(String name, int fuel) { this.name = name; this.fuel = fuel; }
    Vehicle(String name) { this(name, 0); }   // overload -> reuse
}
Vehicle car = new Vehicle("Car", 50);
```

### How to test
`java Step1_ClassObjectConstructor.java` → `Car has 50 litres`, `Bike has 0 litres`.

### Interview summary
"A constructor sets an object's initial state. Overloaded constructors chain with
`this(...)`, so validation stays in one place."

---

# STEP 2 — Encapsulation (Pillar 1)

### Concept (simple)
Make fields `private` so nobody sets bad values. Expose safe methods that hold
the rules. Read with a getter; change with a guarded method. The fuel-positive
rule lives in exactly one place.

### Code — `Step2_Encapsulation.java` (NEW FILE)
```java
private int fuel;
public int getFuel() { return fuel; }
public void addFuel(int litres) {
    if (litres <= 0) throw new IllegalArgumentException("fuel to add must be positive");
    fuel += litres;
}
```

### How to test
`java Step2_Encapsulation.java` → 50, then 10, then `blocked : fuel to add must be positive`.

### Interview summary
"Encapsulation hides state behind methods so invariants can't be broken from
outside. Private fields plus guarded setters give one source of truth for rules."

---

# STEP 3 — Inheritance (Pillar 2)

### Concept (simple)
`class Car extends Vehicle` = "Car is a Vehicle". The child reuses the parent's
fields/methods and adds its own. `super(...)` runs the parent constructor;
`protected` is visible to children.

### Code — `Step3_Inheritance.java` (NEW FILE)
```java
static class Car extends Vehicle {
    int bootLitres;
    Car(String name, int bootLitres) { super(name, 4); this.bootLitres = bootLitres; }
}
```

### How to test
`java Step3_Inheritance.java` → both honk (inherited), `car wheels : 4`, `truck wheels : 6`.

### Interview summary
"Inheritance models an is-a relationship and shares code. `super(...)` runs the
parent setup. I use it only when the subtype truly is the supertype."

---

# STEP 4 — Polymorphism (Pillar 3)

### Concept (simple)
One call, many behaviours. A child overrides a parent method; Java picks the real
object's version at run time (dynamic dispatch). A `Vehicle[]` of mixed children
all respond to `start()` correctly. Overloading (same name, different parameters)
is the compile-time cousin.

### Code — `Step4_Polymorphism.java` (NEW FILE)
```java
@Override void start() { System.out.println(name + " powers up silently"); }
for (Vehicle v : fleet) v.start();   // each runs its own version
```

### How to test
`java Step4_Polymorphism.java` → `Tesla powers up silently`, `Harley roars to life`.

### Interview summary
"Overriding gives runtime polymorphism via dynamic dispatch; overloading is
compile-time, chosen by argument types. Coding to the parent type lets me add new
subtypes without changing callers."

---

# STEP 5 — Abstraction (Pillar 4)

### Concept (simple)
Say what, hide how. An abstract class is a half-built blueprint: shared code plus
unfinished `abstract` methods children must implement. An interface is a pure
contract. A class extends one class but implements many interfaces.

### Code — `Step5_Abstraction.java` (NEW FILE)
```java
abstract static class Vehicle {
    void describe() { System.out.println(name + " moves by: " + howItMoves()); }
    abstract String howItMoves();           // children must fill this in
}
interface Chargeable { void charge(); }
class ElectricCar extends Vehicle implements Chargeable { ... }
```

### How to test
`java Step5_Abstraction.java` → reports how each moves, `Leaf is charging...`, `petrol is Chargeable? false`.

### Interview summary
"Abstraction exposes intent, hides implementation. Abstract class when subtypes
share state/code; interface when I only need a capability — and a class can
implement many interfaces."

---

# STEP 6 — The glue (static, final, Object methods)

### Concept (simple)
`static` belongs to the class and is shared by all objects (a build counter).
`final` is set-once / no-override (constants, fixed fields). `toString` controls
printing; `equals`+`hashCode` define when two objects are the same.

### Code — `Step6_TheGlue.java` (NEW FILE)
```java
static int built = 0;                 // shared by all objects
final String vin;                     // set once per object
static final int MAX_WHEELS = 18;     // class constant
@Override public boolean equals(Object o) { ... same vin ... }
@Override public int hashCode() { return Objects.hash(vin); }
```

### How to test
`java Step6_TheGlue.java` → `built so far: 3`, `a equals aAgain? true`.

### Interview summary
"`static` is class-level state/behaviour; `final` locks a value or blocks
overriding. Override `equals` and `hashCode` together so objects work correctly
in sets and maps."

---

## How to run everything
```bash
java Step1_ClassObjectConstructor.java
java Step2_Encapsulation.java
java Step3_Inheritance.java
java Step4_Polymorphism.java
java Step5_Abstraction.java
java Step6_TheGlue.java
```

## Cheat sheet (one line per tool)
| Tool | What it does |
|------|--------------|
| `class` | a blueprint for objects |
| `new` | builds an object and runs its constructor |
| constructor | sets the object's starting state |
| `this` | the current object (`this.x` = its field x) |
| `this(...)` | call another constructor in the same class |
| `private` | hide a field/method (Pillar 1: encapsulation) |
| getter/setter | safe read / guarded write of private data |
| `extends` | inherit from a parent class (Pillar 2) |
| `super(...)` / `super.m()` | call parent constructor / parent method |
| `protected` | visible to the class and its children |
| `@Override` | replace a parent method (Pillar 3: polymorphism) |
| dynamic dispatch | Java picks the real object's method at run time |
| overloading | same name, different parameters (compile-time) |
| `abstract class` | half-built blueprint with unfinished methods (Pillar 4) |
| `interface` | a pure contract of abilities |
| `implements` | promise to fulfil an interface |
| `static` | belongs to the class, shared by all objects |
| `final` | set-once value / no override / no subclass |
| `toString` | how an object prints |
| `equals` + `hashCode` | when two objects count as the same |

## Where to go next
1. **Composition over inheritance** — "has-a" vs "is-a", and when to prefer it.
2. **Interfaces with `default` methods** — add behaviour to a contract.
3. **`enum`** — a fixed set of typed constants (a special class).
4. **`record`** — a short way to write immutable data classes.
5. The **interview pack** of this topic — all four pillars in a payment gateway.
