# 🚗 Vehicle Factory — Java OOP (Basic) — Start Here

Learn the **four pillars of Object-Oriented Programming** (OOP) plus
**constructors** and the surrounding glue, using one picture: a **vehicle
factory**. Blueprints, real vehicles, a sealed fuel tank, cars and trucks, and a
"start" button that behaves differently per vehicle.

OOP = a way of organising code around **objects** (things that bundle data +
behaviour) instead of loose functions.

## What you need on the other system
1. **Java 16+** (tested on Java 17; uses `instanceof` pattern + records elsewhere).
   Check with: `java -version`
   - **No compiler needed.** Every file runs with `java File.java`.
   - Full JDK (`javac`) only if you want to compile: Ubuntu/Debian
     `sudo apt install default-jdk`, Mac `brew install openjdk`,
     Windows: Temurin from https://adoptium.net
2. Any text editor.

## What's in this folder
```
oop-basic/
├── README.md                          you are here
├── GUIDE.md                           full lesson + cheat sheet
├── Step1_ClassObjectConstructor.java  class, object, constructor, this, overloading
├── Step2_Encapsulation.java           PILLAR 1: private fields + guarded methods
├── Step3_Inheritance.java             PILLAR 2: extends, super, protected
├── Step4_Polymorphism.java            PILLAR 3: override, dynamic dispatch, overload
├── Step5_Abstraction.java             PILLAR 4: abstract class + interface
├── Step6_TheGlue.java                 static, final, toString/equals/hashCode
└── practice/
    ├── PRACTICE.md
    └── Step*_Practice.java            fill-in-the-blank versions
```

## How to learn (suggested order)
1. Read **GUIDE.md** top to bottom.
2. Run each finished file and match the output.
3. Practice: fill in the `practice/` blanks; peek at the finished file when stuck.

## How to run
```bash
java Step1_ClassObjectConstructor.java
java Step2_Encapsulation.java
java Step3_Inheritance.java
java Step4_Polymorphism.java
java Step5_Abstraction.java
java Step6_TheGlue.java
```

## Quick map: step → concept → tool
| Step | Concept | Tool |
|------|---------|------|
| 1 | Blueprint vs real thing; set up state | `class`, `new`, constructor, `this` |
| 2 | Pillar 1: hide and guard data | `private`, getters, guarded setters |
| 3 | Pillar 2: build on an existing class | `extends`, `super`, `protected` |
| 4 | Pillar 3: one call, many behaviours | `@Override`, dynamic dispatch, overloading |
| 5 | Pillar 4: say what, hide how | `abstract class`, `interface` |
| 6 | Class-level glue | `static`, `final`, `toString`/`equals`/`hashCode` |
