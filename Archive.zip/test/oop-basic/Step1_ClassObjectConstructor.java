// STEP 1 — Class, Object, and Constructor
// Analogy: a VEHICLE FACTORY.
//   - A CLASS is the blueprint (the design on paper).
//   - An OBJECT is a real vehicle built from that blueprint.
//   - A CONSTRUCTOR is the build line: it runs once when a vehicle is made
//     and sets up its starting state (name, fuel).
//
// Run with:  java Step1_ClassObjectConstructor.java

public class Step1_ClassObjectConstructor {

    // The blueprint. Every Vehicle built from it HAS a name and a fuel amount.
    static class Vehicle {
        String name;
        int fuel;

        // Constructor: same name as the class, no return type.
        // It runs when you write `new Vehicle(...)`.
        Vehicle(String name, int fuel) {
            this.name = name;   // `this` = the object being built right now
            this.fuel = fuel;
        }

        // Constructor OVERLOADING: a second, shorter way to build one.
        // It calls the first constructor with a default fuel of 0.
        Vehicle(String name) {
            this(name, 0);      // `this(...)` = call the other constructor
        }

        void describe() {
            System.out.println(name + " has " + fuel + " litres of fuel");
        }
    }

    public static void main(String[] args) {
        // `new` builds an OBJECT from the blueprint and runs the constructor.
        Vehicle car = new Vehicle("Car", 50);
        Vehicle bike = new Vehicle("Bike");     // uses the overloaded constructor

        car.describe();     // Car has 50 litres of fuel
        bike.describe();    // Bike has 0 litres of fuel

        // Two objects, one blueprint. They have separate state.
        System.out.println("car and bike are different objects: " + (car != bike));
    }
}
