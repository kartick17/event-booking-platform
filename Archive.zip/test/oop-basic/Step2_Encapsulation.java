// STEP 2 — Encapsulation (PILLAR 1): hide the data, guard it with methods
// Analogy: the FUEL TANK is sealed inside the vehicle. You can't reach in and
//   set it to a silly value (like -100). You go through the fuel cap: addFuel().
//   "private" = locked inside. Public methods = the only safe way in and out.
//
// Run with:  java Step2_Encapsulation.java

public class Step2_Encapsulation {

    static class Vehicle {
        private String name;     // private = hidden from the outside world
        private int fuel;        // nobody can set this directly

        Vehicle(String name, int fuel) {
            this.name = name;
            this.fuel = Math.max(0, fuel);   // guard even at build time
        }

        // A "getter": safe read-only view of the hidden data.
        public int getFuel() {
            return fuel;
        }

        public String getName() {
            return name;
        }

        // A guarded way to change state. The rule lives in ONE place.
        public void addFuel(int litres) {
            if (litres <= 0) {
                throw new IllegalArgumentException("fuel to add must be positive");
            }
            fuel += litres;
        }

        public void drive(int litres) {
            if (litres > fuel) {
                throw new IllegalStateException("not enough fuel");
            }
            fuel -= litres;
        }
    }

    public static void main(String[] args) {
        Vehicle car = new Vehicle("Car", 20);
        System.out.println(car.getName() + " starts with " + car.getFuel() + " litres");

        car.addFuel(30);
        System.out.println("after refuel : " + car.getFuel());   // 50

        car.drive(40);
        System.out.println("after a trip : " + car.getFuel());   // 10

        // The rules can't be broken from outside:
        try {
            car.addFuel(-5);            // blocked
        } catch (IllegalArgumentException e) {
            System.out.println("blocked   : " + e.getMessage());
        }
        // car.fuel = -100;   // <-- would NOT compile: fuel is private
    }
}
