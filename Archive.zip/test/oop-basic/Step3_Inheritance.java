// STEP 3 — Inheritance (PILLAR 2): build a new class on top of an old one
// Analogy: a Car and a Truck are both Vehicles. They SHARE the common parts
//   (name, fuel, drive) and ADD their own. "extends" = "is a kind of".
//   "super" = talk to the parent (its constructor or its methods).
//
// Run with:  java Step3_Inheritance.java

public class Step3_Inheritance {

    // The PARENT class holds what every vehicle shares.
    static class Vehicle {
        protected String name;     // protected = visible to child classes
        protected int wheels;

        Vehicle(String name, int wheels) {
            this.name = name;
            this.wheels = wheels;
        }

        void honk() {
            System.out.println(name + " says: beep!");
        }
    }

    // A CHILD class. It IS a Vehicle, plus a boot size.
    static class Car extends Vehicle {
        int bootLitres;

        Car(String name, int bootLitres) {
            super(name, 4);             // call the parent constructor first
            this.bootLitres = bootLitres;
        }

        void openBoot() {
            System.out.println(name + " opens a " + bootLitres + "L boot");
        }
    }

    // Another child. Reuses everything in Vehicle, adds load capacity.
    static class Truck extends Vehicle {
        int loadTonnes;

        Truck(String name, int loadTonnes) {
            super(name, 6);
            this.loadTonnes = loadTonnes;
        }

        void load() {
            System.out.println(name + " carries " + loadTonnes + " tonnes");
        }
    }

    public static void main(String[] args) {
        Car car = new Car("Sedan", 400);
        Truck truck = new Truck("Lorry", 10);

        car.honk();        // inherited from Vehicle
        car.openBoot();    // Car's own
        truck.honk();      // inherited
        truck.load();      // Truck's own

        System.out.println("car wheels   : " + car.wheels);   // 4 (set via super)
        System.out.println("truck wheels : " + truck.wheels); // 6
    }
}
