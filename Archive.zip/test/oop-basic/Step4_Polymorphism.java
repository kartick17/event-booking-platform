// STEP 4 — Polymorphism (PILLAR 3): one button, many behaviours
// Analogy: press "start" on any vehicle. A car cranks, an electric car hums,
//   a bike kicks. SAME call, DIFFERENT result depending on the real object.
//   - OVERRIDING: a child gives its own version of a parent method.
//   - Dynamic dispatch: Java picks the version from the REAL object at run time.
//   - OVERLOADING (bonus): same method name, different parameters.
//
// Run with:  java Step4_Polymorphism.java

public class Step4_Polymorphism {

    static class Vehicle {
        String name;
        Vehicle(String name) { this.name = name; }

        // The default behaviour. Children can replace it.
        void start() {
            System.out.println(name + " starts");
        }
    }

    static class ElectricCar extends Vehicle {
        ElectricCar(String name) { super(name); }

        @Override                       // tells Java + readers: this replaces the parent
        void start() {
            System.out.println(name + " powers up silently");
        }
    }

    static class Motorbike extends Vehicle {
        Motorbike(String name) { super(name); }

        @Override
        void start() {
            System.out.println(name + " roars to life");
        }
    }

    // OVERLOADING: same name, different parameter lists. Picked at COMPILE time.
    static void refuel(Vehicle v)            { System.out.println("refuel " + v.name); }
    static void refuel(Vehicle v, int extra) { System.out.println("refuel " + v.name + " +" + extra); }

    public static void main(String[] args) {
        // One array typed as the PARENT, holding different children.
        Vehicle[] fleet = {
            new Vehicle("Generic"),
            new ElectricCar("Tesla"),
            new Motorbike("Harley")
        };

        // Same call v.start() — each object runs its OWN version.
        for (Vehicle v : fleet) {
            v.start();
        }

        System.out.println("---");
        refuel(fleet[0]);        // picks the 1-arg version
        refuel(fleet[0], 10);    // picks the 2-arg version
    }
}
