// STEP 5 — Abstraction (PILLAR 4): say WHAT, hide HOW
// Analogy: you drive with a pedal and wheel. You don't touch the engine.
//   The pedal is the "interface" — a promise of what you can do, not how.
//   - ABSTRACT CLASS: a half-built blueprint. It can hold shared code AND
//     leave some methods unfinished (abstract) for children to fill in.
//   - INTERFACE: a pure contract — a list of abilities, no state, no build.
//
// Run with:  java Step5_Abstraction.java

public class Step5_Abstraction {

    // You can never do `new Vehicle()` — it's abstract (half-built).
    abstract static class Vehicle {
        protected String name;
        Vehicle(String name) { this.name = name; }

        // Shared, finished code. Every vehicle gets this for free.
        void describe() {
            System.out.println(name + " moves by: " + howItMoves());
        }

        // UNFINISHED: each child MUST provide its own answer.
        abstract String howItMoves();
    }

    // A pure contract: "anything Chargeable can be charged".
    interface Chargeable {
        void charge();
    }

    static class PetrolCar extends Vehicle {
        PetrolCar(String name) { super(name); }
        @Override String howItMoves() { return "burning petrol"; }
    }

    // A class can extend ONE class and implement MANY interfaces.
    static class ElectricCar extends Vehicle implements Chargeable {
        ElectricCar(String name) { super(name); }
        @Override String howItMoves() { return "an electric motor"; }
        @Override public void charge() { System.out.println(name + " is charging..."); }
    }

    public static void main(String[] args) {
        Vehicle petrol = new PetrolCar("Civic");
        Vehicle electric = new ElectricCar("Leaf");

        petrol.describe();      // uses shared describe() + its own howItMoves()
        electric.describe();

        // Only things that promised Chargeable can be charged.
        if (electric instanceof Chargeable c) {   // pattern check
            c.charge();
        }
        System.out.println("petrol is Chargeable? " + (petrol instanceof Chargeable));
    }
}
