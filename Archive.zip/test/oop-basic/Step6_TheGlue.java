// STEP 6 — The glue: static, final, and the Object methods
// Analogy: things that belong to the WHOLE FACTORY, not one vehicle.
//   - static  : shared by every object (e.g. a count of vehicles built).
//   - final   : can't change (a constant) or can't be overridden/extended.
//   - toString/equals: how an object prints and how two are compared.
//
// Run with:  java Step6_TheGlue.java

import java.util.Objects;

public class Step6_TheGlue {

    static class Vehicle {
        // static field: ONE copy shared by all vehicles (the factory's counter).
        static int built = 0;

        // final field: set once, never changes. A per-object constant.
        final String vin;        // vehicle id number
        String name;

        // static final: a true constant for the whole class.
        static final int MAX_WHEELS = 18;

        Vehicle(String vin, String name) {
            this.vin = vin;
            this.name = name;
            built++;             // every build bumps the shared counter
        }

        // static method: called on the class, not an object.
        static int howManyBuilt() {
            return built;
        }

        // toString: what gets printed instead of "Vehicle@1a2b3c".
        @Override
        public String toString() {
            return "Vehicle{vin=" + vin + ", name=" + name + "}";
        }

        // equals + hashCode: two vehicles are "equal" if same VIN.
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Vehicle other)) return false;
            return vin.equals(other.vin);
        }

        @Override
        public int hashCode() {
            return Objects.hash(vin);
        }
    }

    public static void main(String[] args) {
        Vehicle a = new Vehicle("V1", "Car");
        Vehicle b = new Vehicle("V2", "Truck");
        Vehicle aAgain = new Vehicle("V1", "Car");

        System.out.println("printed  : " + a);                  // uses toString
        System.out.println("built so far: " + Vehicle.howManyBuilt());  // 3 (static)
        System.out.println("max wheels : " + Vehicle.MAX_WHEELS);       // constant

        System.out.println("a equals b?      " + a.equals(b));      // false
        System.out.println("a equals aAgain? " + a.equals(aAgain)); // true (same VIN)

        // a.vin = "V9";   // <-- would NOT compile: vin is final
    }
}
