# 🚗 Practice — Fill in the Blanks (Basic OOP)

Each file is a step with the key lines removed and marked `// TODO:`. Fill them
in, then run. Answer key: the matching finished file in the folder above
(`../Step*.java`).

## How to practice
1. Read the matching step in `../GUIDE.md`.
2. Open a practice file, fill every `// TODO`.
3. Run it (no compiler needed):
   ```bash
   java Step1_ClassObjectConstructor_Practice.java
   java Step2_Encapsulation_Practice.java
   java Step3_Inheritance_Practice.java
   java Step4_Polymorphism_Practice.java
   java Step5_Abstraction_Practice.java
   java Step6_TheGlue_Practice.java
   ```
4. Stuck? Compare with `../Step*.java`.

## The topics to read (in order)
1. **Step 1** → class/object/constructor → build objects and set state.
2. **Step 2** → encapsulation → hide fields, guard with methods.
3. **Step 3** → inheritance → `extends` + `super`.
4. **Step 4** → polymorphism → override + dynamic dispatch.
5. **Step 5** → abstraction → abstract class + interface.
6. **Step 6** → static / final / equals → class-level glue.

## Self-check: did it work?
| Step | What correct output looks like |
|------|--------------------------------|
| 1 | `Car has 50 litres of fuel`, `Bike has 0 litres of fuel` |
| 2 | refuel to 50, drive to 10, then a "blocked" message |
| 3 | both honk; `car wheels : 4`, `truck wheels : 6` |
| 4 | `Tesla powers up silently`, `Harley roars to life` |
| 5 | how each moves; `Leaf is charging...` |
| 6 | `built so far: 3`, `a equals aAgain? true` |
