// PRACTICE — STEP 1: Class, Object, Constructor
// Topic: class, new, constructor, this, constructor overloading
// Goal: build vehicles and set their starting state.
// Fill in every // TODO. Answer key: ../Step1_ClassObjectConstructor.java
//
// Run when done:  java Step1_ClassObjectConstructor_Practice.java

public class Step1_ClassObjectConstructor_Practice {

    static class Vehicle {
        String name;
        int fuel;

        // TODO: write the constructor. Take (String name, int fuel) and assign
        //       them to this.name and this.fuel.
        // YOUR CODE HERE
        Vehicle(String name, int fuel) {
            // TODO: this.name = name;
            // TODO: this.fuel = fuel;
        }

        // TODO: add an overloaded constructor Vehicle(String name) that calls
        //       the constructor above with fuel = 0 using this(name, 0).
        // YOUR CODE HERE

        void describe() {
            System.out.println(name + " has " + fuel + " litres of fuel");
        }
    }

    public static void main(String[] args) {
        Vehicle car = new Vehicle("Car", 50);
        // TODO: build a bike with just the name (uses the overloaded constructor).
        // Vehicle bike = new Vehicle("Bike");

        car.describe();          // expect: Car has 50 litres of fuel
        // bike.describe();      // expect: Bike has 0 litres of fuel
    }
}
