// PRACTICE — STEP 2: Encapsulation (Pillar 1)
// Topic: private fields, getters, guarded setters
// Goal: hide fuel and only let it change through safe methods.
// Fill in every // TODO. Answer key: ../Step2_Encapsulation.java
//
// Run when done:  java Step2_Encapsulation_Practice.java

public class Step2_Encapsulation_Practice {

    static class Vehicle {
        // TODO: make these two fields private.
        String name;          // TODO: private String name;
        int fuel;             // TODO: private int fuel;

        Vehicle(String name, int fuel) {
            this.name = name;
            this.fuel = Math.max(0, fuel);
        }

        // TODO: write a getter getFuel() that returns fuel.
        // YOUR CODE HERE
        public int getFuel() {
            return 0;   // TODO: return fuel;
        }

        // TODO: in addFuel, reject litres <= 0 with IllegalArgumentException,
        //       otherwise add to fuel.
        public void addFuel(int litres) {
            // TODO: if (litres <= 0) throw new IllegalArgumentException("fuel to add must be positive");
            // TODO: fuel += litres;
        }
    }

    public static void main(String[] args) {
        Vehicle car = new Vehicle("Car", 20);
        car.addFuel(30);
        System.out.println("fuel now : " + car.getFuel());   // expect 50
        try {
            car.addFuel(-5);
            System.out.println("NOT blocked (fix addFuel)");
        } catch (IllegalArgumentException e) {
            System.out.println("blocked  : " + e.getMessage());
        }
    }
}
