// PRACTICE — STEP 3: Inheritance (Pillar 2)
// Topic: extends, super, protected
// Goal: make Car a kind of Vehicle and reuse its parts.
// Fill in every // TODO. Answer key: ../Step3_Inheritance.java
//
// Run when done:  java Step3_Inheritance_Practice.java
//
// NOTE: this file will NOT compile until you add `extends Vehicle` — that IS
// the exercise. Once Car extends Vehicle, the inherited honk()/wheels appear.

public class Step3_Inheritance_Practice {

    static class Vehicle {
        protected String name;
        protected int wheels;

        Vehicle(String name, int wheels) {
            this.name = name;
            this.wheels = wheels;
        }

        void honk() {
            System.out.println(name + " says: beep!");
        }
    }

    // TODO: make Car a child of Vehicle using `extends`.
    static class Car /* TODO: extends Vehicle */ {
        int bootLitres;

        Car(String name, int bootLitres) {
            // TODO: call the parent constructor with super(name, 4);
            // YOUR CODE HERE
            this.bootLitres = bootLitres;
        }

        void openBoot() {
            // TODO: print  name + " opens a " + bootLitres + "L boot"
            // (name is inherited from Vehicle once `extends` is added)
        }
    }

    public static void main(String[] args) {
        Car car = new Car("Sedan", 400);
        car.honk();        // expect: Sedan says: beep!   (inherited)
        car.openBoot();    // expect: Sedan opens a 400L boot
        System.out.println("car wheels : " + car.wheels);  // expect 4
    }
}
