// PRACTICE — STEP 4: Polymorphism (Pillar 3)
// Topic: overriding, dynamic dispatch, overloading
// Goal: make each vehicle start in its own way.
// Fill in every // TODO. Answer key: ../Step4_Polymorphism.java
//
// Run when done:  java Step4_Polymorphism_Practice.java
// (This compiles and runs as-given — but every vehicle prints the SAME line
//  until you override start() in the children.)

public class Step4_Polymorphism_Practice {

    static class Vehicle {
        String name;
        Vehicle(String name) { this.name = name; }
        void start() {
            System.out.println(name + " starts");
        }
    }

    static class ElectricCar extends Vehicle {
        ElectricCar(String name) { super(name); }
        // TODO: override start() to print  name + " powers up silently"
        // Hint: add @Override above a new void start() { ... }
        // YOUR CODE HERE
    }

    static class Motorbike extends Vehicle {
        Motorbike(String name) { super(name); }
        // TODO: override start() to print  name + " roars to life"
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        Vehicle[] fleet = {
            new Vehicle("Generic"),
            new ElectricCar("Tesla"),
            new Motorbike("Harley")
        };
        for (Vehicle v : fleet) {
            v.start();   // each should print its OWN line once you override
        }
        // expect: Generic starts / Tesla powers up silently / Harley roars to life
    }
}
