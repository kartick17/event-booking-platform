// PRACTICE — STEP 5: Abstraction (Pillar 4)
// Topic: abstract class, abstract method, interface, implements
// Goal: each car must say HOW it moves; electric cars can also charge.
// Fill in every // TODO. Answer key: ../Step5_Abstraction.java
//
// Run when done:  java Step5_Abstraction_Practice.java
//
// NOTE: this file will NOT compile until you implement the abstract method
// howItMoves() in BOTH children — that IS the exercise.

public class Step5_Abstraction_Practice {

    abstract static class Vehicle {
        protected String name;
        Vehicle(String name) { this.name = name; }

        void describe() {
            System.out.println(name + " moves by: " + howItMoves());
        }

        // Unfinished on purpose: each child MUST provide this.
        abstract String howItMoves();
    }

    interface Chargeable {
        void charge();
    }

    static class PetrolCar extends Vehicle {
        PetrolCar(String name) { super(name); }
        // TODO: implement howItMoves() to return "burning petrol"
        // YOUR CODE HERE
    }

    // TODO: also make ElectricCar implement Chargeable.
    static class ElectricCar extends Vehicle /* TODO: implements Chargeable */ {
        ElectricCar(String name) { super(name); }
        // TODO: implement howItMoves() to return "an electric motor"
        // TODO: implement charge() to print  name + " is charging..."
        // YOUR CODE HERE
    }

    public static void main(String[] args) {
        Vehicle petrol = new PetrolCar("Civic");
        Vehicle electric = new ElectricCar("Leaf");
        petrol.describe();     // expect: Civic moves by: burning petrol
        electric.describe();   // expect: Leaf moves by: an electric motor
        if (electric instanceof Chargeable c) {
            c.charge();        // expect: Leaf is charging...
        }
    }
}
