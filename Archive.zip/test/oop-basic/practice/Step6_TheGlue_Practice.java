// PRACTICE — STEP 6: The glue (static, final, Object methods)
// Topic: static field/method, final field, equals + hashCode
// Goal: count vehicles built and compare them by VIN.
// Fill in every // TODO. Answer key: ../Step6_TheGlue.java
//
// Run when done:  java Step6_TheGlue_Practice.java

import java.util.Objects;

public class Step6_TheGlue_Practice {

    static class Vehicle {
        // TODO: make `built` a static int starting at 0 (shared by all objects).
        int built = 0;          // TODO: static int built = 0;

        // TODO: make `vin` final (set once in the constructor).
        String vin;             // TODO: final String vin;
        String name;

        Vehicle(String vin, String name) {
            this.vin = vin;
            this.name = name;
            // TODO: increase the shared counter here:  built++;
        }

        // TODO: make this method static (called on the class, not an object).
        int howManyBuilt() {    // TODO: static int howManyBuilt()
            return built;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Vehicle other)) return false;
            // TODO: two vehicles are equal when they have the same vin.
            return false;       // TODO: return vin.equals(other.vin);
        }

        @Override
        public int hashCode() {
            return Objects.hash(vin);
        }
    }

    public static void main(String[] args) {
        Vehicle a = new Vehicle("V1", "Car");
        Vehicle b = new Vehicle("V2", "Truck");
        Vehicle aAgain = new Vehicle("V1", "Car");

        // After making howManyBuilt static, call it on the class: Vehicle.howManyBuilt()
        System.out.println("built so far    : " + a.howManyBuilt());   // expect 3 once static
        System.out.println("a equals aAgain : " + a.equals(aAgain));   // expect true once fixed
        System.out.println("a equals b      : " + a.equals(b));        // expect false
    }
}
