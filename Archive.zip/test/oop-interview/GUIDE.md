# 💳 Payment Gateway — Full Learning Guide (Interview)

## 1. What is this project?
A small **payment gateway**. It charges and refunds money across several payment
methods (card, UPI, wallet). One realistic domain shows every OOP pillar at
production depth, and each section ends with *why this design beats the
alternatives* — the part interviewers actually probe.

## 2. What you will learn
| Pillar / topic | Plain-English meaning | Tool | Step |
|----------------|----------------------|------|------|
| Encapsulation | data can't go bad — guard it | immutable record + private balance | 1 |
| Inheritance | share a common base | `extends`, `super` | 2 |
| Polymorphism | one call, right behaviour | abstract `pay()` + dynamic dispatch | 3 |
| Abstraction | type vs capability | `abstract class` + `interface` | 4 |
| Constructors | build only valid objects | compact ctor + static factory | 5 |
| The glue | class-level state & identity | `static`, `final`, `equals`/`hashCode` | 6 |

## 3. The big picture
```
        PaymentMethod (abstract)            Refundable (interface)
        - owner (private, final)            - refund(Money)
        - pay(Money)  [abstract]                  ^
              ^                                    |
   extends    |  extends   extends                 | implements (some, not all)
   +----------+--------+--------------+
 CreditCard         UpiPayment       Wallet
 (refundable)       (NOT refundable) (refundable, mutable balance)

   PaymentService.charge(method, amount) -> method.pay(amount)   <- polymorphism
   Money (immutable value object) flows through everything       <- encapsulation
```

## 4. Project files
```
OopRun.java                                  (NEW FILE)  single-file runnable mirror
src/com/payments/model/Money.java            (NEW FILE)  immutable value object
src/com/payments/model/Receipt.java          (NEW FILE)  result record
src/com/payments/method/PaymentMethod.java   (NEW FILE)  abstract base
src/com/payments/method/Refundable.java      (NEW FILE)  capability interface
src/com/payments/method/CreditCard.java      (NEW FILE)
src/com/payments/method/UpiPayment.java      (NEW FILE)
src/com/payments/method/Wallet.java          (NEW FILE)
src/com/payments/service/PaymentService.java (NEW FILE)  polymorphic driver
src/com/payments/Main.java                   (NEW FILE)  packaged entry point
```

---

# STEP 1 — Encapsulation (Pillar 1)

### Concept
`Money` is an immutable value object: a `record` with validated, final fields.
You can't build a negative amount, and arithmetic returns a *new* `Money`. The
`Wallet` shows the mutable side: a `private` balance that only the wallet's own
methods may change, and paying throws if the balance is too low.

### Why this design (vs the alternatives)
| Alternative | Problem | Why this wins |
|-------------|---------|---------------|
| `double amount` everywhere | rounding errors, no currency, no rules | `Money` holds cents + currency + validation |
| public mutable balance | anyone can set it to a bad value | private balance + guarded `pay`/`refund` |
| validate at call sites | rule duplicated, easy to miss | validate once in the constructor |

### Code — `model/Money.java`, `method/Wallet.java`
```java
public record Money(long cents, String currency) {
    public Money { if (cents < 0) throw new IllegalArgumentException("amount < 0"); }
}
private Money balance;                       // Wallet: only methods touch it
public Receipt pay(Money a) { balance = balance.minus(a); ... }
```

### How to test
`java OopRun.java` → wallet goes 50 → 20 → 30, then `blocked : insufficient funds`.

### Interview defense
"I model money as an immutable value object so it's always valid and compares by
value. Mutable state like a wallet balance stays private behind methods that hold
the invariants — no caller can put it in a bad state."

---

# STEP 2 — Inheritance (Pillar 2)

### Concept
`CreditCard`, `UpiPayment`, and `Wallet` all `extend PaymentMethod`. They inherit
the shared `owner` and `type()` and call `super(owner)` to run the base setup.
Each adds only what's special to it.

### Why this design (vs the alternatives)
| Alternative | Problem | Why this wins |
|-------------|---------|---------------|
| copy owner/type into each class | duplication, drift | shared base holds it once |
| one big class with a `kind` flag | giant `if/switch`, hard to extend | one class per type, open to new ones |

### Code — `method/PaymentMethod.java` + subclasses
```java
public abstract class PaymentMethod {
    private final String owner;
    protected PaymentMethod(String owner) { this.owner = Objects.requireNonNull(owner); }
}
public final class CreditCard extends PaymentMethod { CreditCard(...) { super(owner); ... } }
```

### How to test
`java OopRun.java` → each method prints its own charged line.

### Interview defense
"Inheritance shares the common state and contract in `PaymentMethod`. I keep the
base small and use `super(...)` for setup. Where types only share a capability,
not state, I use an interface instead of inheritance."

---

# STEP 3 — Polymorphism (Pillar 3)

### Concept
`PaymentService.charge` takes a `PaymentMethod` and calls `pay()`. Java's dynamic
dispatch runs the *real* object's version — card, UPI, or wallet — with no
`if/else`. Add a new payment type and the service needs zero changes.

### Why this design (vs the alternatives)
| Alternative | Problem | Why this wins |
|-------------|---------|---------------|
| `if (m instanceof CreditCard) ... else if ...` | edit it for every new type | dynamic dispatch picks automatically |
| return codes per type | callers branch on them | one uniform `Receipt` result |

### Code — `service/PaymentService.java`
```java
public Receipt charge(PaymentMethod method, Money amount) {
    processed++;
    return method.pay(amount);     // real type decides at run time
}
```

### How to test
`java OopRun.java` → same loop, three different "charged ... via ..." lines.

### Interview defense
"Coding to the abstract `PaymentMethod` and relying on dynamic dispatch is the
open/closed principle in action: new payment types extend the system without
touching the service. I only fall back to `instanceof` for genuine capability
checks, like refunds."

---

# STEP 4 — Abstraction (Pillar 4)

### Concept
`PaymentMethod` is an `abstract class` — shared state plus an unfinished `pay()`
that subclasses must define. `Refundable` is a separate `interface`: a capability
some methods have and others don't. UPI is a `PaymentMethod` but not
`Refundable`, so the service refuses to refund it.

### Why this design (vs the alternatives)
| Choice | When to use | Why here |
|--------|-------------|----------|
| abstract class | subtypes share state + code | `PaymentMethod` shares `owner`, `type()` |
| interface | a pure capability, many implementers | `Refundable` is just "can refund" |
| put refund on the base | forces every method to refund | wrong — UPI can't; keep it separate |

### Code — `method/PaymentMethod.java`, `method/Refundable.java`
```java
public abstract class PaymentMethod { public abstract Receipt pay(Money amount); }
public interface Refundable { Receipt refund(Money amount); }
if (method instanceof Refundable r) return r.refund(amount);   // capability check
```

### How to test
`java OopRun.java` → `REFUND NOT SUPPORTED` for UPI, refunds for card and wallet.

### Interview defense
"Abstract class models the is-a base with shared state; interface models an
optional capability. Splitting `Refundable` out keeps types that can't refund
honest — the type system, not a runtime flag, says what each method can do."

---

# STEP 5 — Constructors (build only valid objects)

### Concept
Every object is validated at creation. `PaymentMethod` rejects a null owner;
`Money`'s compact constructor rejects negatives. `Money.of(19.99, "USD")` is a
**static factory** — a named constructor that converts dollars to cents, clearer
than `new Money(1999, "USD")`.

### Why this design (vs the alternatives)
| Alternative | Problem | Why this wins |
|-------------|---------|---------------|
| public no-arg + setters | half-built, invalid objects exist | constructor enforces a valid state up front |
| only `new Money(cents,...)` | callers do the ×100 math, get it wrong | `Money.of` names the intent |

### Code — `model/Money.java`
```java
public Money { if (cents < 0) throw new IllegalArgumentException("amount < 0: " + cents); }
public static Money of(double units, String currency) {
    return new Money(Math.round(units * 100), currency);
}
```

### How to test
`java OopRun.java` → `invalid Money blocked : amount < 0: -5`.

### Interview defense
"I validate in the constructor so an object is never in an invalid state, and I
add static factories like `Money.of` for readable construction. That beats no-arg
+ setters, which allow half-built objects."

---

# STEP 6 — The glue (static, final, equals/hashCode/toString)

### Concept
`PaymentService.processed` is `static` — one counter shared across the whole
service. `Money`/`Receipt` fields are `final` (records). The record's value-based
`equals`/`hashCode` make `Money.of(19.99,"USD")` equal to `new Money(1999,"USD")`,
and a custom `toString` prints `19.99 USD`.

### Why this matters
Value equality is what lets money, ids, and keys behave correctly in sets and
maps. Static state is for things that belong to the class, not one object.

### Code — `service/PaymentService.java`, `model/Money.java`
```java
private static int processed = 0;       // class-level state
public static int processedCount() { return processed; }
// record Money -> equals/hashCode by value; toString overridden for currency
```

### How to test
`java OopRun.java` → `Money.of == new Money? true`, `total charges processed: 3`.

### Interview defense
"Records give me correct value equality and immutability for free, which is what
money and ids need. `static` holds class-level state like a counter. I always
keep `equals` and `hashCode` consistent so objects work as map keys and set
members."

---

## How to run everything
**No compiler:**
```bash
java OopRun.java
```
**Packaged (needs javac):**
```bash
javac -d out $(find src -name "*.java")
java -cp out com.payments.Main
```

## Cheat sheet (one line per tool)
| Tool | What it does |
|------|--------------|
| `record Money(...)` | immutable value object: final fields, value equality, toString |
| compact constructor | validate inside a record, so it's never invalid |
| static factory `Money.of` | named, readable construction |
| `private` balance + methods | encapsulation: guard mutable state |
| `abstract class PaymentMethod` | shared base with an unfinished `pay()` |
| `extends` / `super(...)` | inherit the base and run its setup |
| `interface Refundable` | an optional capability, separate from the base type |
| `implements` | declare a class has a capability |
| dynamic dispatch | `method.pay()` runs the real type's version |
| `instanceof Refundable r` | pattern check + bind, for a capability |
| `static` field/method | class-level state/behaviour (the processed counter) |
| `final` | set-once field / no override / no subclass |
| `equals` + `hashCode` | value identity for sets and maps |

## Where to go next
1. **Composition over inheritance** — prefer "has-a" when there's no real is-a.
2. **Sealed classes** (`sealed`/`permits`) — a closed, exhaustive type hierarchy.
3. **`enum` with behaviour** — typed constants that carry methods.
4. **SOLID principles** — especially Liskov substitution and open/closed, shown here.
5. **Generics + OOP** — see the `generics-wrappers-interview` pack for `Repository<T>`.
