// ============================================================================
// OopRun.java — SELF-CONTAINED single-file version (no compiler needed)
// Run with:  java OopRun.java
//
// Real scenario: a PAYMENT GATEWAY. It charges and refunds across different
// payment methods. This one domain shows all four OOP pillars plus constructors
// and the glue, the way you'd defend them in a senior interview:
//
//   - Encapsulation : Money (immutable value object) + Wallet (guarded balance)
//   - Inheritance   : CreditCard / UpiPayment / Wallet  extend  PaymentMethod
//   - Polymorphism  : PaymentService.charge() treats every method the same way
//   - Abstraction   : abstract PaymentMethod + the Refundable interface
//   - Constructors  : validation, static factory (Money.of), required fields
//   - The glue      : static counter, final fields, equals/hashCode/toString
//
// The packaged version under src/com/payments/ is the production shape; this is
// the runnable mirror for a machine that only has `java`.
// ============================================================================

import java.util.List;
import java.util.Objects;

public final class OopRun {

    // ------------------------------------------------------------------ //
    // ENCAPSULATION (immutable value object)
    // Money is a record: final fields, equals/hashCode/toString for free.
    // The compact constructor validates, so a Money can never be invalid.
    // Static factory of(...) is a clear, named way to build from human units.
    // ------------------------------------------------------------------ //
    record Money(long cents, String currency) {
        Money {
            if (cents < 0) throw new IllegalArgumentException("amount < 0: " + cents);
            Objects.requireNonNull(currency, "currency");
        }

        static Money of(double units, String currency) {
            return new Money(Math.round(units * 100), currency);
        }

        Money plus(Money other) {
            sameCurrency(other);
            return new Money(cents + other.cents, currency);
        }

        Money minus(Money other) {
            sameCurrency(other);
            if (other.cents > cents) {
                throw new IllegalStateException("insufficient funds");
            }
            return new Money(cents - other.cents, currency);
        }

        private void sameCurrency(Money other) {
            if (!currency.equals(other.currency)) {
                throw new IllegalArgumentException("currency mismatch: " + currency + " vs " + other.currency);
            }
        }

        @Override
        public String toString() {
            return String.format("%.2f %s", cents / 100.0, currency);
        }
    }

    record Receipt(String method, String action, Money amount) {
        @Override
        public String toString() {
            return action + " " + amount + " via " + method;
        }
    }

    // ------------------------------------------------------------------ //
    // ABSTRACTION + INHERITANCE
    // PaymentMethod is abstract: it holds the shared owner field and forces
    // every concrete method to define pay(). You can never `new PaymentMethod`.
    // Refundable is a separate capability contract — not every method has it.
    // ------------------------------------------------------------------ //
    abstract static class PaymentMethod {
        private final String owner;       // encapsulated, set once

        protected PaymentMethod(String owner) {
            this.owner = Objects.requireNonNull(owner, "owner");
        }

        public String owner() {
            return owner;
        }

        public String type() {
            return getClass().getSimpleName();
        }

        // Abstract: each subclass MUST say how it charges.
        public abstract Receipt pay(Money amount);
    }

    interface Refundable {
        Receipt refund(Money amount);
    }

    // CreditCard: chargeable AND refundable.
    static final class CreditCard extends PaymentMethod implements Refundable {
        private final String last4;

        CreditCard(String owner, String last4) {
            super(owner);
            this.last4 = Objects.requireNonNull(last4, "last4");
        }

        @Override
        public Receipt pay(Money amount) {
            return new Receipt(type() + "(*" + last4 + ")", "charged", amount);
        }

        @Override
        public Receipt refund(Money amount) {
            return new Receipt(type() + "(*" + last4 + ")", "refunded", amount);
        }
    }

    // UpiPayment: chargeable but NOT refundable (does not implement Refundable).
    static final class UpiPayment extends PaymentMethod {
        private final String vpa;

        UpiPayment(String owner, String vpa) {
            super(owner);
            this.vpa = Objects.requireNonNull(vpa, "vpa");
        }

        @Override
        public Receipt pay(Money amount) {
            return new Receipt("UPI(" + vpa + ")", "charged", amount);
        }
    }

    // Wallet: classic ENCAPSULATION — a mutable balance guarded by methods.
    static final class Wallet extends PaymentMethod implements Refundable {
        private Money balance;            // private + mutable; only methods touch it

        Wallet(String owner, Money opening) {
            super(owner);
            this.balance = Objects.requireNonNull(opening, "opening");
        }

        public Money balance() {
            return balance;
        }

        @Override
        public Receipt pay(Money amount) {
            balance = balance.minus(amount);     // throws if insufficient
            return new Receipt("Wallet", "charged", amount);
        }

        @Override
        public Receipt refund(Money amount) {
            balance = balance.plus(amount);
            return new Receipt("Wallet", "refunded", amount);
        }
    }

    // ------------------------------------------------------------------ //
    // POLYMORPHISM (+ the glue: static state)
    // The service codes to the PaymentMethod type. It never asks "which kind?".
    // It refunds only methods that implement Refundable — checked with instanceof.
    // ------------------------------------------------------------------ //
    static final class PaymentService {
        private static int processed = 0;     // static: shared across all calls

        Receipt charge(PaymentMethod method, Money amount) {
            processed++;
            return method.pay(amount);         // dynamic dispatch: real type decides
        }

        Receipt tryRefund(PaymentMethod method, Money amount) {
            if (method instanceof Refundable r) {
                return r.refund(amount);
            }
            return new Receipt(method.type(), "REFUND NOT SUPPORTED", amount);
        }

        static int processedCount() {
            return processed;
        }
    }

    // ------------------------------------------------------------------ //
    // MAIN — prove every pillar works.
    // ------------------------------------------------------------------ //
    public static void main(String[] args) {
        PaymentService service = new PaymentService();

        // One list, three different concrete types (inheritance + abstraction).
        List<PaymentMethod> methods = List.of(
            new CreditCard("Alice", "4242"),
            new UpiPayment("Bob", "bob@upi"),
            new Wallet("Cara", Money.of(100.00, "USD"))
        );

        Money price = Money.of(19.99, "USD");

        System.out.println("== Polymorphic charge (same call, different behaviour) ==");
        for (PaymentMethod m : methods) {
            System.out.println("  " + service.charge(m, price));   // each pays its own way
        }

        System.out.println("\n== Refund only what is Refundable (capability check) ==");
        for (PaymentMethod m : methods) {
            System.out.println("  " + service.tryRefund(m, price)); // UPI is refused
        }

        System.out.println("\n== Encapsulation: Wallet balance changed only via methods ==");
        Wallet wallet = new Wallet("Dan", Money.of(50.00, "USD"));
        System.out.println("  opening   : " + wallet.balance());
        wallet.pay(Money.of(30.00, "USD"));
        System.out.println("  after pay : " + wallet.balance());
        wallet.refund(Money.of(10.00, "USD"));
        System.out.println("  after rfd : " + wallet.balance());
        try {
            wallet.pay(Money.of(999.00, "USD"));     // guarded: can't overspend
        } catch (IllegalStateException e) {
            System.out.println("  blocked   : " + e.getMessage());
        }

        System.out.println("\n== Constructors + value-object glue ==");
        Money a = Money.of(19.99, "USD");
        Money b = new Money(1999, "USD");
        System.out.println("  Money.of == new Money? " + a.equals(b) + "  (record equals by value)");
        System.out.println("  printed Money         : " + a + "  (custom toString)");
        try {
            new Money(-5, "USD");                    // validated constructor
        } catch (IllegalArgumentException e) {
            System.out.println("  invalid Money blocked : " + e.getMessage());
        }

        System.out.println("\n== Static state (the glue) ==");
        System.out.println("  total charges processed: " + PaymentService.processedCount());
    }
}
