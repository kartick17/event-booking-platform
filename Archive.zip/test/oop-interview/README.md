# 💳 Payment Gateway — Java OOP (Interview) — Start Here

The four pillars of OOP plus constructors and the glue, written the way a strong
engineer would for a senior interview: a small **payment gateway** that charges
and refunds across different payment methods, with a "why this design over the
alternatives" note per pillar.

## What you need on the other system
1. **Java 16+** (tested on Java 17; uses `record` and `instanceof` patterns).
   Check with: `java -version`
   - **No compiler needed** for the single-file mirror `OopRun.java`.
   - To compile the packaged `src/` you need `javac` (full JDK):
     Ubuntu/Debian `sudo apt install default-jdk`, Mac `brew install openjdk`,
     Windows: Temurin from https://adoptium.net
2. Any text editor.

## What's in this folder
```
oop-interview/
├── README.md                              you are here
├── GUIDE.md                               full lesson + "why this design" tables
├── OopRun.java                            SELF-CONTAINED single-file version (no compiler)
├── src/com/payments/
│   ├── model/Money.java                   immutable value object (encapsulation)
│   ├── model/Receipt.java                 immutable result record
│   ├── method/PaymentMethod.java          abstract base (abstraction + inheritance)
│   ├── method/Refundable.java             capability interface
│   ├── method/CreditCard.java             chargeable + refundable
│   ├── method/UpiPayment.java             chargeable, NOT refundable
│   ├── method/Wallet.java                 encapsulated mutable balance
│   ├── service/PaymentService.java        polymorphic driver + static state
│   └── Main.java                          packaged entry point
└── practice/
    ├── PRACTICE.md
    ├── PaymentMethod_Practice.java         build the abstract base + a subclass
    └── Money_Practice.java                 build the validated value object
```

## How to learn (suggested order)
1. Read **GUIDE.md** top to bottom (each pillar has a "why this design" table).
2. Run the single-file version and match the output.
3. Read the packaged `src/` to see the production shape.
4. Practice: fill in the `practice/` blanks.

## How to run
**No compiler (works anywhere with `java`):**
```bash
java OopRun.java
```
**Full packaged build (needs `javac`):**
```bash
javac -d out $(find src -name "*.java")
java -cp out com.payments.Main
```

## Quick map: pillar → where it lives → tool
| Pillar / topic | Where | Tool |
|----------------|-------|------|
| Encapsulation | `Money`, `Wallet` | immutable record + private guarded balance |
| Inheritance | `CreditCard`/`UpiPayment`/`Wallet` | `extends PaymentMethod`, `super` |
| Polymorphism | `PaymentService.charge` | abstract `pay()` + dynamic dispatch |
| Abstraction | `PaymentMethod`, `Refundable` | `abstract class` + `interface` |
| Constructors | `Money.of`, validated ctors | static factory + compact constructor |
| Glue | `PaymentService`, `Money` | `static`, `final`, `equals`/`hashCode` |
