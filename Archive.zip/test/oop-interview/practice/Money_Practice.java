// PRACTICE — STEPS 1, 5, 6: encapsulation + constructors + value-object glue
// Topic: record, validated compact constructor, static factory, value equality
// Goal: build a Money value object that can never be invalid.
// Fill in every // TODO. Answer key: ../src/com/payments/model/Money.java
//
// Run when done:  java Money_Practice.java

public class Money_Practice {

    // A record gives final fields + value-based equals/hashCode for free.
    record Money(long cents, String currency) {
        // TODO: in the compact constructor, reject cents < 0 with
        //       IllegalArgumentException("amount < 0: " + cents).
        Money {
            // YOUR CODE HERE
        }

        // TODO: static factory: convert whole units to cents (round units*100).
        //       e.g. of(19.99, "USD") -> new Money(1999, "USD")
        static Money of(double units, String currency) {
            // YOUR CODE HERE
            return new Money(0, currency);   // TODO: fix this
        }

        @Override
        public String toString() {
            return String.format("%.2f %s", cents / 100.0, currency);
        }
    }

    public static void main(String[] args) {
        Money a = Money.of(19.99, "USD");
        Money b = new Money(1999, "USD");

        System.out.println("of == new : " + a.equals(b));   // expect true (value equality)
        System.out.println("printed   : " + a);             // expect 19.99 USD

        try {
            new Money(-5, "USD");
            System.out.println("NOT blocked (fix the constructor)");
        } catch (IllegalArgumentException e) {
            System.out.println("blocked   : " + e.getMessage());   // expect amount < 0: -5
        }
    }
}
