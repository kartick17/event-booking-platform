# 💳 Practice — Fill in the Blanks (Interview OOP)

Two focused drills on the parts interviewers push on: building an abstract base
with a subclass (abstraction + inheritance + polymorphism), and building a
validated immutable value object (encapsulation + constructors). Each file is
self-contained and runs with no compiler.

## How to practice
1. Read the matching steps in `../GUIDE.md`.
2. Open a practice file, fill every `// TODO`.
3. Run it (no compiler needed):
   ```bash
   java PaymentMethod_Practice.java
   java Money_Practice.java
   ```
4. Stuck? Compare with `../OopRun.java` and the `../src/` files.

## The topics to read (in order)
1. **PaymentMethod_Practice** → Steps 2-4 → abstract base, `extends`/`super`, override.
2. **Money_Practice** → Steps 1, 5, 6 → validated record, static factory, value equality.

## Self-check: did it work?
| File | What correct output looks like |
|------|--------------------------------|
| PaymentMethod_Practice | `charged 10.00 USD via Card(*1234)`, refund refused for UPI |
| Money_Practice | `of == new : true`, `printed : 19.99 USD`, `blocked : amount < 0: -5` |
