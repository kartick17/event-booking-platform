// PRACTICE — STEPS 2-4: abstraction + inheritance + polymorphism
// Topic: abstract class, extends/super, abstract method, interface, instanceof
// Goal: build the base PaymentMethod and a Card subtype that can refund.
// Fill in every // TODO. Answer key: ../src/com/payments/method/*.java
//
// Run when done:  java PaymentMethod_Practice.java
//
// NOTE: this file will NOT compile until you implement the abstract pay()
// method in Card — that IS the exercise.

public class PaymentMethod_Practice {

    // Abstraction: the base holds shared state and an UNFINISHED pay().
    abstract static class PaymentMethod {
        private final String owner;
        protected PaymentMethod(String owner) { this.owner = owner; }
        public String owner() { return owner; }
        public String type()  { return getClass().getSimpleName(); }

        // TODO: declare the abstract method:  public abstract String pay(int cents);
        // YOUR CODE HERE
    }

    // A capability contract, separate from the base type.
    interface Refundable {
        String refund(int cents);
    }

    // TODO: make Card extend PaymentMethod AND implement Refundable.
    static final class Card extends PaymentMethod /* TODO: implements Refundable */ {
        private final String last4;

        Card(String owner, String last4) {
            // TODO: call super(owner) to run the base setup.
            super(owner);          // (given) — keep this
            this.last4 = last4;
        }

        // TODO: implement pay(cents) to return  "charged " + cents + " via Card(*"+last4+")"
        // YOUR CODE HERE

        // TODO: implement refund(cents) to return "refunded " + cents + " via Card(*"+last4+")"
        // YOUR CODE HERE
    }

    // Polymorphism: works on the base type; refunds only if Refundable.
    static String charge(PaymentMethod m, int cents) {
        return m.pay(cents);
    }
    static String tryRefund(PaymentMethod m, int cents) {
        if (m instanceof Refundable r) return r.refund(cents);
        return "REFUND NOT SUPPORTED by " + m.type();
    }

    public static void main(String[] args) {
        Card card = new Card("Alice", "1234");
        System.out.println(charge(card, 1000));      // expect: charged 1000 via Card(*1234)
        System.out.println(tryRefund(card, 1000));   // expect: refunded 1000 via Card(*1234)
    }
}
