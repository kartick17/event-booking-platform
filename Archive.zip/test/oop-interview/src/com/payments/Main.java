package com.payments;

import com.payments.method.CreditCard;
import com.payments.method.PaymentMethod;
import com.payments.method.UpiPayment;
import com.payments.method.Wallet;
import com.payments.model.Money;
import com.payments.service.PaymentService;

import java.util.List;

/**
 * Packaged entry point. Mirrors OopRun.java.
 *
 * <p>Build + run (needs the full JDK with javac):
 * <pre>
 *   cd oop-interview
 *   javac -d out $(find src -name "*.java")
 *   java -cp out com.payments.Main
 * </pre>
 * No compiler? Run the single-file mirror: {@code java OopRun.java}
 */
public final class Main {

    public static void main(String[] args) {
        PaymentService service = new PaymentService();

        List<PaymentMethod> methods = List.of(
            new CreditCard("Alice", "4242"),
            new UpiPayment("Bob", "bob@upi"),
            new Wallet("Cara", Money.of(100.00, "USD"))
        );
        Money price = Money.of(19.99, "USD");

        System.out.println("== Polymorphic charge ==");
        for (PaymentMethod m : methods) {
            System.out.println("  " + service.charge(m, price));
        }

        System.out.println("\n== Refund only what is Refundable ==");
        for (PaymentMethod m : methods) {
            System.out.println("  " + service.tryRefund(m, price));
        }

        System.out.println("\n== Encapsulated wallet ==");
        Wallet wallet = new Wallet("Dan", Money.of(50.00, "USD"));
        wallet.pay(Money.of(30.00, "USD"));
        System.out.println("  wallet balance: " + wallet.balance());

        System.out.println("\n== Static state ==");
        System.out.println("  charges processed: " + PaymentService.processedCount());
    }
}
