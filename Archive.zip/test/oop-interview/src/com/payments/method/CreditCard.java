package com.payments.method;

import com.payments.model.Money;
import com.payments.model.Receipt;

import java.util.Objects;

/** A card: chargeable AND refundable. */
public final class CreditCard extends PaymentMethod implements Refundable {

    private final String last4;

    public CreditCard(String owner, String last4) {
        super(owner);
        this.last4 = Objects.requireNonNull(last4, "last4");
    }

    @Override
    public Receipt pay(Money amount) {
        return new Receipt(type() + "(*" + last4 + ")", "charged", amount);
    }

    @Override
    public Receipt refund(Money amount) {
        return new Receipt(type() + "(*" + last4 + ")", "refunded", amount);
    }
}
