package com.payments.method;

import com.payments.model.Money;
import com.payments.model.Receipt;

import java.util.Objects;

/**
 * Base type for every way to pay (abstraction + inheritance).
 *
 * <p>It is {@code abstract}: it holds the shared, encapsulated {@code owner} and
 * forces each concrete method to define {@link #pay(Money)}. You can never create
 * a bare {@code PaymentMethod} — only a CreditCard, UpiPayment, Wallet, etc.
 */
public abstract class PaymentMethod {

    private final String owner;       // encapsulated, set once

    protected PaymentMethod(String owner) {
        this.owner = Objects.requireNonNull(owner, "owner");
    }

    public String owner() {
        return owner;
    }

    public String type() {
        return getClass().getSimpleName();
    }

    /** Each subclass MUST say how it charges. */
    public abstract Receipt pay(Money amount);
}
