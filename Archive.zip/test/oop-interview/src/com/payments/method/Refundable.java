package com.payments.method;

import com.payments.model.Money;
import com.payments.model.Receipt;

/**
 * A capability contract: only methods that can give money back implement this.
 *
 * <p>Kept separate from {@link PaymentMethod} so "can be refunded" is an
 * independent ability — UPI is a PaymentMethod but is NOT Refundable.
 */
public interface Refundable {
    Receipt refund(Money amount);
}
