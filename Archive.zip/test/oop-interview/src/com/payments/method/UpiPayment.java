package com.payments.method;

import com.payments.model.Money;
import com.payments.model.Receipt;

import java.util.Objects;

/** A UPI transfer: chargeable but NOT refundable (does not implement Refundable). */
public final class UpiPayment extends PaymentMethod {

    private final String vpa;

    public UpiPayment(String owner, String vpa) {
        super(owner);
        this.vpa = Objects.requireNonNull(vpa, "vpa");
    }

    @Override
    public Receipt pay(Money amount) {
        return new Receipt("UPI(" + vpa + ")", "charged", amount);
    }
}
