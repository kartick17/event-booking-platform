package com.payments.method;

import com.payments.model.Money;
import com.payments.model.Receipt;

import java.util.Objects;

/**
 * A prepaid wallet: classic encapsulation — a mutable balance that only the
 * wallet's own methods may change. Paying throws if the balance is too low.
 */
public final class Wallet extends PaymentMethod implements Refundable {

    private Money balance;            // private + mutable; guarded by methods

    public Wallet(String owner, Money opening) {
        super(owner);
        this.balance = Objects.requireNonNull(opening, "opening");
    }

    public Money balance() {
        return balance;
    }

    @Override
    public Receipt pay(Money amount) {
        balance = balance.minus(amount);     // throws if insufficient
        return new Receipt("Wallet", "charged", amount);
    }

    @Override
    public Receipt refund(Money amount) {
        balance = balance.plus(amount);
        return new Receipt("Wallet", "refunded", amount);
    }
}
