package com.payments.model;

import java.util.Objects;

/**
 * Immutable money value object (encapsulation done the modern way).
 *
 * <p>A {@code record} gives final fields, value-based {@code equals}/{@code hashCode}
 * and a generated {@code toString} (overridden here for currency formatting). The
 * compact constructor validates, so a {@code Money} can never exist in a bad state.
 * The static factory {@link #of(double, String)} is a named, readable way to build
 * one from human units (dollars) instead of cents.
 */
public record Money(long cents, String currency) {

    public Money {
        if (cents < 0) {
            throw new IllegalArgumentException("amount < 0: " + cents);
        }
        Objects.requireNonNull(currency, "currency");
    }

    public static Money of(double units, String currency) {
        return new Money(Math.round(units * 100), currency);
    }

    public Money plus(Money other) {
        sameCurrency(other);
        return new Money(cents + other.cents, currency);
    }

    public Money minus(Money other) {
        sameCurrency(other);
        if (other.cents > cents) {
            throw new IllegalStateException("insufficient funds");
        }
        return new Money(cents - other.cents, currency);
    }

    private void sameCurrency(Money other) {
        if (!currency.equals(other.currency)) {
            throw new IllegalArgumentException(
                    "currency mismatch: " + currency + " vs " + other.currency);
        }
    }

    @Override
    public String toString() {
        return String.format("%.2f %s", cents / 100.0, currency);
    }
}
