package com.payments.model;

/**
 * Immutable record of one payment action (a charge or a refund).
 */
public record Receipt(String method, String action, Money amount) {

    @Override
    public String toString() {
        return action + " " + amount + " via " + method;
    }
}
