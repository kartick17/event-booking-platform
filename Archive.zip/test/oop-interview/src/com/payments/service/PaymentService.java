package com.payments.service;

import com.payments.method.PaymentMethod;
import com.payments.method.Refundable;
import com.payments.model.Money;
import com.payments.model.Receipt;

/**
 * Drives payments polymorphically.
 *
 * <p>It codes to {@link PaymentMethod} and never asks "which kind is this?".
 * Adding a new payment type needs zero changes here. Refunds go only to methods
 * that implement {@link Refundable}, checked with an {@code instanceof} pattern.
 */
public final class PaymentService {

    private static int processed = 0;     // static: shared across all instances

    public Receipt charge(PaymentMethod method, Money amount) {
        processed++;
        return method.pay(amount);        // dynamic dispatch picks the real method
    }

    public Receipt tryRefund(PaymentMethod method, Money amount) {
        if (method instanceof Refundable r) {
            return r.refund(amount);
        }
        return new Receipt(method.type(), "REFUND NOT SUPPORTED", amount);
    }

    public static int processedCount() {
        return processed;
    }
}
